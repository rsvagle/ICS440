package com.programix.util;

/**
 * Commonly needed utilities for working with Java's Reflection mechanism.
 */
public class ReflectTools extends Object {
	private ReflectTools() {
	}

	/**
	 * Used to lookup and instantiate the specified class using the class's
	 * zero-argument constuctor and to validate that it can be typecast into
	 * the target type.
	 *
	 * @param className the class to lookup and construct
	 * @param targetType the type to check to see if the constructed
	 * object can be cast into.
	 *
	 * @exception ReflectException if the requested class can not
	 * be found, or if it doesn't have a public zero-argument constructor,
	 * or if the constructed object can't be typecast into the target type,
	 * or if either parameter is null.
	 */
	@SuppressWarnings("unchecked")
    public static <T> T construct(
				String className,
				Class<T> targetType
			) throws ReflectException {

		if ( (className == null) || (className.length() < 1) ) {
			throw new ReflectException("className can't be null or a " +
				"zero-length string");
		}

		if ( targetType == null ) {
			throw new ReflectException("targetType can't be null");
		}

		Object obj = null;

		try {
			Class<?> c = Class.forName(className);
			obj = c.newInstance();
		} catch ( ClassNotFoundException x ) {
			throw new ReflectException(
				"class '" + className + "' not found", x);
		} catch ( IllegalAccessException x ) {
			throw new ReflectException(
				"class '" + className +
				"' does not have a public zero-arg construtor", x);
		} catch ( Exception x ) {
			throw new ReflectException(
				"unable to construct '" + className + "'", x);
		}

		checkType(obj, targetType);

		return (T) obj;
	}

	/**
	 * Checks to see if the object pointed to by <tt>obj</tt> is an instance
	 * of the specified target type. If <tt>allowNull</tt> is <tt>true</tt>,
	 * no exception is thrown if <tt>obj</tt> is <tt>null</tt>.
	 */
	public static void checkType(
				Object obj,
				Class<?> targetType,
				boolean allowNull
			) throws ReflectException {

		if ( obj == null ) {
			if ( allowNull ) {
				// nothing to do--it's null and null is permitted
				return;
			} else {
				throw new ReflectException(
					"reference to check type of is null");
			}
		}

		if ( targetType == null ) {
			throw new ReflectException("targetType can't be null");
		}

		if ( targetType.isInstance(obj) == false ) {
			throw new ReflectException("object's type (" +
				obj.getClass().getName() + ") can't be cast into the " +
				"target type (" + targetType.getName() + ")");
		}
	}

	/**
	 * Checks type of obj and throws an exception if it is not the specified
	 * type or if the reference is null.
	 * Calls {@link #checkType(Object, Class, boolean)} with <tt>allowNull</tt>
	 * set to <tt>false</tt>.
	 */
	public static void checkType(Object obj, Class<?> targetType)
			throws ReflectException {

		checkType(obj, targetType, false);
	}

	/**
	 * Used to indicate that something went wrong in one of the
	 * ReflectTools functions. This is a RuntimeException, so it can
	 * be ignored (try/catch no required).
	 */
	public static class ReflectException extends RuntimeException {
		public ReflectException(String msg, Throwable cause) {
			super(msg, cause);
		}

		public ReflectException(String msg) {
			super(msg);
		}
	} // inner ReflectException
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.