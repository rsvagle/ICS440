package com.programix.util;

import java.io.*;
import java.security.*;
import java.util.*;

import com.programix.collections.*;
import com.programix.math.*;

/**
 * All sorts of tools for working with <tt>String</tt>s.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class StringTools extends Object {
    /**
     * A zero-length <tt>String</tt>, that is: <tt>""</tt>.
     * Many of the methods on <tt>StringTools</tt> may return a reference
     * to this exact instance as there is really no need for more than
     * one zero-length string per VM (<tt>String</tt> is immutable after all).
     * Use of this constant can also help improve code readability.
     */
	public static final String ZERO_LEN_STRING = "";

    /**
     * An array of <tt>String</tt> with a zero-slots in the array.
     */
	public static final String[] ZERO_LEN_ARRAY = new String[0];

    /**
     * This {@link Comparator} sorts <tt>String</tt>'s in their
     * normal case-sensitive ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the top.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<String> NULL_FIRST_CASE_SENSITIVE_ASC =
        new NullFirstComparator<String>(new ComparableComparator<String>());

    /**
     * This {@link Comparator} sorts <tt>String</tt>'s in
     * reverse case-sensitive ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the top.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<String> NULL_FIRST_CASE_SENSITIVE_DESC =
        new NullFirstComparator<String>(
            new ReverseComparator<String>(
                new ComparableComparator<String>()));

    /**
     * This {@link Comparator} sorts <tt>String</tt>'s in
     * case-insensitive ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the top.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<String> NULL_FIRST_CASE_INSENSITIVE_ASC =
        new NullFirstComparator<String>(String.CASE_INSENSITIVE_ORDER);

    /**
     * This {@link Comparator} sorts <tt>String</tt>'s in
     * reverse case-insensitive ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the top.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<String> NULL_FIRST_CASE_INSENSITIVE_DESC =
        new NullFirstComparator<String>(
            new ReverseComparator<String>(String.CASE_INSENSITIVE_ORDER));

    /**
     * This {@link Comparator} sorts <tt>String</tt>'s in their
     * normal case-sensitive ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the bottom.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<String> NULL_LAST_CASE_SENSITIVE_ASC =
        new NullLastComparator<String>(new ComparableComparator<String>());

    /**
     * This {@link Comparator} sorts <tt>String</tt>'s in
     * reverse case-sensitive ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the bottom.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<String> NULL_LAST_CASE_SENSITIVE_DESC =
        new NullLastComparator<String>(
            new ReverseComparator<String>(new ComparableComparator<String>()));

    /**
     * This {@link Comparator} sorts <tt>String</tt>'s in
     * case-insensitive ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the bottom.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<String> NULL_LAST_CASE_INSENSITIVE_ASC =
        new NullLastComparator<String>(String.CASE_INSENSITIVE_ORDER);

    /**
     * This {@link Comparator} sorts <tt>String</tt>'s in
     * reverse case-insensitive ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the bottom.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<String> NULL_LAST_CASE_INSENSITIVE_DESC =
        new NullLastComparator<String>(
            new ReverseComparator<String>(String.CASE_INSENSITIVE_ORDER));

    private static final char[] HEX_DIGIT = "0123456789ABCDEF".toCharArray();

    private static final char[] DIGIT_CHAR_SORTED = toSortedCharArray(
        "0123456789");
    private static final char[] HEXDIGIT_CHAR_SORTED = toSortedCharArray(
        "0123456789ABCDEFabcdef");
    private static final char[] ALPHA_CHAR_SORTED = toSortedCharArray(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz");
    private static final char[] ALPHANUMERIC_CHAR_SORTED = toSortedCharArray(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");

    private static final byte[] ZERO_LEN_BYTE_ARRAY = new byte[0];

    private static final char[] ZERO_LEN_CHAR_ARRAY = new char[0];

	// no instances
	private StringTools() {
	}

	/**
	 * Returns <tt>true</tt> if <tt>str</tt> is <tt>null</tt>,
     * a zero-length string, or trims down to a zero-length string.
	 * Equivalent to:
     * <pre>
     * return (str == null) ||
     *        (str.length() == 0) ||
     *        (str.trim().length() == 0);
     * </pre>
	 */
   	public static boolean isEmpty(String str) {
        // Compare to ZERO_LEN_STRING is cheap and may give a faster response
		return str == null || str == ZERO_LEN_STRING ||
               str.length() == 0 || str.trim().length() == 0;
	}

	/**
	 * Returns <tt>true</tt> if <tt>str</tt> is <i>not</i> <tt>null</tt> and
     * points to a <tt>String</tt> that has at least 1 character left
     * <i>after</i> trimming.
	 * Equivalent to:
     * <tt><b>!</b>{@link #isEmpty(String) isEmpty}(str))</tt>.
	 */
   	public static boolean isNotEmpty(String str) {
        // Compare to ZERO_LEN_STRING is cheap and may give a faster response
		return str != null && str != ZERO_LEN_STRING &&
               str.length() != 0 && str.trim().length() != 0;
	}

	/**
	 * Returns <tt>true</tt> if <tt>obj</tt> is <tt>null</tt>,
     * a zero-length string, or if its <tt>toString()</tt> method returns a
     * <tt>String</tt> that trims down to a zero-length string.
	 * Equivalent to (except that <tt>toString()</tt> is not really
     * called twice):
     * <pre>
     * return (obj == null) ||
     *        (obj.toString().length() == 0) ||
     *        (obj.toString().trim().length() == 0);
     * </pre>
	 */
   	public static boolean isEmpty(Object obj) {
        // Compare to ZERO_LEN_STRING is cheap and may give a faster response
		if ( obj == null || obj == ZERO_LEN_STRING ) {
            return true;
        }

        String str = obj.toString();
        return str.length() == 0 || str.trim().length() == 0;
	}

	/**
	 * Returns <tt>true</tt> if <tt>obj</tt> is <i>not</i> <tt>null</tt> and
     * its <tt>toString()</tt> methods returns a <tt>String</tt> that has at
     * least 1 character left <i>after</i> trimming.
	 * Equivalent to:
     * <tt><b>!</b>{@link #isEmpty(Object) isEmpty}(obj))</tt>.
	 */
   	public static boolean isNotEmpty(Object obj) {
        return !isEmpty(obj);
	}

   	/**
   	 * @deprecated Use {@link #isEmpty(String)} instead.
   	 */
   	@Deprecated
   	public static boolean isEmptyTrimmed(String str) {
        return isEmpty(str);
   	}

    /**
     * @deprecated Use {@link #isNotEmpty(String)} instead.
     */
   	@Deprecated
   	public static boolean isNotEmptyTrimmed(String str) {
   	    return isNotEmpty(str);
   	}

    /**
     * @deprecated Use {@link #isEmpty(Object)} instead.
     */
   	@Deprecated
   	public static boolean isEmptyTrimmed(Object obj) {
        return isEmpty(obj);
   	}

    /**
     * @deprecated Use {@link #isNotEmpty(Object)} instead.
     */
   	@Deprecated
   	public static boolean isNotEmptyTrimmed(Object obj) {
   	    return isNotEmpty(obj);
   	}

    /**
     * Returns <tt>true</tt> if <tt>str</tt> is <tt>null</tt> or if it is a
     * zero-length string.
     * <i>No</i> trimming of whitespace is done.
     */
    public static boolean isEmptyWithoutTrim(String str) {
        // Compare to ZERO_LEN_STRING is cheap and may give a faster response
        return str == null || str == ZERO_LEN_STRING || str.length() == 0;
    }

    /**
     * Returns <tt>true</tt> if <tt>str</tt> is <i>not</i> <tt>null</tt>
     * and points to a <tt>String</tt> with a length of at least 1 character.
     * <i>No</i> trimming of whitespace is done.
     * Equivalent to: <tt><b>!</b>{@link #isEmptyWithoutTrim(String)
     * isEmptyWithoutTrim}(str)</tt>.
     */
    public static boolean isNotEmptyWithoutTrim(String str) {
        // Compare to ZERO_LEN_STRING is cheap and may give a faster response
        return str != null && str != ZERO_LEN_STRING && str.length() != 0;
    }

    /**
     * Returns <tt>true</tt> if <tt>obj</tt> is <tt>null</tt> or if
     * its <tt>toString()</tt> method returns a zero-length string.
     * <i>No</i> trimming of whitespace is done.
     */
    public static boolean isEmptyWithoutTrim(Object obj) {
        // Compare to ZERO_LEN_STRING is cheap and may give a faster response
        return obj == null || obj == ZERO_LEN_STRING ||
               obj.toString().length() == 0;
    }

    /**
     * Returns <tt>true</tt> if <tt>obj</tt> is <i>not</i> <tt>null</tt>
     * and its <tt>toString()</tt> method returns a <tt>String</tt> with a
     * length of at least 1 character.
     * <i>No</i> trimming of whitespace is done.
     * Equivalent to: <tt><b>!</b>{@link #isEmptyWithoutTrim(Object)
     * isEmptyWithoutTrim}(obj)</tt>.
     */
    public static boolean isNotEmptyWithoutTrim(Object obj) {
        // Compare to ZERO_LEN_STRING is cheap and may give a faster response
        return obj != null && obj != ZERO_LEN_STRING &&
               obj.toString().length() != 0;
    }

    /**
     * Returns <tt>true</tt> if the passed <tt>strList</tt> is <tt>null</tt>,
     * is a zero-length array, or if every <tt>String</tt> in the array
     * is "empty" (as defined by {@link #isEmpty(String)}.
     */
    public static boolean isEmpty(String[] strList) {
        if ( strList == null || strList.length == 0 ) {
            return true;
        }

        for ( int i = 0; i < strList.length; i++ ) {
            if ( isNotEmpty(strList[i]) ) {
                return false;
            }
        }

        return true;
    }


    /**
     * Returns <tt>false</tt> if the passed <tt>strList</tt> is <tt>null</tt>,
     * is a zero-length array, or if every <tt>String</tt> in the array
     * is "empty" (as defined by {@link #isEmpty(String)}.
     * <p>
     * Equivalent to:
     * <pre>
     * return !isEmpty(strList);
     * </pre>
     */
    public static boolean isNotEmpty(String[] strList) {
        return !isEmpty(strList);
    }

	/**
	 * Trims the supplied string, or if <tt>null</tt>, returns a zero-length
	 * string instead of <tt>null</tt>.
     * Returned value is <i>never</i> <tt>null</tt>.
     * When the return value would be a zero-length string, a reference to
     * {@link #ZERO_LEN_STRING} is returned to help reduce the number of
     * zero-length strings floating around the VM.
	 */
	public static String trim(String str) {
		if ( str == null || str == ZERO_LEN_STRING || str.length() == 0 ) {
            return ZERO_LEN_STRING;
        }

        String s = str.trim();

        // If it trims down to a zero-length string, then return this
        // shared (immutable) instance to facilitate garbage collection
        // (no need to have hundreds of zero-length string objects out there!).
		return (s.length() == 0) ? ZERO_LEN_STRING : s;
	}

	/**
	 * Trims the <tt>String</tt> returned by the <tt>toString()</tt> method
     * on <tt>obj</tt>, or if <tt>obj</tt> is <tt>null</tt>, returns a
     * zero-length string instead of <tt>null</tt>.
     * Returned value is <i>never</i> <tt>null</tt>.
     * When the return value would be a zero-length string, a reference to
     * {@link #ZERO_LEN_STRING} is returned to help reduce the number of
     * zero-length strings floating around the VM.
	 */
	public static String trim(Object obj) {
        // Compare to ZERO_LEN_STRING is cheap and may give a faster response
        if ( obj == null || obj == ZERO_LEN_STRING ) {
            return ZERO_LEN_STRING;
        }

        return trim(obj.toString());
	}

	/**
	 * Trims the passed string and returns null if the resulting string
	 * has a length of 0. Returns null if the source string is null.
	 * If the trimmed string has a length greater than 0, then the trimmed
	 * string is returned.
	 * @see #blankToNull
	 */
	public static String trimToNull(String str) {
		if ( str == null || str == ZERO_LEN_STRING || str.length() == 0 ) {
            return null;
        }

        String s = str.trim();
		return (s.length() == 0) ? null : s;
	}

    /**
     * Trims the <tt>String</tt> returned by the <tt>toString()</tt> method
     * on <tt>obj</tt>. If <tt>obj</tt> is <tt>null</tt>,
     * a <tt>null</tt> is returned.
     * <tt>null</tt>. If the trimmed <tt>String</tt> has a length of zero,
     * a <tt>null</tt> is returned.
     * Returned value is <i>never</i> zero-length <tt>String</tt>.
     */
    public static String trimToNull(Object obj) {
        // Compare to ZERO_LEN_STRING is cheap and may give a faster response
        if ( obj == null || obj == ZERO_LEN_STRING ) {
            return null;
        }

        return trimToNull(obj.toString());
    }

	/**
	 * If the supplied <tt>String</tt> is <tt>null</tt>, a zero-length string is
	 * returned instead ({@link #ZERO_LEN_STRING}).
     * If not <tt>null</tt>, the string itself is returned unmodified.
	 */
	public static String nullToBlank(String str) {
		return (str == null) ? ZERO_LEN_STRING : str;
	}

	/**
	 * If the supplied <tt>obj</tt> is <tt>null</tt>, a zero-length string is
	 * returned instead ({@link #ZERO_LEN_STRING}).
     * If not <tt>null</tt>, the <tt>toString()</tt> method is invoked on
     * <tt>obj</tt> and that <tt>String</tt> is returned.
	 */
	public static String nullToBlank(Object obj) {
        if ( obj == null ) {
            return ZERO_LEN_STRING;
        } else {
            return obj.toString();
        }
	}

	/**
	 * Returns <tt>null</tt> if the passed <tt>String</tt> is <tt>null</tt>
     * or has a length of 0.
     * Otherwise, the original string is returned unchanged.
	 *
	 * @see #trimToNull
	 */
	public static String blankToNull(String str) {
		if ( str == null || str == ZERO_LEN_STRING || str.length() == 0 ) {
			return null;
		} else {
			return str;
		}
	}

    /**
     * Pads or clips <tt>str</tt> so the the <tt>String</tt> returned is
     * exactly <tt>resultingLength</tt> long. If padding is necessary,
     * spaces are added to the end. If <tt>null</tt> is passed in, it
     * is accepted and treated as a zero-length string.
     */
    public static String padClip(String str, int resultingLength) {
        if ( resultingLength == 0 ) {
            return ZERO_LEN_STRING;
        }

        str = nullToBlank(str);
        int len = str.length();

        if ( len == resultingLength ) {
            return str;
        }

        if ( len >= resultingLength ) {
            return str.substring(0, resultingLength);
        }

        StringBuffer sb = new StringBuffer(resultingLength);
        sb.append(str);

        int padCount = resultingLength - len;
        for ( int i = 0; i < padCount; i++ ) {
            sb.append(' ');
        }

        return sb.toString();
    }

    /**
     * Takes the passed <tt>Collection</tt> of <tt>String</tt>'s and returns
     * a snapshot of it as a <tt>String[]</tt>.
     */
    public static String[] toArray(Collection<String> strings) {
        return strings.toArray(ZERO_LEN_ARRAY);
    }

    /**
     * Compares two strings to see if they are "the same".
     * Returns <tt>true</tt> if <tt>a</tt> is <i>the same </i> as <tt>b</tt>.
     * Specifically, they considered to be the same if <i>any</i> of the
     * following are true:
     * <ul>
     * <li><tt>a == b</tt> (two references to the same object)</li>
     * <li><tt>( a == null ) &amp;&amp; ( b == null )</tt> (both are null)</li>
     * <li><tt>( a != null ) &amp;&amp; ( b != null )
     *         &amp;&amp; ( a.equals(b) == true )</tt></li>
     * </ul>
     *
     * @param a the first String
     * @param b the second String
     *
     * @return <tt>true</tt> if the strings are the same.
     *
     * @see #isDifferent(String, String)
     * @see #isSameIgnoreCase(String, String)
     * @see #isDifferentIgnoreCase(String, String)
     */
    public static boolean isSame(String a, String b) {
        if ( a == b ) {
            // both pointing to same object, OR both are null
            return true;
        } else if ( a == null || b == null ) {
            // one is null and the other is NOT null
            return false;
        } else {
            return a.equals(b);
        }
    }

    /**
     * Compares two strings to see if they are "different".
     * Returns <tt>true</tt> if <tt>a</tt> is <i>different</i> than <tt>b</tt>.
     * Specifically, they considered to be different if <i>any</i> of the
     * following are true:
     * <ul>
     * <li><tt>( a == null ) &amp;&amp; ( b != null )</tt></li>
     * <li><tt>( a != null ) &amp;&amp; ( b == null )</tt></li>
     * <li><tt>( a != null ) &amp;&amp; ( b != null )
     *         &amp;&amp; ( a.equals(b) == false )</tt></li>
     * </ul>
     *
     * @param a the first String
     * @param b the second String
     *
     * @return <tt>true</tt> if the strings are different.
     *
     * @see #isSame(String, String)
     * @see #isSameIgnoreCase(String, String)
     * @see #isDifferentIgnoreCase(String, String)
     */
    public static boolean isDifferent(String a, String b) {
        return !isSame(a, b);
    }

    /**
     * Compares two strings to see if they are "the same" (ignoring
     * any case differences).
     * Returns <tt>true</tt> if <tt>a</tt> is <i>the same </i> as <tt>b</tt>
     * (ignoreing case differences).
     * Specifically, they considered to be the same if <i>any</i> of the
     * following are true:
     * <ul>
     * <li><tt>a == b</tt> (two references to the same object)</li>
     * <li><tt>( a == null ) &amp;&amp; ( b == null )</tt> (both are null)</li>
     * <li><tt>( a != null ) &amp;&amp; ( b != null )
     *         &amp;&amp; ( a.equalsIgnoreCase(b) == true )</tt></li>
     * </ul>
     *
     * @param a the first String
     * @param b the second String
     *
     * @return <tt>true</tt> if the strings are the same
     * (ignoring case differences).
     *
     * @see #isDifferentIgnoreCase(String, String)
     * @see #isSame(String, String)
     * @see #isDifferent(String, String)
     */
    public static boolean isSameIgnoreCase(String a, String b) {
        if ( a == b ) {
            // both pointing to same object, OR both are null
            return true;
        } else if ( a == null || b == null ) {
            // one is null and the other is NOT null
            return false;
        } else {
            return a.equalsIgnoreCase(b);
        }
    }

    /**
     * Compares two strings to see if they are "different"
     * (other than any case differences).
     * Returns <tt>true</tt> if <tt>a</tt> is <i>different</i> than <tt>b</tt>
     * (other than any case differences).
     * Specifically, they considered to be different if <i>any</i> of the
     * following are true:
     * <ul>
     * <li><tt>( a == null ) &amp;&amp; ( b != null )</tt></li>
     * <li><tt>( a != null ) &amp;&amp; ( b == null )</tt></li>
     * <li><tt>( a != null ) &amp;&amp; ( b != null )
     *         &amp;&amp; ( a.equalsIgnoreCase(b) == false )</tt></li>
     * </ul>
     *
     * @param a the first String
     * @param b the second String
     *
     * @return <tt>true</tt> if the strings are different beyond
     * any case differences.
     *
     * @see #isSameIgnoreCase(String, String)
     * @see #isSame(String, String)
     * @see #isDifferent(String, String)
     */
    public static boolean isDifferentIgnoreCase(String a, String b) {
        return !isSameIgnoreCase(a, b);
    }

	/**
	 * Like <tt>String</tt>'s <tt>compareTo</tt>, but <tt>null</tt>
     * is considered "less than" any other string except <tt>null</tt>.
     * If both are <tt>null</tt>, then <tt>0</tt> is returned.
	 * If both are NOT <tt>null</tt>, the result of <tt>s1.compareTo(s2)</tt>
     * is returned.
	 */
	public static int compare(String s1, String s2) {
		if ( s1 == null ) {
			if ( s2 == null ) {
				return 0;
			} else {
				return -1;
			}
		} else {
			if ( s2 == null ) {
				return 1;
			} else {
				return s1.compareTo(s2);
			}
		}
	}

	/**
	 * Does an MD5 hash on the source text, then converts the
	 * 16 bytes to hex. The result is always exactly 32 characters long.
	 */
	public static String hash(String plainText) {
		try {
			byte[] plainBytes = StringTools.trim(plainText).getBytes();

			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] hashBytes = md.digest(plainBytes);
            return toHexString(hashBytes);
		} catch ( Exception x ) {
			throw new RuntimeException("trouble with hash", x);
		}
	}

    /**
     * Converts the passed <tt>byte[]</tt> into a string. The length of the
     * returned <tt>String</tt> is always <tt>(2 * data.length)</tt> [leading
     * zeros are preserved].
     * @param data bytes to convert
     * @return formatted hex string
     * @see #parseHexString
     */
    public static String toHexString(byte[] data) {
        if ( data == null || data.length == 0 ) {
            return ZERO_LEN_STRING;
        }

        char[] ch = new char[data.length * 2];
        for ( int i = 0; i < data.length; i++ ) {
            int msd = ( data[i] & 0x0f0 ) >>> 4;
            int lsd = data[i] & 0x00f;
            ch[i * 2] = HEX_DIGIT[msd];
            ch[(i * 2) + 1] = HEX_DIGIT[lsd];
        }

        return new String(ch);
    }

    /**
     * Converts the string of hex digits into an array of bytes.
     * This method always returns a <tt>byte[]</tt> (never returns
     * <tt>null</tt> and never throws an exception regardless of how poorly
     * the source string is formatted).
     * All characters which are not hex digits are silently ignored
     * (including leading and trailing whitespace&mdash;no need to pre-trim).
     * If the number of hex digits
     * found is an odd number, a leading <tt>0</tt> is automatically prefixed.
     * <i>NOTE: Do <b>NOT</b> include a leading <tt>0x</tt> that you would
     * include in Java source code.</i>
     * <p>Examples:
     * <pre>
     * "3bfe"                   byte[] length is 2
     *                          data[0] = 0x3B;
     *                          data[1] = 0xFE;
     * ---------------------------------------------
     * " 3 B F E "              byte[] length is 2
     *                          data[0] = 0x3B;
     *                          data[1] = 0xFE;
     * ---------------------------------------------
     * "0"                      byte[] length is 1
     *                          data[0] = 0x00;
     * ---------------------------------------------
     * "00"                     byte[] length is 1
     *                          data[0] = 0x00;
     * ---------------------------------------------
     * "1"                      byte[] length is 1
     *                          data[0] = 0x01;
     * ---------------------------------------------
     * "01"                     byte[] length is 1
     *                          data[0] = 0x01;
     * ---------------------------------------------
     * "001"                    byte[] length is 2
     *                          data[0] = 0x00;
     *                          data[1] = 0x01;
     * ---------------------------------------------
     * "777"                    byte[] length is 2
     *                          data[0] = 0x07;
     *                          data[1] = 0x77;
     * ---------------------------------------------
     * "Cafe Babe  "            byte[] length is 4
     *                          data[0] = 0xCA;
     *                          data[1] = 0xFE;
     *                          data[2] = 0xBA;
     *                          data[3] = 0xBE;
     * ---------------------------------------------
     * "   0123456789ABCDEF 0123456789abcdef  "
                  byte[] length is 16
     *    data[ 0] = 0x01;      data[ 8] = 0x01;
     *    data[ 1] = 0x23;      data[ 9] = 0x23;
     *    data[ 2] = 0x45;      data[10] = 0x45;
     *    data[ 3] = 0x67;      data[11] = 0x67;
     *    data[ 4] = 0x89;      data[12] = 0x89;
     *    data[ 5] = 0xAB;      data[13] = 0xAB;
     *    data[ 6] = 0xCD;      data[14] = 0xCD;
     *    data[ 7] = 0xEF;      data[15] = 0xEF;
     * ---------------------------------------------
     * null                     byte[] length is 0
     * ---------------------------------------------
     * ""                       byte[] length is 0
     * ---------------------------------------------
     * "   "                    byte[] length is 0
     * ---------------------------------------------
     * "  !@#$%^()-_+={}[]"     byte[] length is 0
     * ---------------------------------------------
     * " =!= 7 ** F # 2  "      byte[] length is 2
     *                          data[0] = 0x07;
     *                          data[1] = 0xF2;
     * ---------------------------------------------
     * </pre>
     * @param srcStr string to parse (<tt>null</tt> is ok).
     * @return parsed value. The number of bytes returned is always in the
     * range of <tt>0</tt> to <tt>((srcLen + 1) / 2)</tt>. <tt>null</tt> is
     * never returned. The actual number of bytes returned is based on the
     * number of valid hex digits found.
     * @see #toHexString
     */
    public static byte[] parseHexString(String srcStr) {
        if ( isEmpty(srcStr) ) {
            return ZERO_LEN_BYTE_ARRAY;
        }

        int srcLen = srcStr.length();
        byte[] dst = new byte[(srcLen + 1) / 2];
        int dstPtr = dst.length - 1;
        boolean doLowerBits = true;

        for ( int i = srcLen - 1; i >= 0; i-- ) {
            char ch = srcStr.charAt(i);

            int val = 0;
            if ( '0' <= ch && ch <= '9' ) {
                val = (int) (ch - '0');
            } else if ( 'A' <= ch && ch <= 'F' ) {
                val = 10 + (int) (ch - 'A');
            } else if ( 'a' <= ch && ch <= 'f' ) {
                val = 10 + (int) (ch - 'a');
            } else {
                continue; // not a hex char, ignore
            }

            if ( doLowerBits ) {
                dst[dstPtr] = (byte) val;
                doLowerBits = false; // for next val
            } else {
                dst[dstPtr] = (byte) (dst[dstPtr] | (val << 4));

                dstPtr--;
                doLowerBits = true;  // for next val
            }
        }

        int startPtr = dstPtr + (doLowerBits ? 1 : 0);
        if ( startPtr > 0 ) {
            byte[] newDst = new byte[dst.length - startPtr];
            System.arraycopy(dst, startPtr, newDst, 0, newDst.length);
            dst = newDst;
        }

        return dst;
    }

    /**
     * @deprecated Use {@link #winnow(String, String)} instead.
     */
    @Deprecated
    public static String filter(String source, String validChar) {
        return winnow(source, validChar);
    }

    /**
     * Winnows out invalid characters from the <tt>source</tt> <tt>String</tt>
     * keeping <i>only</i> the characters specified in <tt>sortedValidChar</tt>.
     * For this method to work correctly, it is <i>critical</i> that the
     * <tt>char</tt>'s to keep (which are supplied in <tt>sortedValidChar</tt>)
     * are sorted in ascending Unicode order (as if run through
     * {@link Arrays#sort(char[])} or {@link #toSortedCharArray(char[])}).
     * <p>
     * Example:
     * <pre class="preshade">
     * char[] sortedValidChar = StringTools.toSortedCharArray("0246813579");
     * String s1 = StringTools.winnow("763-555-1212", sortedValidChar);
     * //              results in s1: "7635551212"
     * String s2 = StringTools.winnow(" (763) 555  1212 ", sortedValidChar);
     * //              results in s2: "7635551212"
     * //
     * // NOTE: For an easier way, see {@link #winnowDigit(String)}!</pre>
     * <p>
     * Another Example:
     * <pre class="preshade">
     * char[] validChar = StringTools.toSortedCharArray("fedcba");
     * String s3 = StringTools.winnow("happy dad", validChar);
     * //              results in s3: "adad"
     * String s4 = StringTools.winnow("cat fell into big wall bell", validChar);
     * //              results in s4: "cafebabe"</pre>
     *
     * @param source source string to process
     * @param sortedValidChar any <tt>char</tt> in this sorted <tt>char[]</tt>
     * is considered a keeper. If <tt>null</tt> or a zero-length array is passed
     * in, a zero-length <tt>String</tt> is returned. This array must be sorted.
     * @return the winnowed string. If all characters in <tt>source</tt>
     * were valid, that same <tt>String</tt> instance is returned. If
     * there were any characters in <tt>source</tt> that were not in
     * <tt>sortedValidChar</tt>, then a new <tt>String</tt> is returned
     * with those invalid characters stripped out. If either <tt>source</tt> or
     * <tt>sortedValidChar</tt> is "empty" (that is null or zero-length), a
     * zero-length <tt>String</tt> is returned.
     * This method <i>never</i> returns <tt>null</tt>.
     */
    public static String winnow(String source, char[] sortedValidChar) {
        // Names considered:
        //   StringTools.filter(tf.getText(), HEX_CHAR);
        //   StringTools.screen(tf.getText(), HEX_CHAR);
        //   StringTools.sift(tf.getText(), HEX_CHAR);
        //   StringTools.winnow(tf.getText(), HEX_CHAR);
        //   StringTools.eliminate(tf.getText(), HEX_CHAR);
        //   StringTools.reduce(tf.getText(), HEX_CHAR);
        //

        if ( isEmpty(source) ||
                sortedValidChar == null || sortedValidChar.length == 0 ) {

            return ZERO_LEN_STRING;
        }

        int sourceLength = source.length();
        int firstMismatchPos = -1; // -1 indicates no mismatch found
        for ( int i = 0; i < sourceLength; i++  ) {
            if ( Arrays.binarySearch(sortedValidChar, source.charAt(i)) < 0 ) {
                firstMismatchPos = i;
                break;
            }
        }

        if ( firstMismatchPos < 0 ) {
            // no invalid char present
            return source;
        }

        int dstPtr = firstMismatchPos;
        char[] ch = source.toCharArray();
        for ( int srcPtr = dstPtr + 1; srcPtr < sourceLength; srcPtr++ ) {
            if ( Arrays.binarySearch(sortedValidChar, ch[srcPtr]) >= 0 ) {
                // match found
                ch[dstPtr] = ch[srcPtr];
                dstPtr++;
            }
        }

        if ( dstPtr == 0 ) {
            // *none* of the char are valid
            return ZERO_LEN_STRING;
        } else {
            // *some* of the char are valid
            return new String(ch, 0, dstPtr);
        }
    }

    /**
     * Winnows the <tt>source</tt> <tt>String</tt> keeping <i>only</i> the
     * characters specified in <tt>validChar</tt>. If you already have the
     * <tt>validChar</tt> <tt>String</tt> as a <i>sorted</i> <tt>char[]</tt>,
     * it is more efficient to call {@link #winnow(String, char[])} directly.
     *
     * @param source source string to process
     * @param validChar any <tt>char</tt> in this string is considered a keeper.
     * @return the filtered string. If all characters in <tt>source</tt>
     * are valid, that same <tt>String</tt> instance is returned. If
     * there were any characters in <tt>source</tt> that were not in
     * <tt>validChar</tt>, then a new <tt>String</tt> is returned with those
     * invalid characters stripped out. If either <tt>source</tt> or
     * <tt>validChar</tt> is "empty" (that is null or zero-length), a
     * zero-length <tt>String</tt> is returned. This method <i>never</i> returns
     * <tt>null</tt>.
     */
    public static String winnow(String source, String validChar) {
        if ( isEmpty(source) || isEmpty(validChar) ) {
            return ZERO_LEN_STRING;
        }

        return winnow(source, toSortedCharArray(validChar));
    }

    /**
     * Winnows the <tt>source</tt> <tt>String</tt> keeping <i>only</i> the
     * digit characters (0-9).
     * There is no need to trim any whitespace before calling this method
     * as none of the whitespace characters are in the valid set of characters
     * listed above (in fact, pre-trimming of whitespace is likely to be less
     * efficient than allowing this method to do the whitespace trimming).
     *
     * Example:
     * <pre class="preshade">
     * String s1 = StringTools.winnowDigit("763-555-1212");
     * //                   results in s1: "7635551212"
     * String s2 = StringTools.winnowDigit(" (763) 555  1212 ");
     * //                   results in s2: "7635551212"</pre>
     *
     * @param source source string to process
     * @return the filtered string. If all characters in <tt>source</tt>
     * are digits, that same <tt>String</tt> instance is returned. If
     * there were any characters in <tt>source</tt> that were not digits,
     * then a new <tt>String</tt> is returned with those
     * invalid characters stripped out. If <tt>source</tt> is "empty"
     * (that is null or zero-length), a zero-length <tt>String</tt> is
     * returned. This method <i>never</i> returns <tt>null</tt>.
     *
     * @see #winnow(String, char[])
     */
    public static String winnowDigit(String source) {
        return winnow(source, DIGIT_CHAR_SORTED);
    }

    /**
     * Winnows the <tt>source</tt> <tt>String</tt> keeping <i>only</i> the
     * hexadecimal digit characters (0-9, A-F, a-f). Note that both capital
     * and lowercase letters are accepted <i>and retained</i>.
     * There is no need to trim any whitespace before calling this method
     * as none of the whitespace characters are in the valid set of characters
     * listed above (in fact, pre-trimming of whitespace is likely to be less
     * efficient than allowing this method to do the whitespace trimming).
     *
     * Example:
     * <pre class="preshade">
     * String s1 = StringTools.winnowHexDigit("  3B20 CAFE  ");
     * //                      results in s1: "3B20CAFE"
     * String s2 = StringTools.winnowHexDigit("cat has 9 lives");
     * //                      results in s2: "caa9e"</pre>
     *
     * @param source source string to process
     * @return the filtered string. If all characters in <tt>source</tt>
     * are hex digits, that same <tt>String</tt> instance is returned. If
     * there were any characters in <tt>source</tt> that were not hex digits,
     * then a new <tt>String</tt> is returned with those
     * invalid characters stripped out. If <tt>source</tt> is "empty"
     * (that is null or zero-length), a zero-length <tt>String</tt> is
     * returned. This method <i>never</i> returns <tt>null</tt>.
     *
     * @see #winnow(String, char[])
     */
    public static String winnowHexDigit(String source) {
        return winnow(source, HEXDIGIT_CHAR_SORTED);
    }

    /**
     * Winnows the <tt>source</tt> <tt>String</tt> keeping <i>only</i> the
     * English alphabet characters (A-Z, a-z). Note that both capital
     * and lowercase letters are accepted <i>and retained</i>.
     * There is no need to trim any whitespace before calling this method
     * as none of the whitespace characters are in the valid set of characters
     * listed above (in fact, pre-trimming of whitespace is likely to be less
     * efficient than allowing this method to do the whitespace trimming).
     *
     * Example:
     * <pre class="preshade">
     * String s1 = StringTools.winnowAplha("  4T fifty 6T  ");
     * //                   results in s1: "TfiftyT"
     * String s2 = StringTools.winnowAlpha("A983-22JK-TPL5-3WQH");
     * //                   results in s2: "AJKTPLWQH"</pre>
     *
     * @param source source string to process
     * @return the filtered string. If all characters in <tt>source</tt>
     * are alpha char, that same <tt>String</tt> instance is returned. If
     * there were any characters in <tt>source</tt> that were not alpha char,
     * then a new <tt>String</tt> is returned with those
     * invalid characters stripped out. If <tt>source</tt> is "empty"
     * (that is null or zero-length), a zero-length <tt>String</tt> is
     * returned. This method <i>never</i> returns <tt>null</tt>.
     *
     * @see #winnow(String, char[])
     */
    public static String winnowAlpha(String source) {
        return winnow(source, ALPHA_CHAR_SORTED);
    }

    /**
     * Winnows the <tt>source</tt> <tt>String</tt> keeping <i>only</i> the
     * alphanumeric characters (A-Z, a-z, 0-9).
     * Note that both capital and lowercase letters are
     * accepted <i>and retained</i>.
     * There is no need to trim any whitespace before calling this method
     * as none of the whitespace characters are in the valid set of characters
     * listed above (in fact, pre-trimming of whitespace is likely to be less
     * efficient than allowing this method to do the whitespace trimming).
     *
     * Example:
     * <pre class="preshade">
     * String s1 = StringTools.winnowAplhaNumeric(" Today, 3; tomorrow, 4! ");
     * //                          results in s1: "Today3tomorrow4"
     * String s2 = StringTools.winnowAlphaNumeric("A983-22JK-TPL5-3WQH");
     * //                          results in s2: "A98322JKTPL53WQH"</pre>
     *
     * @param source source string to process
     * @return the filtered string. If all characters in <tt>source</tt>
     * are alphanumeric char, that same <tt>String</tt> instance is returned. If
     * there were any characters in <tt>source</tt> that were not
     * alphanumeric char, then a new <tt>String</tt> is returned with those
     * invalid characters stripped out. If <tt>source</tt> is "empty"
     * (that is null or zero-length), a zero-length <tt>String</tt> is
     * returned. This method <i>never</i> returns <tt>null</tt>.
     *
     * @see #winnow(String, char[])
     */
    public static String winnowAlphaNumeric(String source) {
        return winnow(source, ALPHANUMERIC_CHAR_SORTED);
    }

    /**
     * Winnows the passed <tt>String</tt> keeping <i>only</i> the characters
     * that make up the string version of a decimal number.
     * Processes the passed string by <i>ignoring</i> all characters not in the
     * set <tt>{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, ., -}</tt>.
     * <p>
     * The negative sign <tt>'-'</tt> is ignored if it is not the first valid
     * character.
     * <p>
     * Only the first decimal point (<tt>'.'</tt>) is kept, any
     * additional decimal points are ignored.
     * <p>
     * Extra leading zeros (<tt>0</tt>) are removed. A leading zero is only
     * kept if it immediately precedes a decimal point or is the only digit.
     * A leading zero is a zero that appears to the left of the decimal point
     * and if it appears before the other digits.
     * <p>
     * If zero digits are found, then a zero-length <tt>String</tt> is
     * returned (even if a decimal point and/or a minus sign were found).
     * There is no need to trim any whitespace before calling this method
     * as none of the whitespace characters are in the valid set of characters
     * listed above (in fact, pre-trimming of whitespace is likely to be less
     * efficient than allowing this method to do the whitespace trimming).
     * <p>
     * Examples:
     * <pre class="preshade">
     * String s0 = StringTools.winnowDecimal("107.11170524");
     * //                     results in s0: "107.11170524"
     * String s1 = StringTools.winnowDecimal(" -3,591.103 ");
     * //                     results in s1: "-3591.103"
     * String s2 = StringTools.winnowDecimal(" abc-3,efg5h9i1j.k1l0m3n ");
     * //                     results in s2: "-3591.103"
     * String s3 = StringTools.winnowDecimal(" 4 - 3 = 1 "); // no math done!
     * //                     results in s3: "431"
     * String s4 = StringTools.winnowDecimal("  3,148,912.  ");
     * //                     results in s4: "3148912."
     * String s5 = StringTools.winnowDecimal(" -35-91.10.3 ");
     * //                     results in s5: "-3591.103"
     * String s6 = StringTools.winnowDecimal("-abc.def");
     * //                     results in s6: ""
     * String s7 = StringTools.winnowDecimal("-.");
     * //                     results in s7: ""
     * String s8 = StringTools.winnowDecimal("-");
     * //                     results in s8: ""
     * String s9 = StringTools.winnowDecimal(".");
     * //                     results in s9: ""
     * String s10 = StringTools.winnowDecimal("  abc def ghi ");
     * //                     results in s10: ""</pre>
     * String s11 = StringTools.winnowDecimal(".45");
     * //                     results in s11: ".45"</pre>
     * String s12 = StringTools.winnowDecimal("0.45");
     * //                     results in s12: "0.45"</pre>
     * String s13 = StringTools.winnowDecimal("0052");
     * //                     results in s13: "52"</pre>
     * String s14 = StringTools.winnowDecimal("00.5");
     * //                     results in s14: "0.5"</pre>
     * String s15 = StringTools.winnowDecimal("00000");
     * //                     results in s15: "0"</pre>
     * String s16 = StringTools.winnowDecimal("000.0500");
     * //                     results in s16: "0.0500"</pre>
     * String s17 = StringTools.winnowDecimal("1");
     * //                     results in s17: "1"</pre>
     * String s18 = StringTools.winnowDecimal("1.");
     * //                     results in s18: "1."</pre>
     * String s19 = StringTools.winnowDecimal("0");
     * //                     results in s19: "0"</pre>
     * String s20 = StringTools.winnowDecimal("0.");
     * //                     results in s20: "0."</pre>
     * String s21 = StringTools.winnowDecimal("000.");
     * //                     results in s21: "0."</pre>
     *
     * @param source source string to process
     * @return the filtered string. If all characters in <tt>source</tt>
     * are decimal char, that same <tt>String</tt> instance is returned. If
     * there were any characters in <tt>source</tt> that were not
     * decimal char, then a new <tt>String</tt> is returned with those
     * invalid characters stripped out. If <tt>source</tt> is "empty"
     * (that is null or zero-length), a zero-length <tt>String</tt> is
     * returned. This method <i>never</i> returns <tt>null</tt>.
     * If the returned result would be a zero-length <tt>String</tt> or
     * if a zero-length <tt>String</tt> is passed in, then a reference
     * to the single, shared {@link #ZERO_LEN_STRING} instance is returned
     * to help be more memory and more garbage-collection efficient.
     */
    public static String winnowDecimal(String source) {
        if ( isEmpty(source) ) {
            return ZERO_LEN_STRING;
        }

        char[] ch = source.toCharArray();
        int examineLength = ch.length;
        int dstPtr = 0;
        int srcPtr = 0;

        boolean noDigitOneToNineFound = true;
        boolean noDigitZeroFound = true;
        boolean noDecimalPointFound = true;

        boolean potentialLeadingZero = false;

        for ( srcPtr = 0; srcPtr < examineLength; srcPtr++ ) {
            char currChar = ch[srcPtr];

            if ( ('1' <= currChar) && (currChar <= '9') ) {
                noDigitOneToNineFound = false;
            } else if ( currChar == '0' ) {
                noDigitZeroFound = false;

                if ( noDigitOneToNineFound && noDecimalPointFound ) {
                    // don't keep yet, lets see what's next
                    potentialLeadingZero = true;
                    continue;
                }
            } else if ( (currChar == '.') && noDecimalPointFound ) {
                noDecimalPointFound = false;

                if ( potentialLeadingZero ) {
                    potentialLeadingZero = false;
                    ch[dstPtr] = '0';
                    dstPtr++;
                }
            } else if ( (dstPtr == 0) && (currChar == '-') ) {
                if ( potentialLeadingZero ) {
                    // Do NOT keep the '-' as there was already a '0' found,
                    // and this pending '0' should still remain pending.
                    continue;
                }
            } else {
                continue;
            }

            // Getting to here means that the current char is a keeper...

            potentialLeadingZero = false;

            if ( dstPtr < srcPtr ) {
                ch[dstPtr] = currChar;
            }

            dstPtr++;
        }

        if ( potentialLeadingZero ) {
            potentialLeadingZero = false;
            ch[dstPtr] = '0';
            dstPtr++;
        }

        if ( (dstPtr == 0) || (noDigitOneToNineFound && noDigitZeroFound) ) {
            // no valid characters found, so no need to do any more processing
            return ZERO_LEN_STRING;
        }

        // if all of the char were kept, use the original source
        return (dstPtr == srcPtr) ? source : new String(ch, 0, dstPtr);
    }

    /**
     * Winnows the passed <tt>String</tt> keeping <i>only</i> the characters
     * that make up the string version of an integer number.
     * Processes the passed string by <i>ignoring</i> all characters not in the
     * set <tt>{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -}</tt>.
     * <p>
     * The negative sign <tt>'-'</tt> is ignored if it is not the first valid
     * character.
     * <p>
     * All decimal points <i>are</i> ignored, so be careful when winnowing
     * something like <tt>"34.5"</tt> as the result for this method
     * is: <tt>345</tt> which is ten times bigger than probably intended!
     * If input might contain decimal points that should <i>not</i> be ignored,
     * instead use something like {@link #winnowDecimal(String)},
     * {@link DecimalTools#parseBigDecimal(String)}, or
     * {@link DecimalTools#parseValue(String)}.
     * <p>
     * Extra leading zeros (<tt>0</tt>) are removed. A leading zero is only
     * kept if it is the only digit. A leading zero is a zero that appears
     * to the left of the other digits.
     * <p>
     * If zero digits are found, then a zero-length <tt>String</tt> is
     * returned (even if a minus sign was found).
     * There is no need to trim any whitespace before calling this method
     * as none of the whitespace characters are in the valid set of characters
     * listed above (in fact, pre-trimming of whitespace is likely to be less
     * efficient than allowing this method to do the whitespace trimming).
     * <p>
     * Example:
     * <pre class="preshade">
     * String s0 = StringTools.winnowInteger("98555");
     * //                     results in s0: "98555"
     * String s1 = StringTools.winnowInteger(" -3,591 ");
     * //                     results in s1: "-3591"
     * //
     * // If a decimal point is present, it is ignored
     * // and any and all digits after it <i>are</i> retained:
     * String s2 = StringTools.winnowInteger(" 91.0 ");
     * //                     results in s2: "91<u>0</u>" // so be careful!
     * String s3 = StringTools.winnowInteger(" 91.8 ");
     * //                     results in s3: "91<u>8</u>" // so be careful!
     * //
     * String s4 = StringTools.winnowInteger(" abc-3,efg5h9i1j.kmn ");
     * //                     results in s4: "-3591"
     * String s5 = StringTools.winnowInteger(" 4 - 3 = 1 "); // no math done!
     * //                     results in s5: "431"
     * String s6 = StringTools.winnowInteger("  3,148,912.  ");
     * //                     results in s6: "3148912"
     * String s7 = StringTools.winnowInteger(" -35-91.10.3 ");
     * //                     results in s7: "-3591103"
     * String s8 = StringTools.winnowInteger("-abc.def");
     * //                     results in s8: ""
     * String s9 = StringTools.winnowDecimal("-.");
     * //                     results in s9: ""
     * String s10 = StringTools.winnowDecimal("-");
     * //                     results in s10: ""
     * String s11 = StringTools.winnowDecimal(".");
     * //                     results in s11: ""
     * String s12 = StringTools.winnowInteger("  abc def ghi ");
     * //                     results in s12: ""</pre>
     * String s13 = StringTools.winnowInteger("0");
     * //                     results in s13: "0"</pre>
     * String s14 = StringTools.winnowInteger("000");
     * //                     results in s14: "0"</pre>
     * String s15 = StringTools.winnowInteger("0052");
     * //                     results in s15: "52"</pre>
     * String s15 = StringTools.winnowInteger("-0052");
     * //                     results in s15: "-52"</pre>
     *
     * @param source source string to process
     * @return the filtered string. If all characters in <tt>source</tt>
     * are integer char, that same <tt>String</tt> instance is returned. If
     * there were any characters in <tt>source</tt> that were not
     * integer char, then a new <tt>String</tt> is returned with those
     * invalid characters stripped out. If <tt>source</tt> is "empty"
     * (that is null or zero-length), a zero-length <tt>String</tt> is
     * returned. This method <i>never</i> returns <tt>null</tt>.
     * If the returned result would be a zero-length <tt>String</tt> or
     * if a zero-length <tt>String</tt> is passed in, then a reference
     * to the single, shared {@link #ZERO_LEN_STRING} instance is returned
     * to help be more memory and more garbage-collection efficient.
     */
    public static String winnowInteger(String source) {
        if ( isEmpty(source) ) {
            return ZERO_LEN_STRING;
        }

        char[] ch = source.toCharArray();
        int examineLength = ch.length;
        int dstPtr = 0;
        int srcPtr = 0;

        boolean noDigitOneToNineFound = true;
        boolean noDigitZeroFound = true;

        boolean potentialLeadingZero = false;

        for ( srcPtr = 0; srcPtr < examineLength; srcPtr++ ) {
            char currChar = ch[srcPtr];

            if ( ('1' <= currChar) && (currChar <= '9') ) {
                noDigitOneToNineFound = false;
            } else if ( currChar == '0' ) {
                noDigitZeroFound = false;

                if ( noDigitOneToNineFound ) {
                    // don't keep yet, lets see what's next
                    potentialLeadingZero = true;
                    continue;
                }
            } else if ( (dstPtr == 0) && (currChar == '-') ) {
                if ( potentialLeadingZero ) {
                    // Do NOT keep the '-' as there was already a '0' found,
                    // and this pending '0' should still remain pending.
                    continue;
                }
            } else {
                continue;
            }

            // Getting to here means that the current char is a keeper...

            potentialLeadingZero = false;

            if ( dstPtr < srcPtr ) {
                ch[dstPtr] = currChar;
            }

            dstPtr++;
        }

        if ( potentialLeadingZero ) {
            potentialLeadingZero = false;
            ch[dstPtr] = '0';
            dstPtr++;
        }

        if ( (dstPtr == 0) || (noDigitOneToNineFound && noDigitZeroFound) ) {
            // no valid characters found, so no need to do any more processing
            return ZERO_LEN_STRING;
        }

        // if all of the char were kept, use the original source
        return (dstPtr == srcPtr) ? source : new String(ch, 0, dstPtr);
    }

    /**
     * Returns a new <tt>char[]</tt> sorted in Unicode order representing all of
     * the characters in the <tt>source</tt> <tt>char[]</tt>. If <tt>null</tt>
     * or a zero-length array is passed in, a zero-length
     * <tt>char[]</tt> is returned. This method never returns <tt>null</tt>.
     * Note that any duplicate characters in the <tt>source</tt>
     * <i>are</i> retained.
     * <p>
     * The <tt>char[]</tt> returned is suitable for passing into
     * {@link #winnow(String, char[])
     * winnow(String source, char[] sortedValidChar)} as the
     * <tt>sortedValidChar</tt>.
     *
     * @param source original <tt>char[]</tt> to sort. The contents of the
     * passed array are <i>not</i> modified by this method&mdash;a brand new
     * array is allocated internally and returned.
     * @return a new <tt>char[]</tt> with all of the characters in
     * <tt>source</tt> sorted in Unicode order.
     */
    public static char[] toSortedCharArray(char[] source) {
        if ( source == null || source.length == 0 ) {
            return ZERO_LEN_CHAR_ARRAY;
        }

        char[] ch = (char[]) source.clone();
        Arrays.sort(ch);
        return ch;
    }

    /**
     * Returns a <tt>char[]</tt> sorted in Unicode order representing all of
     * the characters in the <tt>source</tt> <tt>String</tt>. If <tt>null</tt>
     * or a zero-length <tt>String</tt> is passed in, a zero-length
     * <tt>char[]</tt> is returned. This method never returns <tt>null</tt>.
     * Note that any duplicate characters in the <tt>source</tt>
     * <i>are</i> retained.
     * <p>
     * The <tt>char[]</tt> returned is suitable for passing into
     * {@link #winnow(String, char[])
     * winnow(String source, char[] sortedValidChar)} as the
     * <tt>sortedValidChar</tt>.
     *
     * @param source set of characters to sort.
     * @return all of the characters in <tt>source</tt> sorted in Unicode
     * order.
     */
    public static char[] toSortedCharArray(String source) {
        if ( isEmpty(source) ) {
            return ZERO_LEN_CHAR_ARRAY;
        }

        char[] ch = source.toCharArray();
        Arrays.sort(ch);
        return ch;
    }

    /**
     * Performs a stack trace on the passed <tt>Throwable</tt> and returns
     * each line as an element in the array.
     */
    public static String[] stackTraceToStringArray(Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        pw.flush();
        pw.close();

        List<String> list = new ArrayList<String>();
        BufferedReader in = new BufferedReader(new StringReader(sw.toString()));
        try {
            String line = null;
            while ( (line = in.readLine()) != null ) {
                list.add(line);
            }
        } catch ( IOException x ) {
            // should 'never' happen
            x.printStackTrace();
        } finally {
            try {
                in.close();
            } catch ( Exception x ) {
                // ignore, should never happen
            }
        }

        return toArray(list);
    }

    /**
     * Splits up the specified <tt>source</tt> into multiple <tt>String</tt>'s
     * based on the specified <tt>delimiter</tt>. Each of the resulting
     * String's is trimmed.
     * <p>
     * Examples:
     * <pre>
     * split("a|b|c|d", '|')   -> { "a", "b", "c", "d" }
     * split("|a|b|c|d", '|')  -> { "", "a", "b", "c", "d" }
     * split("a|b|c|d|", '|')  -> { "a", "b", "c", "d", "" }
     *
     * split("||a||b|||c||d||", '|')  ->
     *         { "", "", "a", "", "b", "", "", "c", "", "d", "", "" }
     *
     * split("apple banana cherry grape watermelon", ' ')  ->
     *         { "apple", "banana", "cherry", "grape", "watermelon" }
     * </pre>
     */
    public static String[] split(String source, char delimiter) {
        if ( source == null ) {
            return ZERO_LEN_ARRAY;
        }

        int startIdx = 0;
        int sLength = source.length();
        List<String> list = new ArrayList<String>();

        for ( int i = 0; i <= sLength; i++ ) {
            if ( i >= sLength || source.charAt(i) == delimiter ) {
                if ( startIdx >= i ) {
                    list.add(ZERO_LEN_STRING);
                } else {
                    list.add(source.substring(startIdx, i).trim());
                }

                startIdx = i + 1;
            }
        }

        return toArray(list);
    }

    /**
     * Splits up the specified <tt>source</tt> into multiple <tt>String</tt>'s
     * based on the specified <tt>delimiter</tt>.
     * The original <tt>source</tt> is trimmed before any processing.
     * Each of the resulting String's is trimmed.
     * <p>
     * Examples:
     * <pre>
     * split("a|b|c|d", "|")   -> { "a", "b", "c", "d" }
     * split("|a|b|c|d", "|")  -> { "", "a", "b", "c", "d" }
     * split("a|b|c|d|", "|")  -> { "a", "b", "c", "d", "" }
     *
     * split("||a||b|||c||d||", "|")  ->
     *         { "", "", "a", "", "b", "", "", "c", "", "d", "", "" }
     *
     * split("apple banana cherry grape watermelon", " ")  ->
     *         { "apple", "banana", "cherry", "grape", "watermelon" }
     *
     * split("apple, banana, cherry, grape, watermelon", ",")  ->
     *         { "apple", "banana", "cherry", "grape", "watermelon" }
     * </pre>
     */
    public static String[] split(String source, String delimiter) {
        if ( source == null ) {
            return ZERO_LEN_ARRAY;
        }

        int startIdx = 0;
        List<String> list = new ArrayList<String>();

        int idx = -1;
        while ( (idx = source.indexOf(delimiter, startIdx)) != -1 ) {
            list.add(source.substring(startIdx, idx).trim());
            startIdx = idx + delimiter.length();
        }

        list.add(source.substring(startIdx, source.length()).trim());

        return toArray(list);
    }

    /**
     * Returns a sorted copy of the original list of strings.
     * If source is null, a zero-length array is returned.
     * Returned array length may be less than source length.
     * If source contains duplicates, they are skipped.
     * If source contains nulls or zero-length strings, they are skipped.
     */
    public static String[] sortUnique(String[] source) {
        if ( source == null ) {
            return ZERO_LEN_ARRAY;
        }

        SortedSet<String> set = new TreeSet<String>();
        for ( int i = 0; i < source.length; i++ ) {
            String s = source[i];
            if ( isNotEmpty(s) ) {
                set.add(s);
            }
        }

        return toArray(set);
    }

    /**
     * Returns the source <tt>String</tt> wrapped with double-quotes.
     * If source is pointing to <tt>null</tt>, then the
     * <tt>String</tt> <tt>null</tt> is returned (with<i>out</i>
     * surrounding quotes).
     * If source is pointing to the <tt>String</tt> <tt>apple</tt> then
     * a new <tt>String</tt> with a prefix and suffix of <tt>"</tt> is
     * returned: <tt>"apple"</tt> (the quotes are actually part of the returned
     * <tt>String</tt>).
     */
    public static String quoteWrap(String source) {
        if ( source == null ) {
            return "null";
        } else {
            return "\"" + source + "\"";
        }
    }

    /**
     * Returns the toString() version of the source <tt>Object</tt> wrapped
     * with double-quotes.
     * If source is pointing to <tt>null</tt>, then the
     * <tt>String</tt> <tt>null</tt> is returned (with<i>out</i>
     * surrounding quotes).
     * If source is pointing to the <tt>String</tt> <tt>apple</tt> then
     * a new <tt>String</tt> with a prefix and suffix of <tt>"</tt> is
     * returned: <tt>"apple"</tt> (the quotes are actually part of the returned
     * <tt>String</tt>).
     */
    public static String quoteWrap(Object source) {
        if ( source == null ) {
            return "null";
        } else {
            return "\"" + source + "\"";
        }
    }

    /**
     * Used as a helper to check passed parameters for prohibited
     * "empty" values in <i>other</i> methods.
     * Being "empty" is determined by {@link #isEmpty(String)}.
     * If <tt>param</tt> is <i>not</i> "empty", then <tt>param</tt> is simply and
     * quietly returned from this method.
     *
     * @param param the parameter value to check.
     * @param paramName the optional name of the parameter being checked.
     * If present, <tt>paramName</tt> is used to enhance the text of the
     * exception.
     * @return the passed <tt>param</tt> if <tt>param</tt> is not "empty".
     * @throws IllegalArgumentException if <tt>param</tt> is "empty".
     */
    public static String paramEmptyCheck(String param, String paramName)
            throws IllegalArgumentException {

        if ( param == null ) {
            if ( isEmpty(paramName) ) {
                throw new IllegalArgumentException(
                    "Passed parameter must not be 'empty'; value is: " +
                    quoteWrap(param));
            } else {
                throw new IllegalArgumentException(
                    "Passed parameter must not be 'empty'; " +
                    paramName + "=" + quoteWrap(param));
            }
        } else {
            return param;
        }
    }

    /**
     * Used as a helper to check passed parameters for prohibited
     * "empty" values in <i>other</i> methods.
     * Being "empty" is determined by {@link #isEmpty(String)}.
     * If <tt>param</tt> is <i>not</i> "empty", then <tt>param</tt> is simply and
     * quietly returned from this method.
     *
     * @param param the parameter value to check.
     * @return the passed <tt>param</tt> if <tt>param</tt> is not "empty".
     * @throws IllegalArgumentException if <tt>param</tt> is "empty".
     */
    public static String paramEmptyCheck(String param)
            throws IllegalArgumentException {

        return paramEmptyCheck(param, null);
    }

    /**
     * Takes the passed strings and formats them into a comma and space
     * delimited string. Each comma is followed by a space. There is
     * no final comma. For example:
     * <pre>
     * StringTools.formatCommandDelimited("apple", "banana", "cherry");
     * </pre>
     * returns this String: <tt>"apple", "banana", "cherry"</tt>.
     * Each item is sent through {@link #quoteWrap(String)}.
     *
     * @param itemList the strings to format
     */
    public static String formatCommaDelimited(String... itemList) {
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for ( String item : itemList ) {
            if ( first ) {
                first = false;
            } else {
                sb.append(", ");
            }
            sb.append(StringTools.quoteWrap(item));
        }
        return sb.toString();
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.