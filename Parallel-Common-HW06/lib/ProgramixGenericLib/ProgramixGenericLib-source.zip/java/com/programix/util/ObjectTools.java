package com.programix.util;

import java.lang.reflect.*;

public class ObjectTools extends Object {
	// no instances
	private ObjectTools() {
	}

	/**
	 * Compares two references to see if they are "the same".
	 * Returns <tt>true</tt> if <tt>a</tt> is <i>the same </i> as <tt>b</tt>.
	 * Specifically, they considered to be the same if <i>any</i> of the
     * following are true:
	 * <ul>
	 * <li><tt>a == b</tt> (two references to the same object)</li>
	 * <li><tt>( a == null ) &amp;&amp; ( b == null )</tt> (both are null)</li>
	 * <li><tt>( a != null ) &amp;&amp; ( b != null )
     *         &amp;&amp; ( a.equals(b) == true )</tt></li>
	 * </ul>
	 *
	 * @param a the first Object
	 * @param b the second Object
	 *
	 * @return <tt>true</tt> if the objects are the same.
     *
     * @see #isDifferent(Object, Object)
	 */
	public static boolean isSame(Object a, Object b) {
        if ( a == b ) {
            // both pointing to same object, OR both are null
            return true;
        } else if ( a == null || b == null ) {
            // one is null and the other is NOT null
            return false;
        } else {
            return a.equals(b);
        }
	}

	/**
	 * Compares two references to see if they are "different".
	 * Returns <tt>true</tt> if <tt>a</tt> is <i>different</i> than <tt>b</tt>.
	 * Specifically, they considered to be different if <i>any</i> of the
	 * following are true:
	 * <ul>
	 * <li><tt>( a == null ) &amp;&amp; ( b != null )</tt></li>
	 * <li><tt>( a != null ) &amp;&amp; ( b == null )</tt></li>
     * <li><tt>( a != null ) &amp;&amp; ( b != null )
     *         &amp;&amp; ( a.equals(b) == false )</tt></li>
	 * </ul>
	 *
	 * @param a the first Object
	 * @param b the second Object
	 *
	 * @return <tt>true</tt> if the objects are different.
     *
     * @see #isSame(Object, Object)
	 */
	public static boolean isDifferent(Object a, Object b) {
        return !isSame(a, b);
	}

    /**
     * Compares two arrays to see if they are "the same".
     * Returns <tt>true</tt> if <tt>a</tt> is <i>the same </i> as <tt>b</tt>.
     * Specifically, they considered to be the same if <i>any</i> of the
     * following are true:
     * <ul>
     * <li><tt>a == b</tt> (two references to the same object)</li>
     * <li><tt>( a == null ) &amp;&amp; ( b == null )</tt> (both are null)</li>
     * <li><tt>( a != null ) &amp;&amp; ( b != null )
     *         &amp;&amp; ( a.length == b.length )
     *         &amp;&amp; ("each element
     *                    {@link #isSame(Object, Object) isSame}"</tt></li>
     * </ul>
     *
     * @param a the first array
     * @param b the second array
     *
     * @return <tt>true</tt> if the arrays are the same.
     *
     * @see #isDifferentArray(Object[], Object[])
     */
    public static boolean isSameArray(Object[] a, Object[] b) {
        if ( a == b ) {
            // both pointing to same object, OR both are null
            return true;
        } else if ( a == null || b == null ) {
            // one is null and the other is NOT null
            return false;
        } else if ( a.length != b.length ) {
            // different lengths
            return false;
        } else {
            for ( int i = 0; i < a.length; i++ ) {
                if ( isDifferent(a[i], b[i]) ) {
                    return false;
                }
            }

            return true;
        }
    }

	/**
	 * Compares two arrays to see if they are "different".
     * See {@link #isSameArray(Object[], Object[])} to see what is
     * considered to be "the same", and this method returns the opposite.
	 */
	public static boolean isDifferentArray(Object[] a, Object[] b) {
        return !isSameArray(a, b);
	}

	/**
	 * Returns true if array is either null or has a length of zero.
	 */
   	public static boolean isEmpty(Object[] obj) {
		return (obj == null) || (obj.length == 0);
	}

	/**
	 * Returns true if array is not null and has a length greater than zero.
	 */
   	public static boolean isNotEmpty(Object[] obj) {
		return (obj != null) && (obj.length > 0);
	}

    /**
     * Returns true if the passed parameter is <tt>null</tt>, points to
     * a zero-length array, or if <i>every</i> slot in that array contains
     * <tt>null</tt>.
     */
    public static boolean isEverySlotEmpty(Object[] obj) {
        if ( obj == null || obj.length == 0 ) {
            return true;
        }

        for ( int i = 0; i < obj.length; i++ ) {
            if ( obj[i] != null ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Returns true if the passed parameter is <tt>null</tt>, points to
     * a zero-length array, or if <i>any</i> slot in that array contains
     * <tt>null</tt>.
     */
    public static boolean isAnySlotEmpty(Object[] obj) {
        if ( obj == null || obj.length == 0 ) {
            return true;
        }

        for ( int i = 0; i < obj.length; i++ ) {
            if ( obj[i] == null ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns true if the passed array does not have any "empty"
     * (<tt>null</tt>) slots. If a zero-length array is passed in, then
     * this method also returns <tt>true</tt> as none of the zero slots
     * are empty. If <tt>null</tt> is passed in, then <tt>false</tt> is
     * returned.
     */
    public static boolean isNoSlotEmpty(Object[] obj) {
        if ( obj == null ) {
            return false;
        }

        for ( int i = 0; i < obj.length; i++ ) {
            if ( obj[i] == null ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Returns a new array of the same type as the passed array but with
     * the length of the new array set to <tt>newLength</tt>.
     * If <tt>newLength</tt> is smaller than the current length,
     * then a new array is returned as a truncated version or <tt>src</tt>.
     * If <tt>newLength</tt> is larger than the current length,
     * then a new array is returned with the contents of <tt>src</tt>
     * followed by the specified <tt>pad</tt> in the remaining slots.
     * If <tt>newLength</tt> is same as the current length, then a clone
     * of <tt>src</tt> is returned.
     *
     * @param src array to copy from and to sense the type from, must not
     * be null (but it is OK if it has a zero-length).
     * @param newLength the length of the returned array.
     * @param pad if needed, this reference is copied into the additional
     * slots.
     * @return a new array with the element type of <tt>src</tt> and
     * a length of <tt>newLength</tt>.
     * @throws IllegalArgumentException if <tt>src</tt> is <tt>null</tt>
     * or if <tt>newLength</tt> is negative.
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] changeArraySize(T[] src,
                                          int newLength,
                                          T pad
                                       ) throws IllegalArgumentException {

        if ( src == null ) {
            throw new IllegalArgumentException("src must not be null");
        } else if ( newLength < 0 ) {
            throw new IllegalArgumentException("newLength=" + newLength +
                ", but must be >= 0");
        } else if ( src.length == newLength ) {
            // Same size as it is already, but return a clone
            return src.clone();
        }

        T[] dest = (T[])
            Array.newInstance(src.getClass().getComponentType(), newLength);

        int copyLen = Math.min(src.length, dest.length);

        if ( copyLen > 0 ) {
            System.arraycopy(src, 0, dest, 0, copyLen);
        }

        for ( int i = copyLen; i < dest.length; i++ ) {
            dest[i] = pad;
        }

        return dest;
    }

    /**
     * Returns a new array of the same type as the passed array but with
     * the length of the new array set to <tt>newLength</tt>.
     * If <tt>newLength</tt> is smaller than the current length,
     * then a new array is returned as a truncated version or <tt>src</tt>.
     * If <tt>newLength</tt> is larger than the current length,
     * then a new array is returned with the contents of <tt>src</tt>
     * followed by <tt>null</tt> in the remaining slots.
     * If <tt>newLength</tt> is same as the current length, then a clone
     * of <tt>src</tt> is returned.
     *
     * @param src array to copy from and to sense the type from, must not
     * be null (but it is OK if it has a zero-length).
     * @param newLength the length of the returned array.
     * @return a new array with the element type of <tt>src</tt> and
     * a length of <tt>newLength</tt>.
     * @throws IllegalArgumentException if <tt>src</tt> is <tt>null</tt>
     * or if <tt>newLength</tt> is negative.
     */
    public static <T> T[] changeArraySize(T[] src,
                                          int newLength
                                        ) throws IllegalArgumentException {

        return changeArraySize(src, newLength, null);
    }

    /**
     * Removes all occurrences of the specified <tt>item</tt> from the
     * specified array. Matching is done via the <tt>equals</tt>
     * method (however, if <tt>item</tt> is <tt>null</tt> then all
     * <tt>null</tt> slots are removed from the array).
     * If there are no matches, then the <i>original</i> array is
     * returned (note: not a clone!). If there are any matches, then
     * a new, smaller array is returned.
     *
     * @param src array to copy from and to sense the type from, must not
     * be null (but it is OK if it has a zero-length).
     * This array is never modified by this method.
     * @param item the one to match for removal. If <tt>null</tt> then
     * all <tt>null</tt> slots in the array are removed.
     * @return an array with all occurrences of <tt>item</tt> removed.
     * If no matches were found, then <tt>src</tt> is simply returned.
     * If any matches were found, then a new, smaller array of the same
     * type as <tt>src</tt> is returned.
     * @throws IllegalArgumentException if <tt>src</tt> is <tt>null</tt>.
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] removeFromArray(T[] src, T item)
            throws IllegalArgumentException {

        if ( src == null ) {
            throw new IllegalArgumentException("src must not be null");
        }

        int srcPtr = 0;
        T[] dest = null;
        int destPtr = 0;
        while ( srcPtr < src.length ) {
            if ( ObjectTools.isSame(item, src[srcPtr]) ) {
                if ( dest == null ) {
                    // this is the first--and perhaps only--item to remove
                    dest = (T[]) Array.newInstance(
                        src.getClass().getComponentType(), src.length - 1);

                    if ( srcPtr > 0 ) {
                        // copy all that have been looked at already
                        System.arraycopy(src, 0, dest, 0, srcPtr);
                        destPtr = srcPtr;
                    }
                }
            } else if ( dest != null ) {
                dest[destPtr] = src[srcPtr];
                destPtr++;
            }

            srcPtr++;
        }

        if ( dest == null ) {
            // nothing needed to be remove, so just return the original
            return src;
        } else if ( destPtr >= dest.length ) {
            return dest;
        } else {
            T[] trimmedDest = (T[]) Array.newInstance(
                dest.getClass().getComponentType(), destPtr);

            if ( trimmedDest.length > 0 ) {
                // copy all that have been looked at already
                System.arraycopy(dest, 0, trimmedDest, 0, trimmedDest.length);
            }

            return trimmedDest;
        }
    }

    /**
     * Returns the index into <tt>list</tt> where the first
     * {@link #isSame(Object, Object) isSame(lookFor, list[i])}
     * returns <tt>true</tt>&mdash;starting with <tt>offset</tt>.
     * Returns -1 if no match is found from the specified <tt>offset</tt> to
     * the end of the array.
     * The <tt>list</tt> passed in does not need to be sorted as the search
     * is sequential starting at <tt>offset</tt>.
     */
    public static int findMatch(Object lookFor, Object[] list, int offset) {
        if ( isNotEmpty(list) ) {
            for ( int i = offset; i < list.length; i++ ) {
                if ( isSame(lookFor, list[i]) ) {
                    return i;
                }
            }
        }

        return -1;
    }

    /**
     * Returns the index into <tt>list</tt> where the first
     * {@link #isSame(Object, Object) isSame(lookFor, list[i])}
     * returns <tt>true</tt>. Returns -1 if not found. The <tt>list</tt>
     * passed in does not need to be sorted as the search is sequential
     * from the beginning.
     */
    public static int findMatch(Object lookFor, Object[] list) {
        return findMatch(lookFor, list, 0);
    }

    /**
     * Returns a <tt>String</tt> with a dump of the contents of the
     * specified array.
     * The output uses the passed <tt>name</tt> when referring to the array.
     * The <tt>toString()</tt> method is used on each element in the array; if
     * any element is <tt>null</tt>, then the word null is appended instead.
     *
     * @param obj the array for format. OK to pass <tt>null</tt> and OK to
     * pass a zero-length array (there will be some output).
     * @param name the name of the array to use in the output.
     * @return a <tt>String</tt> with the formatted array contents.
     */
    public static String printArray(Object[] obj, String name) {
        StringBuffer sb = new StringBuffer();

        if ( obj == null ) {
            sb.append(name + "=null");
        } else {
            sb.append(name + ".length=" + obj.length + " {");

            for ( int i = 0; i < obj.length; i++ ) {
                if ( i > 0 ) {
                    sb.append(", ");
                }

                String s = null;
                if ( obj[i] == null ) {
                    s = "null";
                } else if ( obj[i] instanceof String ) {
                    s = StringTools.quoteWrap((String) obj[i]);
                } else {
                    s = obj[i].toString();
                }

                sb.append(name + "[" + i + "]=" + s);
            }

            sb.append("}");
        }

        return sb.toString();
    }

    /**
     * Used as a helper to check passed parameters for prohibited
     * <tt>null</tt> values in <i>other</i> methods.
     * If <tt>param</tt> is <i>not</i> <tt>null</tt>, then <tt>param</tt>
     * is simply and quietly returned from this method.
     *
     * @param param the parameter value to check.
     * @param paramName the optional name of the parameter being checked.
     * If present, <tt>paramName</tt> is used to enhance the text of the
     * exception.
     * @return the passed <tt>param</tt> if <tt>param</tt> is not <tt>null</tt>.
     * @throws IllegalArgumentException if <tt>param</tt> is <tt>null</tt>.
     */
    public static Object paramNullCheck(Object param, String paramName)
            throws IllegalArgumentException {

        if ( param == null ) {
            if ( StringTools.isEmpty(paramName) ) {
                throw new IllegalArgumentException(
                    "Passed parameter must not be null.");
            } else {
                throw new IllegalArgumentException("Passed parameter " +
                    StringTools.quoteWrap(paramName) + " must not be null.");

            }
        } else {
            return param;
        }
    }


    /**
     * Used as a helper to check passed parameters for prohibited
     * <tt>null</tt> values in <i>other</i> methods.
     * If <tt>param</tt> is <i>not</i> <tt>null</tt>, then <tt>param</tt>
     * is simply and quietly returned from this method.
     *
     * @param param the parameter value to check.
     * @return the passed <tt>param</tt> if <tt>param</tt> is not <tt>null</tt>.
     * @throws IllegalArgumentException if <tt>param</tt> is <tt>null</tt>.
     */
    public static Object paramNullCheck(Object param)
            throws IllegalArgumentException {

        return paramNullCheck(param, null);
    }

    /**
     * Checks that the passed <tt>value</tt> is not <tt>null</tt> and can
     * be cast into the specified <tt>targetType</tt>.
     *
     * @param value the value to check
     * @param targetType the type be check against. If <tt>null</tt>, then
     * the type <tt>Object</tt> is assumed.
     * @return the passed value for method chaining convenience.
     * @throws ClassCastException if the passed value is <tt>null</tt> or
     * if it can't be cast into the specified <tt>targetType</tt>.
     */
    @SuppressWarnings("unchecked")
    public static <T> T typeCheck(Object value, Class<T> targetType)
            throws ClassCastException {

        if ( value == null ) {
            throw new ClassCastException("The value is null and " +
                "therefore does not match the " +
                "target type (" + targetType.getName() + ")");
        }

        if ( targetType == null ) {
            return (T) value;
        }

        if ( targetType.isInstance(value) == false ) {
            throw new ClassCastException("The type (" +
                value.getClass().getName() + ") can't be cast into the " +
                "target type (" + targetType.getName() + ")");
        }

        return (T) value;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.