package com.programix.util;

import java.io.*;
import java.security.*;

import com.programix.io.*;

public class SecurityTools {
    public static final String MD5_ALGORITHM_NAME = "MD5";
    
    // no instances
    private SecurityTools() {
    }

    public static byte[] digest(String digestAlgorithm, InputStream in)
            throws IOException {
        
        try {
            MessageDigest md = MessageDigest.getInstance(digestAlgorithm);
            
            byte[] buf = new byte[4096];
            int len = -1;
            while ( (len = in.read(buf)) != -1 ) {
                md.update(buf, 0, len);
            }
            
            return md.digest();
        } catch ( NoSuchAlgorithmException x ) {
            IOException iox = new IOException(
                "Could not find support for algorithm: " + digestAlgorithm);
            iox.initCause(x);
            throw iox;
        }
    }
    
    public static byte[] digestMD5(InputStream in) throws IOException {
        return digest(MD5_ALGORITHM_NAME, in);
    }

    public static byte[] digestMD5(File source) throws IOException {
        InputStream in = null;
        try {
            in = new FileInputStream(source);
            return digestMD5(in);
        } finally {
            IOTools.closeQuietly(in);
        }
    }
    
    public static String digestMD5ToHexString(File source) throws IOException {
        return StringTools.toHexString(digestMD5(source));
    }

    public static String digestMD5ToHexString(String filename) 
            throws IOException {
        
        return StringTools.toHexString(digestMD5(new File(filename)));
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.