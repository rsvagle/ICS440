package com.programix.util;

import java.io.*;
import java.util.*;

/**
 * Holds one of three states: {@link #YES}, {@link #NO}, and {@link #UNKNOWN}.
 * This can be used instead of a <tt>boolean</tt> to hold a <i>third</i>
 * state of "don't know" or "unknown".
 * This can also be used instead of a <tt>Boolean</tt> reference so that
 * "unknown" can be explicitly represented as opposed to using a
 * <tt>null</tt> reference to implicitly indicate "unknown".
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class TriState implements Serializable, Comparable<TriState> {
    private static int nextSerial = 0;
    private static List<TriState> instanceList = new ArrayList<TriState>();

    // This variable declaration and construction order must never
    // change if there are serialized instances saved somewhere as
    // they will be misinterpreted when de-serialized. If any new
    // instances are to be created, they must be appended to the
    // end of the existing list. The order of the constants will also
    // be the sort order for Comparable.

    /**
     * Indicates that the state is known and that it is "yes"
     * (or "true", or "on", or "affirmative").
     * @see #NO
     * @see #UNKNOWN
     */
    public static final TriState YES = new TriState("YES");

    /**
     * Indicates that the state is known and that it is "no"
     * (or "false", or "off", or "negative").
     * @see #YES
     * @see #UNKNOWN
     */
    public static final TriState NO = new TriState("NO");

    /**
     * Indicates that the state is unknown (neither "yes" or "no" is
     * known at this point).
     * @see #YES
     * @see #NO
     */
    public static final TriState UNKNOWN = new TriState("UNKNOWN");

    private static final TriState[] VALUES = (TriState[])
        instanceList.toArray(new TriState[instanceList.size()]);

    /**
     * An unmodifiable {@link List} of all the instances of <tt>TriState</tt>.
     */
    public static final List<TriState> VALUE_LIST =
        Collections.unmodifiableList(instanceList);

    private final int serial;
    private final transient String name;

    // private constructor to prevent outside instantiation
    private TriState(String name) {
        this.serial = getSerial(this);
        this.name = name;
    }

    private static synchronized int getSerial(TriState instance) {
        instanceList.add(instance);
        return nextSerial++;
    }

    /**
     * Returns an array of all the instances of <tt>TriState</tt>.
     * A cloned copy is returned, so no special care is required.
     */
    public static TriState[] getValues() {
        return (TriState[]) VALUES.clone();
    }

    /**
     * Returns the instance whose {@link #getName} method returns
     * a <tt>String</tt> that matches the <tt>name</tt> passed in.
     * The matching is done ignoring any case differences and after
     * trimming any leading or trailing whitespace on the string
     * passed in.
     *
     * @param name the name to search for.
     * @return the matching instance
     * @throws IllegalArgumentException if no match is found.
     */
    public static TriState valueOf(String name)
            throws IllegalArgumentException {

        String s = (name == null) ? "" : name.trim();
        for ( int i = 0; i < VALUES.length; i++ ) {
            if ( VALUES[i].name.equalsIgnoreCase(s) ) {
                return VALUES[i];
            }
        }

        throw new IllegalArgumentException(
            "Can not find a match for '" + name + "'");
    }

    // Used during de-serialization
    private Object readResolve() {
        // Only return one of the few instances.
        return VALUES[serial];
    }

    @Override
    public boolean equals(Object obj) {
        return this == obj;
    }

    @Override
    public int hashCode() {
        return serial;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(getClass().getName() + "[");
        sb.append("serial=" + serial);
        sb.append(", name=" + name);
        sb.append("]");
        return sb.toString();
    }

    public int compareTo(TriState other) {
        return serial - other.serial;
    }

    /**
     * Returns the name of this instance, one of:
     * <tt>"YES"</tt>, <tt>"NO"</tt>, or <tt>"UNKNOWN"</tt>.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns <tt>true</tt> if the state is either {@link #YES} or
     * {@link #NO} (not {@link #UNKNOWN}).
     */
    public boolean isKnown() {
        return (this == YES) || (this == NO);
    }

    /**
     * Returns <tt>true</tt> if the state is neither {@link #YES} nor
     * {@link #NO}, but is {@link #UNKNOWN}.
     */
    public boolean isUnknown() {
        return (this == UNKNOWN);
    }

    /**
     * Returns <tt>true</tt> if the state is {@link #YES}.
     */
    public boolean isYes() {
        return this == YES;
    }

    /**
     * Returns <tt>true</tt> if the state is not {@link #YES},
     * but is either {@link #NO} or {@link #UNKNOWN}.
     */
    public boolean isNotYes() {
        return (this == NO) || (this == UNKNOWN);
    }

    /**
     * Returns <tt>true</tt> if the state is {@link #NO}.
     */
    public boolean isNo() {
        return this == NO;
    }

    /**
     * Returns <tt>true</tt> if the state is not {@link #NO},
     * but is either {@link #YES} or {@link #UNKNOWN}.
     */
    public boolean isNotNo() {
        return (this == YES) || (this == UNKNOWN);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.