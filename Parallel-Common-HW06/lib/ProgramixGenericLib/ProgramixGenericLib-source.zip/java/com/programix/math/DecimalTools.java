package com.programix.math;

import java.math.*;
import java.text.*;
import java.util.*;

import com.programix.util.*;
import com.programix.value.*;

public class DecimalTools extends Object {
	public static final BigDecimal ZERO = new BigDecimal("0");
	public static final BigDecimal ONE = new BigDecimal("1");
	public static final BigDecimal TWO = new BigDecimal("2");
	public static final BigDecimal THREE = new BigDecimal("3");
	public static final BigDecimal FOUR = new BigDecimal("4");
	public static final BigDecimal FIVE = new BigDecimal("5");
	public static final BigDecimal SIX = new BigDecimal("6");
	public static final BigDecimal SEVEN = new BigDecimal("7");
	public static final BigDecimal EIGHT = new BigDecimal("8");
	public static final BigDecimal NINE = new BigDecimal("9");

	public static final BigDecimal TEN = new BigDecimal("10");
    public static final BigDecimal ELEVEN = new BigDecimal("11");
    public static final BigDecimal TWELVE = new BigDecimal("12");
    public static final BigDecimal THIRTEEN = new BigDecimal("13");
    public static final BigDecimal FOURTEEN = new BigDecimal("14");
    public static final BigDecimal FIFTEEN = new BigDecimal("15");
    public static final BigDecimal SIXTEEN = new BigDecimal("16");
    public static final BigDecimal SEVENTEEN = new BigDecimal("17");
    public static final BigDecimal EIGHTEEN = new BigDecimal("18");
    public static final BigDecimal NINETEEN = new BigDecimal("19");

    public static final BigDecimal TWENTY = new BigDecimal("20");
    public static final BigDecimal TWENTY_ONE = new BigDecimal("21");
    public static final BigDecimal TWENTY_TWO = new BigDecimal("22");
    public static final BigDecimal TWENTY_THREE = new BigDecimal("23");
    public static final BigDecimal TWENTY_FOUR = new BigDecimal("24");
    public static final BigDecimal TWENTY_FIVE = new BigDecimal("25");
    public static final BigDecimal TWENTY_SIX = new BigDecimal("26");
    public static final BigDecimal TWENTY_SEVEN = new BigDecimal("27");
    public static final BigDecimal TWENTY_EIGHT = new BigDecimal("28");
    public static final BigDecimal TWENTY_NINE = new BigDecimal("29");

    public static final BigDecimal THIRTY = new BigDecimal("30");
    public static final BigDecimal THIRTY_ONE = new BigDecimal("31");
    public static final BigDecimal THIRTY_TWO = new BigDecimal("32");
    public static final BigDecimal THIRTY_THREE = new BigDecimal("33");
    public static final BigDecimal THIRTY_FOUR = new BigDecimal("34");
    public static final BigDecimal THIRTY_FIVE = new BigDecimal("35");
    public static final BigDecimal THIRTY_SIX = new BigDecimal("36");
    public static final BigDecimal THIRTY_SEVEN = new BigDecimal("37");
    public static final BigDecimal THIRTY_EIGHT = new BigDecimal("38");
    public static final BigDecimal THIRTY_NINE = new BigDecimal("39");

    public static final BigDecimal FORTY = new BigDecimal("40");
    public static final BigDecimal FORTY_ONE = new BigDecimal("41");
    public static final BigDecimal FORTY_TWO = new BigDecimal("42");
    public static final BigDecimal FORTY_THREE = new BigDecimal("43");
    public static final BigDecimal FORTY_FOUR = new BigDecimal("44");
    public static final BigDecimal FORTY_FIVE = new BigDecimal("45");
    public static final BigDecimal FORTY_SIX = new BigDecimal("46");
    public static final BigDecimal FORTY_SEVEN = new BigDecimal("47");
    public static final BigDecimal FORTY_EIGHT = new BigDecimal("48");
    public static final BigDecimal FORTY_NINE = new BigDecimal("49");

    public static final BigDecimal FIFTY = new BigDecimal("50");
    public static final BigDecimal FIFTY_ONE = new BigDecimal("51");
    public static final BigDecimal FIFTY_TWO = new BigDecimal("52");
    public static final BigDecimal FIFTY_THREE = new BigDecimal("53");
    public static final BigDecimal FIFTY_FOUR = new BigDecimal("54");
    public static final BigDecimal FIFTY_FIVE = new BigDecimal("55");
    public static final BigDecimal FIFTY_SIX = new BigDecimal("56");
    public static final BigDecimal FIFTY_SEVEN = new BigDecimal("57");
    public static final BigDecimal FIFTY_EIGHT = new BigDecimal("58");
    public static final BigDecimal FIFTY_NINE = new BigDecimal("59");

    public static final BigDecimal SIXTY = new BigDecimal("60");
    public static final BigDecimal SIXTY_ONE = new BigDecimal("61");
    public static final BigDecimal SIXTY_TWO = new BigDecimal("62");
    public static final BigDecimal SIXTY_THREE = new BigDecimal("63");
    public static final BigDecimal SIXTY_FOUR = new BigDecimal("64");
    public static final BigDecimal SIXTY_FIVE = new BigDecimal("65");
    public static final BigDecimal SIXTY_SIX = new BigDecimal("66");
    public static final BigDecimal SIXTY_SEVEN = new BigDecimal("67");
    public static final BigDecimal SIXTY_EIGHT = new BigDecimal("68");
    public static final BigDecimal SIXTY_NINE = new BigDecimal("69");

    public static final BigDecimal SEVENTY = new BigDecimal("70");
    public static final BigDecimal SEVENTY_ONE = new BigDecimal("71");
    public static final BigDecimal SEVENTY_TWO = new BigDecimal("72");
    public static final BigDecimal SEVENTY_THREE = new BigDecimal("73");
    public static final BigDecimal SEVENTY_FOUR = new BigDecimal("74");
    public static final BigDecimal SEVENTY_FIVE = new BigDecimal("75");
    public static final BigDecimal SEVENTY_SIX = new BigDecimal("76");
    public static final BigDecimal SEVENTY_SEVEN = new BigDecimal("77");
    public static final BigDecimal SEVENTY_EIGHT = new BigDecimal("78");
    public static final BigDecimal SEVENTY_NINE = new BigDecimal("79");

    public static final BigDecimal EIGHTY = new BigDecimal("80");
    public static final BigDecimal EIGHTY_ONE = new BigDecimal("81");
    public static final BigDecimal EIGHTY_TWO = new BigDecimal("82");
    public static final BigDecimal EIGHTY_THREE = new BigDecimal("83");
    public static final BigDecimal EIGHTY_FOUR = new BigDecimal("84");
    public static final BigDecimal EIGHTY_FIVE = new BigDecimal("85");
    public static final BigDecimal EIGHTY_SIX = new BigDecimal("86");
    public static final BigDecimal EIGHTY_SEVEN = new BigDecimal("87");
    public static final BigDecimal EIGHTY_EIGHT = new BigDecimal("88");
    public static final BigDecimal EIGHTY_NINE = new BigDecimal("89");

    public static final BigDecimal NINETY = new BigDecimal("90");
    public static final BigDecimal NINETY_ONE = new BigDecimal("91");
    public static final BigDecimal NINETY_TWO = new BigDecimal("92");
    public static final BigDecimal NINETY_THREE = new BigDecimal("93");
    public static final BigDecimal NINETY_FOUR = new BigDecimal("94");
    public static final BigDecimal NINETY_FIVE = new BigDecimal("95");
    public static final BigDecimal NINETY_SIX = new BigDecimal("96");
    public static final BigDecimal NINETY_SEVEN = new BigDecimal("97");
    public static final BigDecimal NINETY_EIGHT = new BigDecimal("98");
    public static final BigDecimal NINETY_NINE = new BigDecimal("99");

    public static final BigDecimal ONE_HUNDRED = new BigDecimal("100");

    private static final BigDecimal[] COMMON_LIST = {
        ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE,
        TEN, ELEVEN, TWELVE, THIRTEEN, FOURTEEN,
        FIFTEEN, SIXTEEN, SEVENTEEN, EIGHTEEN, NINETEEN,
        TWENTY, TWENTY_ONE, TWENTY_TWO, TWENTY_THREE, TWENTY_FOUR,
        TWENTY_FIVE, TWENTY_SIX, TWENTY_SEVEN, TWENTY_EIGHT, TWENTY_NINE,
        THIRTY, THIRTY_ONE, THIRTY_TWO, THIRTY_THREE, THIRTY_FOUR,
        THIRTY_FIVE, THIRTY_SIX, THIRTY_SEVEN, THIRTY_EIGHT, THIRTY_NINE,
        FORTY, FORTY_ONE, FORTY_TWO, FORTY_THREE, FORTY_FOUR,
        FORTY_FIVE, FORTY_SIX, FORTY_SEVEN, FORTY_EIGHT, FORTY_NINE,
        FIFTY, FIFTY_ONE, FIFTY_TWO, FIFTY_THREE, FIFTY_FOUR,
        FIFTY_FIVE, FIFTY_SIX, FIFTY_SEVEN, FIFTY_EIGHT, FIFTY_NINE,
        SIXTY, SIXTY_ONE, SIXTY_TWO, SIXTY_THREE, SIXTY_FOUR,
        SIXTY_FIVE, SIXTY_SIX, SIXTY_SEVEN, SIXTY_EIGHT, SIXTY_NINE,
        SEVENTY, SEVENTY_ONE, SEVENTY_TWO, SEVENTY_THREE, SEVENTY_FOUR,
        SEVENTY_FIVE, SEVENTY_SIX, SEVENTY_SEVEN, SEVENTY_EIGHT, SEVENTY_NINE,
        EIGHTY, EIGHTY_ONE, EIGHTY_TWO, EIGHTY_THREE, EIGHTY_FOUR,
        EIGHTY_FIVE, EIGHTY_SIX, EIGHTY_SEVEN, EIGHTY_EIGHT, EIGHTY_NINE,
        NINETY, NINETY_ONE, NINETY_TWO, NINETY_THREE, NINETY_FOUR,
        NINETY_FIVE, NINETY_SIX, NINETY_SEVEN, NINETY_EIGHT, NINETY_NINE,
        ONE_HUNDRED
    };

    public static final BigDecimal ONE_THOUSAND = new BigDecimal("1000");
    public static final BigDecimal TEN_THOUSAND = new BigDecimal("10000");
    public static final BigDecimal ONE_HUNDRED_THOUSAND =
                                                    new BigDecimal("100000");
    public static final BigDecimal ONE_MILLION = new BigDecimal("1000000");
    public static final BigDecimal TEN_MILLION = new BigDecimal("10000000");
    public static final BigDecimal ONE_HUNDRED_MILLION =
                                                    new BigDecimal("100000000");
    public static final BigDecimal ONE_BILLION = new BigDecimal("1000000000");
    public static final BigDecimal TEN_BILLION = new BigDecimal("10000000000");
    public static final BigDecimal ONE_HUNDRED_BILLION =
                                                 new BigDecimal("100000000000");
    public static final BigDecimal ONE_TRILLION =
                                                new BigDecimal("1000000000000");

    /** Equal to: <tt>0.5</tt> (1 decimal place) */
    public static final BigDecimal ONE_HALF = new BigDecimal("0.5");

    /** Equal to: <tt>0.3333333333333333333333333</tt> (25 decimal places) */
    public static final BigDecimal ONE_THIRD =
            ONE.divide(THREE, 25, BigDecimal.ROUND_HALF_UP);

    /** Equal to: <tt>0.25</tt> (2 decimal places) */
    public static final BigDecimal ONE_QUARTER = new BigDecimal("0.25");

    /** Alternate name for {@link #ONE_QUARTER} */
    public static final BigDecimal ONE_FOURTH = ONE_QUARTER;

    /** Equal to: <tt>0.2</tt> (1 decimal place) */
    public static final BigDecimal ONE_FIFTH = new BigDecimal("0.2");

    /** Equal to: <tt>0.1666666666666666666666667</tt> (25 decimal places) */
    public static final BigDecimal ONE_SIXTH =
            ONE.divide(SIX, 25, BigDecimal.ROUND_HALF_UP);

    /** Equal to: <tt>0.1428571428571428571428571</tt> (25 decimal places) */
    public static final BigDecimal ONE_SEVENTH =
            ONE.divide(SEVEN, 25, BigDecimal.ROUND_HALF_UP);

    /** Equal to: <tt>0.125</tt> (3 decimal places) */
    public static final BigDecimal ONE_EIGHTH = new BigDecimal("0.125");

    /** Equal to: <tt>0.1111111111111111111111111</tt> (25 decimal places) */
    public static final BigDecimal ONE_NINTH =
            ONE.divide(NINE, 25, BigDecimal.ROUND_HALF_UP);

    /** Equal to: <tt>0.1</tt> (1 decimal place) */
    public static final BigDecimal ONE_TENTH = new BigDecimal("0.1");

    /** Equal to: <tt>0.0909090909090909090909091</tt> (25 decimal places) */
    public static final BigDecimal ONE_ELEVENTH =
            ONE.divide(ELEVEN, 25, BigDecimal.ROUND_HALF_UP);

    /** Equal to: <tt>0.0833333333333333333333333</tt> (25 decimal places) */
    public static final BigDecimal ONE_TWELFTH =
            ONE.divide(TWELVE, 25, BigDecimal.ROUND_HALF_UP);

    /** Equal to: <tt>0.0625</tt> (4 decimal places) */
    public static final BigDecimal ONE_SIXTEENTH = new BigDecimal("0.0625");

    /** Equal to: <tt>0.01</tt> (2 decimal places) */
    public static final BigDecimal ONE_HUNDREDTH = new BigDecimal("0.01");

    /** Equal to: <tt>0.001</tt> (3 decimal places) */
    public static final BigDecimal ONE_THOUSANDTH = new BigDecimal("0.001");

    /** Equal to: <tt>0.0001</tt> (4 decimal places) */
    public static final BigDecimal ONE_TEN_THOUSANDTH =
                                                    new BigDecimal("0.0001");

    /** Equal to: <tt>0.00001</tt> (5 decimal places) */
    public static final BigDecimal ONE_MILLIONTH = new BigDecimal("0.00001");

    /** Equal to: <tt>-1</tt>*/
    public static final BigDecimal NEGATIVE_ONE = new BigDecimal("-1");

    /**
     * The character <tt>','</tt> (comma). Used here to specify that commas
     * should be used for any necessary thousand's grouping (for example:
     * <tt>12,345</tt>).
     * There is nothing special about this <tt>char</tt>; it is
     * simply defined as a constant for readability.
     */
    public static final char GROUPING_CHAR_COMMA = ',';

    /**
     * Used to indicate that "thousands" should not be separated by
     * <i>any</i> character at all (no grouping). The value of this
     * <tt>char</tt> is <tt>'\u0000'</tt>.
     */
    public static final char GROUPING_CHAR_NONE = '\u0000';

    /**
     * The character <tt>' '</tt> (space). Used here to specify that spaces
     * should be used for any necessary padding. There is nothing special
     * about this <tt>char</tt>; it is simply defined as a constant for
     * readability.
     */
    public static final char PAD_CHAR_SPACE = ' ';

    /**
     * The character <tt>'0'</tt> (zero). Used here to specify that zeros
     * should be used for any necessary padding. There is nothing special
     * about this <tt>char</tt>; it is simply defined as a constant for
     * readability.
     */
    public static final char PAD_CHAR_ZERO = '0';

    /**
     * Used to indicate that there should not be any <i>any</i> padding
     * done at all. The value of this <tt>char</tt> is <tt>'\u0000'</tt>.
     */
    public static final char PAD_CHAR_NONE = '\u0000';

    /**
     * An array of <tt>BigDecimal</tt> with a length of zero.
     */
	public static final BigDecimal[] ZERO_LEN_ARRAY = new BigDecimal[0];

	private static final int GREATEST_INTEGER_DIGIT_COUNT = 30;
    private static final int GREATEST_FRACTIONAL_DIGIT_COUNT = 15;
    private static final BigDecimal[][] MAX_POSITIVE_FOR =
        new BigDecimal[GREATEST_INTEGER_DIGIT_COUNT][];
    private static final BigDecimal[][] MIN_NEGATIVE_FOR =
        new BigDecimal[GREATEST_INTEGER_DIGIT_COUNT][];

    //private static final CharArrayPool CHAR_ARRAY_POOL = new CharArrayPool(50);

	// no instances
	private DecimalTools() {
	}

    /**
     * Compares two BigDecimals to see if they are the "same" (without
     * regard to the scales of each one). Scale is not considered, for
     * example <tt>2.0</tt> and <tt>2.00</tt> are consider to be the same
     * (see {@link BigDecimal#compareTo(BigDecimal) compareTo} on
     * <tt>BigDecimal</tt>).
     * Returns <tt>true</tt> if <tt>a</tt> is <i>the same</i> as <tt>b</tt>.
     * Specifically, they are the same if either of the following are true:
     * <ul>
     * <li><tt>( a == null ) &amp;&amp; ( b == null )</tt></li>
     * <li><tt>( a != null ) &amp;&amp; ( b != null ) &amp;&amp;
     *         ( a.compareTo(b) == 0 )</tt></li>
     * </ul>
     *
     * @param a the first number or <tt>null</tt>
     * @param b the second number or <tt>null</tt>
     *
     * @return <tt>true</tt> if the numbers numerically the same, or if both
     * parameters are <tt>null</tt>.
     */
    public static boolean isSame(BigDecimal a, BigDecimal b) {
        return ( ( a == null ) && ( b == null ) ) ||
               ( ( a != null ) && ( b != null ) && ( a.compareTo(b) == 0 ) );
    }

    /**
     * Compares two BigDecimals to see if they are "different" (without
     * regard to the scales of each one). Scale is not considered, for
     * example <tt>2.0</tt> and <tt>2.00</tt> are consider to be the same
     * (see {@link BigDecimal#compareTo(BigDecimal) compareTo} on
     * <tt>BigDecimal</tt>).
     * Returns <tt>true</tt> if <tt>a</tt> is <i>different</i> than <tt>b</tt>.
     * Specifically, they are different if any of the following are true:
     * <ul>
     * <li><tt>( a == null ) &amp;&amp; ( b != null )</tt></li>
     * <li><tt>( a != null ) &amp;&amp; ( b == null )</tt></li>
     * <li><tt>( a != null ) &amp;&amp; ( b != null ) &amp;&amp;
     *         ( a.compareTo(b) != 0 )</tt></li>
     * </ul>
     *
     * @param a the first number or <tt>null</tt>
     * @param b the second number or <tt>null</tt>
     *
     * @return <tt>true</tt> if the numbers differ by more than just scale,
     * or if only one of them is <tt>null</tt>.
     */
    public static boolean isDifferent(BigDecimal a, BigDecimal b) {
        return !isSame(a, b);
    }

    private static void checkNull(BigDecimal val, String varName)
            throws IllegalArgumentException {

        if ( val == null ) {
            throw new IllegalArgumentException("Parameter '" + varName +
                "' must not be null.");
        }
    }

    private static void checkNull(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        checkNull(a, "a");
        checkNull(b, "b");
    }

    /**
     * Returns true if <tt>a</tt> is numerically equal to <tt>b</tt> (with
     * no regard to scale).
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static boolean equalTo(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        checkNull(a, b);
        return a.compareTo(b) == 0;
    }

    /**
     * Returns true if <tt>a</tt> is numerically not equal to <tt>b</tt> (with
     * no regard to scale).
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static boolean notEqualTo(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        checkNull(a, b);
        return a.compareTo(b) != 0;
    }

    /**
     * Returns true if <tt>a</tt> is numerically less than <tt>b</tt> (with
     * no regard to scale).
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static boolean lessThan(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        checkNull(a, b);
        return a.compareTo(b) < 0;
    }

    /**
     * Returns true if <tt>a</tt> is numerically less than or equal to
     * <tt>b</tt> (with no regard to scale).
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static boolean lessThanOrEqualTo(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        checkNull(a, b);
        return a.compareTo(b) <= 0;
    }

    /**
     * Returns true if <tt>a</tt> is numerically greater than <tt>b</tt> (with
     * no regard to scale).
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static boolean greaterThan(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        checkNull(a, b);
        return a.compareTo(b) > 0;
    }

    /**
     * Returns true if <tt>a</tt> is numerically greater than or equal to
     * <tt>b</tt> (with no regard to scale).
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static boolean greaterThanOrEqualTo(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        checkNull(a, b);
        return a.compareTo(b) >= 0;
    }

    /**
     * Returns true if <tt>a</tt> is numerically not less than
     * <tt>b</tt> (with no regard to scale). This is the same as saying:
     * returns true if <tt>a</tt> is numerically greater than or equal to
     * <tt>b</tt>.
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static boolean notLessThan(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        return greaterThanOrEqualTo(a, b);
    }

    /**
     * Returns true if <tt>a</tt> is numerically not greater than
     * <tt>b</tt> (with no regard to scale). This is the same as saying:
     * returns true if <tt>a</tt> is numerically less than or equal to
     * <tt>b</tt>.
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static boolean notGreaterThan(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        return lessThanOrEqualTo(a, b);
    }

    /**
     * Returns the numerically <i>larger</i> of <tt>a</tt> and <tt>b</tt>
     * (with no regard to scale). If they are numerically equal,
     * then <tt>a</tt> is returned.
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static BigDecimal max(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        return ( greaterThanOrEqualTo(a, b) ) ? a : b;
    }

    /**
     * Returns the numerically <i>largest</i> of <tt>a</tt>, <tt>b</tt>
     * and <tt>c</tt> (with no regard to scale).
     * If they are numerically equal, then <tt>a</tt> is returned.
     *
     * @throws IllegalArgumentException if either <tt>a</tt>, <tt>b</tt>,
     * or <tt>c</tt> is <tt>null</tt>.
     */
    public static BigDecimal max(BigDecimal a, BigDecimal b, BigDecimal c)
            throws IllegalArgumentException {

        return max(max(a, b), c);
    }

    /**
     * Returns the numerically <i>smaller</i> of <tt>a</tt> and <tt>b</tt>
     * (with no regard to scale). If they are numerically equal,
     * then <tt>a</tt> is returned.
     *
     * @throws IllegalArgumentException if either <tt>a</tt> or <tt>b</tt>
     * is <tt>null</tt>.
     */
    public static BigDecimal min(BigDecimal a, BigDecimal b)
            throws IllegalArgumentException {

        return ( lessThanOrEqualTo(a, b) ) ? a : b;
    }

    /**
     * Returns the numerically <i>smallest</i> of <tt>a</tt>, <tt>b</tt>
     * and <tt>c</tt> (with no regard to scale).
     * If they are numerically equal, then <tt>a</tt> is returned.
     *
     * @throws IllegalArgumentException if either <tt>a</tt>, <tt>b</tt>,
     * or <tt>c</tt> is <tt>null</tt>.
     */
    public static BigDecimal min(BigDecimal a, BigDecimal b, BigDecimal c)
            throws IllegalArgumentException {

        return min(min(a, b), c);
    }

    /**
     * Bounds <tt>value</tt> to the specified range. If <tt>value</tt> is
     * less than <tt>minValue</tt> then <tt>minValue</tt> is returned.
     * If <tt>value</tt> is greater than <tt>maxValue</tt> then
     * <tt>maxValue</tt> is returned. Scale is not considered.
     *
     * @throws IllegalArgumentException if any of <tt>minValue</tt>,
     * <tt>value</tt>, or <tt>maxValue</tt> is <tt>null</tt>.
     */
    public static BigDecimal rangeBound(BigDecimal minValue,
                                        BigDecimal value,
                                        BigDecimal maxValue)
                                    throws IllegalArgumentException {

        return min(max(minValue, value), maxValue);
    }

    /**
     * Returns true if <tt>val</tt> is numerically equal to
     * {@link #ZERO} (with no regard to scale).
     *
     * @throws IllegalArgumentException if <tt>val</tt> is <tt>null</tt>.
     */
    public static boolean isZero(BigDecimal val)
            throws IllegalArgumentException {

        checkNull(val, "val");
        return val.signum() == 0;
    }

    /**
     * Returns true if <tt>val</tt> is numerically not equal to
     * {@link #ZERO} (with no regard to scale).
     *
     * @throws IllegalArgumentException if <tt>val</tt> is <tt>null</tt>.
     */
    public static boolean isNotZero(BigDecimal val)
            throws IllegalArgumentException {

        checkNull(val, "val");
        return val.signum() != 0;
    }

    /**
     * Returns true if <tt>val</tt> is negative (numerically less than
     * {@link #ZERO}).
     *
     * @throws IllegalArgumentException if <tt>val</tt> is <tt>null</tt>.
     */
    public static boolean isNegative(BigDecimal val)
            throws IllegalArgumentException {

        checkNull(val, "val");
        return val.signum() < 0;
    }

    /**
     * Returns true if <tt>val</tt> is non-negative (numerically greater than
     * or equal to {@link #ZERO}).
     *
     * @throws IllegalArgumentException if <tt>val</tt> is <tt>null</tt>.
     */
    public static boolean isNotNegative(BigDecimal val)
            throws IllegalArgumentException {

        return !isNegative(val);
    }

    /**
     * Returns true if <tt>val</tt> is positive (numerically greater than
     * {@link #ZERO}). Note that zero is <i>not</i> considered to be a
     * positive number.
     *
     * @throws IllegalArgumentException if <tt>val</tt> is <tt>null</tt>.
     */
    public static boolean isPositive(BigDecimal val)
            throws IllegalArgumentException {

        checkNull(val, "val");
        return val.signum() > 0;
    }

    /**
     * Returns true if <tt>val</tt> is non-positive (numerically less than
     * or equal to {@link #ZERO}).
     * Note that zero is <i>not</i> considered to be a positive number.
     *
     * @throws IllegalArgumentException if <tt>val</tt> is <tt>null</tt>.
     */
    public static boolean isNotPositive(BigDecimal val)
            throws IllegalArgumentException {

        return !isPositive(val);
    }

    /**
     * Returns true if the specified BigDecimal is either null <i>or</i> zero.
     */
   	public static boolean isEmpty(BigDecimal val) {
        return (val == null) || isZero(val);
	}

    /**
     * Returns true if the specified BigDecimal is not null <i>and</i>
     * is not equal to zero.
     */
   	public static boolean isNotEmpty(BigDecimal val) {
        return !isEmpty(val);
	}

    public static BigDecimal[] toArray(Collection<BigDecimal> bigDecimals) {
        return bigDecimals.toArray(ZERO_LEN_ARRAY);
    }

    /**
     * Permissively parses the passed <tt>String</tt> into a {@link Value}
     * that if not empty, wraps an instance of {@link BigDecimal}.
     * Parses the passed string by <i>ignoring</i> all characters not in the
     * set <tt>{0, 1, 2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,. , -}</tt>. The negative
     * sign <tt>'-'</tt> is ignored if it is not the first valid
     * character; and only the first decimal point <tt>'.'</tt> is kept, any
     * additional decimal points are ignored. There is no need to trim any
     * whitespace before calling this method as none of the whitespace
     * characters are in the valid set of characters listed above (in fact,
     * pre-trimming of whitespace is likely to be less efficient than
     * allowing this method to do the whitespace trimming).
     * <p>
     * Calling the {@link Value#getBigDecimal() getBigDecimal()} method
     * on the returned <tt>Value</tt> is inexpensive (the reference to
     * the wrapped <tt>BigDecimal</tt> created during parsing is simply
     * returned&mdash;no new object is created and no parsing need be done).
     * <p>
     * If <tt>null</tt> is passed in, then
     * {@link ValueFactory#NULL_INSTANCE ValueFactory.NULL_INSTANCE} is
     * returned. <tt>NULL_INSTANCE</tt> always returns <tt>true</tt> for
     * {@link Value#isEmpty() isEmpty()} and for
     * {@link Value#isNull() isNull()}; and returns <tt>false</tt> for
     * {@link Value#isNumeric() isNumeric()}.
     * <p>
     * If a zero-length <tt>String</tt>, a <tt>String</tt>
     * containing only whitespace, or a <tt>String</tt> that contains
     * no valid characters is passed in, then
     * {@link ValueFactory#ZERO_LEN_STRING_INSTANCE
     * ValueFactory.ZERO_LEN_STRING_INSTANCE} is returned.
     * <tt>ZERO_LEN_STRING_INSTANCE</tt> always returns <tt>true</tt> for
     * {@link Value#isEmpty() isEmpty()}; and returns <tt>false</tt> for
     * {@link Value#isNull() isNull()} and for
     * {@link Value#isNumeric() isNumeric()}.
     *
     * @param source to be parsed
     * @return the resulting {@link Value}.
     *
     * @see #parseBigDecimal(String)
     * @see StringTools#winnowDecimal(String)
     */
    public static Value parseValue(String source) {
        if ( source == null ) {
            return ValueFactory.NULL_INSTANCE;
        }

        String parsedSource = StringTools.winnowDecimal(source);

        if ( StringTools.isEmpty(parsedSource) ) {
            return ValueFactory.ZERO_LEN_STRING_INSTANCE;
        }

        return ValueFactory.create(new BigDecimal(parsedSource));
    }

    /**
     * Permissively parses the passed <tt>String</tt> into a {@link BigDecimal}.
     * Parses the passed string by <i>ignoring</i> all characters not in the
     * set <tt>{0, 1, 2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,. , -}</tt>. The negative
     * sign <tt>'-'</tt> is ignored if it is not the first valid
     * character; and only the first decimal point <tt>'.'</tt> is kept, any
     * additional decimal points are ignored. There is no need to trim any
     * whitespace before calling this method as none of the whitespace
     * characters are in the valid set of characters listed above (in fact,
     * pre-trimming of whitespace is likely to be less efficient than
     * allowing this method to do the whitespace trimming).
     * <p>
     * If <tt>null</tt>, a zero-length <tt>String</tt>, a <tt>String</tt>
     * containing only whitespace, or a <tt>String</tt> that contains
     * no valid characters is passed in, then
     * a {@link ValueException} is thrown.
     *
     * @param source to be parsed
     * @return the resulting <tt>BigDecimal</tt>.
     * @exception ValueException if the parsing fails. <tt>ValueException</tt>
     * is a {@link RuntimeException} and is not <i>required</i> to be caught.
     *
     * @see #parseBigDecimal(String, BigDecimal)
     * @see #parseValue(String)
     * @see StringTools#winnowDecimal(String)
     */
    public static BigDecimal parseBigDecimal(String source)
            throws ValueException {

        try {
            if ( source == null ) {
                throw new ValueException(
                    "Can not parse a BigDecimal from null");
            }

            String parsedSource = StringTools.winnowDecimal(source);

            if ( StringTools.isEmpty(parsedSource) ) {
                throw new ValueException("Can not parse a BigDecimal from " +
                    StringTools.quoteWrap(source));
            }

            return new BigDecimal(parsedSource);
        } catch ( ValueException x ) {
            throw x;
        } catch ( Exception x ) {
            throw new ValueException(x);
        }
    }

    /**
     * Permissively parses the passed <tt>String</tt> into a {@link BigDecimal}.
     * Parses the passed string by <i>ignoring</i> all characters not in the
     * set <tt>{0, 1, 2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,. , -}</tt>. The negative
     * sign <tt>'-'</tt> is ignored if it is not the first valid
     * character; and only the first decimal point <tt>'.'</tt> is kept, any
     * additional decimal points are ignored. There is no need to trim any
     * whitespace before calling this method as none of the whitespace
     * characters are in the valid set of characters listed above (in fact,
     * pre-trimming of whitespace is likely to be less efficient than
     * allowing this method to do the whitespace trimming).
     * <p>
     * If <tt>null</tt>, a zero-length <tt>String</tt>, a <tt>String</tt>
     * containing only whitespace, or a <tt>String</tt> that contains
     * no valid characters is passed in, then the specified
     * <tt>defaultValue</tt> is returned.
     *
     * @param source to be parsed
     * @param defaultValue the value to return if parsing does not find
     * any valid characters.
     * @return the resulting <tt>BigDecimal</tt>, or the specified
     * <tt>defaultValue</tt>.
     *
     * @see #parseBigDecimal(String)
     * @see StringTools#winnowDecimal(String)
     */
    public static BigDecimal parseBigDecimal(String source,
                                             BigDecimal defaultValue) {

        try {
            if ( source == null ) {
                return defaultValue;
            }

            String parsedSource = StringTools.winnowDecimal(source);

            if ( StringTools.isEmpty(parsedSource) ) {
                return defaultValue;
            }

            return new BigDecimal(parsedSource);
        } catch ( Exception x ) {
            return defaultValue;
        }
    }

    /**
     * Permissively parses the passed <tt>String</tt> into a <tt>double</tt>.
     * Parses the passed string by <i>ignoring</i> all characters not in the
     * set <tt>{0, 1, 2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,. , -}</tt>. The negative
     * sign <tt>'-'</tt> is ignored if it is not the first valid
     * character; and only the first decimal point <tt>'.'</tt> is kept, any
     * additional decimal points are ignored. There is no need to trim any
     * whitespace before calling this method as none of the whitespace
     * characters are in the valid set of characters listed above (in fact,
     * pre-trimming of whitespace is likely to be less efficient than
     * allowing this method to do the whitespace trimming).
     * <p>
     * If <tt>null</tt>, a zero-length <tt>String</tt>, a <tt>String</tt>
     * containing only whitespace, or a <tt>String</tt> that contains
     * no valid characters is passed in, then
     * a {@link ValueException} is thrown.
     *
     * @param source to be parsed
     * @return the resulting <tt>double</tt>.
     * @exception ValueException if the parsing fails. <tt>ValueException</tt>
     * is a {@link RuntimeException} and is not <i>required</i> to be caught.
     *
     * @see #parseDouble(String, double)
     * @see #parseValue(String)
     * @see StringTools#winnowDecimal(String)
     */
    public static double parseDouble(String source) throws ValueException {
        try {
            if ( source == null ) {
                throw new ValueException(
                    "Can not parse a double from null");
            }

            String parsedSource = StringTools.winnowDecimal(source);

            if ( StringTools.isEmpty(parsedSource) ) {
                throw new ValueException("Can not parse a double from " +
                    StringTools.quoteWrap(source));
            }

            return Double.parseDouble(parsedSource);
        } catch ( ValueException x ) {
            throw x;
        } catch ( Exception x ) {
            throw new ValueException(x);
        }
    }

    /**
     * Permissively parses the passed <tt>String</tt> into a <tt>double</tt>.
     * Parses the passed string by <i>ignoring</i> all characters not in the
     * set <tt>{0, 1, 2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,. , -}</tt>. The negative
     * sign <tt>'-'</tt> is ignored if it is not the first valid
     * character; and only the first decimal point <tt>'.'</tt> is kept, any
     * additional decimal points are ignored. There is no need to trim any
     * whitespace before calling this method as none of the whitespace
     * characters are in the valid set of characters listed above (in fact,
     * pre-trimming of whitespace is likely to be less efficient than
     * allowing this method to do the whitespace trimming).
     * <p>
     * If <tt>null</tt>, a zero-length <tt>String</tt>, a <tt>String</tt>
     * containing only whitespace, or a <tt>String</tt> that contains
     * no valid characters is passed in, then the specified
     * <tt>defaultValue</tt> is returned.
     *
     * @param source to be parsed
     * @param defaultValue the value to return if parsing does not find
     * any valid characters.
     * @return the resulting <tt>double</tt>, or the specified
     * <tt>defaultValue</tt>.
     *
     * @see #parseDouble(String)
     * @see StringTools#winnowDecimal(String)
     */
    public static double parseDouble(String source,
                                     double defaultValue) {

        try {
            if ( source == null ) {
                return defaultValue;
            }

            String parsedSource = StringTools.winnowDecimal(source);

            if ( StringTools.isEmpty(parsedSource) ) {
                return defaultValue;
            }

            return Double.parseDouble(parsedSource);
        } catch ( Exception x ) {
            return defaultValue;
        }
    }

    /**
     * Converts the specified value to a <tt>BigDecimal</tt> returning
     * one of the shared, common, immutable instances if possible.
     */
    public static BigDecimal convert(int value) {
        if ( 0 <= value && value < COMMON_LIST.length ) {
            return COMMON_LIST[value];
        } else {
            return BigDecimal.valueOf(value);
        }
    }

    /**
     * Converts the specified value to a <tt>BigDecimal</tt> returning
     * one of the shared, common, immutable instances if possible.
     */
    public static BigDecimal convert(long value) {
        if ( 0 <= value && value < COMMON_LIST.length ) {
            return COMMON_LIST[(int) value];
        } else {
            return BigDecimal.valueOf(value);
        }
    }

    /**
     * Converts the specified value to a <tt>BigDecimal</tt> returning
     * one of the shared, common, immutable instances if possible.
     */
    public static BigDecimal convert(Number value) {
        if ( value instanceof Integer ) {
            return convert(value.intValue());
        } else if ( value instanceof Long ) {
            return convert(value.longValue());
        } else {
            return new BigDecimal(value.toString());
        }
    }

    /**
     * Returns <tt>value</tt> rounded to the nearest multiple of the specified
     * value <tt>nearest</tt>. Result has a scale of <tt>nearest.scale()</tt>.
     * If necessary, the specified <tt>roundingMode</tt> is used (the valid
     * rounding modes are defined in {@link BigDecimal}).
     */
    public static BigDecimal round(BigDecimal value,
                                   BigDecimal nearest,
                                   int roundingMode) {

        return value.divide(nearest, 0, roundingMode).multiply(nearest);
    }

    /**
     * Equivalent to: <tt>round(value, nearest, BigDecimal.ROUND_HALF_UP)</tt>
     */
    public static BigDecimal round(BigDecimal value,
                                   BigDecimal nearest) {

        return round(value, nearest, BigDecimal.ROUND_HALF_UP);
    }

    /**
     * Rounds to the nearest <tt>1</tt> (nearest integer).
     * Result has a scale of <tt>0</tt>. If <tt>value</tt> already has a
     * scale of <tt>0</tt>, then <tt>value</tt> is simply (and efficiently)
     * returned.
     * If necessary, {@link BigDecimal#ROUND_HALF_UP} is used.
     */
    public static BigDecimal round(BigDecimal value) {
        int currentScale = value.scale();
        if ( currentScale == 0 ) {
            return value;
        } else {
            return round(value, ONE);
        }
    }

    /**
     * Rounds to the nearest <tt>0.1</tt>.
     * Result has a scale of <tt>1</tt>. If <tt>value</tt> already has a
     * scale of <tt>1</tt>, then <tt>value</tt> is simply (and efficiently)
     * returned.
     * If necessary, {@link BigDecimal#ROUND_HALF_UP} is used.
     */
    public static BigDecimal roundTenth(BigDecimal value) {
        int currentScale = value.scale();
        if ( currentScale == 1 ) {
            return value;
        } else if ( currentScale < 1 ) {
            return value.setScale(1);
        } else {
            return round(value, ONE_TENTH);
        }
    }

    /**
     * Rounds to the nearest <tt>0.01</tt>.
     * Result has a scale of <tt>2</tt>. If <tt>value</tt> already has a
     * scale of <tt>2</tt>, then <tt>value</tt> is simply (and efficiently)
     * returned.
     * If necessary, {@link BigDecimal#ROUND_HALF_UP} is used.
     */
    public static BigDecimal roundHundredth(BigDecimal value) {
        int currentScale = value.scale();
        if ( currentScale == 2 ) {
            return value;
        } else if ( currentScale < 2 ) {
            return value.setScale(2);
        } else {
            return round(value, ONE_HUNDREDTH);
        }
    }

    /**
     * Rounds to the nearest <tt>0.001</tt>.
     * Result has a scale of <tt>3</tt>. If <tt>value</tt> already has a
     * scale of <tt>3</tt>, then <tt>value</tt> is simply (and efficiently)
     * returned.
     * If necessary, {@link BigDecimal#ROUND_HALF_UP} is used.
     */
    public static BigDecimal roundThousandth(BigDecimal value) {
        int currentScale = value.scale();
        if ( currentScale == 3 ) {
            return value;
        } else if ( currentScale < 3 ) {
            return value.setScale(3);
        } else {
            return round(value, ONE_THOUSANDTH);
        }
    }

    /**
     * Rounds to the nearest <tt>1/16</tt> (multiple of <tt>0.0625</tt>).
     * Result has a scale of <tt>4</tt>.
     * If necessary, {@link BigDecimal#ROUND_HALF_UP} is used.
     */
    public static BigDecimal roundSixteenth(BigDecimal value) {
        return round(value, ONE_SIXTEENTH);
    }

    /**
     * Rounds to the nearest <tt>1/8</tt> (multiple of <tt>0.125</tt>).
     * Result has a scale of <tt>3</tt>.
     * If necessary, {@link BigDecimal#ROUND_HALF_UP} is used.
     */
    public static BigDecimal roundEighth(BigDecimal value) {
        return round(value, ONE_EIGHTH);
    }

    /**
     * Rounds to the nearest <tt>1/4</tt> (multiple of <tt>0.25</tt>).
     * Result has a scale of <tt>2</tt>.
     * If necessary, {@link BigDecimal#ROUND_HALF_UP} is used.
     */
    public static BigDecimal roundQuarter(BigDecimal value) {
        return round(value, ONE_QUARTER);
    }

    /**
     * Rounds to the nearest <tt>1/2</tt> (multiple of <tt>0.5</tt>).
     * Result has a scale of <tt>1</tt>.
     * If necessary, {@link BigDecimal#ROUND_HALF_UP} is used.
     */
    public static BigDecimal roundHalf(BigDecimal value) {
        return round(value, ONE_HALF);
    }

    /**
     * Same as {@link #roundHundredth(BigDecimal)}. This method exists to
     * enhance readability when US currency is being used.
     */
    public static BigDecimal roundPenny(BigDecimal value) {
        return roundHundredth(value);
    }

    /**
     * Same as {@link #round(BigDecimal)} (nearest integer).
     * This method exists to enhance readability when US currency is being used.
     */
    public static BigDecimal roundDollar(BigDecimal value) {
        return round(value);
    }

    /**
     * Returns the sum of all of the values in the array passed in.
     * If any slot in the array is <tt>null</tt>, then that slot is
     * ignored (skipped).
     *
     * @param val values to total up.
     * @return the sum of all the values. Zero is returned if <tt>val</tt>
     * is empty (<tt>null</tt> or zero-length).
     * @see NumberTools#sum(int[])
     * @see NumberTools#sum(double[])
     */
    public static BigDecimal sum(BigDecimal[] val) {
        if ( ObjectTools.isEmpty(val) ) {
            return ZERO;
        }

        BigDecimal sum = ZERO;
        for ( int i = 0; i < val.length; i++ ) {
            if ( val[i] != null ) {
                sum = sum.add(val[i]);
            }
        }

        return sum;
    }

    /**
     * Returns the largest positive value than can fit into the specified
     * number of integer and fractional digits (all nines).
     *
     * @param integerDigitCount the number of digits to the left of the decimal
     * decimal point.
     * @param fractionalDigitCount the number of digits to the right of the
     * decimal point.
     * @return the largest positive value
     */
    public static BigDecimal getMaxValueFor(int integerDigitCount,
                                            int fractionalDigitCount) {

        return getValueFor(integerDigitCount, fractionalDigitCount, true);
    }

    /**
     * Returns the most negative value than can fit into the specified
     * number of integer and fractional digits (all nines preceded by
     * a minus sign).
     *
     * @param integerDigitCount the number of digits to the left of the decimal
     * decimal point.
     * @param fractionalDigitCount the number of digits to the right of the
     * decimal point.
     * @return the most negative value
     */
    public static BigDecimal getMinValueFor(int integerDigitCount,
                                            int fractionalDigitCount) {

        return getValueFor(integerDigitCount, fractionalDigitCount, false);
    }

    private static BigDecimal getValueFor(int integerDigitCount,
                                          int fractionalDigitCount,
                                          boolean seekingMax) {

        if ( integerDigitCount < 1 || fractionalDigitCount < 0 ) {
            throw new IllegalArgumentException(
                "The integerDigitCount (specified as " +
                integerDigitCount +
                ") must be greater than or equal to one, " +
                "and the fractionalDigitCount (specified as " +
                fractionalDigitCount +
                ") must be greater than or equal to zero.");
        }

        if ( integerDigitCount >= GREATEST_INTEGER_DIGIT_COUNT ||
             fractionalDigitCount >= GREATEST_FRACTIONAL_DIGIT_COUNT ) {

            BigDecimal max = calcMaxPositiveFor(
                integerDigitCount, fractionalDigitCount);

            return (seekingMax) ? max : max.negate();
        }

        synchronized ( MAX_POSITIVE_FOR ) {
            if ( MAX_POSITIVE_FOR[integerDigitCount] == null ) {
                MAX_POSITIVE_FOR[integerDigitCount] =
                    new BigDecimal[GREATEST_FRACTIONAL_DIGIT_COUNT];

                MIN_NEGATIVE_FOR[integerDigitCount] =
                    new BigDecimal[GREATEST_FRACTIONAL_DIGIT_COUNT];
            }

            if ( seekingMax ) {
                BigDecimal max =
                    MAX_POSITIVE_FOR[integerDigitCount][fractionalDigitCount];

                if ( max == null ) {
                    max = calcMaxPositiveFor(
                        integerDigitCount, fractionalDigitCount);

                    MAX_POSITIVE_FOR[integerDigitCount][fractionalDigitCount] =
                        max;

                    MIN_NEGATIVE_FOR[integerDigitCount][fractionalDigitCount] =
                        max.negate();
                }

                return max;
            } else {
                BigDecimal min =
                    MIN_NEGATIVE_FOR[integerDigitCount][fractionalDigitCount];

                if ( min == null ) {
                    BigDecimal bd = calcMaxPositiveFor(
                        integerDigitCount, fractionalDigitCount);
                    min = bd.negate();

                    MAX_POSITIVE_FOR[integerDigitCount][fractionalDigitCount] =
                        bd;

                    MIN_NEGATIVE_FOR[integerDigitCount][fractionalDigitCount] =
                        min;
                }

                return min;
            }
        }
    }

    private static BigDecimal calcMaxPositiveFor(int integerDigitCount,
                                                 int fractionalDigitCount) {

        StringBuffer sb = new StringBuffer(50);

        for ( int i = 0; i < integerDigitCount; i++ ) {
            sb.append("9");
        }

        if ( fractionalDigitCount > 0 ) {
            sb.append(".");

            for ( int i = 0; i < fractionalDigitCount; i++ ) {
                sb.append("9");
            }
        }

        return new BigDecimal(sb.toString());
    }

    public static String format(BigDecimal value,
                                int integerDigitCount,
                                char integerPaddingChar,
                                int fractionalDigitCount,
                                char fractionalPaddingChar,
                                char thousandGroupingChar) {

        if ( value == null ) {
            return StringTools.ZERO_LEN_STRING;
        }

        int valueScale = value.scale();
        if ( valueScale < 0 ) {
            value = value.setScale(0, BigDecimal.ROUND_HALF_UP);
            valueScale = 0;
        }

        if ( valueScale > fractionalDigitCount ) {
            value = value.setScale(
                fractionalDigitCount, BigDecimal.ROUND_HALF_UP);
            valueScale = fractionalDigitCount;
        }

        DecimalFormat df = new DecimalFormat("#,###.0",
            new DecimalFormatSymbols(Locale.US));
        df.setMaximumIntegerDigits(integerDigitCount);
        if ( fractionalDigitCount > 0 ) {
            df.setMinimumIntegerDigits(1);
        }

        df.setMinimumFractionDigits(fractionalDigitCount);
        df.setMaximumFractionDigits(fractionalDigitCount);
        return df.format(value);

//        String valStr = value.toPlainString();
//        int decimalIndex = valStr.indexOf('.');
//        if ( decimalIndex < 0 ) {
//            decimalIndex = valStr.length();
//            valStr = valStr + ".";
//        }

        // TODO - look into some memory efficiency here...
//
//        boolean negative = isNegative(value);
//        boolean useGrouping =(thousandGroupingChar != GROUPING_CHAR_NONE);
//        boolean useIntPadding = (integerPaddingChar != PAD_CHAR_NONE);
//        boolean useFractionPadding = (fractionalPaddingChar != PAD_CHAR_NONE);
//
//        char[] digit = value.unscaledValue().abs().toString().toCharArray();
//
//
//        /*
//        char[] wholeDigit = new char[0];
//        char[] fractionDigit = new char[0];
//
//        if ( fractionalDigitCount < 1 ) {
//            // whole number
//            wholeDigit = digit;
//        } else if ( digit.length > valueScale ) {
//            // int and fact parts exist
//            wholeDigit = System.a
//        } else {
//            // -1.0 < x < 1.0  -> no integer digits
//            wholeDigit = new char[] { '0' };
//            fractionDigit = digit;
//        }
//        */
//
//        /*
//        int sigIntDigitCount = digit.length - valueScale;
//        if ( sigIntDigitCount > integerDigitCount ) {
//            throw new IllegalArgumentException("Too large a number to fit");
//        }
//
//        if ( sigIntDigitCount < 1 ) {
//            int prefixZerosNeeded = valueScale - digit.length + 1;
//            StringBuffer sb = new StringBuffer();
//            for ( int i = 0; i < prefixZerosNeeded; i++ ) {
//
//            }
//
//            // FIXME
//            throw new RuntimeException("not yet implemented");
//        }
//
//        int commaCount = 0;
//        if ( useGrouping ) {
//            if ( useIntPadding ) {
//                commaCount += integerDigitCount / 3;
//            } else {
//                commaCount += sigIntDigitCount / 3;
//            }
//        }
//        */
//
//        CharArray charArray = CHAR_ARRAY_POOL.checkOut();
//        try {
//            /*
//            // FIXME
//            //return new String(charArray.data, 0, width);
//            int intPortionLength =
//                ((negative) ? 1 : 0) +
//                ((useIntPadding) ? integerDigitCount : sigIntDigitCount) +
//                commaCount;
//
//                */
//            char[] dst = charArray.data;
//            int startPtr = 1024;
//            int endPtr = 1024;
//
////            startPtr--;
////            dst[startPtr] = '.';
//
//            if ( fractionalDigitCount < 1 ) {
//                // whole number
//                int subCount = 0;
//                for ( int i = digit.length - 1; i >= 0; i-- ) {
//                    if ( thousandGroupingChar != GROUPING_CHAR_NONE &&
//                         subCount == 3 ) {
//
//                        subCount = 0;
//                        startPtr--;
//                        dst[startPtr] = thousandGroupingChar;
//                    }
//
//                    startPtr--;
//                    dst[startPtr] = digit[i];
//                    subCount++;
//                }
//
//                if ( integerPaddingChar != PAD_CHAR_NONE ) {
//                    for ( int i = digit.length; i < integerDigitCount; i++ ) {
//                        startPtr--;
//                        dst[startPtr] = integerPaddingChar;
//                    }
//                }
//
//                return new String(dst, startPtr, endPtr - startPtr);
//            } else if ( digit.length > valueScale ) {
//                // int and fact parts exist
//            } else {
//                // -1.0 < x < 1.0  -> no integer digits
//
//            }
//
//
//        } finally {
//            CHAR_ARRAY_POOL.checkIn(charArray);
//        }
//
//
//        return null;
    }

    public static String format(BigDecimal value,
                                int integerDigitCount,
                                int fractionalDigitCount) {

        return format(value,
            integerDigitCount, PAD_CHAR_SPACE,
            fractionalDigitCount, PAD_CHAR_ZERO,
            GROUPING_CHAR_COMMA);
    }

    /*
    private static class CharArray {
        public char[] data = new char[2048];
    } // class CharArray

    private static class CharArrayPool {
        private CharArray[] fifo;
        private int head;
        private int tail;
        private int size;

        public CharArrayPool(int capacity) {
            fifo = new CharArray[capacity];
            head = 0;
            tail = 0;
            size = 0;

            for ( int i = 0; i < fifo.length; i++ ) {
                checkIn(new CharArray());
            }
        }

        public synchronized CharArray checkOut() {
            if ( size == 0 ) {
                return new CharArray();
            }

            CharArray item = fifo[head];
            fifo[head] = null;
            head = (head + 1) % fifo.length;
            size-- ;

            return item;
        }

        public synchronized void checkIn(CharArray item) {
            if ( item == null ) {
                return; // just to be silently tolerant of a null checkin
            }

            if ( size == fifo.length ) {
                // toss it out, nothing to do to 'close' this resource
                return;
            } else {
                fifo[tail] = item;
                tail = (tail + 1) % fifo.length;
                size++ ;
            }
        }
    } // class CharArrayPool
     */
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.