package com.programix.math;

import java.math.*;

import com.programix.util.*;
import com.programix.value.*;

/**
 * Various tools for working with numbers.
 * For {@link BigDecimal}, see {@link DecimalTools}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class NumberTools {
    private static final char[] DIGIT = "0123456789".toCharArray();

    private static final CharArrayPool CHAR_ARRAY_POOL = new CharArrayPool(50);

    /**
     * The character <tt>' '</tt> (space). Used here to specify that spaces
     * should be used for any necessary padding. There is nothing special
     * about this <tt>char</tt>; it is simply defined as a constant for
     * readability.
     */
    public static final char PAD_CHAR_SPACE = ' ';

    /**
     * The character <tt>'0'</tt> (zero). Used here to specify that zeros
     * should be used for any necessary padding. There is nothing special
     * about this <tt>char</tt>; it is simply defined as a constant for
     * readability.
     */
    public static final char PAD_CHAR_ZERO = '0';

    /**
     * Used to indicate that there should not be any <i>any</i> padding
     * done at all. The value of this <tt>char</tt> is <tt>'\u0000'</tt>.
     */
    public static final char PAD_CHAR_NONE = '\u0000';

    /**
     * The character <tt>','</tt> (comma). Used here to specify that commas
     * should be used for any necessary thousand's grouping (for example:
     * <tt>12,345</tt>).
     * There is nothing special about this <tt>char</tt>; it is
     * simply defined as a constant for readability.
     */
    public static final char GROUPING_CHAR_COMMA = ',';

    /**
     * Used to indicate that "thousands" should not be separated by
     * <i>any</i> character at all (no grouping). The value of this
     * <tt>char</tt> is <tt>'\u0000'</tt>.
     */
    public static final char GROUPING_CHAR_NONE = '\u0000';


    private static final BigDecimal MAX_BYTE_VALUE =
        new BigDecimal(String.valueOf(Byte.MAX_VALUE));
    private static final BigDecimal MIN_BYTE_VALUE =
        new BigDecimal(String.valueOf(Byte.MIN_VALUE));

    private static final BigDecimal MAX_SHORT_VALUE =
        new BigDecimal(String.valueOf(Short.MAX_VALUE));
    private static final BigDecimal MIN_SHORT_VALUE =
        new BigDecimal(String.valueOf(Short.MIN_VALUE));

    private static final BigDecimal MAX_INT_VALUE =
        new BigDecimal(String.valueOf(Integer.MAX_VALUE));
    private static final BigDecimal MIN_INT_VALUE =
        new BigDecimal(String.valueOf(Integer.MIN_VALUE));

    private static final BigDecimal MAX_LONG_VALUE =
        new BigDecimal(String.valueOf(Long.MAX_VALUE));
    private static final BigDecimal MIN_LONG_VALUE =
        new BigDecimal(String.valueOf(Long.MIN_VALUE));

    // no instances
    private NumberTools() {
    }

    private static long checkRange(Number num,
                                   long minLong,
                                   long maxLong,
                                   BigDecimal minBigDecimal,
                                   BigDecimal maxBigDecimal
                               ) throws RangeValueException {

        if ( num == null ) {
            throw new RangeValueException(
                "Can not determine if 'null' is in a valid range.");
        }

        if ( num instanceof Byte ||
             num instanceof Short ||
             num instanceof Integer ||
             num instanceof Long ) {

            long val = num.longValue();
            if ( minLong <= val && val <= maxLong ) {
                return val;
            } else {
                throw new RangeValueException("Number '" + num +
                    "' is not within the valid range: " + minLong +
                    ".." + maxLong);
            }
        }

        BigDecimal dec = null;
        if ( num instanceof BigDecimal ) {
            dec = (BigDecimal) num;
            dec = dec.setScale(0, BigDecimal.ROUND_HALF_UP);
        } else if ( num instanceof BigInteger) {
            dec = new BigDecimal((BigInteger) num);
        } else if ( num instanceof Double || num instanceof Float ) {
            dec = new BigDecimal(Double.toString(num.doubleValue()));
            dec = dec.setScale(0, BigDecimal.ROUND_HALF_UP);
        } else {
            // Just ask this unknown subclass of Number to be a long
            dec = new BigDecimal(String.valueOf(num.longValue()));
        }

        if ( DecimalTools.lessThanOrEqualTo(minBigDecimal, dec) &&
                DecimalTools.lessThanOrEqualTo(dec, maxBigDecimal) ) {

            return dec.longValue();
        }

        throw new RangeValueException("Number '" + num +
            "' is not within the valid range: " + minLong +
            ".." + maxLong);
    }

    private static long forceRange(Number num,
                                   long minLong,
                                   long maxLong,
                                   BigDecimal minBigDecimal,
                                   BigDecimal maxBigDecimal
            ) throws IllegalArgumentException {

        ObjectTools.paramNullCheck(num, "num");

        if ( num instanceof Byte ||
             num instanceof Short ||
             num instanceof Integer ||
             num instanceof Long ) {

            long val = num.longValue();

            if ( val < minLong ) {
                return minLong;
            } else if ( val > maxLong ) {
                return maxLong;
            }

            return val;
        }

        BigDecimal dec = null;
        if ( num instanceof BigDecimal ) {
            dec = (BigDecimal) num;
            dec = dec.setScale(0, BigDecimal.ROUND_HALF_UP);
        } else if ( num instanceof BigInteger) {
            dec = new BigDecimal((BigInteger) num);
        } else if ( num instanceof Double || num instanceof Float ) {
            dec = new BigDecimal(Double.toString(num.doubleValue()));
            dec = dec.setScale(0, BigDecimal.ROUND_HALF_UP);
        } else {
            // Just ask this unknown subclass of Number to be a long
            dec = new BigDecimal(String.valueOf(num.longValue()));
        }

        if ( DecimalTools.lessThan(dec, minBigDecimal) ) {
            return minLong;
        } else if ( DecimalTools.greaterThan(dec, maxBigDecimal) ) {
            return maxLong;
        }

        return dec.longValue();
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>byte</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up".
     *
     * @param num source to convert
     * @return the value as a <tt>byte</tt>
     * @throws RangeValueException if the value is not in the
     * valid range of values for <tt>byte</tt>.
     * <tt>RangeValueException</tt> is a subclass of {@link ValueException}
     * which is a {@link RuntimeException} and is therefore not
     * <i>required</i> to be caught.
     * @see #toByteForced(Number)
     */
    public static byte toByte(Number num) throws RangeValueException {
        if ( num instanceof Byte ) {
            return num.byteValue();
        }

        long val = checkRange(num,
            Byte.MIN_VALUE, Byte.MAX_VALUE, MIN_BYTE_VALUE, MAX_BYTE_VALUE);

        return (byte) val;
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>Byte</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up".
     * If a <tt>Byte</tt> is passed in, it is simply (and efficiently)
     * returned.
     *
     * @param num source to convert
     * @return the value as a <tt>Byte</tt>
     * @throws RangeValueException if the value is not in the
     * valid range of values for <tt>Byte</tt>.
     * <tt>RangeValueException</tt> is a subclass of {@link ValueException}
     * which is a {@link RuntimeException} and is therefore not
     * <i>required</i> to be caught.
     */
    public static Byte toByteNumber(Number num) throws RangeValueException {
        if ( num instanceof Byte ) {
            return (Byte) num;
        }

        return new Byte(toByte(num));
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>byte</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up" rule.
     * <p>
     * This method never throws {@link RangeValueException}. Instead,
     * if the rounded off number is less than {@link Byte#MIN_VALUE},
     * then {@link Byte#MIN_VALUE} is returned. Likewise,
     * if the rounded off number is greater than {@link Byte#MAX_VALUE},
     * then {@link Byte#MAX_VALUE} is returned.
     *
     * @param num source to convert
     * @return the value as an <tt>byte</tt>
     * @throws IllegalArgumentException if null is passed in
     * @see #toByte(Number)
     */
    public static byte toByteForced(Number num) throws IllegalArgumentException {
        ObjectTools.paramNullCheck(num, "num");

        if ( num instanceof Byte ) {
            return num.byteValue();
        }

        long val = forceRange(num,
            Byte.MIN_VALUE, Byte.MAX_VALUE, MIN_BYTE_VALUE, MAX_BYTE_VALUE);

        return (byte) val;
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>short</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up".
     *
     * @param num source to convert
     * @return the value as a <tt>short</tt>
     * @throws RangeValueException if the value is not in the
     * valid range of values for <tt>short</tt>.
     * <tt>RangeValueException</tt> is a subclass of {@link ValueException}
     * which is a {@link RuntimeException} and is therefore not
     * <i>required</i> to be caught.
     * @see #toShortForced(Number)
     */
    public static short toShort(Number num) throws RangeValueException {
        if ( num instanceof Short || num instanceof Byte ) {
            return num.shortValue();
        }

        long val = checkRange(num,
            Short.MIN_VALUE, Short.MAX_VALUE, MIN_SHORT_VALUE, MAX_SHORT_VALUE);

        return (short) val;
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>Short</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up".
     * If a <tt>Short</tt> is passed in, it is simply (and efficiently)
     * returned.
     *
     * @param num source to convert
     * @return the value as a <tt>Short</tt>
     * @throws RangeValueException if the value is not in the
     * valid range of values for <tt>Short</tt>.
     * <tt>RangeValueException</tt> is a subclass of {@link ValueException}
     * which is a {@link RuntimeException} and is therefore not
     * <i>required</i> to be caught.
     */
    public static Short toShortNumber(Number num) throws RangeValueException {
        if ( num instanceof Short ) {
            return (Short) num;
        }

        return new Short(toShort(num));
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>short</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up" rule.
     * <p>
     * This method never throws {@link RangeValueException}. Instead,
     * if the rounded off number is less than {@link Short#MIN_VALUE},
     * then {@link Short#MIN_VALUE} is returned. Likewise,
     * if the rounded off number is greater than {@link Short#MAX_VALUE},
     * then {@link Short#MAX_VALUE} is returned.
     *
     * @param num source to convert
     * @return the value as an <tt>short</tt>
     * @throws IllegalArgumentException if null is passed in
     * @see #toShort(Number)
     */
    public static short toShortForced(Number num)
            throws IllegalArgumentException {

        ObjectTools.paramNullCheck(num, "num");

        if ( num instanceof Short ||
             num instanceof Byte ) {

            return num.shortValue();
        }

        long val = forceRange(num,
            Short.MIN_VALUE, Short.MAX_VALUE, MIN_SHORT_VALUE, MAX_SHORT_VALUE);

        return (short) val;
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>int</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up" rule.
     *
     * @param num source to convert
     * @return the value as an <tt>int</tt>
     * @throws RangeValueException if the value is not in the
     * valid range of values for <tt>int</tt>.
     * <tt>RangeValueException</tt> is a subclass of {@link ValueException}
     * which is a {@link RuntimeException} and is therefore not
     * <i>required</i> to be caught.
     * @see #toIntForced(Number)
     */
    public static int toInt(Number num) throws RangeValueException {
        if ( num instanceof Integer ||
             num instanceof Short ||
             num instanceof Byte ) {

            return num.intValue();
        }

        long val = checkRange(num,
            Integer.MIN_VALUE, Integer.MAX_VALUE, MIN_INT_VALUE, MAX_INT_VALUE);

        return (int) val;
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>Integer</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up".
     * If a <tt>Integer</tt> is passed in, it is simply (and efficiently)
     * returned.
     *
     * @param num source to convert
     * @return the value as a <tt>Integer</tt>
     * @throws RangeValueException if the value is not in the
     * valid range of values for <tt>Integer</tt>.
     * <tt>RangeValueException</tt> is a subclass of {@link ValueException}
     * which is a {@link RuntimeException} and is therefore not
     * <i>required</i> to be caught.
     */
    public static Integer toIntegerNumber(Number num)
           throws RangeValueException {

        if ( num instanceof Integer ) {
            return (Integer) num;
        }

        return new Integer(toInt(num));
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>int</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up" rule.
     * <p>
     * This method never throws {@link RangeValueException}. Instead,
     * if the rounded off number is less than {@link Integer#MIN_VALUE},
     * then {@link Integer#MIN_VALUE} is returned. Likewise,
     * if the rounded off number is greater than {@link Integer#MAX_VALUE},
     * then {@link Integer#MAX_VALUE} is returned.
     *
     * @param num source to convert
     * @return the value as an <tt>int</tt>
     * @throws IllegalArgumentException if null is passed in
     * @see #toInt(Number)
     */
    public static int toIntForced(Number num) throws IllegalArgumentException {
        ObjectTools.paramNullCheck(num, "num");

        if ( num instanceof Integer ||
             num instanceof Short ||
             num instanceof Byte ) {

            return num.intValue();
        }

        long val = forceRange(num,
            Integer.MIN_VALUE, Integer.MAX_VALUE, MIN_INT_VALUE, MAX_INT_VALUE);

        return (int) val;
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>long</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up".
     *
     * @param num source to convert
     * @return the value as a <tt>long</tt>
     * @throws RangeValueException if the value is not in the
     * valid range of values for <tt>long</tt>.
     * <tt>RangeValueException</tt> is a subclass of {@link ValueException}
     * which is a {@link RuntimeException} and is therefore not
     * <i>required</i> to be caught.
     * @see #toLongForced(Number)
     */
    public static long toLong(Number num) throws RangeValueException {
        if ( num instanceof Long ||
             num instanceof Integer ||
             num instanceof Short ||
             num instanceof Byte ) {

            return num.longValue();
        }

        long val = checkRange(num,
            Long.MIN_VALUE, Long.MAX_VALUE, MIN_LONG_VALUE, MAX_LONG_VALUE);

        return val;
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>Long</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up".
     * If a <tt>Long</tt> is passed in, it is simply (and efficiently)
     * returned.
     *
     * @param num source to convert
     * @return the value as a <tt>Long</tt>
     * @throws RangeValueException if the value is not in the
     * valid range of values for <tt>Long</tt>.
     * <tt>RangeValueException</tt> is a subclass of {@link ValueException}
     * which is a {@link RuntimeException} and is therefore not
     * <i>required</i> to be caught.
     */
    public static Long toLongNumber(Number num) throws RangeValueException {
        if ( num instanceof Long ) {
            return (Long) num;
        }

        return new Long(toLong(num));
    }

    /**
     * Returns the value of the {@link Number} rounding off to
     * the nearest <tt>long</tt>. {@link Double}, {@link Float},
     * and {@link BigDecimal} are fine to pass in, the value
     * is rounded off using the widely used "round half up" rule.
     * <p>
     * This method never throws {@link RangeValueException}. Instead,
     * if the rounded off number is less than {@link Long#MIN_VALUE},
     * then {@link Long#MIN_VALUE} is returned. Likewise,
     * if the rounded off number is greater than {@link Long#MAX_VALUE},
     * then {@link Long#MAX_VALUE} is returned.
     *
     * @param num source to convert
     * @return the value as an <tt>long</tt>
     * @throws IllegalArgumentException if null is passed in
     * @see #toLong(Number)
     */
    public static long toLongForced(Number num) throws IllegalArgumentException {
        ObjectTools.paramNullCheck(num, "num");

        if ( num instanceof Long ||
             num instanceof Integer ||
             num instanceof Short ||
             num instanceof Byte ) {

            return num.longValue();
        }

        long val = forceRange(num,
            Long.MIN_VALUE, Long.MAX_VALUE, MIN_LONG_VALUE, MAX_LONG_VALUE);

        return val;
    }

    /**
     * Permissively parses the passed <tt>String</tt> into an <tt>int</tt>.
     * If a decimal point is present, then the source is attempted to be
     * interpretted as <tt>BigDecimal</tt> and then rounded off to
     * the nearest <tt>int</tt>. 
     * Parses the passed string by <i>ignoring</i> all characters not in the 
     * set <tt>{0, 1, 2 ,3 , 4, 5, 6, 7, 8, 9, -}</tt>. The negative
     * sign <tt>'-'</tt> is ignored if it is not the first valid
     * character; and only the first decimal point <tt>'.'</tt> is kept, any
     * additional decimal points are ignored. There is no need to trim any
     * whitespace before calling this method as none of the whitespace
     * characters are in the valid set of characters listed above.
     * <p>
     * If <tt>null</tt>, a zero-length <tt>String</tt>, a <tt>String</tt>
     * containing only whitespace, or a <tt>String</tt> that contains
     * no valid characters is passed in, then 
     * a {@link ValueException} is thrown.
     * If the resulting value is not in the range of <tt>int</tt>, then
     * a {@link RangeValueException} is thrown (which is a subclass of
     * {@link ValueException}). Both are {@link RuntimeException}'s and
     * are therefore not required to be caught.
     *   
     * @param source to be parsed
     * @return the resulting <tt>int</tt>.
     * @exception RangeValueException if the value does not fit into the value
     * range for an <tt>int</tt>. <tt>RangeValueException</tt>
     * is a {@link RuntimeException} and is not <i>required</i> to be caught
     * (it is also a subclass of {@link ValueException}).
     * @exception ValueException if the parsing fails. <tt>ValueException</tt>
     * is a {@link RuntimeException} and is not <i>required</i> to be caught.
     * 
     * @see DecimalTools#parseBigDecimal(String)
     * @see #parseInt(String)
     * @see StringTools#winnowDecimal(String)
     */
    public static int parseIntLenient(String source) 
            throws RangeValueException, ValueException {
        
        try {
            if ( source == null ) {
                throw new ValueException("Can not parse an int from null");
            }
            
            String parsedSource = StringTools.winnowDecimal(source);
            
            if ( StringTools.isEmpty(parsedSource) ) {
                throw new ValueException("Can not parse an int from " + 
                    StringTools.quoteWrap(source));
            }
            
            if ( parsedSource.indexOf('.') >= 0 || parsedSource.length() > 9 ) {
                return toInt(new BigDecimal(parsedSource));
            } else {
                return Integer.parseInt(parsedSource);
            }
        } catch ( ValueException x ) {
            throw x;
        } catch ( Exception x ) {
            throw new ValueException(x);
        }
    }

    /**
     * Returns an <tt>int</tt> derived from parsing the specified source
     * as specified by {@link #parseIntLenient(String)}.
     * If there is trouble parsing, then <tt>defaultValue</tt> 
     * is returned (no exception is thrown).
     */
    public static int parseInt(String source, int defaultValue) {
        try {
            if ( StringTools.isEmpty(source) ) {
                return defaultValue;
            }
            
            return parseIntLenient(source);
        } catch ( Exception x ) {
            return defaultValue;
        }
    }
    
    /**
     * Returns an <tt>int</tt> derived from parsing the specified source
     * as specified by {@link #parseIntLenient(String)}.
     * If there is trouble parsing, then <tt>0</tt> 
     * is returned (no exception is thrown).
     */
    public static int parseInt(String source) {
        return parseInt(source, 0);
    }
    
    /**
     * Permissively parses the passed <tt>String</tt> into a <tt>long</tt>.
     * If a decimal point is present, then the source is attempted to be
     * interpretted as <tt>BigDecimal</tt> and then rounded off to
     * the nearest <tt>long</tt>. 
     * Parses the passed string by <i>ignoring</i> all characters not in the 
     * set <tt>{0, 1, 2 ,3 , 4, 5, 6, 7, 8, 9, -}</tt>. The negative
     * sign <tt>'-'</tt> is ignored if it is not the first valid
     * character; and only the first decimal point <tt>'.'</tt> is kept, any
     * additional decimal points are ignored. There is no need to trim any
     * whitespace before calling this method as none of the whitespace
     * characters are in the valid set of characters listed above.
     * <p>
     * If <tt>null</tt>, a zero-length <tt>String</tt>, a <tt>String</tt>
     * containing only whitespace, or a <tt>String</tt> that contains
     * no valid characters is passed in, then 
     * a {@link ValueException} is thrown.
     * If the resulting value is not in the range of <tt>long</tt>, then
     * a {@link RangeValueException} is thrown (which is a subclass of
     * {@link ValueException}). Both are {@link RuntimeException}'s and
     * are therefore not required to be caught.
     *   
     * @param source to be parsed
     * @return the resulting <tt>long</tt>.
     * @exception RangeValueException if the value does not fit into the value
     * range for an <tt>long</tt>. <tt>RangeValueException</tt>
     * is a {@link RuntimeException} and is not <i>required</i> to be caught
     * (it is also a subclass of {@link ValueException}).
     * @exception ValueException if the parsing fails. <tt>ValueException</tt>
     * is a {@link RuntimeException} and is not <i>required</i> to be caught.
     * 
     * @see DecimalTools#parseBigDecimal(String)
     * @see #parseLong(String)
     * @see StringTools#winnowDecimal(String)
     */
    public static long parseLongLenient(String source) 
            throws RangeValueException, ValueException {
        
        try {
            if ( source == null ) {
                throw new ValueException("Can not parse a long from null");
            }
            
            String parsedSource = StringTools.winnowDecimal(source);
            
            if ( StringTools.isEmpty(parsedSource) ) {
                throw new ValueException("Can not parse a long from " + 
                    StringTools.quoteWrap(source));
            }
            
            if ( parsedSource.indexOf('.') >= 0 || 
                 parsedSource.length() > 16 ) {
                
                return toLong(new BigDecimal(parsedSource));
            } else {
                return Long.parseLong(parsedSource);
            }
        } catch ( ValueException x ) {
            throw x;
        } catch ( Exception x ) {
            throw new ValueException(x);
        }
    }
    
    /**
     * Returns a <tt>long</tt> derived from parsing the specified source
     * as specified by {@link #parseLongLenient(String)}.
     * If there is trouble parsing, then <tt>defaultValue</tt> 
     * is returned (no exception is thrown).
     */
    public static long parseLong(String source, long defaultValue) {
        try {
            if ( StringTools.isEmpty(source) ) {
                return defaultValue;
            }
            
            return parseLongLenient(source);
        } catch ( Exception x ) {
            return defaultValue;
        }
    }
    
    /**
     * Returns a <tt>long</tt> derived from parsing the specified source
     * as specified by {@link #parseLongLenient(String)}.
     * If there is trouble parsing, then <tt>0L</tt> 
     * is returned (no exception is thrown).
     */
    public static long parseLong(String source) {
        return parseLong(source, 0L);
    }

    /**
     * Returns a value that is <i>always</i> at least <tt>minValue</tt> and
     * at most <tt>maxValue</tt>. If <tt>value</tt> is less than
     * <tt>minValue</tt>, then <tt>minValue</tt> is returned.
     * If <tt>value</tt> is greater than <tt>maxValue</tt>,
     * then <tt>maxValue</tt> is returned.
     * If <tt>maxValue</tt> is (very strangely) <i>less</i> than
     * <tt>minValue</tt>, then <tt>maxValue</tt> will be returned.
     */
    public static int rangeBound(int minValue, int value, int maxValue) {
        return Math.min(Math.max(minValue, value), maxValue);
    }

    /**
     * Returns the smallest of the three numbers passed in.
     */
    public static int min(int a, int b, int c) {
        return Math.min(Math.min(a, b), c);
    }

    /**
     * Returns the largest of the three numbers passed in.
     */
    public static int max(int a, int b, int c) {
        return Math.max(Math.max(a, b), c);
    }

    /**
     * Formats the specified <tt>value</tt> into the specified
     * <tt>destination</tt>. The text version of the value is right-justified
     * in the destination and (if necessary) the <tt>padChar</tt> is used
     * to prefix the text to fully fill the destination.
     * If <tt>padChar</tt> is not {@link #PAD_CHAR_NONE}, then all slots in
     * the destination array are overwritten by this method.
     *
     * @param value the value to format
     * @param padChar the character to use as prefix padding if necessary.
     * @param groupingChar the character to use to group thousands if necessary.
     * @param width the space to fill with the formatted value, prefixing
     *        with the specified padding character if necessary.
     * @param destination the location to place the characters
     * @param destinationOffset the position within destination to begin
     *        placing the characters.
     *
     * @throws IllegalArgumentException if the destination <tt>char[]</tt>
     * is too small to hold the value; if the width is larger than the space
     * available; and if the offset is out-of-range.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static void format(int value,
                              char padChar,
                              char groupingChar,
                              int width,
                              char[] destination,
                              int destinationOffset)
            throws IllegalArgumentException {

        if ( destination == null ) {
            throw new IllegalArgumentException("destination must not be null");
        }

        if ( width < 1 ) {
            throw new IllegalArgumentException(
                "width [" + width + "] must be at least 1");
        }

        if ( destinationOffset < 0 ) {
            throw new IllegalArgumentException("destinationOffset [" +
                destinationOffset + "] must be at least 0");
        }

        if ( (destinationOffset + width) > destination.length ) {
            throw new IllegalArgumentException(
                "destinationOffset [" + destinationOffset +
                "] plus width [" + width + "] must be <= destination.length [" +
                destination.length + "]");
        }

        boolean useGrouping = groupingChar != GROUPING_CHAR_NONE;

        int q = value;
        boolean negativeValue = value < 0;

        int ptr = destinationOffset + width - 1;
        int digitCount = 0;
        while ( ptr >= destinationOffset ) {
            if ( useGrouping && (digitCount % 3 == 0) && (digitCount > 0) ) {
                destination[ptr] = groupingChar;
                ptr--;

                if ( ptr < destinationOffset ) {
                    throw new IllegalArgumentException(
                        "Formatted value [" + value +
                        "] does not fit into specified width of " + width +
                        " when thousands grouping char '" + groupingChar +
                        "' is used.");
                }
            }

            int idx = (negativeValue) ? -(q % 10) : q % 10;
            destination[ptr] = DIGIT[idx];

            ptr--;
            digitCount++;

            q = q / 10;

            if ( q == 0 ) {
                break;
            }
        }

        if ( q != 0 ) {
            if ( groupingChar == GROUPING_CHAR_NONE ) {
                throw new IllegalArgumentException("Formatted value [" + value +
                    "] does not fit into specified width of " + width);
            } else {
                throw new IllegalArgumentException(
                    "Formatted value [" + value +
                    "] does not fit into specified width of " + width +
                    " when thousands grouping char '" + groupingChar +
                    "' is used.");
            }
        }

        if ( value < 0 ) {
            if ( ptr >= destinationOffset ) {
                destination[ptr] = '-';
                ptr--;
            } else {
                throw new IllegalArgumentException("Formatted value [" + value +
                    "] does not fit [no room for negative sign] " +
                    "into specified width of " + width);
            }
        }

        if ( padChar != PAD_CHAR_NONE ) {
            while ( ptr >= destinationOffset ) {
                destination[ptr] = padChar;
                ptr--;
            }
        }
    }


    /**
     * Formats the specified <tt>value</tt> into the specified
     * <tt>destination</tt>. The text version of the value is right-justified
     * in the destination and (if necessary) the <tt>padChar</tt> is used
     * to prefix the text to fully fill the destination. All slots in
     * the destination array are overwritten by this method.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param padChar the character to use as prefix padding if necessary.
     * @param width the space to fill with the formatted value, prefixing
     *        with the specified padding character if necessary.
     * @param destination the location to place the characters
     * @param destinationOffset the position within destination to begin
     *        placing the characters.
     *
     * @throws IllegalArgumentException if the destination <tt>char[]</tt>
     * is too small to hold the value; if the width is larger than the space
     * available; and if the offset is out-of-range.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static void format(int value,
                              char padChar,
                              int width,
                              char[] destination,
                              int destinationOffset)
            throws IllegalArgumentException {

        format(value, padChar, GROUPING_CHAR_NONE,
            width, destination, destinationOffset);
    }
    /**
     * Formats the specified <tt>value</tt> into the specified
     * <tt>destination</tt>. The text version of the value is right-justified
     * <tt>width</tt> characters into the destination and (if necessary)
     * the <tt>padChar</tt> is used to prefix the text.
     * All the slots from index <tt>0</tt> to <tt>width - 1</tt> in
     * the destination array are overwritten by this method.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param padChar the character to use as prefix padding if necessary.
     * @param width the space to fill with the formatted value, prefixing
     *        with the specified padding character if necessary.
     * @param destination the location to place the characters
     *
     * @throws IllegalArgumentException if the destination <tt>char[]</tt>
     * is too small to hold the value; if the width is larger than the space
     * available; and if the offset is out-of-range.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static void format(int value,
                              char padChar,
                              int width,
                              char[] destination)
            throws IllegalArgumentException {

        format(value, padChar, width, destination, 0);
    }

    /**
     * Formats the specified <tt>value</tt> into the specified
     * <tt>destination</tt>. The text version of the value is right-justified
     * in the destination and (if necessary) the <tt>padChar</tt> is used
     * to prefix the text to fully fill the destination. All slots in
     * the destination array are overwritten by this method.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param padChar the character to use as prefix padding if necessary.
     * @param destination the location to place the characters
     *
     * @throws IllegalArgumentException if the destination <tt>char[]</tt>
     * is too small to hold the value.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static void format(int value,
                              char padChar,
                              char[] destination)
            throws IllegalArgumentException {

        if ( destination == null ) {
            throw new IllegalArgumentException("destination must not be null");
        }

        format(value, padChar, destination.length, destination, 0);
    }

    /**
     * Formats the specified <tt>value</tt> into a string.
     * The text version of the value is right-justified in the generated string
     * which is exactly <tt>width</tt> characters long.
     * If necessary the <tt>padChar</tt> is used to prefix the text.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param padChar the character to use as prefix padding if necessary.
     * @param width the space to fill with the formatted value, prefixing
     *        with the specified padding character if necessary.
     *
     * @throws IllegalArgumentException if the width is smaller than the space
     * needed.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static String format(int value,
                                char padChar,
                                int width)
            throws IllegalArgumentException {

        CharArray charArray = CHAR_ARRAY_POOL.checkOut();
        try {
            format(value, padChar, width, charArray.data, 0);
            return new String(charArray.data, 0, width);
        } finally {
            CHAR_ARRAY_POOL.checkIn(charArray);
        }
    }

    /**
     * Formats the specified <tt>value</tt> into a string.
     * The text version of the value is right-justified in the generated string
     * which is exactly <tt>width</tt> characters long.
     * If necessary the <tt>padChar</tt> is used to prefix the text.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param padChar the character to use as prefix padding if necessary.
     * @param width the space to fill with the formatted value, prefixing
     *        with the specified padding character if necessary.
     *
     * @throws IllegalArgumentException if the width is smaller than the space
     * needed.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static String formatComma(int value,
                                     char padChar,
                                     int width)
            throws IllegalArgumentException {

        CharArray charArray = CHAR_ARRAY_POOL.checkOut();
        try {
            format(value, padChar, GROUPING_CHAR_COMMA,
                width, charArray.data, 0);
            return new String(charArray.data, 0, width);
        } finally {
            CHAR_ARRAY_POOL.checkIn(charArray);
        }
    }

    /**
     * Formats the specified <tt>value</tt> into a string.
     * The text version of the value is right-justified in the generated string
     * which is exactly <tt>width</tt> characters long.
     * If necessary {@link #PAD_CHAR_SPACE} (the <tt>' '</tt> character)
     * is used to prefix the text.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param width the space to fill with the formatted value, prefixing
     *        with the {@link #PAD_CHAR_SPACE} padding character if necessary.
     *
     * @throws IllegalArgumentException if the width is smaller than the space
     * needed.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static String formatPadSpace(int value, int width)
            throws IllegalArgumentException {

        return format(value, PAD_CHAR_SPACE, width);
    }

    /**
     * Formats the specified <tt>value</tt> into a string.
     * The text version of the value is right-justified in the generated string
     * which is exactly <tt>width</tt> characters long.
     * If necessary {@link #PAD_CHAR_ZERO} (the <tt>'0'</tt> character)
     * is used to prefix the text.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param width the space to fill with the formatted value, prefixing
     *        with the {@link #PAD_CHAR_ZERO} padding character if necessary.
     *
     * @throws IllegalArgumentException if the width is smaller than the space
     * needed.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static String formatPadZero(int value, int width)
            throws IllegalArgumentException {

        return format(value, PAD_CHAR_ZERO, width);
    }

    /**
     * Formats the specified <tt>value</tt> into a string.
     * The text version of the value is right-justified in the generated string
     * which is exactly <tt>width</tt> characters long.
     * If necessary {@link #PAD_CHAR_SPACE} (the <tt>' '</tt> character)
     * is used to prefix the text.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param width the space to fill with the formatted value, prefixing
     *        with the {@link #PAD_CHAR_SPACE} padding character if necessary.
     *
     * @throws IllegalArgumentException if the width is smaller than the space
     * needed or if the passed <tt>Integer</tt> reference is <tt>null</tt>.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static String formatPadSpace(Integer value, int width)
            throws IllegalArgumentException {

        if ( value == null ) {
            throw new IllegalArgumentException("Passed value can not be null");
        }

        return format(value.intValue(), PAD_CHAR_SPACE, width);
    }

    /**
     * Formats the specified <tt>value</tt> into a string.
     * The text version of the value is right-justified in the generated string
     * which is exactly <tt>width</tt> characters long.
     * If necessary {@link #PAD_CHAR_ZERO} (the <tt>'0'</tt> character)
     * is used to prefix the text.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param width the space to fill with the formatted value, prefixing
     *        with the {@link #PAD_CHAR_ZERO} padding character if necessary.
     *
     * @throws IllegalArgumentException if the width is smaller than the space
     * needed or if the passed <tt>Integer</tt> reference is <tt>null</tt>.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static String formatPadZero(Integer value, int width)
            throws IllegalArgumentException {

        if ( value == null ) {
            throw new IllegalArgumentException("Passed value can not be null");
        }

        return format(value.intValue(), PAD_CHAR_ZERO, width);
    }

    /**
     * Formats the specified <tt>value</tt> and appends it to the specified
     * {@link StringBuffer}.
     * The text version of the value is right-justified in the generated string
     * which is exactly <tt>width</tt> characters long.
     * If necessary the <tt>padChar</tt> is used to prefix the text.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param padChar the character to use as prefix padding if necessary.
     * @param width the space to fill with the formatted value, prefixing
     *        with the specified padding character if necessary.
     * @param sb the destination for the formatted value.
     * @return the same <tt>StringBuffer</tt> that was passed in (for ease
     *         of method chaining if desired).
     *
     * @throws IllegalArgumentException if the width is smaller than the space
     * needed or if <tt>sb</tt> is <tt>null</tt>.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static StringBuffer format(int value,
                                      char padChar,
                                      int width,
                                      StringBuffer sb)
            throws IllegalArgumentException {

        if ( sb == null ) {
            throw new IllegalArgumentException("passed StringBuffer is null");
        }

        CharArray charArray = CHAR_ARRAY_POOL.checkOut();
        try {
            format(value, padChar, width, charArray.data, 0);
            return sb.append(charArray.data, 0, width);
        } finally {
            CHAR_ARRAY_POOL.checkIn(charArray);
        }
    }

    /**
     * Formats the specified <tt>value</tt> and appends it to the specified
     * {@link StringBuffer}.
     * The text version of the value is right-justified in the generated string
     * which is exactly <tt>width</tt> characters long.
     * If necessary {@link #PAD_CHAR_SPACE} (the <tt>' '</tt> character)
     * is used to prefix the text.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param width the space to fill with the formatted value, prefixing
     *        with the {@link #PAD_CHAR_SPACE} padding character if necessary.
     * @param sb the destination for the formatted value.
     * @return the same <tt>StringBuffer</tt> that was passed in (for ease
     *         of method chaining if desired).
     *
     * @throws IllegalArgumentException if the width is smaller than the space
     * needed or if <tt>sb</tt> is <tt>null</tt>.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static StringBuffer formatPadSpace(int value,
                                              int width,
                                              StringBuffer sb)
            throws IllegalArgumentException {

        return format(value, PAD_CHAR_SPACE, width, sb);
    }

    /**
     * Formats the specified <tt>value</tt> and appends it to the specified
     * {@link StringBuffer}.
     * The text version of the value is right-justified in the generated string
     * which is exactly <tt>width</tt> characters long.
     * If necessary {@link #PAD_CHAR_ZERO} (the <tt>'0'</tt> character)
     * is used to prefix the text.
     * No thousand grouping char is used.
     *
     * @param value the value to format
     * @param width the space to fill with the formatted value, prefixing
     *        with the {@link #PAD_CHAR_ZERO} padding character if necessary.
     * @param sb the destination for the formatted value.
     * @return the same <tt>StringBuffer</tt> that was passed in (for ease
     *         of method chaining if desired).
     *
     * @throws IllegalArgumentException if the width is smaller than the space
     * needed or if <tt>sb</tt> is <tt>null</tt>.
     * This is a {@link RuntimeException}, so callers are not
     * <i>required</i> to explicitly catch it.
     */
    public static StringBuffer formatPadZero(int value,
                                             int width,
                                             StringBuffer sb)
            throws IllegalArgumentException {

        return format(value, PAD_CHAR_ZERO, width, sb);
    }

    /**
     * Formats the specified value using a comma to groups thousands. All
     * leading and trailing whitespace is trimmed.
     */
    public static String formatComma(int value) {
        return formatComma(value, PAD_CHAR_SPACE, 20).trim();
    }

    /**
     * Returns <tt>true</tt> if either <tt>val</tt> is <tt>null</tt> or
     * <tt>val</tt> is pointing to a zero-length array.
     */
    public static boolean isEmpty(int[] val) {
        return val == null || val.length == 0;
    }

    /**
     * Returns <tt>true</tt> if <tt>val</tt> is not <tt>null</tt> and
     * <tt>val</tt> is pointing to an array with a length greater than zero.
     */
    public static boolean isNotEmpty(int[] val) {
        return !isEmpty(val);
    }

    /**
     * Returns <tt>true</tt> if either <tt>val</tt> is <tt>null</tt> or
     * <tt>val</tt> is pointing to a zero-length array.
     */
    public static boolean isEmpty(double[] val) {
        return val == null || val.length == 0;
    }

    /**
     * Returns <tt>true</tt> if <tt>val</tt> is not <tt>null</tt> and
     * <tt>val</tt> is pointing to an array with a length greater than zero.
     */
    public static boolean isNotEmpty(double[] val) {
        return !isEmpty(val);
    }

    /**
     * Returns the sum of all of the values in the array passed in.
     *
     * @param val values to total up.
     * @return the sum of all the values. Zero is returned if <tt>val</tt>
     * is empty (<tt>null</tt> or zero-length).
     * @see #sum(double[])
     * @see DecimalTools#sum(java.math.BigDecimal[])
     */
    public static int sum(int[] val) {
        if ( isEmpty(val) ) {
            return 0;
        }

        int sum = 0;
        for ( int i = 0; i < val.length; i++ ) {
            sum += val[i];
        }

        return sum;
    }

    /**
     * Returns the sum of all of the values in the array passed in.
     *
     * @param val values to total up.
     * @return the sum of all the values. Zero is returned if <tt>val</tt>
     * is empty (<tt>null</tt> or zero-length).
     * @see #sum(int[])
     * @see DecimalTools#sum(java.math.BigDecimal[])
     */
    public static double sum(double[] val) {
        if ( isEmpty(val) ) {
            return 0.0;
        }

        double sum = 0.0;
        for ( int i = 0; i < val.length; i++ ) {
            sum += val[i];
        }

        return sum;
    }

    /**
     * Distributes the excess to the items in the <tt>int[]</tt> proportional
     * to the amount that each item represents when compared to the total.
     * If the excess is a negative number, the values will be proportionally
     * shrunk.
     *
     * @param val the array to alter
     * @param excessToDistribute the amount to distribute
     */
    public static void distributeExcessProportionally(int[] val,
                                                      int excessToDistribute) {

        if ( isEmpty(val) || excessToDistribute == 0 ) {
            // nothing to do, silently ignore the request
            return;
        }

        int origSum = 0;
        for ( int i = 0; i < val.length; i++ ) {
            if ( val[i] < 0 ) {
                val[i] = 0;
            } else {
                origSum += val[i];
            }
        }

        if ( origSum == 0 ) {
            // nothing can be done with a zero denominator
            return;
        }

        boolean subtract = excessToDistribute < 0;

        double factor =
            ((double) Math.abs(excessToDistribute)) / ((double) origSum);

        double prevExactCut = 0.0;
        int prevActualCut = 0;

        for ( int i = 0; i < val.length; i++ ) {
            double idealShare = val[i] * factor;
            double currExactCut = prevExactCut + idealShare;

            // Add a tiny bit to help with the inexactness of double
            int currActualCut = (int) (currExactCut + 0.0000001);

            int actualShare = currActualCut - prevActualCut;
            if ( subtract ) {
                if ( val[i] < actualShare ) {
                    val[i] = 0;
                    currActualCut -= (actualShare - val[i]);
                } else {
                    val[i] -= actualShare;
                }
            } else {
                val[i] += actualShare;
            }

            prevExactCut = currExactCut;
            prevActualCut = currActualCut;
        }
    }

    /**
     * Returns a <tt>String</tt> with a dump of the contents of the
     * specified array.
     * The output uses the passed <tt>name</tt> when referring to the array.
     *
     * @param val the array for format. OK to pass <tt>null</tt> and OK to
     * pass a zero-length array (there will be some output).
     * @param name the name of the array to use in the output.
     * @return a <tt>String</tt> with the formatted array contents.
     */
    public static String printArray(byte[] val, String name) {
        StringBuffer sb = new StringBuffer();

        if ( val == null ) {
            sb.append(name + "=null");
        } else {
            sb.append(name + ".length=" + val.length + "{");

            for ( int i = 0; i < val.length; i++ ) {
                if ( i > 0 ) {
                    sb.append(", ");
                }

                sb.append(name + "[" + i + "]=" + val[i]);
            }

            sb.append("}");
        }

        return sb.toString();
    }

    /**
     * Returns a <tt>String</tt> with a dump of the contents of the
     * specified array.
     * The output uses the passed <tt>name</tt> when referring to the array.
     *
     * @param val the array for format. OK to pass <tt>null</tt> and OK to
     * pass a zero-length array (there will be some output).
     * @param name the name of the array to use in the output.
     * @return a <tt>String</tt> with the formatted array contents.
     */
    public static String printArray(int[] val, String name) {
        StringBuffer sb = new StringBuffer();

        if ( val == null ) {
            sb.append(name + "=null");
        } else {
            sb.append(name + ".length=" + val.length + "{");

            for ( int i = 0; i < val.length; i++ ) {
                if ( i > 0 ) {
                    sb.append(", ");
                }

                sb.append(name + "[" + i + "]=" + val[i]);
            }

            sb.append("}");
        }

        return sb.toString();
    }

    /**
     * Returns a <tt>String</tt> with a dump of the contents of the
     * specified array.
     * The output uses the passed <tt>name</tt> when referring to the array.
     *
     * @param val the array for format. OK to pass <tt>null</tt> and OK to
     * pass a zero-length array (there will be some output).
     * @param name the name of the array to use in the output.
     * @return a <tt>String</tt> with the formatted array contents.
     */
    public static String printArray(double[] val, String name) {
        StringBuffer sb = new StringBuffer();

        if ( val == null ) {
            sb.append(name + "=null");
        } else {
            sb.append(name + ".length=" + val.length + "{");

            for ( int i = 0; i < val.length; i++ ) {
                if ( i > 0 ) {
                    sb.append(", ");
                }

                sb.append(name + "[" + i + "]=" + val[i]);
            }

            sb.append("}");
        }

        return sb.toString();
    }

    private static class CharArray {
        public char[] data = new char[1024];
    } // class CharArray

    private static class CharArrayPool {
        private CharArray[] fifo;
        private int head;
        private int tail;
        private int size;

        public CharArrayPool(int capacity) {
            fifo = new CharArray[capacity];
            head = 0;
            tail = 0;
            size = 0;

            for ( int i = 0; i < fifo.length; i++ ) {
                checkIn(new CharArray());
            }
        }

        public synchronized CharArray checkOut() {
            if ( size == 0 ) {
                return new CharArray();
            }

            CharArray item = fifo[head];
            fifo[head] = null;
            head = (head + 1) % fifo.length;
            size-- ;

            return item;
        }

        public synchronized void checkIn(CharArray item) {
            if ( item == null ) {
                return; // just to be silently tolerant of a null checkin
            }

            if ( size == fifo.length ) {
                // toss it out, nothing to do to 'close' this resource
                return;
            } else {
                fifo[tail] = item;
                tail = (tail + 1) % fifo.length;
                size++ ;
            }
        }
    } // class CharArrayPool
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.