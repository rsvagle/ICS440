package com.programix.math;

import java.io.*;
import java.math.*;
import java.util.*;

import com.programix.collections.*;
import com.programix.util.*;
import com.programix.value.*;

/**
 * Immutable encapsulation of a range of decimal values as expressed by a
 * starting {@link BigDecimal} and an ending {@link BigDecimal}.
 * Either the starting value or the ending value or both can be <tt>null</tt>.
 * If you need a value span that does not need fractional information,
 * see {@link IntegerRange}.
 * <p>
 * The {@link BigDecimal} class itself and the utility
 * {@link DecimalTools} have handy utilities for formatting and parsing
 * <tt>BigDecimal</tt> instances to and from more human-readable
 * <tt>String</tt>s.
 *
 * @see DecimalTools
 * @see BigDecimal
 * @see IntegerRange
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class DecimalRange
        implements Serializable, Comparable<DecimalRange>, Cloneable {

    /**
     * This constant can be used to specify that either the start or end of of
     * the range is "open" (that is, it is not defined and can be considered to
     * stretch out to infinity).
     */
    public static final BigDecimal OPEN = null;

    /**
     * This <tt>DecimalRange</tt> has both an undefined start <i>and</i>
     * an undefined end. This is a shareable instance as all instances
     * of {@link DecimalRange} are immutable. In addition, there is no
     * need to create any other instances that have both ends open
     * (although is it permissible to create those instances).
     * This <tt>DecimalRange</tt> has both an undefined start <i>and</i>
     * and undefined end.
     */
    public static final DecimalRange BOTH_OPEN =
        new DecimalRange(OPEN, OPEN);

    /**
     * This <tt>DecimalRange</tt> covers all non-negative values with
     * a start of "0.0" and an undefined end.
     * It includes zero and all of the positive numbers.
     * This is a shareable instance as all instances
     * of {@link DecimalRange} are immutable.
     */
    public static final DecimalRange NON_NEGATIVE =
        new DecimalRange(DecimalTools.ZERO, OPEN);

    /**
     * This <tt>DecimalRange</tt> covers all non-positive values with
     * an undefined start and an end of "0.0".
     * It includes zero and all of the negative numbers.
     * This is a shareable instance as all instances
     * of {@link DecimalRange} are immutable.
     */
    public static final DecimalRange NON_POSITIVE =
        new DecimalRange(OPEN, DecimalTools.ZERO);

    // TODO - add example of sorting
    /**
     * Compares two ranges placing ranges that are considered "lowest"
     * first.
     * Open start values are considered to come before defined start values.
     * Open end values are considered to come after defined end values.
     * The following are listed in the order that would result by
     * using this {@link Comparator}:
     * <pre>
     * </pre>
     * <p>
     * Also see {@link #HIGHEST_FIRST_COMPARATOR} as it is <i>not</i> simply
     * the reverse of this comparator.
     * <p>
     * For additional permutations, see {@link NullFirstComparator},
     * {@link NullLastComparator}, and {@link ReverseComparator}.
     */
    public static final Comparator<DecimalRange> LOWEST_FIRST_COMPARATOR =
        new LowestFirstComparator();

    // TODO - add example of sorting
    /**
     * Compares two ranges placing ranges that are considered "highest"
     * first.
     * Open end values are considered to come before defined end values.
     * Open start values are considered to come after defined start values.
     * The following are listed in the order that would result by
     * using this {@link Comparator}:
     * <pre>
     * </pre>
     * <p>
     * Also see {@link #LOWEST_FIRST_COMPARATOR} as it is <i>not</i> simply
     * the reverse of this comparator.
     * <p>
     * For additional permutations, see {@link NullFirstComparator},
     * {@link NullLastComparator}, and {@link ReverseComparator}.
     */
    public static final Comparator<DecimalRange> HIGHEST_FIRST_COMPARATOR =
        new HighestFirstComparator();


    private final BigDecimal start;
    private final BigDecimal end;

    /**
     * Creates a new instance with the specified <tt>start</tt> and
     * <tt>end</tt> values. The constant {@link #OPEN} (or <tt>null</tt>)
     * can be used to indicate that one end or the other is open-ended.
     * Both the <tt>start</tt> and the <tt>end</tt> can be open, and if
     * you prefer, there is a shared, immutable instance that can be
     * used instead: {@link #BOTH_OPEN}.
     *
     * @param start the beginning of the value range. Use {@link #OPEN}
     * or <tt>null</tt> to indicate that the range is open-ended and has
     * no starting value (negative infinity).
     * @param end the ending of the value range. Use {@link #OPEN}
     * or <tt>null</tt> to indicate that the range is open-ended and has
     * no ending value (positive infinity).
     * @exception IllegalArgumentException if the <tt>start</tt> value
     * is greater than the <tt>end</tt> value.
     *
     * @see #DecimalRange(Value, Value)
     * @see #DecimalRange(String, String)
     */
    public DecimalRange(BigDecimal start, BigDecimal end)
            throws IllegalArgumentException {

        if ( start != OPEN && end != OPEN &&
             DecimalTools.greaterThan(start, end)) {

            throw new IllegalArgumentException("The start value [" + start +
                "] must not be after the end value [" + end + "]");
        }

        this.start = start;
        this.end = end;
    }

    /**
     * Creates a new instance with the specified <tt>start</tt> and
     * <tt>end</tt> values.
     * You can use <tt>null</tt> or an
     * {@link StringTools#isEmpty(String) empty} string
     * to indicate that one end or the other (or both) is open-ended.
     *
     * @param start the beginning of the value range.
     * Use <tt>null</tt> or an {@link StringTools#isEmpty(String) empty} string
     * to indicate that the range is open-ended and has no starting value.
     * @param end the ending of the value range.
     * Use <tt>null</tt> or an {@link StringTools#isEmpty(String) empty} string
     * to indicate that the range is open-ended and has no end value.
     * @exception IllegalArgumentException if the <tt>start</tt> value
     * is greater than the <tt>end</tt> value.
     * Or, if one of the <tt>String</tt>'s is not empty and can not be parsed
     * as a <tt>BigDecimal</tt>
     * (see {@link DecimalTools#parseBigDecimal(String)}).
     *
     * @see #DecimalRange(BigDecimal, BigDecimal)
     * @see #DecimalRange(Value, Value)
     * @see DecimalTools#parseBigDecimal(String)
     */
    public DecimalRange(String start, String end)
            throws IllegalArgumentException {

        this(parse(start), parse(end));
    }

    /**
     * Creates a new instance with the specified <tt>start</tt> and
     * <tt>end</tt> values.
     * You can use <tt>null</tt> for either parameter to indicate that
     * one end or the other (or both) is open-ended.
     * You can also use a {@link Value} who's {@link Value#isEmpty() isEmpty()}
     * method returns <tt>true</tt> to indicate that one end or the other
     * (or both) is open-ended.
     *
     * @param start the beginning of the value range.
     * Use <tt>null</tt> or an {@link Value#isEmpty() empty} <tt>Value</tt>
     * to indicate that the range is open-ended and has no starting value.
     * @param end the ending of the value range.
     * Use <tt>null</tt> or an {@link Value#isEmpty() empty} <tt>Value</tt>
     * to indicate that the range is open-ended and has no ending value.
     * @exception IllegalArgumentException if the <tt>start</tt> value
     * is greater than the <tt>end</tt> value.
     * Or, if one of the <tt>Value</tt>'s is not empty and can not be parsed
     * as a <tt>BigDecimal</tt> (see {@link Value#getBigDecimalOrNull()}).
     *
     * @see #DecimalRange(BigDecimal, BigDecimal)
     * @see #DecimalRange(String, String)
     * @see Value#getBigDecimalOrNull()
     */
    public DecimalRange(Value start, Value end)
            throws IllegalArgumentException {

        this(parse(start), parse(end));
    }

    private static BigDecimal parse(String s) throws IllegalArgumentException {
        try {
            return StringTools.isEmpty(s) ? OPEN :
                DecimalTools.parseBigDecimal(s);
        } catch ( Exception x ) {
            throw new IllegalArgumentException(x);
        }
    }

    private static BigDecimal parse(Value value)
            throws IllegalArgumentException {

        try {
            return (value == null) ? OPEN : value.getBigDecimalOrNull();
        } catch ( Exception x ) {
            throw new IllegalArgumentException(x);
        }
    }

    /**
     * Creates a new instance with an open start and the specified
     * <tt>end</tt> value.
     *
     * @param end the end of the value range.
     */
    public static DecimalRange createWithOpenStart(BigDecimal end) {
        return new DecimalRange(OPEN, end);
    }

    /**
     * Creates a new instance with an open end and the specified
     * <tt>start</tt> value.
     *
     * @param start the start of the value range.
     */
    public static DecimalRange createWithOpenEnd(BigDecimal start) {
        return new DecimalRange(start, OPEN);
    }

    /**
     * Returns a new instance with the specified <tt>newStart</tt> value
     * and this instance's end value.
     *
     * @param newStart the new start value for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the <tt>start</tt> value
     * is greater than the <tt>end</tt> value.
     * @see #DecimalRange(BigDecimal, BigDecimal)
     */
    public DecimalRange setStart(BigDecimal newStart)
            throws IllegalArgumentException {

        return new DecimalRange(newStart, this.end);
    }

    /**
     * Returns a new instance with the specified <tt>newStart</tt> value
     * and this instance's end value.
     *
     * @param newStart the new start value for the new instance or null
     * (or empty).
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end
     * or if <tt>newStart</tt> is not empty and can't be parsed.
     * @see #DecimalRange(String, String)
     */
    public DecimalRange setStart(String newStart)
            throws IllegalArgumentException {

        return new DecimalRange(parse(newStart), this.end);
    }

    /**
     * Returns a new instance with the specified <tt>newStart</tt> value
     * and this instance's end value.
     *
     * @param newStart the new start value for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end
     * or if <tt>newStart</tt> is not empty and can't be parsed.
     * @see #DecimalRange(Value, Value)
     */
    public DecimalRange setStart(Value newStart)
            throws IllegalArgumentException {

        return new DecimalRange(parse(newStart), this.end);
    }

    /**
     * Returns a new instance with the specified <tt>newEnd</tt> value
     * and this instance's start value.
     *
     * @param newEnd the new end value for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end.
     * @see #DecimalRange(BigDecimal, BigDecimal)
     */
    public DecimalRange setEnd(BigDecimal newEnd)
            throws IllegalArgumentException {

        return new DecimalRange(this.start, newEnd);
    }

    /**
     * Returns a new instance with the specified <tt>newEnd</tt> value
     * and this instance's start value.
     *
     * @param newEnd the new end value for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end
     * or if the end is not empty and can't be parsed.
     * @see #DecimalRange(String, String)
     */
    public DecimalRange setEnd(String newEnd)
            throws IllegalArgumentException {

        return new DecimalRange(this.start, parse(newEnd));
    }

    /**
     * Returns a new instance with the specified <tt>newEnd</tt> value
     * and this instance's start value.
     *
     * @param newEnd the new end value for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end
     * or if the end is not empty and can't be parsed.
     * @see #DecimalRange(Value, Value)
     */
    public DecimalRange setEnd(Value newEnd)
            throws IllegalArgumentException {

        return new DecimalRange(this.start, parse(newEnd));
    }

    /**
     * Returns <tt>true</tt> if this range has a defined start value.
     * If no start is defined, then this range is open-ended and <tt>false</tt>
     * is returned.
     * @see #getStart()
     */
    public boolean hasDefinedStart() {
        return start != OPEN;
    }

    /**
     * Returns the start of this range. If no starting value was specified,
     * then this range is open-ended and {@link #OPEN}
     * (<tt>null</tt>) is returned.
     * @see #hasDefinedStart()
     * @see #getStartString()
     * @see #getStartValue()
     */
    public BigDecimal getStart() {
        return start;
    }

    /**
     * Returns the start of this range as a <tt>String</tt>.
     * If no starting value was specified, then this range is open-ended and
     * <tt>null</tt> is returned.
     * @see #hasDefinedStart()
     * @see #getStart()
     * @see #getStartValue()
     */
    public String getStartString() {
        return (start == null) ? null : start.toString();
    }

    /**
     * Returns the start of this range as a <tt>Value</tt>.
     * If no starting value was specified, then this range is open-ended and
     * an empty <tt>Value</tt> is returned.
     * Unlike most of the other getters, a <tt>Value</tt> is always
     * returned&mdash;<tt>null</tt> is never returned.
     * @see #hasDefinedStart()
     * @see #getStart()
     * @see #getStartString()
     */
    public Value getStartValue() {
        return ValueFactory.create(start);
    }

    /**
     * Returns <tt>true</tt> if this range has a defined end value.
     * If no end is defined, then this range is open-ended and <tt>false</tt>
     * is returned.
     * @see #getEnd()
     */
    public boolean hasDefinedEnd() {
        return end != OPEN;
    }

    /**
     * Returns the end of this range. If no ending value was specified,
     * then this range is open-ended and {@link #OPEN}
     * (<tt>null</tt>) is returned.
     * @see #hasDefinedEnd()
     */
    public BigDecimal getEnd() {
        return end;
    }

    /**
     * Returns the end of this range as a <tt>String</tt>.
     * If no ending value was specified, then this range is open-ended and
     * <tt>null</tt> is returned.
     * @see #hasDefinedEnd()
     * @see #getEnd()
     * @see #getEndValue()
     */
    public String getEndString() {
        return (end == null) ? null : end.toString();
    }

    /**
     * Returns the end of this range as a <tt>Value</tt>.
     * If no ending value was specified, then this range is open-ended and
     * an empty <tt>Value</tt> is returned.
     * Unlike most of the other getters, a <tt>Value</tt> is always
     * returned&mdash;<tt>null</tt> is never returned.
     * @see #hasDefinedEnd()
     * @see #getEnd()
     * @see #getEndString()
     */
    public Value getEndValue() {
        return ValueFactory.create(end);
    }

    /**
     * Returns <tt>true</tt> if the specified <tt>BigDecimal</tt> falls
     * within this range (inclusive of both endpoints).
     * If <tt>null</tt> is passed in, then <tt>false</tt> is always
     * returned (regardless of the values of either endpoint).
     * If this instance has a defined start, but an unknown end, then
     * <tt>true</tt> is returned if the passed value is greater than or
     * equal to the start.
     * If this instance has a defined end, but an unknown start, then
     * <tt>true</tt> is returned if the passed value is less than or equal to
     * the end.
     * If this instance has both ends open and the passed parameter is
     * not <tt>null</tt>, then <tt>true</tt> is returned.
     */
    public boolean contains(BigDecimal value) {
        if ( value == null ) {
            return false;
        }

        if ( start == OPEN ) {
            if ( end == OPEN ) {
                return true;
            } else {
                return DecimalTools.lessThanOrEqualTo(value, end);
            }
        } else {
            if ( end == OPEN ) {
                return DecimalTools.lessThanOrEqualTo(start, value);
            } else {
                return DecimalTools.lessThanOrEqualTo(start, value) &&
                       DecimalTools.lessThanOrEqualTo(value, end);
            }
        }
    }

    /**
     * Forces the specified <tt>BigDecimal</tt> into this range.
     * If the specified value is contained with this range
     * (see {@link #contains(BigDecimal)}), then the passed value
     * is simply returned (no forcing is necessary).
     * If the range has a defined start and the specified value
     * is less than the start, then the start is returned.
     * If the range has a defined end and the specified value
     * is greater than the end, then the end is returned.
     * @param value the value to force into this range.
     * @return a value that is within this range.
     * @throws IllegalArgumentException if the specified value is <tt>null</tt>.
     */
    public BigDecimal forceIntoRange(BigDecimal value)
            throws IllegalArgumentException {

        if ( value == null ) {
            throw new IllegalArgumentException(
                "value to force can not be null");
        }

        // All scenarios and what to return:
        //
        //        start        end         contains     return
        //          |----val----|            true         val
        //    <----------val----|            true         val
        //          |----val------------>    true         val
        //    <----------val------------>    true         val
        //     val  |-----------|            false       start
        //     val  |------------------->    false       start
        //          |-----------|  val       false        end
        //    <-----------------|  val       false        end

        if ( contains(value) ) {
            return value;
        } else if ( hasDefinedStart() &&
                    DecimalTools.lessThanOrEqualTo(value, start) ) {

            return start;
        } else {
            return end;
        }
    }

    /**
     * Compares this instance to <tt>otherRange</tt> as defined by
     * {@link #LOWEST_FIRST_COMPARATOR}.
     * @throws IllegalArgumentException if null is passed.
     */
    public int compareTo(DecimalRange otherRange)
            throws IllegalArgumentException {

        if ( this == otherRange ) {
            return 0;
        } else {
            return LOWEST_FIRST_COMPARATOR.compare(this, otherRange);
        }
    }

    /**
     * Returns <tt>true</tt> if this instance's start and end values exactly
     * match the start and end values of the passed instance.
     * If <tt>null</tt> is passed, <tt>false</tt> is returned.
     */
    public boolean equals(DecimalRange otherBigDecimal) {
        return (this == otherBigDecimal) || (
                otherBigDecimal != null &&
                DecimalTools.equalTo(start, otherBigDecimal.start) &&
                DecimalTools.equalTo(end, otherBigDecimal.end)
            );
    }

    /**
     * Returns <tt>true</tt> if this instance's start and end values exactly
     * match the start and end values of the passed instance.
     * If <tt>null</tt> is passed, <tt>false</tt> is returned.
     * If a type other than <tt>DecimalRange</tt> is passed in,
     * <tt>false</tt> is returned (<tt>ClassCastException</tt> is not thrown).
     */
    @Override
    public boolean equals(Object obj) {
        if ( this == obj ) {
            return true;
        } else if ( obj == null || !(obj instanceof DecimalRange) ) {
            return false;
        }

        return equals((DecimalRange) obj);
    }

    @Override
    public int hashCode() {
        return ((start == null) ? 0 : start.hashCode()) ^
               ((end == null) ? 0 : end.hashCode());
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(getClass().getName() + "[");
        sb.append("start=" + start);
        sb.append(", end=" + end);
        sb.append("]");
        return sb.toString();
    }

    /**
     * Simply returns a reference to <i>this</i> instance. No need to actually
     * clone since objects of this type are immutable.
     */
    @Override
    public Object clone() {
        return this;
    }

    private static class LowestFirstComparator
            implements Comparator<DecimalRange> {

        public int compare(DecimalRange dr1, DecimalRange dr2) {
            try {
                if ( dr1 == dr2 ) {
                    return 0;
                }

                int startDiff = CollectionsTools.NULL_FIRST_COMPARABLE_ASC
                    .compare(dr1.start, dr2.start);

                if ( startDiff != 0 ) {
                    return startDiff;
                }

                // start's are both null or are both the same...

                int endDiff = CollectionsTools.NULL_LAST_COMPARABLE_ASC
                    .compare(dr1.end, dr2.end);

                if ( endDiff != 0 ) {
                    return endDiff;
                }

                return 0;
            } catch ( NullPointerException x ) {
                if ( dr1 == null || dr2 == null ) {
                    throw new IllegalArgumentException(
                        "One of the parameters passed to compare() is null. " +
                        "Wrap with NullFirstComparator or NullLastComparator " +
                        "if null should be considered valid in these " +
                        "comparisons.");
                } else {
                    throw x;  // throw the original if we get here
                }
            }
        }
    } // class LowestFirstComparator

    private static class HighestFirstComparator
            implements Comparator<DecimalRange> {

        public int compare(DecimalRange dr1, DecimalRange dr2) {
            try {
                if ( dr1 == dr2 ) {
                    return 0;
                }

                int endDiff = CollectionsTools.NULL_LAST_COMPARABLE_ASC
                    .compare(dr2.end, dr1.end);

                if ( endDiff != 0 ) {
                    return endDiff;
                }

                // end's are both null or are both the same...

                int startDiff = CollectionsTools.NULL_FIRST_COMPARABLE_ASC
                    .compare(dr2.start, dr1.start);

                if ( startDiff != 0 ) {
                    return startDiff;
                }

                return 0;
            } catch ( NullPointerException x ) {
                if ( dr1 == null || dr2 == null ) {
                    throw new IllegalArgumentException(
                        "One of the parameters passed to compare() is null. " +
                        "Wrap with NullFirstComparator or NullLastComparator " +
                        "if null should be considered valid in these " +
                        "comparisons.");
                } else {
                    throw x;  // throw the original if we get here
                }
            }
        }
    } // class HighestFirstComparator
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.