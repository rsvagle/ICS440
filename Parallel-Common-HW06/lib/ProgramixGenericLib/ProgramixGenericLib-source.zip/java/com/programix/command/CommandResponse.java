package com.programix.command;

import java.io.*;

public interface CommandResponse extends Serializable {
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.