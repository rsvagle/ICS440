package com.programix.command.bridge.http;

import java.io.*;
import java.net.*;

import com.programix.command.*;
import com.programix.io.*;
import com.programix.value.*;

public class HttpCommandProcessor implements CommandProcessor {
    /**
     * The configuration sent to {@link #init} must have a <tt>String</tt>
     * stored under this key. The value must be a string representation of
     * an <tt>http</tt> URL.
     * <p>
     * The value of this key is always: 
     * <tt>http.command.processor.target.url</tt>.
     */
    public static final String TARGET_URL_KEY = 
        "http.command.processor.target.url";
    
    private URL servletURL;
    
    public HttpCommandProcessor() {
    }

    public void init(ValueMap config) throws CommandException {
        try {
            String urlString = config.getString(TARGET_URL_KEY);
            servletURL = new URL(urlString);
        } catch ( Exception x ) {
            throw new CommandException(x);
        }
    }

    public void close() {
        servletURL = null; // break future requests--which shouldn't happen!
    }

    public CommandResponse process(CommandRequest req) throws CommandException {
        DataOutputStream out = null;
        DataInputStream in = null;
        
        try {
            HttpURLConnection uc =
                (HttpURLConnection) servletURL.openConnection();
            uc.setRequestMethod("POST");
            uc.setAllowUserInteraction(false); // system may not ask the user
            uc.setDoOutput(true); // we want to send things
            
            // To not be blocked by firewall or proxy server:
            uc.setRequestProperty("Content-Type", "image/png"); 

            TransferWrapper requestTW = SerializationTools.wrap(req, 100);
            uc.setRequestProperty("Content-Length", 
                String.valueOf(requestTW.calcWriteToByteCount()));

            uc.connect();

            out = new DataOutputStream(
                new BufferedOutputStream(uc.getOutputStream()));
            requestTW.writeTo(out);
            out.flush();
            out.close();
            out = null;  // success, save closeQuietly() the work

            in = new DataInputStream(
                new BufferedInputStream(uc.getInputStream()));
            
            TransferWrapper responseTW = new TransferWrapper();
            responseTW.readFrom(in);
            in.close();
            in = null;  // success, save closeQuietly() the work
            
            Object obj = SerializationTools.unwrap(responseTW);
            
            if ( obj instanceof CommandResponse ) {
                return (CommandResponse) obj;
            } else if ( obj instanceof CommandException ) {
                throw (CommandException) obj;
            } else {
                throw new CommandException("Unexpected response");
            }
        } catch ( CommandException x ) {
            throw x;
        } catch ( Exception x ) {
            throw new CommandException(x);
        } finally {
            IOTools.closeQuietly(out);  // be sure this is closed
            IOTools.closeQuietly(in);   // be sure this is closed
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.