package com.programix.command;

import com.programix.value.*;

public interface CommandProcessor {
    void init(ValueMap config) throws CommandException;
    void close();
    
    CommandResponse process(CommandRequest req) throws CommandException;
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.