package com.programix.command;

import java.io.*;

public interface CommandRequest extends Serializable {
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.