package com.programix.command.bridge.http;

import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.programix.command.*;
import com.programix.io.*;
import com.programix.value.*;

public class HttpCommandBridgeServlet extends HttpServlet {
    /**
     * Set to: <tt>command.processor.config.filename</tt>, used to load the
     * configuration for the {@link CommandProcessor} that this servlet
     * will relay to.
     * This file is expected to be bundled in the war-file and in the
     * format used by {@link ValueMap} and shall be passed to
     * {@link CommandProcessorFactory}.
     */
    public static final String COMMAND_PROCESSOR_CONFIG_FILENAME =
        "command.processor.config.filename";

    private CommandProcessor commandProcessor;
    private int postCount;

    @Override
    public void init() throws ServletException {
        try {
            String configFilename =
                getInitParameter(COMMAND_PROCESSOR_CONFIG_FILENAME);

            URL url = getServletContext().getResource(configFilename);
            commandProcessor = CommandProcessorFactory.create(url, null);
        } catch ( Exception x ) {
            throw new ServletException("Failed to initialize CommandBridge", x);
        }
    }

    @Override
    protected void doGet(
                    HttpServletRequest req,
                    HttpServletResponse res
                ) throws ServletException, IOException {

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        out.println("<html>");
        out.println("<head>");
        out.println("<title>Serialization Servlet</title>");
        out.println("</head>");
        out.println("<body>");

        out.println("<p>Serialization Servlet has processed: " +
            getPostCount() + " post requests</p>");

        out.println("</body>");
        out.println("</html>");
    }

    private synchronized int getPostCount() {
        return postCount;
    }

    private synchronized void incrementPostCount() {
        postCount++;
    }

    @Override
    public void doPost(
                HttpServletRequest req,
                HttpServletResponse res
            ) throws ServletException, IOException {

        incrementPostCount();

        DataInputStream in = null;
        DataOutputStream out = null;
        try {
            in = new DataInputStream(
                new BufferedInputStream(req.getInputStream()));

            TransferWrapper requestTW = new TransferWrapper();
            requestTW.readFrom(in);

            CommandRequest commandReq = (CommandRequest)
                SerializationTools.unwrap(requestTW, CommandRequest.class);

            // The result might be a CommandResponse or a CommandException
            Object commandResult = process(commandReq);

            TransferWrapper resultTW =
                SerializationTools.wrap(commandResult, 100);

            res.setContentType("image/png");
            res.setContentLength(resultTW.calcWriteToByteCount());

            out = new DataOutputStream(
                new BufferedOutputStream(res.getOutputStream()));
            resultTW.writeTo(out);
            out.flush();
        } catch ( IOException x ) {
            throw x;
        } catch ( Exception x ) {
            throw new ServletException(x);
        } finally {
            IOTools.closeQuietly(in);
            IOTools.closeQuietly(out);
        }
    }

    private Object process(CommandRequest req) {
        try {
            return commandProcessor.process(req);
        } catch ( CommandException x ) {
            // Do NOT throw, but simply return it:
            return x;
        } catch ( Exception x ) {
            // Do NOT throw, but simple wrap and return it:
            return new CommandException(x);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.