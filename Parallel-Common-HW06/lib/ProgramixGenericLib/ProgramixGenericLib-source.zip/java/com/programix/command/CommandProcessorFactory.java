package com.programix.command;

import java.io.*;
import java.net.*;

import com.programix.value.*;

/**
 * Used to construct and initialize instances of {@link CommandProcessor} using
 * reflection.
 * <p>
 * Common usage is (where <code>CustomerCommandProcessor</code> is an
 * interface that extends the {@link CommandProcessor} interface):
 * <pre class="preshade">
 * {@link ValueMap} config = //...
 * CustomerCommandProcessor ccp = (CustomerCommandProcessor)
 *     CommandProcessorFactory.{@link #create(ValueMap, Class)
 *     create}(config, CustomerCommandProcessor.class);</pre>
 * or
 * <pre class="preshade">
 * String filename = //...
 * CustomerCommandProcessor cda = (CustomerCommandProcessor)
 *     CommandProcessorFactory.{@link #createFromFile(String, Class)
 *     create}(filename, CustomerCommandProcessor.class);</pre>
 *
 * The configuration {@link ValueMap} passed in must contain the class name of
 * the class to be instantiated stored under the key
 * {@link #COMMAND_PROCESSOR_CLASSNAME_KEY}. Other key/value pairs in the map
 * are populated with whatever the specific <tt>CommandProcessor</tt>
 * implementation needs for initialization.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class CommandProcessorFactory extends Object {
	/**
     * The reserved key that retrieves the fully-qualified name (as a
     * <tt>String</tt>) of the <tt>CommandProcessor</tt> implementation
     * class that will be instantiated via reflection.
     * <p>
     * The value of this key is always:
     *
     * <pre class="preshade">
     * command.processor.classname
     * </pre>
     */
	public static final String COMMAND_PROCESSOR_CLASSNAME_KEY =
			"command.processor.classname"; // keep value in sync with api docs!

	// no instances
	private CommandProcessorFactory() {
	}

	/**
	 * Constructs an instance of the {@link CommandProcessor} implementation
	 * specified in the configuration. One required key
	 * that must always be present is: {@link #COMMAND_PROCESSOR_CLASSNAME_KEY}
	 * with a <tt>String</tt> value which is the full class name.
	 * <p>
     * Immediately after the zero-argument constructor is invoked,
	 * the {@link CommandProcessor#init init(ValueMap conf)} of
     * <tt>CommandProcessor</tt> is invoked to initialize the configuration.
	 * <p>
     * If the <tt>targetType</tt> is not <tt>null</tt>, then an
	 * additional check is done to ensure that the constructed object
	 * can be type cast into that type (failures throw a
	 * <tt>CommandException</tt> instead of a
     * <tt>ClassCastException</tt>).
	 *
	 * @param config key/value mapping with everything that is needed to
	 * initialize the instance of <tt>CommandProcessor</tt>.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>CommandException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception CommandException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
	 */
	@SuppressWarnings("unchecked")
    public static <T extends CommandProcessor> T create(ValueMap config,
	                                                    Class<T> targetType)
            throws CommandException {

		CommandProcessor cp = null;

		try {
			String className =
                config.getString(COMMAND_PROCESSOR_CLASSNAME_KEY);

			Class<?> c = Class.forName(className);
			cp = (CommandProcessor) c.newInstance(); // zero-arg constructor
		} catch ( Exception x ) {
			throw new CommandException(
				"Failed to create CommandProcessor implementation", x);
		}

		if ( (targetType != null ) && (targetType.isInstance(cp) == false) ) {
			throw new CommandException("Constructed object's type (" +
				cp.getClass().getName() + ") can't be cast into the " +
				"target type (" + targetType.getName() + ")");
		}

		cp.init(config); // might throw CommandException too...

		return (T) cp;
	}

	/**
	 * Create a <tt>CommandProcessor</tt> instance using a <tt>Reader</tt>
	 * whose data is in the format described by {@link ValueMap}
     * (nearly identical to the format for a <code>Properties</code> file).
	 * Internally, the stream <i>will</i> be buffered and the stream
	 * <i>will</i> be closed.
	 *
	 * @param rawIn a stream whose contents can be loaded into
	 * a <tt>ValueMap</tt> with everything that is needed to
	 * initialize the instance of <tt>CommandProcessor</tt>.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>CommandException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception CommandException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
	 */
	public static <T extends CommandProcessor> T create(Reader rawIn,
	                                                    Class<T> targetType)
			throws CommandException {

		try {
            return create(ValueMap.createFrom(rawIn), targetType);
        } catch ( ValueMapException x ) {
            throw new CommandException(
                "Failed to create CommandProcessor implementation", x);
        }
	}

    /**
	 * Create a <tt>CommandProcessor</tt> instance using an <tt>InputStream</tt>
	 * whose data is in the format described by {@link ValueMap}
     * (nearly identical to the format for a <code>Properties</code> file).
	 * Internally, the stream <i>will</i> be buffered and the stream
	 * <i>will</i> be closed.
	 *
	 * @param rawIn a stream whose contents can be loaded into
	 * a <tt>ValueMap</tt> with everything that is needed to
	 * initialize the instance of <tt>CommandProcessor</tt>.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>CommandException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception CommandException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)

	 */
	public static <T extends CommandProcessor> T create(InputStream rawIn,
	                                                    Class<T> targetType)
			throws CommandException {

		try {
            return create(ValueMap.createFrom(rawIn), targetType);
        } catch ( ValueMapException x ) {
            throw new CommandException(
                "Failed to create CommandProcessor implementation", x);
        }
	}

    /**
     * Create a <tt>CommandProcessor</tt> instance using an <tt>File</tt>
     * whose data is in the format described by {@link ValueMap}
     * (nearly identical to the format for a <code>Properties</code> file).
     *
     * @param file file with key/value mapping with everything that
     *        is needed to initialize the instance of <tt>CommandProcessor</tt>.
     * @param targetType the class type that this instance is expected to be
     *        cast into. Use <tt>null</tt> to skip this check. If not
     *        <tt>null</tt> and the type does not match what is
     *        constructed, then a <tt>CommandException</tt> is thrown.
     *
     * @return the constructed and initialized instance.
     *
     * @exception CommandException if instance can not be constructed
     *         and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(URL, Class)

     */
    public static <T extends CommandProcessor> T create(File file,
                                                        Class<T> targetType)
            throws CommandException {

        try {
            return create(ValueMap.createFrom(file), targetType);
        } catch ( ValueMapException x ) {
            throw new CommandException(
                "Failed to create CommandProcessor implementation", x);
        }
    }

    /**
     * Create a <tt>CommandProcessor</tt> instance using the specified
     * <tt>filename</tt> whose data is in the format described by
     * {@link ValueMap}(nearly identical to the format for a
     * <code>Properties</code> file).
     *
     * @param filename file with key/value mapping with everything that is
     *        needed to initialize the instance of <tt>CommandProcessor</tt>.
     * @param targetType the class type that this instance is expected to be
     *        cast into. Use <tt>null</tt> to skip this check. If not
     *        <tt>null</tt> and the type does not match what is
     *        constructed, then a <tt>CommandException</tt> is thrown.
     *
     * @return the constructed and initialized instance.
     *
     * @exception CommandException if instance can not be constructed
     * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
     */
    public static <T extends CommandProcessor> T createFromFile(
                String filename,
                Class<T> targetType
            ) throws CommandException {

        try {
            return create(ValueMap.createFromFile(filename), targetType);
        } catch ( ValueMapException x ) {
            throw new CommandException(
                "Failed to create CommandProcessor implementation", x);
        }
    }

	/**
     * Create a <tt>CommandProcessor</tt> instance using the specified
     * <tt>URL</tt> whose data is in the format described by
     * {@link ValueMap}(nearly identical to the format for a
     * <code>Properties</code> file).

	 * @param propertiesURL a URL whose contents can be loaded into
	 * a <tt>ValueMap</tt> with everything that is needed to
	 * initialize the instance of <tt>CommandProcessor</tt>.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>CommandException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception CommandException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #createFromResource(String, Class)
	 */
	public static <T extends CommandProcessor> T create(URL propertiesURL,
	                                                    Class<T> targetType)
			throws CommandException {

        try {
            return create(ValueMap.createFrom(propertiesURL), targetType);
        } catch ( ValueMapException x ) {
            throw new CommandException(
                "Failed to create CommandProcessor implementation", x);
        }
	}

    /**
     * Create a <tt>CommandProcessor</tt> instance using the specified
     * <tt>resourceLocation</tt> whose data is in the format described by
     * {@link ValueMap}(nearly identical to the format for a
     * <code>Properties</code> file).
     *
     * @param resourceLocation file with key/value mapping with everything
     *        that is needed to initialize the instance of
     *        <tt>CommandProcessor</tt>.
     * @param targetType the class type that this instance is expected to be
     *        cast into. Use <tt>null</tt> to skip this check. If not
     *        <tt>null</tt> and the type does not match what is
     *        constructed, then a <tt>CommandException</tt> is thrown.
     *
     * @return the constructed and initialized instance.
     *
     * @exception CommandException if instance can not be constructed
     * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #create(File, Class)
     * @see #createFromFile(String, Class)
     * @see #create(URL, Class)
     */
    public static <T extends CommandProcessor> T createFromResource(
                String resourceLocation,
                Class<T> targetType
            ) throws CommandException {

        try {
            return create(
                ValueMap.createFromResource(resourceLocation), targetType);
        } catch ( ValueMapException x ) {
            throw new CommandException(
                "Failed to create CommandProcessor implementation", x);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.