package com.programix.command;

import java.util.*;

import com.programix.value.*;

public abstract class DelegatingCommandProcessor implements CommandProcessor {
    private Map<Class<? extends CommandRequest>, CommandProcessor> handlerMap;

    public final void init(ValueMap config) throws CommandException {
        handlerMap = Collections.synchronizedMap(
            new HashMap<Class<? extends CommandRequest>, CommandProcessor>());
        customInit(config);
    }

    /**
     * Overridden in subclasses that need to perform any custom
     * initialization.
     *
     * @param config the configuration settings
     * @throws CommandException subclasses can throw this to indicate trouble
     */
    protected void customInit(ValueMap config) throws CommandException {
    }

    public final void close() {
        customClose();
        handlerMap.clear();
    }

    protected void customClose() {
    }

    public final void delegate(Class<? extends CommandRequest> requestClass,
                               CommandProcessor handler) {

        handlerMap.put(requestClass, handler);
    }

    public final CommandResponse process(CommandRequest req)
            throws CommandException {

        CommandProcessor handler = (CommandProcessor)
            handlerMap.get(req.getClass());

        if ( handler == null ) {
            throw new CommandException(
                "Could not find a handler for request type: " +
                req.getClass().getName());
        }

        return handler.process(req);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.