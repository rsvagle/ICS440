package com.programix.http;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;

import javax.swing.*;

import com.programix.io.*;

public class SimpleHttpServer extends Object {
	// currently available HttpWorker objects
	private SimpleObjectFIFO idleWorkers;

	// all HttpWorker objects
	private HttpWorker[] workerList;
	private ServerSocket ss;
	private int port;
    private Output output;

	private Thread internalThread;
	private volatile boolean noStopRequested;

	public SimpleHttpServer(
				File docRoot,
				int port,
				int numberOfWorkers,
                Output output
			) throws IOException {

        this.output = output;

        output.outln("Initializing for...");
        output.outln("                     docRoot: " + docRoot);
        output.outln("  docRoot.getCanonicalPath(): ");
        output.outln("    " + docRoot.getCanonicalPath());
        output.outln("                        port: " + port);
        output.outln("             numberOfWorkers: " + numberOfWorkers);

		this.port = port;

		// Allow a max of 10 sockets to queue up
		// waiting for accpet().
		ss = new ServerSocket(port, 50);

		if ( ( docRoot == null ) ||
			 !docRoot.exists() ||
			 !docRoot.isDirectory()
		   ) {

			throw new IOException("specified docRoot is null " +
				"or does not exist or is not a directory");
		}

		// ensure that at least one worker is created
		numberOfWorkers = Math.max(1, numberOfWorkers);

		int serverPriority = 6;

		// Have the workers run at a slightly lower priority so
		// that new requests are handled with more urgency than
		// in-progress requests.
		int workerPriority = serverPriority - 1;

		idleWorkers = new SimpleObjectFIFO(numberOfWorkers);
		workerList = new HttpWorker[numberOfWorkers];

		for ( int i = 0; i < numberOfWorkers; i++ ) {
			// Workers get a reference to the FIFO to add
			// themselves back in when they are ready to
			// handle a new request.
			workerList[i] = new HttpWorker(
						docRoot, workerPriority, idleWorkers, output);
		}

		// Just before returning, the thread should be
		// created and started.
		noStopRequested = true;

		Runnable r = new Runnable() {
				public void run() {
					try {
						runWork();
					} catch ( Exception x ) {
						// in case ANY exception slips through
						x.printStackTrace();
					}
				}
			};

		internalThread = new Thread(r);
		internalThread.setPriority(serverPriority);
		internalThread.start();
	}

	private void runWork() {
		output.outln("HttpServer ready to receive requests on port: " + port);

		while ( noStopRequested ) {
			try {
				Socket s = ss.accept();

				if ( !idleWorkers.waitWhileEmpty(5000L) ) {
					output.outln("HttpServer too busy, denying request");

					BufferedWriter writer =
						new BufferedWriter(
							new OutputStreamWriter(
								s.getOutputStream()));

					writer.write("HTTP/1.0 503 Service " +
									"Unavailable\r\n\r\n");

					writer.flush();
					writer.close();
					writer = null;
				} else {
					// No need to be worried that idleWorkers
					// will suddenly be empty since this is the
					// only thread removing items from the queue.
					HttpWorker worker =
							(HttpWorker) idleWorkers.remove();

					worker.processRequest(s);
				}
			} catch ( IOException iox ) {
				if ( noStopRequested ) {
					output.outln(iox);
				}
			} catch ( InterruptedException x ) {
				// re-assert interrupt
				Thread.currentThread().interrupt();
			}
		}
	}

	public void stopRequest() {
		noStopRequested = false;
		internalThread.interrupt();

		for ( int i = 0; i < workerList.length; i++ ) {
			workerList[i].stopRequest();
		}

		if ( ss != null ) {
			try { ss.close(); } catch ( IOException iox ) { }
			ss = null;
		}
	}

	public boolean isAlive() {
		return internalThread.isAlive();
	}

	private static void usage(String msg, Output out) {
		out.outln(msg);
		out.outln(
            "Usage: java com.programix.http.SimpleHttpServer <port> " +
			"<numWorkers> <docRoot>");
		out.outln("   <port> - port to listen on for HTTP requests");
		out.outln(
            "   <numWorkers> - number of worker threads to create");
		out.outln("   <docRoot> - base directory for HTML files");
	}

    private static SimpleHttpServer create(String[] args, Output output) {
        if ( args.length != 3 ) {
            usage("wrong number of arguments", output);
        }

        String portStr = args[0];
        String numWorkersStr = args[1];
        String docRootStr = args[2];

        int port = 0;

        try {
            port = Integer.parseInt(portStr);
        } catch ( NumberFormatException x ) {
            usage("could not parse port number from '" +
                portStr + "'", output);
        }

        if ( port < 1 ) {
            usage("invalid port number specified: " + port, output);
        }

        int numWorkers = 0;

        try {
            numWorkers = Integer.parseInt(numWorkersStr);
        } catch ( NumberFormatException x ) {
            usage(
                    "could not parse number of workers from '" +
                    numWorkersStr + "'", output);
        }

        File docRoot = new File(docRootStr);

        try {
            return new SimpleHttpServer(docRoot, port, numWorkers, output);
        } catch ( IOException x ) {
            output.outln(x);
            usage("could not construct HttpServer", output);
            return null;
        }
    }

	/**
     * Used to run a simple HTTP server.
     *
     * <pre>
     * Usage: java SimpleHttpServer &lt;port&gt; &lt;threads&gt; &lt;root&gt;
     *    &lt;port&gt; - port to listen on for HTTP requests
     *    &lt;threads&gt; - number of worker threads to create
     *    &lt;root&gt; - base directory for HTML files
     * </pre>
	 */
    public static void main(String[] args) {
        //create(args, new ConsoleOutput());
        GuiConsole.createFramedInstance(args);
	}

    private static class HttpWorker extends Object {
        private static int nextWorkerID = 0;

        private File docRoot;
        private SimpleObjectFIFO idleWorkers;
        private int workerID;
        private SimpleObjectFIFO handoffBox;
        private Output output;

        private Thread internalThread;
        private volatile boolean noStopRequested;

        public HttpWorker(
                    File docRoot,
                    int workerPriority,
                    SimpleObjectFIFO idleWorkers,
                    Output output
                ) {

            this.output = output;
            this.docRoot = docRoot;
            this.idleWorkers = idleWorkers;

            workerID = getNextWorkerID();
            handoffBox = new SimpleObjectFIFO(1); // only one slot

            // Just before returning, the thread should be
            // created and started.
            noStopRequested = true;

            Runnable r = new Runnable() {
                    public void run() {
                        try {
                            runWork();
                        } catch ( Exception x ) {
                            // in case ANY exception slips through
                            x.printStackTrace();
                        }
                    }
                };

            internalThread = new Thread(r);
            internalThread.setPriority(workerPriority);
            internalThread.start();
        }

        public static synchronized int getNextWorkerID() {
            // synchronized at the class level to ensure uniqueness
            int id = nextWorkerID;
            nextWorkerID++;
            return id;
        }

        public void processRequest(Socket s)
                    throws InterruptedException {

            handoffBox.add(s);
        }

        private void runWork() {
            Socket s = null;
            InputStream in = null;
            OutputStream out = null;
            String reqIP = null;

            while ( noStopRequested ) {
                try {
                    // Worker is ready to receive new service
                    // requests, so it adds itself to the idle
                    // worker queue.
                    idleWorkers.add(this);

                    // Wait here until the server puts a request
                    // into the handoff box.
                    s = (Socket) handoffBox.remove();

                    in = s.getInputStream();
                    out = s.getOutputStream();
                    reqIP = s.getInetAddress().getHostAddress();
                    generateResponse(in, out, reqIP);
                } catch ( IOException iox ) {
                    output.outln(
                        "I/O error while processing request from: " + reqIP +
                        ", ignoring and adding back to idle " +
                        "queue - workerID=" + workerID);
                    output.outln(iox);
                } catch ( InterruptedException x ) {
                    // re-assert the interrupt
                    Thread.currentThread().interrupt();
                } finally {
                    IOTools.closeQuietly(s, in, out);
                }
            }
        }

        private void generateResponse(
                    InputStream in,
                    OutputStream out,
                    String reqIP
                ) throws IOException {

            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(in));

            String requestLine = reader.readLine();

            if ( ( requestLine == null ) ||
                 ( requestLine.length() < 1 )
               ) {

                throw new IOException("could not read request");
            }

            //System.out.println("workerID=" + workerID +
            //      ", requestLine=" + requestLine);

            StringTokenizer st = new StringTokenizer(requestLine);
            String filename = null;

            try {
                // request method, typically 'GET', but ignored
                st.nextToken();

                // the second token should be the filename
                filename = st.nextToken();
            } catch ( NoSuchElementException x ) {
                throw new IOException(
                        "could not parse request line");
            }

            File requestedFile = generateFile(filename);

            BufferedOutputStream buffOut =
                    new BufferedOutputStream(out);

            if ( requestedFile.exists() && !requestedFile.isDirectory() ) {
                output.outln("workerID=" + workerID + ", " + reqIP +
                    ", 200 OK: " + filename);

                int fileLen = (int) requestedFile.length();

                BufferedInputStream fileIn =
                    new BufferedInputStream(
                        new FileInputStream(requestedFile));

                // Use this utility to make a guess obout the
                // content type based on the first few bytes
                // in the stream.
                String contentType = "text/html";

                if ( filename.endsWith(".html") ) {
                    contentType = "text/html";
                } else if ( filename.endsWith(".java") ) {
                    contentType = "text/plain";
                } else if ( filename.endsWith(".class") ) {
                    contentType = "application/octet-stream";
                } else if ( filename.endsWith(".jar") ) {
                    contentType = "application/octet-stream";
                } else if ( filename.endsWith(".jnlp") ) {
                    contentType = "application/x-java-jnlp-file";
                } else {
                    contentType = URLConnection.guessContentTypeFromStream(fileIn);
                }

                byte[] headerBytes = createHeaderBytes(
                        "HTTP/1.0 200 OK",
                        fileLen,
                        contentType
                    );

                buffOut.write(headerBytes);

                byte[] buf = new byte[2048];
                int blockLen = 0;

                while ( ( blockLen = fileIn.read(buf) ) != -1 ) {
                    buffOut.write(buf, 0, blockLen);
                }

                fileIn.close();
            } else if (requestedFile.exists() && requestedFile.isDirectory() ) {
                output.outln("workerID=" + workerID +
                    ", " + reqIP +
                    ", 301 Moved Permenently: " + filename );

                byte[] headerBytes = createHeaderBytes(
                    "HTTP/1.0 301 Moved Permanently\r\nLocation: " +
                        filename + "/",
                    -1,
                    null
                );

                buffOut.write(headerBytes);
            } else {
                output.outln("workerID=" + workerID +
                        ", " + reqIP +
                        ", 404 Not Found: " + filename );

                byte[] headerBytes = createHeaderBytes(
                        "HTTP/1.0 404 Not Found",
                        -1,
                        null
                    );

                buffOut.write(headerBytes);
            }

            buffOut.flush();
        }

        private File generateFile(String filename) {
            File requestedFile = docRoot; // start at the base

            // Build up the path to the requested file in a
            // platform independent way. URL's use '/' in their
            // path, but this platform may not.
            StringTokenizer st = new StringTokenizer(filename, "/");
            while ( st.hasMoreTokens() ) {
                String tok = st.nextToken();

                if ( tok.equals("..") ) {
                    // Silently ignore parts of path that might
                    // lead out of the document root area.
                    continue;
                }

                requestedFile =
                    new File(requestedFile, tok);
            }

            if ( requestedFile.exists() &&
                 requestedFile.isDirectory() &&
                 filename.endsWith("/")
               ) {

                // If a directory was requested, modify the request
                // to look for the "index.html" file in that
                // directory.
                requestedFile =
                    new File(requestedFile, "index.html");
            }

            return requestedFile;
        }

        private byte[] createHeaderBytes(
                    String resp,
                    int contentLen,
                    String contentType
                ) throws IOException {

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(baos));

            // Write the first line of the response, followed by
            // the RFC-specified line termination sequence.
            writer.write(resp + "\r\n");

            // If a length was specified, add it to the header
            if ( contentLen != -1 ) {
                writer.write(
                    "Content-Length: " + contentLen + "\r\n");
            }

            // If a type was specified, add it to the header
            if ( contentType != null ) {
                writer.write(
                    "Content-Type: " + contentType + "\r\n");
            }

            // A blank line is required after the header.
            writer.write("\r\n");
            writer.flush();

            byte[] data = baos.toByteArray();
            writer.close();

            return data;
        }

        public void stopRequest() {
            noStopRequested = false;
            internalThread.interrupt();
        }

        public boolean isAlive() {
            return internalThread.isAlive();
        }
    } // class HttpWorker

    private static class SimpleObjectFIFO extends Object {
        private Object[] queue;
        private int capacity;
        private int size;
        private int head;
        private int tail;

        public SimpleObjectFIFO(int cap) {
            capacity = ( cap > 0 ) ? cap : 1; // at least 1
            queue = new Object[capacity];
            head = 0;
            tail = 0;
            size = 0;
        }

        public int getCapacity() {
            return capacity;
        }

        public synchronized int getSize() {
            return size;
        }

        public synchronized boolean isEmpty() {
            return ( size == 0 );
        }

        public synchronized boolean isFull() {
            return ( size == capacity );
        }

        public synchronized void add(Object obj)
                throws InterruptedException {

            waitWhileFull();

            queue[head] = obj;
            head = ( head + 1 ) % capacity;
            size++;

            notifyAll(); // let any waiting threads know about change
        }

        public synchronized void addEach(Object[] list)
                throws InterruptedException {

            //
            // You might want to code a more efficient
            // implementation here ... (see ByteFIFO.java)
            //

            for ( int i = 0; i < list.length; i++ ) {
                add(list[i]);
            }
        }

        public synchronized Object remove()
                throws InterruptedException {

            waitWhileEmpty();

            Object obj = queue[tail];

            // don't block GC by keeping unnecessary reference
            queue[tail] = null;

            tail = ( tail + 1 ) % capacity;
            size--;

            notifyAll(); // let any waiting threads know about change

            return obj;
        }

        public synchronized Object[] removeAll()
                throws InterruptedException {

            //
            // You might want to code a more efficient
            // implementation here ... (see ByteFIFO.java)
            //

            Object[] list = new Object[size]; // use the current size

            for ( int i = 0; i < list.length; i++ ) {
                list[i] = remove();
            }

            // if FIFO was empty, a zero-length array is returned
            return list;
        }

        public synchronized Object[] removeAtLeastOne()
                throws InterruptedException {

            waitWhileEmpty(); // wait for a least one to be in FIFO
            return removeAll();
        }

        public synchronized boolean waitUntilEmpty(long msTimeout)
                throws InterruptedException {

            if ( msTimeout == 0L ) {
                waitUntilEmpty();  // use other method
                return true;
            }

            // wait only for the specified amount of time
            long endTime = System.currentTimeMillis() + msTimeout;
            long msRemaining = msTimeout;

            while ( !isEmpty() && ( msRemaining > 0L ) ) {
                wait(msRemaining);
                msRemaining = endTime - System.currentTimeMillis();
            }

            // May have timed out, or may have met condition,
            // calc return value.
            return isEmpty();
        }

        public synchronized void waitUntilEmpty()
                throws InterruptedException {

            while ( !isEmpty() ) {
                wait();
            }
        }

        public synchronized boolean waitWhileEmpty(long msTimeout)
                throws InterruptedException {

            if ( msTimeout == 0L ) {
                waitWhileEmpty();  // use other method
                return true;
            }

            // wait only for the specified amount of time
            long endTime = System.currentTimeMillis() + msTimeout;
            long msRemaining = msTimeout;

            while ( isEmpty() && ( msRemaining > 0L ) ) {
                wait(msRemaining);
                msRemaining = endTime - System.currentTimeMillis();
            }

            // May have timed out, or may have met condition,
            // calc return value.
            return !isEmpty();
        }

        public synchronized void waitWhileEmpty()
                throws InterruptedException {

            while ( isEmpty() ) {
                wait();
            }
        }

        public synchronized void waitUntilFull()
                throws InterruptedException {

            while ( !isFull() ) {
                wait();
            }
        }

        public synchronized void waitWhileFull()
                throws InterruptedException {

            while ( isFull() ) {
                wait();
            }
        }
    } // class SimpleObjectFIFO

    public static interface Output {
        void outln(String msg);
        void outln(Exception x);
    }

    public static class ConsoleOutput extends Object implements Output {
        public ConsoleOutput() {
        }

        public void outln(String msg) {
            System.out.println(msg);
        }

        public void outln(Exception x) {
            System.out.println(x);
        }
    } // class ConsoleOutput

    private static class GuiConsole extends JPanel implements Output {
        private JTextArea logTA;

        public GuiConsole() {
            logTA = new JTextArea();

            setLayout(new GridLayout());
            add(new JScrollPane(logTA));
        }

        public void outln(String msg) {
            SwingUtilities.invokeLater(new AppendTask(msg, logTA));
        }

        public void outln(Exception x) {
            outln(String.valueOf(x));
        }

        public static JFrame createFramedInstance(String[] args) {
            GuiConsole gc = new GuiConsole();

            JFrame.setDefaultLookAndFeelDecorated(true);
            JFrame f = new JFrame("SimpleHttpServer");
            f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            f.setContentPane(gc);
            f.setSize(600, 250);
            f.setVisible(true);
            f.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    System.exit(0);
                }
            });

            create(args, gc);

            return f;
        }
    } // class GuiConsole

    private static class AppendTask extends Object implements Runnable {
        private String msg;
        private JTextArea ta;

        public AppendTask(String msg, JTextArea ta) {
            this.msg = msg;
            this.ta = ta;
        }

        // called by event thread
        public void run() {
            ta.append(msg);
            ta.append("\n");
        }
    } // class AppendTask
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.