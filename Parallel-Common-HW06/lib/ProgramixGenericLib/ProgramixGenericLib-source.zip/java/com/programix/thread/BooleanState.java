package com.programix.thread;

/**
 * This class serves as a thread-safe tracker of a <tt>boolean</tt> state.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class BooleanState implements ThreadSafe {
    private boolean state;
    private final Object lockObject;

    private final Waiter waiter;
    private final Waiter.Condition trueCondition;

    private BooleanState(boolean initialState,
                         Waiter proposedWaiter,
                         Object proposedLockObject) {

        if ( proposedWaiter != null ) {
            waiter = proposedWaiter;
            lockObject = proposedWaiter.getLockObject();
        } else {
            lockObject =
                (proposedLockObject == null) ? this : proposedLockObject;
            waiter = new Waiter(lockObject);
        }

        state = initialState;

        trueCondition = waiter.createCondition(new Waiter.Expression() {
            @Override
            public boolean isTrue() {
                return state;
            }
        });
    }

    /**
     * Creates an instance that is initially set to the state of
     * <tt>initialState</tt> and synchronizes on
     * the lock used by the specified <tt>waiter</tt>.
     */
    public BooleanState(boolean initialState, Waiter waiter) {
        this(initialState, waiter, null);
    }

    /**
     * Creates an instance that is initially set to the state of
     * <tt>initialState</tt> and synchronizes on
     * the specified <tt>lockObject</tt>.
     */
    public BooleanState(boolean initialState, Object lockObject) {
        this(initialState, null, lockObject);
    }

    /**
     * Creates an instance that is initially set to the state of
     * <tt>initialState</tt> and synchronizes on itself.
     */
    public BooleanState(boolean initialState) {
        this(initialState, null, null);
    }

    /**
     * Creates an instance that is initially <tt>false</tt> and synchronizes
     * on the specified <tt>lockObject</tt>.
     */
    public BooleanState(Object lockObject) {
        this(false, null, lockObject);
    }

    /**
     * Creates an instance that is initially <tt>false</tt> and synchronizes
     * on itself.
     */
    public BooleanState() {
        this(false, null, null);
    }

    /**
     * Returns <tt>true</tt> if the internal state is currently <tt>true</tt>.
     */
    public boolean isTrue() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();

            return state;
        }
    }

    /**
     * Returns <tt>true</tt> if the internal state is currently <tt>false</tt>.
     */
    public boolean isFalse() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();

            return state == false;
        }
    }

    /**
     * Sets the internal state to the specified <tt>newState</tt>.
     */
    public void setState(boolean newState) throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();

            if ( newState != state ) {
                state = newState;
                waiter.signalChange();
            }
        }
    }

    /**
     * Sets the internal state to the opposite of whatever is was before
     * the call.
     */
    public void toggleState() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();

            state = !state;
            waiter.signalChange();
        }
    }

    /**
     * If the current state is <tt>true</tt>, then the state is changed
     * to <tt>false</tt>.
     * If not, then the state is left unchanged. The return value
     * indicates whether or not a change occurred.
     *
     * @return <tt>true</tt> if the state was changed, <tt>false</tt> is
     * it was not changed.
     */
    public boolean ifTrueSetFalse() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();

            if ( state == true ) {
                state = false;
                waiter.signalChange();
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * If the current state is <tt>false</tt>, then the state is changed
     * to <tt>true</tt>.
     * If not, then the state is left unchanged. The return value
     * indicates whether or not a change occurred.
     *
     * @return <tt>true</tt> if the state was changed, <tt>false</tt> is
     * it was not changed.
     */
    public boolean ifFalseSetTrue() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();

            if ( state == false ) {
                state = true;
                waiter.signalChange();
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * Waits while the state is <tt>true</tt> up to the specified
     * maximum amount of time.
     */
    public void waitWhileTrue(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        trueCondition.waitWhileTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits while the state is <tt>true</tt>.
     */
    public void waitWhileTrue() throws ShutdownException, InterruptException {
        trueCondition.waitWhileTrue();
    }

    /**
     * Waits until the state is <tt>true</tt> up to the specified
     * maximum amount of time.
     */
    public void waitUntilTrue(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        trueCondition.waitUntilTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits until the state is <tt>true</tt>.
     */
    public void waitUntilTrue() throws ShutdownException, InterruptException {
        trueCondition.waitUntilTrue();
    }

    /**
     * Waits while the state is <tt>false</tt> up to the specified
     * maximum amount of time.
     */
    public void waitWhileFalse(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        trueCondition.waitUntilTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits while the state is <tt>false</tt>.
     */
    public void waitWhileFalse() throws ShutdownException, InterruptException {
        trueCondition.waitUntilTrue();
    }

    /**
     * Waits until the state is <tt>false</tt> up to the specified
     * maximum amount of time.
     */
    public void waitUntilFalse(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        trueCondition.waitWhileTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits until the state is <tt>false</tt>.
     */
    public void waitUntilFalse() throws ShutdownException, InterruptException {
        trueCondition.waitWhileTrue();
    }

    public Waiter getWaiter() {
        return waiter;
    }

    /**
     * Called to shutdown all access to this counter and to dislodge
     * any threads waiting on conditions.
     */
    public void shutdown() {
        waiter.shutdown();
    }

    public boolean isShutdown() {
        return waiter.isShutdown();
    }

    public Object getLockObject() {
        return lockObject;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.