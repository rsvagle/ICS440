package com.programix.thread.assemblyline;

import com.programix.thread.*;

/**
 * This is a convenience class to subclass when a worker is an
 * {@link AssemblyLineProcessWorker}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public abstract class AbstractAssemblyLineProcessWorker<T>
        extends AbstractStandardAssemblyLineWorker<T>
        implements AssemblyLineProcessWorker<T> {

    protected AbstractAssemblyLineProcessWorker(String displayName,
                                                BoundedFIFO<T> inbox,
                                                BoundedFIFO<T> outbox,
                                                int numberOfThreads,
                                                int requestedThreadPriority) {

        super(displayName, inbox, outbox,
            numberOfThreads, requestedThreadPriority);
    }

    protected AbstractAssemblyLineProcessWorker(String displayName,
                                                BoundedFIFO<T> inbox,
                                                BoundedFIFO<T> outbox,
                                                int numberOfThreads) {

        this(displayName, inbox, outbox,
            numberOfThreads, DEFAULT_THREAD_PRIORITY);
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.