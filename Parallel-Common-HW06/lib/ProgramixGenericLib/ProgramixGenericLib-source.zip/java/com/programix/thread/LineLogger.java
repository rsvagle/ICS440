package com.programix.thread;

import java.awt.*;

import javax.swing.*;

import com.programix.util.*;

/**
 * Logs messages a line at a time prefixing each line with the elapsed time
 * since the first message was sent and the name of the thread that sent
 * the message.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class LineLogger implements ThreadSafe {
    private long testStartTime;
    private long lastElapsedTime = -1L;
    private char[] elapsedDigit = new char[12];

    private boolean nextOutIsNewLine = true;
    private StringBuffer buf = new StringBuffer(512);

    private final OutputBuffer outputBuffer;

    private boolean prefixWithTime = true;
    private int timeFormatLength = elapsedDigit.length;
    private boolean prefixWithThreadName = true;
    private int threadNameLength = 10;

    public LineLogger(Output output) {
        outputBuffer = new OutputBuffer(output, 250);
    }

    /**
     * Defaults to use the {@link LineLogger.ConsoleOutput} instance.
     */
    public LineLogger() {
        this(ConsoleOutput.getInstance());
    }

	public void setOutput(Output output) {
        outputBuffer.setRawOutput(output);
	}

    public synchronized boolean isPrefixWithThreadName() {
        return prefixWithThreadName;
    }

    public synchronized void setPrefixWithThreadName(
                                                 boolean prefixWithThreadName) {

        this.prefixWithThreadName = prefixWithThreadName;
    }

    public synchronized int getThreadNameLength() {
        return threadNameLength;
    }

    public synchronized void setThreadNameLength(int threadNameLength) {
        this.threadNameLength = threadNameLength;
    }

    public synchronized boolean isPrefixWithTime() {
        return prefixWithTime;
    }

    public synchronized void setPrefixWithTime(boolean prefixWithTime) {
        this.prefixWithTime = prefixWithTime;
    }

    public synchronized int getTimeFormatLength() {
        return timeFormatLength;
    }

    public synchronized void setTimeFormatLength(int timeFormatLength)
            throws IllegalArgumentException {

        if ( timeFormatLength > elapsedDigit.length ) {
            throw new IllegalArgumentException(
                "Formatted time length can not be more than "
                + elapsedDigit.length);
        }

        if ( timeFormatLength < 5 ) {
            throw new IllegalArgumentException(
                "Formatted time length can not be less than 5 ");
        }

        this.timeFormatLength = timeFormatLength;
    }

    // Give back time as: hh:mm:ss.ppp (up to 99:59:59.999, then rolls over)
    //private synchronized String getElapsedTime() {
    //    updateElapsedTime();
    //    return new String(elapsedDigit);
    //}

    private synchronized void updateElapsedTime() {
        if ( testStartTime == 0L ) {
            testStartTime = System.currentTimeMillis();
        }

        long elapsedTime = System.currentTimeMillis() - testStartTime;
        if ( elapsedTime == lastElapsedTime ) {
            // same as last call... no need to work hard
            return;
        }

        lastElapsedTime = elapsedTime;

        int msPart = (int) (elapsedTime % 1000L);
        int secTotal = (int) (elapsedTime / 1000L);
        int secPart = secTotal % 60;
        int minTotal = secTotal / 60;
        int minPart = minTotal % 60;
        int hrTotal = minTotal / 60;
        int hrPart = hrTotal % 100;

        int ptr = elapsedDigit.length - 1;

        calcDigits(msPart, 3, elapsedDigit, ptr);
        ptr -= 3;

        elapsedDigit[ptr] = '.';
        ptr--;

        calcDigits(secPart, 2, elapsedDigit, ptr);
        ptr -= 2;

        elapsedDigit[ptr] = ':';
        ptr--;

        calcDigits(minPart, 2, elapsedDigit, ptr);
        ptr -= 2;

        elapsedDigit[ptr] = ':';
        ptr--;

        calcDigits(hrPart, 2, elapsedDigit, ptr);
    }

    private static void calcDigits(int val,
                                   int placeCount,
                                   char[] dst,
                                   int ptr) {

        for ( int i = 0; i < placeCount; i++ ){
            int placeVal = val % 10;
            val = val / 10;
            dst[ptr] = (char) ('0' + placeVal);
            ptr--;
        }
    }

	private synchronized void outGuts(String msg, boolean completeLine) {
        if ( nextOutIsNewLine && ( prefixWithTime || prefixWithThreadName ) ) {
            buf.setLength(0);

            if ( prefixWithTime ) {
                updateElapsedTime();

                int offset = elapsedDigit.length - timeFormatLength;
                buf.append(elapsedDigit, offset, timeFormatLength);
                buf.append('|');
            }

            if ( prefixWithThreadName ) {
                buf.append(
                    StringTools.padClip(
                        Thread.currentThread().getName(), threadNameLength));
                buf.append('|');
            }

            buf.append(msg);
            msg = buf.toString();
        }

        outputBuffer.add(msg, completeLine);
        nextOutIsNewLine = completeLine;
	}

	public void out(String msg) {
        outGuts(msg, false);
	}

	public void outln(String msg) {
        outGuts(msg, true);
    }

    public void out(Object msg) {
        String s = (msg == null) ? null : msg.toString();
	    outGuts(s, false);
	}

    public void outln(Object msg) {
        String s = (msg == null) ? null : msg.toString();
        outGuts(s, true);
    }

	public void printStackTrace(Throwable t) {
		String[] msg = StringTools.stackTraceToStringArray(t);
        if ( msg.length < 1 ) {
            return;
        }

        synchronized ( this ) {
            outGuts(msg[0], true);

            for ( int i = 1; i < msg.length; i++ ) {
                outGuts("    " + msg[i], true);
            }
        }
	}

    /**
     * Used as a destination for lines sent to {@link LineLogger}.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static interface Output {
        /**
         * Write out a partial line&mdash;without a newline.
         */
        public void out(String msg);

        /**
         * Write out a full line&mdash;or complete an already partially
         * written line.
         */
        public void outln(String msg);
    } // interface Output

    /**
     * An implementation of {@link Output LineLogger.Output} that just
     * sends the output to the console (<tt>System.out</tt>). This is
     * an <a href="http://en.wikipedia.org/wiki/Singleton_pattern">singlton</a>
     * as there is no need for more than one.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class ConsoleOutput implements Output {
        private static final ConsoleOutput singleton = new ConsoleOutput();

        private ConsoleOutput() {
        }

        /**
         * Returns the one and only instance.
         */
        public static ConsoleOutput getInstance() {
            return singleton;
        }

        public void out(String msg) {
            System.out.print(msg);
        }

        public void outln(String msg) {
            System.out.println(msg);
        }
    } // class ConsoleOutput

    /**
     * An implementation of {@link Output LineLogger.Output} that appends
     * output to a <tt>JTextArea</tt>.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class TextAreaOutput implements Output {
        private JTextArea textArea;
        private JScrollPane scrollPane;
        private boolean nextOutStartsNewLine;

        public TextAreaOutput(int rowCount, int colCount) {
            textArea = new JTextArea(rowCount, colCount);
            textArea.setEditable(false);
            textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

            nextOutStartsNewLine = true;
        }

        public TextAreaOutput() {
            this(20, 40);
        }

        /**
         * Returns the <tt>JTextArea</tt> that's being logged to.
         */
        public JTextArea getTextArea() {
            return textArea;
        }

        /**
         * Returns a <tt>JScrollPane</tt> wrapped around
         * the <tt>JTextArea</tt> that's being logged to.
         */
        public synchronized JScrollPane getTextAreaWrapped() {
            if ( scrollPane == null ) {
                scrollPane = new JScrollPane(textArea);
            }

            return scrollPane;
        }

        public synchronized void out(String msg) {
            if ( nextOutStartsNewLine ) {
                textArea.append("\n");
            }

            textArea.append(msg);
        }

        public synchronized void outln(String msg) {
            out(msg);
            nextOutStartsNewLine = true;
        }
    } // class TextAreaOutput

    private class OutputBuffer implements Runnable {
        private final OutputBufferEntry[] fifo;
        private int head;
        private int tail;
        private int size;

        private Waiter waiter;
        private Waiter.Condition emptyCondition;
        private Waiter.Condition fullCondition;

        private Output rawOutput;
        private volatile boolean noStopRequested;
        private final Thread internalThread;

        public OutputBuffer(Output rawOutput, int fifoCapacity) {
            this.rawOutput = rawOutput;

            head = 0;
            tail = 0;
            size = 0;

            waiter = new Waiter(this);
            emptyCondition = waiter.createCondition(new Waiter.Expression() {
                @Override
                public boolean isTrue() {
                    return isEmpty();
                }
            });

            fullCondition = waiter.createCondition(new Waiter.Expression() {
                @Override
                public boolean isTrue() {
                    return isFull();
                }
            });

            fifo = new OutputBufferEntry[fifoCapacity];
            for ( int i = 0; i < fifo.length; i++ ) {
                fifo[i] = new OutputBufferEntry();
            }

            noStopRequested = true;
            internalThread = new Thread(this, "LineLogger-Worker");
            internalThread.setDaemon(true);
            internalThread.start();
        }

        public synchronized void setRawOutput(Output rawOutput) {
            this.rawOutput = rawOutput;
        }

        public synchronized void run() {
            try {
                while ( noStopRequested ) {
                    waitWhileEmpty();

                    String message = fifo[head].message;
                    boolean sendNewLine = fifo[head].sendNewline;

                    // do not stand in the way of garbage collection
                    fifo[head].message = null;

                    head = (head + 1) % fifo.length;
                    size--;
                    notifyAll();

                    if ( sendNewLine ) {
                        rawOutput.outln(message);
                    } else {
                        rawOutput.out(message);
                    }
                }
            } catch ( InterruptException x ) {
                // ignore, and return
            }
        }

        public synchronized void add(String msg, boolean newLine)
                throws InterruptException {

            waitWhileFull();

            fifo[tail].message = msg;
            fifo[tail].sendNewline = newLine;

            tail = (tail + 1) % fifo.length;
            size++;
            notifyAll();
        }

        public synchronized boolean isEmpty() {
            return size == 0;
        }

        public synchronized boolean isNotEmpty() {
            return size > 0;
        }

        public synchronized boolean isFull() {
            return size == fifo.length;
        }

        public synchronized boolean isNotFull() {
            return size < fifo.length;
        }

        public boolean waitUntilEmpty(long msTimeout)
                throws InterruptException {

            return emptyCondition.waitUntilTrue(msTimeout);
        }

        public void waitUntilEmpty() throws InterruptException {
            emptyCondition.waitUntilTrue();
        }

        public void waitWhileEmpty() throws InterruptException {
            emptyCondition.waitWhileTrue();
        }

        public void waitWhileFull() throws InterruptException {
            fullCondition.waitWhileTrue();
        }

        public boolean stopGracefully(long maxTimeToWaitForEmpty,
                                      long maxTimeToWaitForStop)
                throws InterruptException {

            boolean empty = waitUntilEmpty(maxTimeToWaitForEmpty);
            stopRequest();
            boolean stopped = waitUntilStopped(maxTimeToWaitForStop);
            return empty && stopped;
        }

        public boolean stopGracefully(long maxTimeToWaitForEmpty)
                throws InterruptException {

            return stopGracefully(maxTimeToWaitForEmpty, 1000L);
        }

        /**
         * Wait up to 20 sec for empty, then up to 5 sec for full stop.
         * Returns false if either times out. If true is returned, then
         * the buffer is empty and the thread is stopped.
         */
        public boolean stopGracefully() throws InterruptException {
            return stopGracefully(20000L, 5000L);
        }

        public void stopRequest() {
            noStopRequested = false;
            internalThread.interrupt();
        }

        public boolean waitUntilStopped(long msTimeout)
                throws InterruptException {

            try {
                internalThread.join(msTimeout);
                return internalThread.isAlive();
            } catch ( InterruptedException x ) {
                throw new InterruptException(x);
            }
        }

        public void waitUntilStopped() throws InterruptException {
            waitUntilStopped(ThreadTools.NO_TIMEOUT);
        }
    } // class OutputBuffer

    private static class OutputBufferEntry {
        public String message;
        public boolean sendNewline;
    } // class OutputBufferEntry
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.