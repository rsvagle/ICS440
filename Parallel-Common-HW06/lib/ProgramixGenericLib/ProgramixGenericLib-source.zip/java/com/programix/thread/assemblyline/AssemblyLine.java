package com.programix.thread.assemblyline;

import java.lang.reflect.*;
import java.util.*;

import com.programix.thread.*;

/**
 * An assembly line made up of multiple of {@link AssemblyLineWorker}'s.
 * All of the workers are running.
 * Use {@link Builder} to create instances.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class AssemblyLine<T> {
    private AssemblyLineWorker<T>[] workers;

    private AssemblyLine(AssemblyLineWorker<T>[] workers) {
        this.workers = workers;
    }

    public AssemblyLineWorker<T>[] getWorkers() {
        return workers.clone();
    }

    /**
     * Called to wait for the last worker in the assembly line to be done.
     *
     * @param msTimeout maximum number of ms to wait
     * @throws TimedOutException if still not done after timeout
     * @throws InterruptException if the calling thread is interrupted
     * while waiting.
     */
    public void waitUntilDone(long msTimeout)
            throws TimedOutException, InterruptException {

        workers[workers.length - 1].waitUntilDone(msTimeout);
    }

    /**
     * Called to wait for the last worker in the assembly line to be done,
     * without ever timing out.
     *
     * @throws InterruptException if the calling thread is interrupted
     * while waiting.
     */
    public void waitUntilDone() throws InterruptException {
        waitUntilDone(ThreadTools.NO_TIMEOUT);
    }

    /**
     * Used to create instances of {@link AssemblyLine}.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class Builder<T> {
        private final Class<T> workType;
        private final int defaultFifoCapacity;
        private List<AssemblyLineWorker.Builder<T>> workerBuilderList;
        private List<Integer> inboxFifoCapacityList;
        private int nextFifoCapacity;

        public Builder(Class<T> workType, int defaultFifoCapacity) {
            this.workType = workType;
            this.defaultFifoCapacity = defaultFifoCapacity;
            nextFifoCapacity = defaultFifoCapacity;
            workerBuilderList = new ArrayList<AssemblyLineWorker.Builder<T>>();
            inboxFifoCapacityList = new ArrayList<Integer>();
        }

        public void append(AssemblyLineWorker.Builder<T> workerBuilder) {
            workerBuilderList.add(workerBuilder);
            inboxFifoCapacityList.add(nextFifoCapacity);
            nextFifoCapacity = defaultFifoCapacity;
        }

        public void setNextFifoCapacity(int nextFifoCapacity) {
            this.nextFifoCapacity = nextFifoCapacity;
        }

        public AssemblyLine<T> create() throws IllegalArgumentException {
            AssemblyLineWorker.Builder<T>[] workerBuilders =
                workerBuilderList.toArray(createBuilderArray(0));

            if ( workerBuilders.length == 0 ) {
                throw new IllegalArgumentException(
                    "no worker builders have been specified");
            }

            AssemblyLineWorker<T>[] workers =
                createWorkerArray(workerBuilders.length);
            BoundedFIFO<T>[] fifos = createBoundedFifoArray(workers.length - 1);
            for ( int i = 0; i < fifos.length; i++ ) {
                // add one to the list index because there were the next inbox
                int capacity = inboxFifoCapacityList.get(i + 1);
                fifos[i] = new BoundedFIFO<T>(capacity);
            }

            // build chain from end to beginning
            for ( int i = workers.length - 1; i >= 0; i-- ) {
                boolean firstInChain = (i == 0);
                boolean lastInChain = (i == workers.length - 1);

                BoundedFIFO<T> inbox = null;
                if ( firstInChain == false ) {
                    // not the first one, give it an actual inbox
                    inbox = fifos[i - 1];
                }
                BoundedFIFO<T> outbox = null;
                if ( lastInChain == false ) {
                    // not the last one, give it an actual outbox
                    outbox = fifos[i];
                }

                workers[i] = workerBuilders[i].create(inbox, outbox);
            }

            // start from end to beginning
            for ( int i = workers.length - 1; i >= 0; i-- ) {
                workers[i].kickoff();
            }

            return new AssemblyLine<T>(workers);
        }

        @SuppressWarnings("unchecked")
        private AssemblyLineWorker.Builder<T>[] createBuilderArray(int count) {
            return (AssemblyLineWorker.Builder<T>[]) Array.newInstance(
                AssemblyLineWorker.Builder.class, count);
        }

        @SuppressWarnings("unchecked")
        private AssemblyLineWorker<T>[] createWorkerArray(int count) {
            return (AssemblyLineWorker<T>[]) Array.newInstance(
                AssemblyLineWorker.class, count);
        }

        @SuppressWarnings("unchecked")
        private BoundedFIFO<T>[] createBoundedFifoArray(int count) {
            return (BoundedFIFO<T>[]) Array.newInstance(
                BoundedFIFO.class, count);
        }
    } // class Builder
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.