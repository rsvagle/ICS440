package com.programix.thread;

/**
 * Marker interface used to indicate that a class has been designed to
 * be safely access by multiple threads at the same time.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface ThreadSafe {
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.