package com.programix.thread;

import java.util.*;

/**
 * This class serves as a thread-safe First-In-First-Out (FIFO) which holds
 * a single type with a fixed capacity (see {@link UnboundedFIFO} for
 * unlimited capacity).
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class BoundedFIFO<E> implements ThreadSafe {
    // TODO - consider using a E[], head, tail, size, instead of a List
    private final List<E> fifo;

    private final int capacity;
    private final Object lockObject;
    private final Waiter waiter;
    private final Waiter.Condition fullCondition;
    private final Waiter.Condition emptyCondition;

    private BoundedFIFO(int capacity,
                        Waiter proposedWaiter,
                        Object proposedLockObject) {

        if ( proposedWaiter != null ) {
            waiter = proposedWaiter;
            lockObject = proposedWaiter.getLockObject();
        } else {
            lockObject =
                (proposedLockObject == null) ? this : proposedLockObject;
            waiter = new Waiter(lockObject);
        }

        this.capacity = capacity;

        fifo = new LinkedList<E>();

        fullCondition = waiter.createCondition(new Waiter.Expression() {
            @Override
            public boolean isTrue() {
                return isFull();
            }
        });

        emptyCondition = waiter.createCondition(new Waiter.Expression() {
            @Override
            public boolean isTrue() {
                return isEmpty();
            }
        });
    }

    /**
     * Creates an instance has the specified maximum capacity
     * and synchronizes on the lock used by the specified <tt>waiter</tt>.
     */
    public BoundedFIFO(int capacity, Waiter waiter) {
        this(capacity, waiter, null);
    }

    /**
     * Creates an instance has the specified maximum capacity
     * and synchronizes on the lock used by the specified <tt>lockObject</tt>.
     */
    public BoundedFIFO(int capacity, Object lockObject) {
        this(capacity, null, lockObject);
    }

    /**
     * Creates an instance has the specified maximum capacity
     * and synchronizes on itself.
     */
    public BoundedFIFO(int capacity) {
        this(capacity, null, null);
    }

    public void add(E item, long msTimeout)
            throws InterruptException, TimedOutException, ShutdownException {

        synchronized ( lockObject ) {
            fullCondition.waitWhileTrueWithTimedOutException(msTimeout);
            fifo.add(item);
            waiter.signalChange();
        }
    }

    public void add(E item) throws InterruptException, ShutdownException {
        add(item, ThreadTools.NO_TIMEOUT);
    }

    public E remove(long msTimeout)
            throws InterruptException, TimedOutException, ShutdownException {

        synchronized ( lockObject ) {
            emptyCondition.waitWhileTrueWithTimedOutException(msTimeout);
            waiter.signalChange();
            return fifo.remove(0);
        }
    }

    public E remove() throws InterruptException, ShutdownException {
        return remove(ThreadTools.NO_TIMEOUT);
    }

    public int getSize() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();
            return fifo.size();
        }
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean isEmpty() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();
            return fifo.size() < 1;
        }
    }

    public boolean isNotEmpty() throws ShutdownException {
        return !isEmpty();
    }

    public boolean isFull() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();
            return fifo.size() >= capacity;
        }
    }

    public boolean isNotFull() throws ShutdownException {
        return !isFull();
    }

    public void waitUntilEmpty(long msTimeout)
            throws TimedOutException, InterruptException, ShutdownException {

        emptyCondition.waitUntilTrueWithTimedOutException(msTimeout);
    }

    public void waitUntilEmpty() throws InterruptException, ShutdownException {
        waitUntilEmpty(ThreadTools.NO_TIMEOUT);
    }

    public void waitWhileEmpty(long msTimeout)
            throws TimedOutException, InterruptException, ShutdownException {

        emptyCondition.waitWhileTrueWithTimedOutException(msTimeout);
    }

    public void waitWhileEmpty() throws InterruptException, ShutdownException {
        waitWhileEmpty(ThreadTools.NO_TIMEOUT);
    }

    public void waitUntilFull(long msTimeout)
            throws TimedOutException, InterruptException, ShutdownException {

        fullCondition.waitUntilTrueWithTimedOutException(msTimeout);
    }

    public void waitUntilFull() throws InterruptException, ShutdownException {
        waitUntilFull(ThreadTools.NO_TIMEOUT);
    }

    public void waitWhileFull(long msTimeout)
            throws TimedOutException, InterruptException, ShutdownException {

        fullCondition.waitWhileTrueWithTimedOutException(msTimeout);
    }

    public void waitWhileFull() throws InterruptException, ShutdownException {
        waitWhileFull(ThreadTools.NO_TIMEOUT);
    }

    public Waiter getWaiter() {
        return waiter;
    }

    /**
     * Called to shutdown all access to this counter and to dislodge
     * any threads waiting on conditions.
     */
    public void shutdown() {
        waiter.shutdown();
    }

    public boolean isShutdown() {
        return waiter.isShutdown();
    }

    public Object getLockObject() {
        return lockObject;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.