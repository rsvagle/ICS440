package com.programix.thread;

import com.programix.thread.ix.*;

/**
 * Utility to assist in waiting for certain conditions to be met with
 * and without timeouts. To specify an expression to be evaluated, see
 * {@link Waiter.Expression}.
 * <p>
 * <tt>Waiter</tt> also handles the potential for a <i>shutdown</i>
 * by throwing {@link ShutdownException} from most methods.
 * <p>
 * {@link TimedOutException} is thrown by some methods to indicate that a
 * timeout occurred. Some other methods may simple return
 * {@link ThreadTools#TIMED_OUT} (<tt>false</tt>) to indicate a timeout.
 * <p>
 * {@link TimedOutException}, {@link ShutdownException}, and
 * {@link InterruptException} are all subclasses
 * of {@link RuntimeException} so callers are not <i>required</i>
 * to catch them.
 * <p>
 * <a ref="UNIVERSAL"><b><u>Universal Behavior</u></b></a>
 * <p>
 * <b><tt>{@link InterruptException}</tt></b> - thrown from methods
 * when the calling thread is interrupted while waiting inside the method.
 * This exception is only thrown if any waiting is necessary; if the
 * condition has already been met, the calling thread doesn't need to wait
 * and will not notice if it has been interrupted or not.
 * <tt>InterruptException</tt> is a subclass of {@link RuntimeException} and
 * does not have to be caught by the caller.
 * For a version that uses <tt>java.lang.InterruptedException</tt> instead,
 * see {@link WaiterIx}.
 * <p>
 * <b><tt>{@link ShutdownException}</tt></b> - thrown from methods when this
 * <tt>WaitFor</tt> has been <i>shutdown</i> via {@link #shutdown}.
 * If the shutdown occurs <i>before</i> a method is called, then the
 * method immediately throws a <tt>ShutdownException</tt>
 * (without evaluating anything else).
 * If the shutdown occurs while the calling thread is waiting inside
 * a method, then the waiting ends and the method throws a
 * <tt>ShutdownException</tt> (without evaluating anything else).
 * <tt>ShutdownException</tt> is a subclass of {@link RuntimeException} and
 * does not have to be caught by the caller.
 * <p>
 * <b><tt>msTimeout</tt></b> - the maximum number of milliseconds to wait for a
 * condition to be met. On occasion, the actual waiting time may
 * be slightly longer due to lock contention and CPU scheduling.
 * When the calling thread runs out of time, it competes to reacquire the lock,
 * and the condition is evaluated once again. If the condition has finally
 * been met (with<i>out</i> any regard to how much time may have elapsed),
 * then the calling thread leaves the method indicating 'success'
 * (the condition <i>has</i> been met@mdash;even if a few milliseconds
 * too late). If {@link ThreadTools#NO_TIMEOUT} (<tt>0L</tt>)
 * is passed in for <tt>msTimeout</tt>, then waiting will continue
 * without regard for how much time has elapsed (waiting will never timeout).
 * If a negative timeout is passed in, then no waiting will occur; the
 * condition will just be evaluated immediately. If the condition has already
 * been met, then the calling thread leaves the method indicating 'success'
 * (the condition <i>has</i> been met&mdash;even if the timeout value is
 * silly). If the condition has not been met, then this 'negative timeout'
 * situation is treated as a timeout).
 * <p>
 * <b><tt>{@link ThreadTools#SUCCESS}</tt> and
 * <tt>{@link ThreadTools#TIMED_OUT}</tt></b> - are used as return values
 * by <tt>waitWhileX</tt> and <tt>wailUntilY</tt> methods that take a
 * timeout value (<tt>msTimeout</tt>).
 * {@link ThreadTools#SUCCESS} (<tt>true</tt>) is returned if the condition
 * was already met at the time of invocation or was met after some waiting
 * some waiting (and is still being met while the lock is held).
 * {@link ThreadTools#TIMED_OUT} (<tt>false</tt>) is returned if the
 * specified time (<tt>msTimeout</tt>) elapses and the condition is still
 * not met (or if a negative timeout value was passed in and the condition
 * was not already met).
 * <p>
 * <b><tt>{@link TimedOutException}</tt></b> - can be thrown
 * by <tt>waitWhileX</tt> and <tt>wailUntilY</tt> methods that take a
 * timeout value (<tt>msTimeout</tt>) and do not use a return value
 * to indicate timeout (these methods declare that they might throw a
 * <tt>TimedOutException</tt>).
 * <tt>TimedOutException</tt> is thrown if the condition
 * has not been met within the time limit specified by <tt>msTimeout</tt>.
 * <tt>TimedOutException</tt> is a subclass of {@link RuntimeException} and
 * does not have to be caught by the caller.
 *
 * <p>
 * For advanced tools and utilities related to multithreading, please
 * check out <a href="http://www.jthreadkit.com/">JThreadKit</a>.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class Waiter implements ThreadSafe {
    private final Object lock;
    private boolean shutdown;

    /**
     * Sets up a <tt>Waiter</tt> that's ready to have conditions created.
     *
     * @param lock the object to synchronize on for safe multithreaded
     * access and the object to use for {@link Object#wait wait} and
     * {@link Object#notifyAll notifyAll} signaling.
     */
    public Waiter(Object lock) {
        this.lock = lock;
        this.shutdown = false;
    }

    /**
     * Creates an {@link Condition} for the specified {@link Expression}
     * that is tightly associated with this <tt>Waiter</tt>.
     * All <tt>WaitFor.Condition</tt>'s lock on the same object, hear about
     * a change via {@link #signalChange()}, and throw
     * {@link ShutdownException} when (or if) this <tt>Waiter</tt> is shutdown.
     */
    public Waiter.Condition createCondition(Expression expr) {
        return new Condition(expr);
    }

    /**
     * Called to signal to any and all waiting threads (on the lock object
     * specified at construction) that something has changed.
     * Internally, <tt>notifyAll</tt> is used.
     *
     */
    public void signalChange() {
        synchronized ( lock ) {
            lock.notifyAll();
        }
    }

    /**
     * Immediately shuts down this <tt>Waiter</tt>. Any threads that are
     * waiting inside <tt>waitUntilX</tt> and <tt>waitWhileY</tt> methods
     * will throw a {@link ShutdownException} from the method. Any future
     * calls to most of the methods on this class will result in a
     * <tt>Shutdown</tt> exception being immediately thrown (any of the
     * methods on this class that declare that they might throw a
     * <tt>ShutdownException</tt> fall into this category).
     * <p>
     * This method may be harmlessly called multiple times.
     */
    public void shutdown() {
        synchronized ( lock ) {
            shutdown = true;
            lock.notifyAll();
        }
    }

    /**
     * Returns <tt>true</tt> if any thread has previously called
     * {@link #shutdown}.
     */
    public boolean isShutdown() {
        synchronized ( lock ) {
            return shutdown;
        }
    }

    /**
     * Immediately throws a {@link ShutdownException} if any thread has
     * previously called {@link #shutdown}.
     */
    public void shutdownCheck() throws ShutdownException {
        synchronized ( lock ) {
            if ( shutdown ) {
                throw new ShutdownException();
            }
        }
    }

    /**
     * Returns the reference to the object that is being used to lock
     * on by all the internal <tt>synchronized</tt>'s and <tt>wait</tt>
     * and <tt>notifyAll</tt> methods.
     */
    public Object getLockObject() {
        return lock;
    }

    private boolean waitUntilTrue(Expression expression, long msTimeout)
                throws InterruptException, ShutdownException {

        synchronized ( lock ) {
            shutdownCheck();

            if ( expression.isTrue() ) {
                return ThreadTools.SUCCESS;
            }

            try {
                if ( msTimeout == ThreadTools.NO_TIMEOUT ) {
                    do {
                        lock.wait();
                        shutdownCheck();
                    } while ( expression.isFalse() );

                    return ThreadTools.SUCCESS;
                }

                long endTime = System.currentTimeMillis() + msTimeout;
                long msRemaining = msTimeout;

                while ( msRemaining > 0L ) {
                    lock.wait(msRemaining);
                    shutdownCheck();

                    if ( expression.isTrue() ) {
                        return ThreadTools.SUCCESS;
                    }

                    msRemaining = endTime - System.currentTimeMillis();
                }

                return ThreadTools.TIMED_OUT;
            } catch ( InterruptedException x ) {
                throw new InterruptException(x);
            }
        }
    }

    private boolean waitWhileTrue(Expression expression, long msTimeout)
            throws InterruptException, ShutdownException {

        synchronized ( lock ) {
            shutdownCheck();

            if ( expression.isFalse() ) {
                return ThreadTools.SUCCESS;
            }

            try {
                if ( msTimeout == ThreadTools.NO_TIMEOUT ) {
                    do {
                        lock.wait();
                        shutdownCheck();
                    } while ( expression.isTrue() );

                    return ThreadTools.SUCCESS;
                }

                long endTime = System.currentTimeMillis() + msTimeout;
                long msRemaining = msTimeout;

                while ( msRemaining > 0L ) {
                    lock.wait(msRemaining);
                    shutdownCheck();

                    if ( expression.isFalse() ) {
                        return ThreadTools.SUCCESS;
                    }

                    msRemaining = endTime - System.currentTimeMillis();
                }

                return ThreadTools.TIMED_OUT;
            } catch ( InterruptedException x ) {
                throw new InterruptException(x);
            }
        }
    }

    /**
     * Used to provide {@link Condition} with a boolean <i>expression</i>
     * to evaluate by subclassing and implementing the {@link #isTrue()}
     * method.
     * An <tt>Expression</tt> is passed into the
     * {@link Waiter#createCondition(Expression) createCondition}
     * method of {@link Waiter}.
     * <p>
     * When these two methods are called from {@link Waiter} and
     * {@link Condition}, the calling thread will be holding a lock on
     * the object specified as a parameter to the constructor
     * for <tt>WaitFor</tt>.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static abstract class Expression {
        /**
         * Returns <tt>true</tt> when the expression currently evaluates to
         * be, well, <tt>true</tt>. Implemented by subclasses.
         */
        public abstract boolean isTrue();

        /**
         * Returns <tt>true</tt> when the expression currently evaluates to
         * be <tt>false</tt>. The implementation on this class simply
         * does:
         * <pre class="preshade">
         * return <b>!</b>isTrue();
         * </pre>
         * Feel free to override it if you have a more efficient way of
         * determining that it is false.
         */
        public boolean isFalse() {
            return !isTrue();
        }
    } // class Expression

    /**
     * Used to associate additional conditions on an existing {@link Waiter}.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public class Condition {
        private Expression expression;

        private Condition(Expression expression) {
            this.expression = expression;
        }

        /**
         * Returns <tt>true</tt> if the expression specified at construction
         * currently evaluates to <tt>true</tt>.
         *
         * @throws ShutdownException if already shutdown.
         */
        public boolean isTrue() throws ShutdownException {
            synchronized ( lock ) {
                shutdownCheck();
                return expression.isTrue();
            }
        }

        /**
         * Returns <tt>true</tt> if the expression specified at construction
         * currently evaluates to <tt>false</tt>.
         *
         * @throws ShutdownException if already shutdown.
         */
        public boolean isFalse() throws ShutdownException {
            synchronized ( lock ) {
                shutdownCheck();
                return expression.isFalse();
            }
        }

        /**
         * Waits (up to a maximum amount of time) for the supplied
         * {@link Waiter.Expression expression} to evaluate to <tt>true</tt>.
         * Uses a return value to signal whether or not a timeout occurred.
         * See the Universal Behavior section in the class-level documentation
         * of {@link Waiter} for details about the timeouts, return
         * values, exceptions potentially thrown, and other general behavior.
         */
        public boolean waitUntilTrue(long msTimeout)
                throws InterruptException, ShutdownException {

            return Waiter.this.waitUntilTrue(expression, msTimeout);
        }

        /**
         * Waits (for an unlimited amount of time) for the supplied
         * {@link Waiter.Expression expression} to evaluate to <tt>true</tt>.
         * See the Universal Behavior section in the class-level documentation
         * of {@link Waiter} for details about the timeouts, return
         * values, exceptions potentially thrown, and other general behavior.
         */
        public void waitUntilTrue() throws InterruptException,
                                           ShutdownException {

            waitUntilTrue(ThreadTools.NO_TIMEOUT);
        }

        /**
         * Waits (up to a maximum amount of time) for the supplied
         * {@link Waiter.Expression expression} to evaluate to <tt>true</tt>.
         * Throws {@link TimedOutException} to signal that a timeout occurred.
         * See the Universal Behavior section in the class-level documentation
         * of {@link Waiter} for details about the timeouts, return
         * values, exceptions potentially thrown, and other general behavior.
         */
        public void waitUntilTrueWithTimedOutException(long msTimeout)
            throws InterruptException,
                   TimedOutException,
                   ShutdownException {

            if ( waitUntilTrue(msTimeout) == ThreadTools.TIMED_OUT ) {
                throw new TimedOutException(msTimeout);
            }
        }

        /**
         * Waits (up to a maximum amount of time) for the supplied
         * {@link Waiter.Expression expression} to evaluate to <tt>false</tt>.
         * Uses a return value to signal whether or not a timeout occurred.
         * See the Universal Behavior section in the class-level documentation
         * of {@link Waiter} for details about the timeouts, return
         * values, exceptions potentially thrown, and other general behavior.
         */
        public boolean waitWhileTrue(long msTimeout)
                throws InterruptException, ShutdownException {

            return Waiter.this.waitWhileTrue(expression, msTimeout);
        }

        /**
         * Waits (for an unlimited amount of time) for the supplied
         * {@link Waiter.Expression expression} to evaluate to <tt>false</tt>.
         * See the Universal Behavior section in the class-level documentation
         * of {@link Waiter} for details about the timeouts, return
         * values, exceptions potentially thrown, and other general behavior.
         */
        public void waitWhileTrue() throws InterruptException,
                                           ShutdownException {

            waitWhileTrue(ThreadTools.NO_TIMEOUT);
        }

        /**
         * Waits (up to a maximum amount of time) for the supplied
         * {@link Waiter.Expression expression} to evaluate to <tt>false</tt>.
         * Throws {@link TimedOutException} to signal that a timeout occurred.
         * See the Universal Behavior section in the class-level documentation
         * of {@link Waiter} for details about the timeouts, return
         * values, exceptions potentially thrown, and other general behavior.
         */
        public void waitWhileTrueWithTimedOutException(long msTimeout)
            throws InterruptException,
                   TimedOutException,
                   ShutdownException {

            if ( waitWhileTrue(msTimeout) == ThreadTools.TIMED_OUT ) {
                throw new TimedOutException(msTimeout);
            }
        }

        /**
         * Returns the {@link Waiter} that owns this condition.
         */
        public Waiter getOwner() {
            return Waiter.this;
        }
    } // class Condition
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.