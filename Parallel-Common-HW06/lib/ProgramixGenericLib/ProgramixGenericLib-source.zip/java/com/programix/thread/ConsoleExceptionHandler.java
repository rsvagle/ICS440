package com.programix.thread;

/**
 * An implementation of {@link ExceptionHandler} that prints a 
 * stack trace to {@link System#err System.err}. 
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ConsoleExceptionHandler implements ExceptionHandler {
    public void handle(Exception x) {
        x.printStackTrace(System.err);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.