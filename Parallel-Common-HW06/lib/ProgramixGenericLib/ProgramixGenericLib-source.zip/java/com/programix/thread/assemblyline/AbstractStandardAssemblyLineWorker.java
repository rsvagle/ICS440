package com.programix.thread.assemblyline;

import com.programix.thread.*;

/**
 * Serves as the "standard" worker pattern.
 * In particular, it serves as the superclass for
 * {@link AbstractAssemblyLineCreateWorker} or
 * {@link AbstractAssemblyLineProcessWorker}
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public abstract class AbstractStandardAssemblyLineWorker<T>
        extends AbstractAssemblyLineWorker<T> {

    private AssemblyLineCreateWorker<T> createWorker;
    private AssemblyLineProcessWorker<T> processWorker;

    private final Object statisticsLock;
    private int totalItemCount;
    private double totalSecondsWaitingOnInbox;
    private double totalSecondsWaitingOnOutbox;
    private double totalSecondsProcessing;

    protected AbstractStandardAssemblyLineWorker(String displayName,
                                                 BoundedFIFO<T> inbox,
                                                 BoundedFIFO<T> outbox,
                                                 int numberOfThreads,
                                                 int requestedThreadPriority) {

        super(displayName, inbox, outbox,
            numberOfThreads, requestedThreadPriority);

        statisticsLock = new Object();
        setupKindOfWorker();
    }

    protected AbstractStandardAssemblyLineWorker(String displayName,
                                                 BoundedFIFO<T> inbox,
                                                 BoundedFIFO<T> outbox,
                                                 int numberOfThreads) {

        this(displayName, inbox, outbox,
            numberOfThreads, DEFAULT_THREAD_PRIORITY);
    }

    @SuppressWarnings("unchecked")
    private void setupKindOfWorker() {
        if ( this instanceof AssemblyLineCreateWorker ) {
            if ( inbox != null ) {
                throw new IllegalStateException(
                    "inbox must be null for AssemblyLineCreateWorker's");
            }
            createWorker = (AssemblyLineCreateWorker<T>) this;
        } else if ( this instanceof AssemblyLineProcessWorker ) {
            if ( inbox == null ) {
                throw new IllegalStateException(
                    "inbox must not be null for AssemblyLineProcessWorker's");
            }
            processWorker = (AssemblyLineProcessWorker<T>) this;
        } else {
            throw new IllegalArgumentException("worker must be one of " +
        		"AssemblyLineCreateWorker or AssemblyLineProcessWorker");
        }
    }

    // called once by each of the worker threads
    @Override
    protected void runWork() {
        int itemCount = 0;
        NanoTimer inboxWaitTime = NanoTimer.createStopped();
        NanoTimer processingTime = NanoTimer.createStopped();
        NanoTimer outboxWaitTime = NanoTimer.createStopped();
        try {
            while ( true ) {
                T item = null;

                if ( inbox != null ) {
                    try {
                        inboxWaitTime.start();
                        item = inbox.remove();
                        itemCount++;
                    } catch ( ShutdownException x ) {
                        // normal way that we find out that we're done!
                        return;
                    } finally {
                        inboxWaitTime.stop();
                    }
                }

                boolean success = false;
                try {
                    processingTime.start();
                    if ( processWorker != null ) {
                        processWorker.processItem(item);
                    } else {
                        item = createWorker.createItem();
                        if ( item == null ) {
                            // normal way that we find out that we're done!
                            return;
                        }
                        itemCount++;
                    }
                    success = true;
                } catch ( Exception x ) {
                    x.printStackTrace();
                } finally {
                    processingTime.stop();
                }

                if ( success ) {
                    if ( outbox != null ) {
                        outboxWaitTime.start();
                        outbox.add(item);
                        outboxWaitTime.stop();
                    }
                } else {
                    // TODO - log this somewhere too...
                    System.err.println("In " + displayName + ", skipping " +
                        item + " because of trouble!");
                }
            }
        } finally {
            synchronized ( statisticsLock ) {
                totalItemCount += itemCount;
                totalSecondsProcessing += processingTime.getElapsedSeconds();
                totalSecondsWaitingOnInbox += inboxWaitTime.getElapsedSeconds();
                totalSecondsWaitingOnOutbox +=
                    outboxWaitTime.getElapsedSeconds();
            }
        }
    }

    @Override
    protected String createSummaryText() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.createSummaryText());
        synchronized ( statisticsLock ) {
            sb.append(String.format(
                ", completed %d items processing for %.3f seconds " +
                    "(avg %.1f ms each)",
                totalItemCount,
                totalSecondsProcessing,
                totalSecondsProcessing * 1000.0 / totalItemCount));

            if ( inbox != null ) {
                sb.append(String.format(
                    " and inbox waiting for %.3f seconds " +
                        "(avg %.1f ms each time)",
                    totalSecondsWaitingOnInbox,
                    totalSecondsWaitingOnInbox * 1000.0 / totalItemCount));
            }

            if ( outbox != null ) {
                sb.append(String.format(
                    " and outbox waiting for %.3f seconds " +
                        "(avg %.1f ms each time)",
                    totalSecondsWaitingOnOutbox,
                    totalSecondsWaitingOnOutbox * 1000.0 / totalItemCount));
            }
        }

        return sb.toString();
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.