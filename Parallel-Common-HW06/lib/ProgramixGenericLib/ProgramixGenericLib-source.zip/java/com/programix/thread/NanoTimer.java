package com.programix.thread;

import com.programix.time.*;

/**
 * Used to time things with nanosecond accuracy. Multiple start and
 * stop calls can be made.
 * Instances are relatively cheap (in particular, there is no internal
 * thread running).
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class NanoTimer {
    private static final double NS_PER_MILLISECOND = 1.0e6;
    private static final double NS_PER_SECOND = 1.0e9;
    private static final double NS_PER_MINUTE =
        NS_PER_MILLISECOND * DateTools.MS_PER_MINUTE;
    private static final double NS_PER_HOUR =
        NS_PER_MILLISECOND * DateTools.MS_PER_HOUR;
    private static final double NS_PER_DAY =
        NS_PER_MILLISECOND * DateTools.MS_PER_DAY;

    private long nsStartThisInterval = 0L;
    private long nsTotalPreviousInterval = 0L;
    private boolean paused = true;

    // use either createStarted or createStopped
    private NanoTimer() {
    }

    /**
     * Creates a timer which is already running.
     */
    public static NanoTimer createStarted() {
        NanoTimer timer = new NanoTimer();
        timer.start();
        return timer;
    }

    /**
     * Creates a timer which is stopped (no accumulated time yet).
     */
    public static NanoTimer createStopped() {
        return new NanoTimer();
    }

    public synchronized void start() {
        if ( paused ) {
            paused = false;
            nsStartThisInterval = System.nanoTime();
        }
    }

    public synchronized void stop() {
        if ( !paused ) {
            paused = true;
            nsTotalPreviousInterval +=
                (System.nanoTime() - nsStartThisInterval);
        }
    }

    /**
     * Stops the timer and resets the accumulated time to 0.
     */
    public synchronized void resetAndStop() {
        stop();
        nsTotalPreviousInterval = 0L;
    }

    /**
     * Stops the timer, resets the accumulated time to 0, and then restarts it.
     */
    public synchronized void resetAndStart() {
        resetAndStop();
        start();
    }

    public synchronized long getElapsedNanoseconds() {
        if ( paused ) {
            return nsTotalPreviousInterval;
        } else {
            return nsTotalPreviousInterval +
                (System.nanoTime() - nsStartThisInterval);
        }
    }

    public double getElapsedMilliseconds() {
        return getElapsedNanoseconds() / NS_PER_MILLISECOND;
    }

    public double getElapsedSeconds() {
        return getElapsedNanoseconds() / NS_PER_SECOND;
    }

    public double getElapsedMinutes() {
        return getElapsedNanoseconds() / NS_PER_MINUTE;
    }

    public double getElapsedHours() {
        return getElapsedNanoseconds() / NS_PER_HOUR;
    }

    public double getElapsedDays() {
        return getElapsedNanoseconds() / NS_PER_DAY;
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.