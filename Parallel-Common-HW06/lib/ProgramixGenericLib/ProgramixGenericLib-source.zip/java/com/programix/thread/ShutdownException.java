package com.programix.thread;

/**
 * Thrown to indicate that the object that a method was invoked against
 * has been shutdown. The shutdown may have occurred at some point in the 
 * past, or the shutdown may have occurred during the time that the 
 * caller was inside the method.
 * <p>
 * This is a {@link RuntimeException} so callers are not <i>required</i>
 * to catch it.
 * <p>
 * For advanced tools and utilities related to multithreading, please
 * check out <a href="http://www.jthreadkit.com/">JThreadKit</a>.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ShutdownException extends RuntimeException {
    public ShutdownException() {
        super();
    }

    public ShutdownException(String message) {
        super(message);
    }

    public ShutdownException(String message, Throwable cause) {
        super(message, cause);
    }

    public ShutdownException(Throwable cause) {
        super(cause);
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.