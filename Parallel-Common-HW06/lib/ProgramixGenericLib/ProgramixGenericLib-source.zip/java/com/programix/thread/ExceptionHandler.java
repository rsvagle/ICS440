package com.programix.thread;

/**
 * Sometimes self-running objects accept an <tt>ExceptionHandler</tt>
 * as a means to have the self-running object's internal thread
 * report unexpected trouble. The <tt>ExceptionHandler</tt> is then
 * responsible for deciding where to report the exception. 
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface ExceptionHandler {
    
    /**
     * Called when a thread encounters an exception and does not know
     * where to report it.
     */
    void handle(Exception x);
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.