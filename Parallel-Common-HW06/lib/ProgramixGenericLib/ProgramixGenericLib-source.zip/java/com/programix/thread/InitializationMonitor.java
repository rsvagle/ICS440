package com.programix.thread;

/**
 * This class serves as a thread-safe way to monitor the initialization
 * of a component in a system.
 * <p>
 * This monitor starts off in the "in progress" state and
 * ends up in either one of two states: "success" or "failure".
 * Only on state transition occurs (they state either
 * goes from "in progress" to "success"
 * or it goes from "in progress" to "failed").
 * There is no way to "reset" or "retry"&mdash;that is, the state never
 * returns to "in progress".
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class InitializationMonitor implements ThreadSafe {
    private static final int IN_PROGRESS = 1;
    private static final int SUCCESS = 2;
    private static final int FAILURE = 3;

    private int state;
    private final Object lockObject;

    private final Waiter waiter;
    private final Waiter.Condition initializingCondition;

    /**
     * Creates a monitor that starts off in the "in progress" state.
     *
     * @param proposedWaiter the {@link Waiter} to use.
     * If <tt>null</tt>, then a new {@link Waiter} is automatically created.
     * @param proposedLockObject the object to synchronize on.
     * If <tt>null</tt>, the the synchronization will be on this instance.
     */
    private InitializationMonitor(Waiter proposedWaiter,
                                  Object proposedLockObject) {

        if ( proposedWaiter != null ) {
            waiter = proposedWaiter;
            lockObject = proposedWaiter.getLockObject();
        } else {
            lockObject =
                (proposedLockObject == null) ? this : proposedLockObject;
            waiter = new Waiter(lockObject);
        }

        state = IN_PROGRESS;

        initializingCondition = waiter.createCondition(new Waiter.Expression() {
            @Override
            public boolean isTrue() {
                return state == IN_PROGRESS;
            }
        });
    }

    /**
     * Creates a monitor that starts off in the "in progress" state.
     *
     * @param waiter the {@link Waiter} to use.
     * If <tt>null</tt>, then a new {@link Waiter} is automatically created.
     */
    public InitializationMonitor(Waiter waiter) {
        this(waiter, null);
    }

    /**
     * Creates a monitor that starts off in the "in progress" state.
     *
     * @param lockObject the object to synchronize on.
     * If <tt>null</tt>, the the synchronization will be on this instance.
     */
    public InitializationMonitor(Object lockObject) {
        this(null, lockObject);
    }

    /**
     * Creates a monitor that starts off in the "in progress" state
     * and locks on this instance.
     */
    public InitializationMonitor() {
        this(null, null);
    }

    /**
     * Returns <tt>true</tt> while the initialization is still "in progress".
     */
    public boolean isInProgress() {
        synchronized ( lockObject ) {
            return state == IN_PROGRESS;
        }
    }

    /**
     * Returns <tt>true</tt> if the initialization is complete and was
     * successful.
     */
    public boolean isSuccess() {
        synchronized ( lockObject ) {
            return state == SUCCESS;
        }
    }

    /**
     * Returns <tt>true</tt> if the initialization is complete but failed.
     */
    public boolean isFailure() {
        synchronized ( lockObject ) {
            return state == FAILURE;
        }
    }

    /**
     * Mark the initialization as complete and successful.
     *
     * @throws IllegalStateException if the state is not currently
     * "in progress".
     */
    public void indicateSuccess() throws IllegalStateException {
        synchronized ( lockObject ) {
            if ( state != IN_PROGRESS ) {
                throw new IllegalStateException("Can not mark as successful " +
                        "because completion state has been previously set");
            }

            state = SUCCESS;
            waiter.signalChange();
        }
    }

    /**
     * Mark the initialization as complete and successful if it has
     * not already been marked as a failure. If this is "in progress", then
     * it is transitions to "success". If this is already "success",
     * then nothing is changed and no exception is thrown.
     *
     * @throws IllegalStateException if the state is already "failure".
     */
    public void indicateSuccessIfNotFailure() throws IllegalStateException {
        synchronized ( lockObject ) {
            if ( state == FAILURE ) {
                throw new IllegalStateException("Can not mark as successful " +
                    "because failure state has been previously set");
            } else if ( state == IN_PROGRESS ) {
                state = SUCCESS;
                waiter.signalChange();
            }
        }
    }

    /**
     * Mark the initialization as complete but a failure.
     *
     * @throws IllegalStateException if the state is not currently
     * "in progress".
     */
    public void indicateFailure() throws IllegalStateException {
        synchronized ( lockObject ) {
            if ( state != IN_PROGRESS ) {
                throw new IllegalStateException("Can not mark as failure " +
                "because completion state has been previously set");
            }

            state = FAILURE;
            waiter.signalChange();
        }
    }

    /**
     * Mark the initialization as complete but a failure if it has
     * not already been marked as a success. If this is "in progress", then
     * it is transitions to "failure". If this is already "failure",
     * then nothing is changed and no exception is thrown.
     *
     * @throws IllegalStateException if the state is already "success".
     */
    public void indicateFailureIfNotSuccess() throws IllegalStateException {
        synchronized ( lockObject ) {
            if ( state == SUCCESS ) {
                throw new IllegalStateException("Can not mark as failure " +
                    "because success state has been previously set");
            } else if ( state == IN_PROGRESS ) {
                state = FAILURE;
                waiter.signalChange();
            }
        }
    }

    /**
     * Waits until the initialization has completed successfully.
     * If the initialization fails, then a {@link FailedException} is
     * thrown.
     *
     * @param msTimeout the maximum number of ms to wait
     * @throws FailedException if the initialization completed, but was a
     * failure.
     * @throws InterruptException if interrupted while waiting
     * @throws TimedOutException if the time runs out and it is still
     * "in progress".
     */
    public void waitUntilSuccess(long msTimeout)
            throws InitializationMonitor.FailedException,
                   InterruptException,
                   TimedOutException {

        synchronized ( lockObject ) {
            initializingCondition.waitWhileTrueWithTimedOutException(msTimeout);

            if ( state == SUCCESS ) {
                return;
            } else {
                throw new FailedException("Initialization failed");
            }
        }
    }

    /**
     * Waits until the initialization has completed successfully.
     * If the initialization fails, then a {@link FailedException} is
     * thrown.
     *
     * @throws FailedException if the initialization completed, but was a
     * failure.
     * @throws InterruptException if interrupted while waiting
     */
    public void waitUntilSuccess()
            throws InitializationMonitor.FailedException, InterruptException {

        waitUntilSuccess(ThreadTools.NO_TIMEOUT);
    }

    /**
     * Waits until the initialization is completed&mdash;whether it is
     * successful or a failure. Call {@link #isSuccess()} and/or call
     * {@link #isFailure()} to find out the result when no
     * longer "in progress".
     *
     * @param msTimeout the maximum number of ms to wait
     * @throws InterruptException if interrupted while waiting
     * @throws TimedOutException if the time runs out and it is still
     * "in progress".
     */
    public void waitWhileInProgress(long msTimeout)
            throws InterruptException, TimedOutException {

        initializingCondition.waitWhileTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits until the initialization is completed&mdash;whether it is
     * successful or a failure. Call {@link #isSuccess()} and/or call
     * {@link #isFailure()} to find out the result when no
     * longer "in progress".
     *
     * @throws InterruptException if interrupted while waiting
     */
    public void waitWhileInProgress() throws InterruptException {
        waitWhileInProgress(ThreadTools.NO_TIMEOUT);
    }

    /**
     * Thrown by some methods on {@link InitializationMonitor}
     * to indicate that the initialization failed.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class FailedException extends Exception {
        public FailedException(String msg) {
            super(msg);
        }
    } // class FailedException
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.