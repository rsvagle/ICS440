package com.programix.thread.assemblyline;

import com.programix.thread.*;

/**
 * Must be implemented by all workers on the {@link AssemblyLine}.
 * Workers must NOT start an internal thread during construction.
 * The {@link #kickoff()} method will be called by the framework when it is
 * time to start the running of the worker. See
 * {@link AbstractStandardAssemblyLineWorker#kickoff()} for the
 * common situation.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface AssemblyLineWorker<T> {
    /**
     * Called by the {@link AssemblyLine} framework when this worker should
     * spawn an internal thread (or possibly multiple threads) to do its work.
     */
    void kickoff();

    /**
     * Called by code outside of the worker to wait for this worker to be done.
     *
     * @param msTimeout maximum number of ms to wait
     * @throws TimedOutException if still not done after timeout
     * @throws InterruptException if the calling thread is interrupted
     * while waiting.
     */
    void waitUntilDone(long msTimeout)
        throws TimedOutException, InterruptException;

    /**
     * This interface is used to create {@link AssemblyLineWorker}'s.
     */
    public static interface Builder<T> {
        /**
         * This method is called by the {@link AssemblyLine} framework when
         * the workers on the line created.
         * Do NOT call the {@link AssemblyLineWorker#kickoff()} method,
         * that will be called by the framework.
         *
         * @param inbox the source of items to work on, will be null for
         * the first worker in the {@link AssemblyLine}.
         * @param outbox the destination to place items that have been
         * worked on by this worker, will be null for the last worker
         * in the {@link AssemblyLine}.
         */
        AssemblyLineWorker<T> create(BoundedFIFO<T> inbox,
                                     BoundedFIFO<T> outbox);
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.