package com.programix.thread.assemblyline;

/**
 * The process worker is in the middle of the assembly line and
 * processes one item at a time.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface AssemblyLineProcessWorker<T> extends AssemblyLineWorker<T> {
    void processItem(T item) throws Exception;
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.