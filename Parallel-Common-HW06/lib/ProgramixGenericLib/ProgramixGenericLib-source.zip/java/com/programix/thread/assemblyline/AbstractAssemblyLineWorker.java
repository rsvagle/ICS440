package com.programix.thread.assemblyline;

import com.programix.thread.*;
import com.programix.util.*;

/**
 * A partial implementation of {@link AssemblyLineWorker} which can
 * often serve as a helpful superclass.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public abstract class AbstractAssemblyLineWorker<T>
        implements AssemblyLineWorker<T> {

    public static final int DEFAULT_THREAD_PRIORITY = -1;

    protected final String displayName;
    protected final BoundedFIFO<T> inbox;
    protected final BoundedFIFO<T> outbox;

    private final int numberOfThreads;
    private final int requestedThreadPriority;
    private final BooleanState workerDone;

    private volatile Thread[] internalThreads;

    private final NanoTimer workerTimer;

    /**
     * Sets up the parameters for this worker.
     *
     * @param displayName the name of this worker, never null.
     * @param inbox the source of items for this worker, or null.
     * @param outbox the destination for items after the worker is done with
     * them, or null.
     * @param numberOfThreads the number of workers to spawn.
     * @param requestedThreadPriority the desired priority for worker
     * thread(s) (see {@link Thread#setPriority(int)}).
     * Use {@value #DEFAULT_THREAD_PRIORITY} to indicate that you don't
     * want to specify a particular priority.
     */
    protected AbstractAssemblyLineWorker(String displayName,
                                         BoundedFIFO<T> inbox,
                                         BoundedFIFO<T> outbox,
                                         int numberOfThreads,
                                         int requestedThreadPriority) {

        ObjectTools.paramNullCheck(displayName, "displayName");
        numberOfThreads = numberOfThreads < 1 ? 1 : numberOfThreads;
        // inbox or outbox CAN be null

        this.displayName = displayName;
        this.inbox = inbox;
        this.outbox = outbox;
        this.numberOfThreads = numberOfThreads;
        this.requestedThreadPriority = requestedThreadPriority;

        workerDone = new BooleanState(false);

        workerTimer = NanoTimer.createStopped();
    }

    protected AbstractAssemblyLineWorker(String displayName,
                                         BoundedFIFO<T> inbox,
                                         BoundedFIFO<T> outbox,
                                         int numberOfThreads) {

        this(displayName, inbox, outbox,
            numberOfThreads, DEFAULT_THREAD_PRIORITY);
    }

    @Override
    public synchronized void kickoff() {
        if ( internalThreads != null ) {
            throw new IllegalStateException(
                "kickoff can only be called one time!");
        }

        workerTimer.start();

        Thread[] threads = new Thread[numberOfThreads];
        for ( int i = 0; i < threads.length; i++ ) {
            threads[i] = new Thread(new Runnable() {
                @Override
                public void run() {
                    runWork();
                }
            }, displayName);

            if ( Thread.MIN_PRIORITY <= requestedThreadPriority &&
                 requestedThreadPriority <= Thread.MAX_PRIORITY ) {

                threads[i].setPriority(requestedThreadPriority);
            }

            // wait to start the threads after all have been constructed
        }

        // Start them after all have been constructed in case they are
        // resource hogs:
        for ( int i = 0; i < threads.length; i++ ) {
            threads[i].start();
        }

        internalThreads = threads;

        Thread shutdownThread = new Thread(new Runnable() {
            @Override
            public void run() {
                runWorkShutdownOutbox();
            }
        }, displayName + "-shutdownWaiter");
        shutdownThread.start();
    }

    @Override
    public void waitUntilDone(long msTimeout)
            throws TimedOutException, InterruptException {

        workerDone.waitUntilTrue(msTimeout);
    }

    /**
     * Called once by EACH of the worker threads. If you allow more than one
     * thread in your worker, make sure that everything you do in the method
     * implementation is threadsafe.
     */
    protected abstract void runWork();

    private void runWorkShutdownOutbox() {
        boolean shutdownCompletedNormally = false;
        try {
            for ( Thread thread : internalThreads ) {
                thread.join();
            }

            shutdownOutboxWhenEmpty();
            shuttingDown();
            shutdownCompletedNormally = true;
        } catch ( Exception x ) {
            // TODO - log this, not just to console
            x.printStackTrace();
        } finally {
            workerTimer.stop();
            workerDone.setState(true);

            if ( shutdownCompletedNormally == false ) {
                // TODO - log this, not just to console
                System.err.println("ABNORMAL SHUTDOWN for " +
                    getClass().getName());
            }

            try {
                shutdownComplete(shutdownCompletedNormally);
            } catch ( Exception x ) {
                // TODO - log this, not just to console
                x.printStackTrace();
            }
        }
    }

    private void shutdownOutboxWhenEmpty() throws InterruptException {
        if ( outbox != null ) {
            outbox.waitUntilEmpty();
            outbox.shutdown();
        }
    }

    /**
     * Called after all of the worker threads have died and after the outbox
     * (if one exists) is empty.
     * This implementation does nothing. Subclasses can override this if they
     * need to perform any additional shutdown tasks before this worker can
     * be considered fully shutdown.
     */
    protected void shuttingDown() {
    }

    /**
     * Subclasses can override this method if they want or need to know and/or
     * if they want to override the message printed. Any subclass implementation
     * should be sure to finish quickly (without blocking long). This
     * implementation writes a summary text message to the console.
     */
    protected void shutdownComplete(boolean shutdownCompletedNormally) {
        System.out.println(createSummaryText());
    }

    /**
     * Creates overall summary information.
     */
    protected String createSummaryText() {
        StringBuilder sb = new StringBuilder();
        sb.append("WORKER DONE: ");
        sb.append(displayName);
        sb.append(" ran for ");
        if ( workerTimer.getElapsedHours() > 1.0 ) {
            sb.append(String.format("%.1f hours",
                workerTimer.getElapsedHours()));
        } else if ( workerTimer.getElapsedMinutes() > 1.0 ) {
            sb.append(String.format("%.1f minutes",
                workerTimer.getElapsedMinutes()));
        } else {
            sb.append(String.format("%.1f seconds",
                workerTimer.getElapsedSeconds()));
        }

        sb.append(String.format(", using %d thread", internalThreads.length));
        if ( internalThreads.length != 1 ) {
            sb.append("s");
        }
        return sb.toString();
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.