package com.programix.thread;

/**
 * This class serves as a thread-safe integer counter. In fact, there's
 * no requirement that the value only increment or decrement&mdash;the
 * value can hop around to any value by using {@link #setCount(int)}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class Counter implements ThreadSafe {
    private int count;
    private final Object lockObject;
    private final Waiter waiter;
    private Waiter.Condition zeroCondition;
    private Waiter.Condition positiveCondition;
    private Waiter.Condition negativeCondition;

    private Counter(int initialCount,
                    Waiter proposedWaiter,
                    Object proposedLockObject) {

        if ( proposedWaiter != null ) {
            waiter = proposedWaiter;
            lockObject = proposedWaiter.getLockObject();
        } else {
            lockObject =
                (proposedLockObject == null) ? this : proposedLockObject;
            waiter = new Waiter(lockObject);
        }

        count = initialCount;

        zeroCondition = waiter.createCondition(new Waiter.Expression() {
            @Override
            public boolean isTrue() {
                return count == 0;
            }
        });

        positiveCondition = waiter.createCondition(new Waiter.Expression() {
            @Override
            public boolean isTrue() {
                return count > 0;
            }
        });

        negativeCondition = waiter.createCondition(new Waiter.Expression() {
            @Override
            public boolean isTrue() {
                return count < 0;
            }
        });
    }

    /**
     * Creates a counter that starts off with the specified
     * <tt>initialCount</tt>.
     *
     * @param initialCount the starting value.
     * @param waiter the {@link Waiter} to use.
     * If <tt>null</tt>, then a new {@link Waiter} is automatically created.
     */
    public Counter(int initialCount, Waiter waiter) {
        this(initialCount, waiter, null);
    }

    /**
     * Creates a counter that starts off with the specified
     * <tt>initialCount</tt>.
     *
     * @param initialCount the starting value.
     * @param lockObject the object to synchronize on.
     * If <tt>null</tt>, the the synchronization will be on this instance.
     */
    public Counter(int initialCount, Object lockObject) {
        this(initialCount, null, lockObject);
    }

    /**
     * Creates a counter that starts off with the specified
     * <tt>initialCount</tt>.
     *
     * @param initialCount the starting value.
     */
    public Counter(int initialCount) {
        this(initialCount, null, null);
    }

    /**
     * Creates a counter that starts off with a value of <tt>0</tt>.
     *
     * @param lockObject the object to synchronize on.
     * If <tt>null</tt>, the the synchronization will be on this instance.
     */
    public Counter(Object lockObject) {
        this(0, null, lockObject);
    }

    /**
     * Creates a counter that starts off with a value of <tt>0</tt>.
     */
    public Counter() {
        this(0, null, null);
    }

    public int getCount() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();

            return count;
        }
    }

    public void setCount(int newCount) throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();

            if ( newCount != count ) {
                count = newCount;
                waiter.signalChange();
            }
        }
    }

    public void increment() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();
            count++;
            waiter.signalChange();
        }
    }

    /**
     * Potentially increments the counter returning <tt>true</tt> if
     * the counter was incremented or <tt>false</tt> is the counter was
     * not changed because it's already been shutdown.
     */
    public boolean incrementIfNotShutdown() {
        synchronized ( lockObject ) {
            if ( waiter.isShutdown() ) {
                return false;
            } else {
                increment();
                return true;
            }
        }
    }

    public void decrement() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();
            count--;
            waiter.signalChange();
        }
    }


    /**
     * Potentially decrements the counter returning <tt>true</tt> if
     * the counter was decremented or <tt>false</tt> is the counter was
     * not changed because it's already been shutdown.
     */
    public boolean decrementIfNotShutdown() {
        synchronized ( lockObject ) {
            if ( waiter.isShutdown() ) {
                return false;
            } else {
                decrement();
                return true;
            }
        }
    }

    public boolean isZero() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();
            return count == 0;
        }
    }

    public boolean isNotZero() throws ShutdownException {
        synchronized ( lockObject ) {
            waiter.shutdownCheck();
            return count != 0;
        }
    }

    /**
     * Waits while the count is exactly zero.
     */
    public void waitWhileZero(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        zeroCondition.waitWhileTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits while the count is exactly zero.
     */
    public void waitWhileZero() throws ShutdownException, InterruptException {
        zeroCondition.waitWhileTrue();
    }

    /**
     * Waits until the count is exactly zero.
     */
    public void waitUntilZero(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        zeroCondition.waitUntilTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits until the count is exactly zero.
     */
    public void waitUntilZero() throws ShutdownException, InterruptException {
        zeroCondition.waitUntilTrue();
    }

    /**
     * Waits while the count is a positive number (greater than zero).
     */
    public void waitWhilePositive(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        positiveCondition.waitWhileTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits while the count is a positive number (greater than zero).
     */
    public void waitWhilePositive()
            throws ShutdownException, InterruptException {

        positiveCondition.waitWhileTrue();
    }

    /**
     * Waits until the count is a positive number (greater than zero).
     */
    public void waitUntilPositive(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        positiveCondition.waitUntilTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits until the count is a positive number (greater than zero).
     */
    public void waitUntilPositive()
            throws ShutdownException, InterruptException {

        positiveCondition.waitUntilTrue();
    }

    /**
     * Waits while the count is a negative number (less than zero).
     */
    public void waitWhileNegative(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        negativeCondition.waitWhileTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits while the count is a negative number (less than zero).
     */
    public void waitWhileNegative()
            throws ShutdownException, InterruptException {

        negativeCondition.waitWhileTrue();
    }

    /**
     * Waits until the count is a negative number (less than zero).
     */
    public void waitUntilNegative(long msTimeout)
            throws TimedOutException, ShutdownException, InterruptException {

        negativeCondition.waitUntilTrueWithTimedOutException(msTimeout);
    }

    /**
     * Waits until the count is a negative number (less than zero).
     */
    public void waitUntilNegative()
            throws ShutdownException, InterruptException {

        negativeCondition.waitUntilTrue();
    }

    /**
     * Returns a {@link Waiter.Condition} that can be used to
     * wait while or wait until the count is greater than or equal
     * to the specified <tt>minCount</tt>.
     */
    public Waiter.Condition createAtLeastCondition(int minCount) {
        return waiter.createCondition(new MinCountExpr(minCount));
    }

    /**
     * Returns a {@link Waiter.Condition} that can be used to
     * wait while or wait until the count is less than or equal
     * to the specified <tt>maxCount</tt>.
     */
    public Waiter.Condition createAtMostCondition(int maxCount) {
        return waiter.createCondition(new MaxCountExpr(maxCount));
    }

    /**
     * Returns a {@link Waiter.Condition} that can be used to
     * wait while or wait until the count is within the specified
     * range (inclusive of the min and max).
     */
    public Waiter.Condition createRangeCondition(int min, int max) {
        return waiter.createCondition(new RangeCountExpr(min, max));
    }

    /**
     * Returns a {@link Waiter.Condition} that can be used to
     * wait while or wait until the the specified expression is true.
     */
    public Waiter.Condition createCondition(Waiter.Expression expression) {
        return waiter.createCondition(expression);
    }

    public Waiter getWaiter() {
        return waiter;
    }

    /**
     * Called to shutdown all access to this counter and to dislodge
     * any threads waiting on conditions.
     */
    public void shutdown() {
        waiter.shutdown();
    }

    public boolean isShutdown() {
        return waiter.isShutdown();
    }

    public Object getLockObject() {
        return lockObject;
    }

    private class MinCountExpr extends Waiter.Expression {
        private int minCount;

        public MinCountExpr(int minCount) {
            this.minCount = minCount;
        }

        @Override
        public boolean isTrue() {
            return count >= minCount;
        }
    } // class MinCountExpr

    private class MaxCountExpr extends Waiter.Expression {
        private int maxCount;

        public MaxCountExpr(int maxCount) {
            this.maxCount = maxCount;
        }

        @Override
        public boolean isTrue() {
            return count <= maxCount;
        }
    } // class MaxCountExpr

    private  class RangeCountExpr extends Waiter.Expression {
        private int min;
        private int max;

        public RangeCountExpr(int min, int max) {
            this.min = min;
            this.max = max;
        }

        @Override
        public boolean isTrue() {
            int localCount = count;
            return (min <= localCount) && (localCount <= max);
        }
    } // class RangeCountExpr
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.