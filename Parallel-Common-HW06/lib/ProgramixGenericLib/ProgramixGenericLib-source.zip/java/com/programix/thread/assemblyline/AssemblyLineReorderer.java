package com.programix.thread.assemblyline;

import java.util.*;

import com.programix.thread.*;
import com.programix.util.*;

/**
 * Used to reinstate the order of items.
 * <p>
 * For example, the if the following workers exist in this sequence on the
 * assembly line:
 * <pre>
 *    W1 -> W2 -> W3 -> W4
 * </pre>
 * and you want to use multiple threads for W2 (and/or W3) but are
 * concerned about the random reordering of items arriving at W4, you can
 * use an instance of this class to create TWO workers. The "Front End"
 * worker takes note of the order the items and works cooperatively with
 * the "Back End" worker to reorder them. The "Back End" worker holds up
 * out-of-order items until it's their turn to head out. This is the new
 * sequence on the assembly line:
 * <pre>
 *    W1 -> W-FrontEnd -> W2 -> W3 -> W-BackEnd -> W4
 * </pre>
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class AssemblyLineReorderer<T> {
    private FrontEndWorkerBuilder<T> frontEndWorkerBuilder;
    private BackEndWorkerBuilder<T> backEndWorkerBuilder;

    /**
     * Creates a worker builder pair.
     *
     * @param maxBacklog the maximum number of out of order items which can
     * be back-logged. If less than 2, this is silently increased to 2.
     * Generally good values are between 20 and 200.
     * Smaller backlogs result in less search time and a smoother flow
     * downstream.
     * Larger backlogs can increase the efficiency of the threaded worker
     * before the "back end" (which can sometimes increase throughput),
     * but result in burstier flow downstream (items tend to be released
     * in large chunks).
     */
    public AssemblyLineReorderer(int maxBacklog) {
        maxBacklog = Math.max(2, maxBacklog);
        BoundedFIFO<T> orderFifo = new BoundedFIFO<T>(maxBacklog - 1);
        frontEndWorkerBuilder = new FrontEndWorkerBuilder<T>(orderFifo);
        backEndWorkerBuilder = new BackEndWorkerBuilder<T>(orderFifo);
    }

    /**
     * The "Front End" worker builder. This builder can only have it's create()
     * method called one time.
     */
    public AssemblyLineWorker.Builder<T> getFrontEndWorkerBuilder() {
        return frontEndWorkerBuilder;
    }

    /**
     * The "Back End" worker builder. This builder can only have it's create()
     * method called one time. This worker must come after the associated
     * "Front End" worker (or else there will be a deadlock).
     */
    public AssemblyLineWorker.Builder<T> getBackEndWorkerBuilder() {
        return backEndWorkerBuilder;
    }

    private static class FrontEndWorker<T>
            extends AbstractAssemblyLineProcessWorker<T> {

        private final BoundedFIFO<T> orderFifo;
        private NanoTimer orderFifoWaitTime;
        private Counter itemCounter;

        public FrontEndWorker(BoundedFIFO<T> orderFifo,
                              BoundedFIFO<T> inbox,
                              BoundedFIFO<T> outbox) {

            // always single-threaded--must maintain the order that items arrive
            super("Reorderer-FrontEnd", inbox, outbox, 1);

            ObjectTools.paramNullCheck(orderFifo, "orderFifo");
            ObjectTools.paramNullCheck(inbox, "inbox");
            ObjectTools.paramNullCheck(outbox, "outbox");

            this.orderFifo = orderFifo;

            itemCounter = new Counter();
            orderFifoWaitTime = NanoTimer.createStopped();
        }

        @Override
        public void processItem(T item) throws Exception {
            // Nothing really to process other than putting this item on the
            // back channel FIFO.
            // This add() call may block if the back-end is at the max backlog.
            // By blocking here,
            // this is how we prevent ourselves from getting too far ahead.

            try {
                itemCounter.increment();
                orderFifoWaitTime.start();
                orderFifo.add(item);
            } finally {
                orderFifoWaitTime.stop();
            }
        }

        @Override
        protected void shuttingDown() throws InterruptException {
            orderFifo.waitUntilEmpty();
            orderFifo.shutdown();
        }

        @Override
        protected String createSummaryText() {
            StringBuilder sb = new StringBuilder();
            sb.append(super.createSummaryText());

            // to just be doubly sure (should be unnecessary)
            orderFifoWaitTime.stop();

            sb.append(String.format(" and order fifo waiting for " +
        		    "%.3f seconds (avg %.1f ms each time)",
                orderFifoWaitTime.getElapsedSeconds(),
                orderFifoWaitTime.getElapsedMilliseconds() /
                    itemCounter.getCount()));

            return sb.toString();
        }

    } // class FrontEndWorker

    private static class FrontEndWorkerBuilder<T>
            implements AssemblyLineWorker.Builder<T> {

        private final BoundedFIFO<T> orderFifo;
        private BooleanState alreadyCreated = new BooleanState(false);

        public FrontEndWorkerBuilder(BoundedFIFO<T> orderFifo) {
            this.orderFifo = orderFifo;
        }

        @Override
        public AssemblyLineWorker<T> create(BoundedFIFO<T> inbox,
                                            BoundedFIFO<T> outbox) {
            if ( alreadyCreated.isTrue() ) {
                throw new IllegalStateException("The create() method can " +
            		"only be called one time on the Front End Worker Builder");
            }
            if ( inbox == null ) {
                throw new IllegalArgumentException("inbox can't be null, " +
                    "the Front End Worker for the reorderer can't be the " +
                    "first in line");
            }
            if ( outbox == null ) {
                throw new IllegalArgumentException("outbox can't be null, " +
                    "the Front End Worker for the reorderer can't be the " +
                    "last in line");
            }
            alreadyCreated.setState(true);
            return new FrontEndWorker<T>(orderFifo, inbox, outbox);
        }
    } // class FrontEndWorkerBuilder

    private static class BackEndWorker<T>
            extends AbstractAssemblyLineWorker<T> {

        private final BoundedFIFO<T> orderFifo;

        private final Object statisticsLock;
        private int totalItemCount;
        private double totalSecondsWaitingOnOrderFifo;
        private double totalSecondsWaitingOnInbox;
        private double totalSecondsWaitingOnOutbox;

        public BackEndWorker(BoundedFIFO<T> orderFifo,
                             BoundedFIFO<T> inbox,
                             BoundedFIFO<T> outbox) {

            // always single-threaded--must maintain the order
            super("Reorderer-BackEnd", inbox, outbox, 1);

            ObjectTools.paramNullCheck(orderFifo, "orderFifo");
            ObjectTools.paramNullCheck(inbox, "inbox");
            ObjectTools.paramNullCheck(outbox, "outbox");

            this.orderFifo = orderFifo;
            statisticsLock = new Object();
        }

        @Override
        protected void runWork() {
            int itemCount = 0;
            NanoTimer orderFifoWaitTime = NanoTimer.createStopped();
            NanoTimer inboxWaitTime = NanoTimer.createStopped();
            NanoTimer outboxWaitTime = NanoTimer.createStopped();

            List<T> unorderedItems = new ArrayList<T>();
            try {
                while ( true ) {
                    T neededNextItem = null;
                    try {
                        orderFifoWaitTime.start();
                        neededNextItem = orderFifo.remove();
                    } catch ( ShutdownException x ) {
                        // normal way that we find out that we're done!
                        return;
                    } finally {
                        orderFifoWaitTime.stop();
                    }

                    boolean foundMatch = false;

                    // check out what's already pending (if anything)
                    for ( Iterator<T> iter = unorderedItems.iterator();
                          iter.hasNext(); ) {

                        T pendingItem = iter.next();
                        if ( neededNextItem == pendingItem ) {
                            iter.remove();
                            foundMatch = true;
                            break;
                        }
                    }

                    if ( foundMatch == false ) {
                        // Not in the pending list, keep pulling off inbox until
                        // there's a match
                        try {
                            while ( foundMatch == false ) {
                                inboxWaitTime.start();
                                T item = inbox.remove();
                                inboxWaitTime.stop();
                                itemCount++;

                                if ( neededNextItem == item ) {
                                    foundMatch = true;
                                    break;
                                } else {
                                    // keep in the unordered pending items list
                                    unorderedItems.add(item);
                                }
                            }
                        } catch ( ShutdownException x ) {
                            // This should 'never' happen as we should always
                            // find a match first and we get the
                            // ShutdownException from orderFifo.
                            throw new RuntimeException(x);
                        } finally {
                            // just to be sure, harmless if already called
                            inboxWaitTime.stop();
                        }
                    }

                    outboxWaitTime.start();
                    outbox.add(neededNextItem);
                    outboxWaitTime.stop();
                }
            } finally {
                synchronized ( statisticsLock ) {
                    totalItemCount += itemCount;
                    totalSecondsWaitingOnOrderFifo +=
                        orderFifoWaitTime.getElapsedSeconds();
                    totalSecondsWaitingOnInbox +=
                        inboxWaitTime.getElapsedSeconds();
                    totalSecondsWaitingOnOutbox +=
                        outboxWaitTime.getElapsedSeconds();
                }
            }
        }

        @Override
        protected String createSummaryText() {
            StringBuilder sb = new StringBuilder();
            sb.append(super.createSummaryText());
            synchronized ( statisticsLock ) {
                sb.append(String.format(
                    ", completed %d items",
                    totalItemCount));

                sb.append(String.format( "and inbox waiting for %.3f seconds " +
                		"(avg %.1f ms each time)",
                    totalSecondsWaitingOnInbox,
                    totalSecondsWaitingOnInbox * 1000.0 / totalItemCount));

                sb.append(String.format(" and outbox waiting for " +
                		"%.3f seconds (avg %.1f ms each time)",
                    totalSecondsWaitingOnOutbox,
                    totalSecondsWaitingOnOutbox * 1000.0 / totalItemCount));

                sb.append(String.format(" and order fifo waiting for " +
                		"%.3f seconds (avg %.1f ms each time)",
                    totalSecondsWaitingOnOrderFifo,
                    totalSecondsWaitingOnOrderFifo * 1000.0 / totalItemCount));
            }

            return sb.toString();
        }
    } // class BackEndWorker

    private static class BackEndWorkerBuilder<T>
            implements AssemblyLineWorker.Builder<T> {

        private final BoundedFIFO<T> orderFifo;
        private BooleanState alreadyCreated = new BooleanState(false);

        public BackEndWorkerBuilder(BoundedFIFO<T> orderFifo) {
            this.orderFifo = orderFifo;
        }

        @Override
        public AssemblyLineWorker<T> create(BoundedFIFO<T> inbox,
                                            BoundedFIFO<T> outbox) {
            if ( alreadyCreated.isTrue() ) {
                throw new IllegalStateException("The create() method can " +
            		"only be called one time on the Back End Worker Builder");
            }
            if ( inbox == null ) {
                throw new IllegalArgumentException("inbox can't be null, " +
            		"the Back End Worker for the reorderer can't be the " +
            		"first in line");
            }
            if ( outbox == null ) {
                throw new IllegalArgumentException("outbox can't be null, " +
                    "the Back End Worker for the reorderer can't be the " +
                    "last in line");
            }

            alreadyCreated.setState(true);
            return new BackEndWorker<T>(orderFifo, inbox, outbox);
        }
    } // class FrontEndWorkerBuilder
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.