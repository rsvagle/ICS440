package com.programix.thread;

/**
 * Thrown by some methods to indicate that a timeout occurred.
 * Instead of throwing this exception, some methods may simply 
 * return <tt>false</tt> or {@link ThreadTools#TIMED_OUT} to indicate a timeout.
 * <p>
 * This is a {@link RuntimeException} so callers are not <i>required</i>
 * to catch it.
 * <p>
 * For advanced tools and utilities related to multithreading, please
 * check out <a href="http://www.jthreadkit.com/">JThreadKit</a>.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class TimedOutException extends RuntimeException {
    public TimedOutException() {
        super();
    }
    
    public TimedOutException(String message) {
        super(message);
    }
    
    public TimedOutException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public TimedOutException(Throwable cause) {
        super(cause);
    }
    
    public TimedOutException(long msTimeout) {
        this("Waiting timed out after " + msTimeout + " milliseconds.");
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.