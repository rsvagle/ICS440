package com.programix.thread;

/**
 * This is a {@link RuntimeException} that is used in place of the more
 * traditional {@link InterruptedException} to avoid the forced use of
 * a try-catch. This exception is thrown as a signal that a thread should
 * gracefully clean up and die. The thread that constructs this exception 
 * also has its interrupt flag set to true.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class InterruptException extends RuntimeException {
    public InterruptException(String message, Throwable cause) {
        super(message, cause);
        Thread.currentThread().interrupt();
    }

    public InterruptException(Throwable cause) {
        super(cause);
        Thread.currentThread().interrupt();
    }

    public InterruptException(String message) {
        super(message);
        Thread.currentThread().interrupt();
    }
    
    public InterruptException() {
        super();
        Thread.currentThread().interrupt();
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.