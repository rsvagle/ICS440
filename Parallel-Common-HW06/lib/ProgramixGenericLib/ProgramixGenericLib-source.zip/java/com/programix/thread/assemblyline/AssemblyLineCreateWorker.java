package com.programix.thread.assemblyline;

/**
 * The create worker is at the beginning of the assembly line and has no inbox.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface AssemblyLineCreateWorker<T> extends AssemblyLineWorker<T> {
    /**
     * Creates another item or returns null to indicate that there are
     * no more items to create.
     */
    T createItem() throws Exception;
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.