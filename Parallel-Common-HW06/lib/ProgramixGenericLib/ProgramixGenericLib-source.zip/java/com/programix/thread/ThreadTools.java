package com.programix.thread;

/**
 * Handy and commonly used tools for working with multithreaded code.
 * <p>
 * For advanced tools and utilities related to multithreading, please
 * check out <a href="http://www.jthreadkit.com/">JThreadKit</a>.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ThreadTools {
    /**
     * Indicates that the 'waiting' should not time out (no matter
     * how much time elapses).
     */
    public static final long NO_TIMEOUT = 0L;
    
    /**
     * Signals that the attempted operation was successful.
     */
    public static final boolean SUCCESS = true;
    
    /**
     * Signals that the attempted operation ran out of time.
     */
    public static final boolean TIMED_OUT = false;
    
    private static LineLogger LINE_LOGGER;
    
    // no instances
    private ThreadTools() {
    }
    
    /**
     * Prints the specified message prefixed with the name of the calling
     * thread to <tt>System.out.println</tt> (standard out).
     * 
     * @param message the message to print printed.
     */
    public static void println(Object message) {
        String threadName = Thread.currentThread().getName();
        System.out.println(threadName + ": " + message);
    }
    
    /**
     * Prints the specified message prefixed with the elapsed time and
     * the name of the calling thread. The message is printed to the console
     * using a single {@link LineLogger} held by <tt>ThreadTools</tt> (if
     * you need more flexibility, then use <tt>LineLogger</tt> directly).
     */
    public static synchronized void out(Object msg) {
        if ( LINE_LOGGER == null ) {
            LINE_LOGGER = new LineLogger();
        }
        
        LINE_LOGGER.out(msg);
    }
    
    /**
     * Prints the specified message prefixed with the elapsed time and
     * the name of the calling thread. The message is printed to the console
     * using a single {@link LineLogger} held by <tt>ThreadTools</tt> (if
     * you need more flexibility, then use <tt>LineLogger</tt> directly).
     */
    public static synchronized void outln(Object msg) {
        if ( LINE_LOGGER == null ) {
            LINE_LOGGER = new LineLogger();
        }
        
        LINE_LOGGER.outln(msg);
    }
    
    /**
     * Causes the calling thread to go to sleep for the specified amount
     * of time. If the calling thread is interrupted while sleeping, an
     * {@link InterruptException} is thrown (note that this is a 
     * {@link RuntimeException} so callers are not required to catch it).
     * 
     * @param msDuration the number of milliseconds to sleep for.
     * @throws InterruptException if the nap is interrupted.
     */
    public static void nap(long msDuration) throws InterruptException {
        try {
            Thread.sleep(msDuration);
        } catch ( InterruptedException x ) {
            throw new InterruptException(x);
        }
    }
    
    /**
     * Causes the calling thread to go to sleep for a random amount of time
     * in the specified range of time. 
     * If the calling thread is interrupted while sleeping, an
     * {@link InterruptException} is thrown (note that this is a 
     * {@link RuntimeException} so callers are not required to catch it).
     * 
     * @param msMinDuration the minimum number of milliseconds to sleep for.
     * @param msMaxDuration the maximum number of milliseconds to sleep for.
     * @throws InterruptException if the nap is interrupted.
     */
    public static void napRandom(long msMinDuration, long msMaxDuration) 
            throws InterruptException {
        
        nap(msMinDuration + 
            ((long) (Math.random() * (msMaxDuration - msMinDuration + 1))));
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.