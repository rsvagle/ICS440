package com.programix.saxplus;

import org.xml.sax.*;

/**
 * A plain {@link ErrorHandler} for use with SAXPlus (and just SAX) during
 * XML parsing. This implementation simply dumps the exception details 
 * to <tt>System.err</tt>.
 *  
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ConsoleErrorHandler extends Object implements ErrorHandler {
	public void warning(SAXParseException spe) throws SAXException {
		print("SAX WARNING", spe);
	}

	public void error(SAXParseException spe) throws SAXException {
		print("SAX ERROR", spe);
	}

	public void fatalError(SAXParseException spe) throws SAXException {
		print("SAX FATAL ERROR", spe);
	}

	private void print(String type, SAXParseException spe) {
		System.err.println(type + " systemId=" + spe.getSystemId() +
			" publicId=" + spe.getPublicId());
		System.err.println("    at line: " + spe.getLineNumber() + 
			", column: " + spe.getColumnNumber());
		System.err.println("    " + spe.toString());

		Exception cause = spe.getException();
		if ( cause != null ) {
			System.err.println("    Caused by: " + cause.toString());
		}
        
        spe.printStackTrace();
	}
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.