package com.programix.saxplus;

import com.programix.value.*;

/**
 * The group of attributes found in the starting tag for an element.
 * The methods below which take a <tt>name</tt> parameter use the 
 * 'simple name' that would be returned by the 
 * {@link NameDetail#getName getName()} of {@link NameDetail} [the 'simple name'
 * is what you probably expect the name of the attribute to be!].
 * <p>
 * For the vast majority of code, the {@link #getValueMap()} method will
 * be the most useful as {@link ValueMap} has many handy ways of accessing
 * and interpreting the data (including suppling default values for optional
 * items).
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface AttributeGroup {
    /**
     * Returns all of the attributes conveniently accessible from a 
     * {@link ValueMap}. The key into this {@link ValueMap} is
     * the simple name returned from the {@link NameDetail#getName getName()}
     * method of {@link NameDetail} [the simple name is what you probably 
     * expect the name of the attribute to be!]. The value of the key-value
     * pair is actually a {@link Value}.
     */
    ValueMap getValueMap();

	/**
     * Returns the number of attributes present.
	 */
    int getSize();
    
    /**
     * Returns <tt>true</tt> if there is an attribute present with the
     * specified simple name. If an attribute is optional and you know the 
     * default value that you want to use when the attribute is not present,
     * you can use this simple approach (instead of this method):
     * <pre>
     * AttributeGroup ag = //...
     * String s = ag.getValueMap().getString("attrName", "defaultValue");
     * </pre>
     */
    boolean hasAttribute(String name);
    
    /**
     * Returns the attribute with the specified name. If no attribute with
     * that name is present, <tt>null</tt> is returned.
     */
	Attribute get(String name);
    
    /**
     * Returns the attribute with the specified index. If less than 0 or
     * greater than (size - 1), an exception is thrown.
     */
	Attribute get(int index) throws ArrayIndexOutOfBoundsException;
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.