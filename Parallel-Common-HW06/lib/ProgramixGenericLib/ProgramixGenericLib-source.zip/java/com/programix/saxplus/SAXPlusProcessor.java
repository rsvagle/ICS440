package com.programix.saxplus;

import java.io.*;

import javax.xml.parsers.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

import com.programix.util.*;
import com.programix.value.*;

/**
 * Central piece of SAXPlus parsing. First, the {@link TagHandler} for
 * the "root" XML element is specified during construction. This is the only
 * tag handler needed at this level as each tag handler delegates to "sub tag"
 * handlers as necessary. Second, if you can optionally call
 * {@link #setErrorHandler(ErrorHandler)} if you want parsing errors to be
 * reported to someplace other than <tt>System.err</tt>. Third, if you
 * are in a debugging mode, you'll probably want to call
 * {@link #setTrace(boolean) setTrace(true)} to see a trace of the
 * parsing as each XML tag is processed. Finally, choose one of the
 * <tt>parse</tt> methods to initiate the parsing of an XML document.
 * <p>
 * This class is definitely NOT multithread-safe.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class SAXPlusProcessor extends Object {
	private static final ErrorHandler DEFAULT_ERROR_HANDLER =
			new ConsoleErrorHandler();

	private TagHandler rootHandler;
	private ErrorHandler errorHandler;
	private boolean trace;
	private Locator locator;

    /**
     * Builds an instance that will use <tt>rootHandler</tt> at the initial
     * {@link TagHandler}.
     */
	public SAXPlusProcessor(TagHandler rootHandler) {
		this.rootHandler = rootHandler;
		this.errorHandler = DEFAULT_ERROR_HANDLER;
		this.trace = false;
	}

    /**
     * Specifies the SAX {@link ErrorHandler} that is interested in being
     * informed of warnings, errors, and fatal errors encountered during
     * parsing. If this method is never called, or if <tt>null</tt> is passed
     * in, an instance of {@link ConsoleErrorHandler} is used.
     */
	public void setErrorHandler(ErrorHandler errorHandler) {
		this.errorHandler = (errorHandler == null) ?
			DEFAULT_ERROR_HANDLER : errorHandler;
	}

    /**
     * Passing <tt>true</tt> specifies that a <i>trace</i> of internal
     * activity should be printed to <tt>System.out</tt>. This method is only
     * really useful for debugging. If this method is never called, or if
     * <tt>false</tt> is passed in, then no trace information is printed.
     */
	public void setTrace(boolean trace) {
		this.trace = trace;
	}

	public Value process(XMLReader reader, InputSource source)
			throws SAXException {

		try {
			reader.setContentHandler(new SAXPlusContentHandler());
			reader.setErrorHandler(errorHandler);
			reader.parse(source);
			locator = null;
			return rootHandler.getResult();
		} catch ( IOException x ) {
			throw new SAXException(x);
		}
	}

	public Value process(XMLReader reader, String source)
			throws SAXException {

		return process(reader, new InputSource(source));
	}

	public Value process(InputSource source,
                         boolean namespaceAware,
                         boolean validating) throws SAXException {

		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			factory.setNamespaceAware(namespaceAware);
			factory.setValidating(validating);
			SAXParser parser = factory.newSAXParser();
			XMLReader reader = parser.getXMLReader();

			return process(reader, source);
		} catch ( ParserConfigurationException x ) {
			throw new SAXException(x);
		}
	}

	public Value process(String source,
                         boolean namespaceAware,
                         boolean validating) throws SAXException {

		return process(new InputSource(source), namespaceAware, validating);
	}

	public Value process(InputSource source) throws SAXException {
		return process(source, false, false);
	}

	public Value process(String source) throws SAXException {
		return process(new InputSource(source));
	}

	/**
	 * Returns the current {@link Locator} while a document is being actively
	 * parsed, null otherwise.
	 */
	public Locator getLocator() {
        return locator;
    }

	// This method tries to use localName, but if not present because
	// namespace-aware is false, then qName is used.
	private static String deriveName(String localName, String qName) {
        return StringTools.isEmpty(localName) ? qName : localName;
	}

	private static class SimpleNameDetail extends Object implements NameDetail {
		private String name;
		private String namespaceURI;
		private String localName;
		private String qName;
		private NameDetail parent;

		public SimpleNameDetail(
    				String namespaceURI,
    				String localName,
    				String qName,
    				NameDetail parent
    			) {

			this.name = deriveName(localName, qName);
			this.namespaceURI = namespaceURI;
			this.localName = localName;
			this.qName = qName;
			this.parent = parent;
		}

		public String getName() {
			return name;
		}

		public String getLocalName() {
			return localName;
		}

		public String getQName() {
			return qName;
		}

		public String getURI() {
			return namespaceURI;
		}

		public NameDetail getParent() {
			return parent;
		}
	} // class SimpleNameDetail

	private static class CharBuffer extends Object {
		private static final String ZERO_LEN_STRING = "";

		private char[] data;
		private int length;

		private boolean mustCalculatePositions;
		private int startPos;
		private int endPos;

		public CharBuffer() {
			data = new char[200];
			clear();
		}

		public void clear() {
			length = 0;

			mustCalculatePositions = false;
			startPos = 0;
			endPos = -1;
		}

        public int getLength() {
			return length;
		}

		public void append(char[] ch, int start, int len) {
			if ( len < 1 ) {
				return; // nothing to do
			}

			if ( (length + len) > data.length ) {
				int increment = Math.max(200, length + len);
				char[] newData = new char[data.length + increment];
				System.arraycopy(data, 0, newData, 0, length);
				data = newData;
			}

			System.arraycopy(ch, start, data, length, len);
			length += len;
			mustCalculatePositions = true;
		}

		private void calculatePositions() {
			mustCalculatePositions = false;

			startPos = 0;
			endPos = length - 1; // inclusive range

			while ( (startPos <= endPos) &&
				    Character.isWhitespace(data[startPos])
				  ) {

				startPos++;
			}

			if ( startPos > endPos ) {
				return; // all whitespace
			}

			while ( Character.isWhitespace(data[endPos]) ) {
				endPos--;
			}
		}

		public boolean isAllWhitespace() {
			if ( length == 0 ) {
				return true;
			}

			if ( mustCalculatePositions ) {
				calculatePositions();
			}

			return startPos > endPos;
		}

		public boolean needsNoTrimming() {
			if ( length == 0 ) {
				return true;
			}

			if ( mustCalculatePositions ) {
				calculatePositions();
			}

			return (startPos == 0) && (endPos == (length - 1));
		}

		public String getRawString() {
			return (length == 0) ? ZERO_LEN_STRING :
			    new String(data, 0, length);
		}

		public String getTrimmedString() {
			// Note: we're counting on the fact that isAllWhitespace()
			// calls calculatePositions if necessary!
			if ( length == 0 || isAllWhitespace() ) {
				return ZERO_LEN_STRING;
			}

			return new String(data, startPos, endPos - startPos + 1);
		}

		public Value getValueSnapshot() {
			if ( length == 0 ) {
                return ValueFactory.ZERO_LEN_STRING_INSTANCE;
			}

			// Note: we're counting on the fact that isAllWhitespace()
			// calls calculatePositions if necessary!
			if ( isAllWhitespace() ) {
                return ValueFactory.create(getRawString(), ZERO_LEN_STRING);
			}

			if ( needsNoTrimming() ) {
				String rawString = getRawString();
                return ValueFactory.create(rawString, rawString);
			}

			return ValueFactory.create(getRawString(), getTrimmedString());
		}
	} // inner CharBuffer

	private static class SimpleAttributeGroup
			extends Object implements AttributeGroup {

		private Attribute[] attr;
        private ValueMap valueMap;

		public SimpleAttributeGroup(Attributes saxAttr,
                                    NameDetail tagNameDetail) {

			int count = saxAttr.getLength();
			attr = new Attribute[count];

			for ( int i = 0; i < count; i++ ) {
				NameDetail nd = new SimpleNameDetail(
						saxAttr.getURI(i),
						saxAttr.getLocalName(i),
						saxAttr.getQName(i),
						tagNameDetail);

				Value val = ValueFactory.create(saxAttr.getValue(i));
				attr[i] = new SimpleAttribute(nd, val);
			}
		}

        public synchronized ValueMap getValueMap() {
            if ( valueMap == null ) {
                valueMap = new ValueMap();
                for ( int i = 0; i < attr.length; i++ ) {
                    valueMap.put(attr[i].getName(), attr[i].getValue());
                }
            }

            return valueMap;
        }

		public int getSize() {
			return attr.length;
		}

        public boolean hasAttribute(String name) {
            return get(name) != null;
        }

		public Attribute get(String name) {
			for ( int i = 0; i < attr.length; i++ ) {
				if ( attr[i].getName().equals(name) ) {
					return attr[i];
				}
			}

			return null;
		}

		public Attribute get(int index) {
			return attr[index];
		}

        /*
		public Value getValue(String name) {
			return get(name).getValue();
		}

		public Value getValue(int index) {
			return get(index).getValue();
		}

		public String getString(String name) {
			return getValue(name).getString();
		}

		public String getString(int index) {
			return getValue(index).getString();
		}

		public int getInt(String name) throws ValueException {
			return getValue(name).getInt();
		}

		public int getInt(int index) throws ValueException {
			return getValue(index).getInt();
		}

		public Number getNumber(String name) throws ValueException {
			return getValue(name).getNumber();
		}

		public Number getNumber(int index) throws ValueException {
			return getValue(index).getNumber();
		}

		public boolean isTrue(String name) {
			return getValue(name).isTrue();
		}

		public boolean isTrue(int index) {
			return getValue(index).isTrue();
		}
        */
	} // inner SimpleAttributeGroup

	private static class SimpleAttribute extends Object implements Attribute {
		private NameDetail nameDetail;
		private Value value;

		public SimpleAttribute(NameDetail nameDetail, Value value) {
			this.nameDetail = nameDetail;
			this.value = value;
		}

		public NameDetail getNameDetail() {
			return nameDetail;
		}

		public String getName() {
			return nameDetail.getName();
		}

		public Value getValue() {
			return value;
		}

		public String getStringValue() {
			return value.getString();
		}
	} // inner SimpleAttribute

	private class SAXPlusContentHandler
			extends DefaultHandler implements ContentHandler {

		private CharBuffer cb;
		private TagHandler currHandler;
		private HandlerStack handlerStack;
		private int ignoreDepth;

		public SAXPlusContentHandler() {
			this.cb = new CharBuffer();
			this.ignoreDepth = 0;
			this.handlerStack = new HandlerStack();
		}

		private boolean shouldIgnore() {
			return ignoreDepth > 0;
		}

		private void sendText() throws SAXException {
            try {
    			if ( cb.isAllWhitespace() == false ) {
    				currHandler.text(cb.getValueSnapshot());
    			}

    			cb.clear();
            } catch ( RuntimeException x ) {
                throw new SAXException(x);
            }
		}

		@Override
        public void setDocumentLocator(Locator newLocator) {
			locator = newLocator;
		}

		@Override
        public void startElement(
					String namespaceURI,
					String localName,
					String qName,
					Attributes atts
				) throws SAXException {

            try {
    			if ( shouldIgnore() ) {
    				// We are already ignoring one of this tag's parent tags,
    				// but now we're on level deeper with this 'start' tag--so
    				// increment the depth level count.
    				ignoreDepth++;
    				return;
    			}

    			NameDetail parentNameDetail = null;
    			HandlerStackEntry parent = handlerStack.peekTop();
    			if ( parent != null ) {
    				parentNameDetail = parent.nameDetail;
    			}

    			NameDetail nd = new SimpleNameDetail(
    				namespaceURI, localName, qName, parentNameDetail);

    			if ( currHandler == null ) {
    				currHandler = rootHandler;
    				cb.clear();  // just to be sure
    			} else {
    				// Send any text that has accumulated to the current handler
    				sendText();

    				// Ask the current handler who handles this sub tag
    				TagHandler newHandler = currHandler.startSubTag(nd);
    				if ( newHandler == null ) {
    					// Ignore this tag and all content nested below it
    					ignoreDepth = 1;

    					if ( trace ) {
    						System.out.println(
    							"SAXPlus TRACE - start tag: " + nd.getName() +
    								" [IGNORING]");
    					}

    					return;
    				}

    				currHandler = newHandler;
    			}

    			if ( trace ) {
    				System.out.println(
    					"SAXPlus TRACE - start tag: " + nd.getName() +
                        " [line: " + locator.getLineNumber() + "]");
    			}

    			handlerStack.push(currHandler, nd);

    			AttributeGroup ag = new SimpleAttributeGroup(atts, nd);
    			currHandler.startTag(nd, ag);
            } catch ( RuntimeException x ) {
                throw new SAXException(x);
            }
		}

		@Override
        public void endElement(
					String namespaceURI,
					String localName,
					String qName
				) throws SAXException {

            try {
    			if ( shouldIgnore() ) {
    				// We are already ignoring one of this tag's parent tags,
    				// but now we're on higher level with this 'end' tag--so
    				// decrement the depth level count.
    				ignoreDepth--;
    				return;
    			}

    			sendText();
    			currHandler.endTag();

    			if ( currHandler == rootHandler ) {
    				handlerStack.pop(); // DONE, get the root entry out
    				currHandler = null;
    				return;
    			}

    			Value result = currHandler.getResult();

    			HandlerStackEntry child = handlerStack.pop();
    			HandlerStackEntry parent = handlerStack.peekTop();

    			currHandler = parent.tagHandler;
    			currHandler.endSubTag(child.nameDetail, result);
            } catch ( RuntimeException x ) {
                throw new SAXException(x);
            }
		}

		@Override
        public void characters(char[] ch, int start, int len) {
			if ( shouldIgnore() == false ) {
				cb.append(ch, start, len);
			}
		}
	} // inner SAXPlusContentHandler

	private static class HandlerStack extends Object {
		private HandlerStackEntry[] stack;
		private int size;
		private int growthIncrement;

		public HandlerStack() {
			size = 0;

			stack = new HandlerStackEntry[20];
			growthIncrement = 5;
		}

        public synchronized int getSize() {
			return size;
		}

		public synchronized void push(TagHandler th, NameDetail name) {
			HandlerStackEntry entry = new HandlerStackEntry();
			entry.tagHandler = th;
			entry.nameDetail = name;

			if ( size == stack.length ) {
				// grow it
				HandlerStackEntry[] newStack =
						new HandlerStackEntry[size + growthIncrement];
				System.arraycopy(stack, 0, newStack, 0, size);
				stack = newStack;
			}

			stack[size] = entry;
			size++;
		}

		public synchronized HandlerStackEntry pop() {
			if ( size < 1 ) {
				return null;
			}

			size--;
			HandlerStackEntry entry = stack[size];
			stack[size] = null;

			return entry;
		}

		public synchronized HandlerStackEntry peekTop() {
			if ( size < 1 ) {
				return null;
			}

			return stack[size - 1];
		}
	} // inner HandlerStack

	private static class HandlerStackEntry extends Object {
		public TagHandler tagHandler;
		public NameDetail nameDetail;
	}
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.