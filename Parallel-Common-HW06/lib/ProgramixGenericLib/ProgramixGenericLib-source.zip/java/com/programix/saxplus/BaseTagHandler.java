package com.programix.saxplus;

import java.util.*;

import org.xml.sax.*;

import com.programix.value.*;

/**
 * Implements all methods of {@link TagHandler} and can serve as a class
 * to extend for your {@link TagHandler}'s. In your subclass, just override
 * the methods that you are interested in.
 * <p>
 * <tt>BaseTagHandler</tt> also supports a name-handler mapping for
 * all of the sub-tags of a tag (see
 * {@link #setSubTagHandler(String, TagHandler)} and
 * {@link #setSubTagHandler(NameDetail, TagHandler)}).
 * Therefore, the implementation of {@link #startSubTag(NameDetail)}
 * rarely needs to be overridden.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public abstract class BaseTagHandler extends Object implements TagHandler {
    private Map<String, TagHandler> subTagHandlerMap;

	protected BaseTagHandler() {
	}

    protected void setSubTagHandler(String tagName, TagHandler handler) {
        if ( subTagHandlerMap == null ) {
            subTagHandlerMap = new HashMap<String, TagHandler>();
        }

        subTagHandlerMap.put(tagName, handler);
    }

    /**
     * Pulls of the plain name (using {@link NameDetail#getName()}) and
     * calls {@link #setSubTagHandler(String, TagHandler)}.
     */
    protected void setSubTagHandler(NameDetail tagName, TagHandler handler) {
        setSubTagHandler(tagName.getName(), handler);
    }

    /**
     * Returns the handler for the specified tag, or <tt>null</tt> if no
     * handler is found for the name.
     */
    protected TagHandler getSubTagHandler(String tagName) {
        return (subTagHandlerMap == null)
                    ? null
                    : (TagHandler) subTagHandlerMap.get(tagName);
    }

    /**
     * Pulls of the plain name (using {@link NameDetail#getName()}) and
     * calls {@link #getSubTagHandler(String)}.
     */
    protected TagHandler getSubTagHandler(NameDetail tagName) {
        return getSubTagHandler(tagName.getName());
    }

	public void startTag(NameDetail tagName, AttributeGroup attr)
            throws SAXException {
    }

	public void endTag() throws SAXException {
	}

	public void text(Value tagText) throws SAXException {
	}

	/**
	 * This implementation returns whatever
     * {@link #getSubTagHandler(NameDetail)} finds for the specified sub tag.
     * If no sub tag handler is found, then <tt>null</tt> is returned,
     * indicating that the sub tag is ignored.
     * Overridden by subclasses as appropriate.
	 */
	public TagHandler startSubTag(NameDetail subTagName) throws SAXException {
        return getSubTagHandler(subTagName);
	}

	public void endSubTag(NameDetail subTagName, Value subTagResult)
            throws SAXException {
    }

	/**
	 * This implementation returns {@link ValueFactory#NULL_INSTANCE
     * ValueFactory.NULL_INSTANCE}. Overridden by subclasses as appropriate.
	 */
	public Value getResult() throws SAXException {
		return ValueFactory.NULL_INSTANCE;
	}
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.