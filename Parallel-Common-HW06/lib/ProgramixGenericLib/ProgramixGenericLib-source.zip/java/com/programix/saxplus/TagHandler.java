package com.programix.saxplus;

import org.xml.sax.*;

import com.programix.value.*;

/**
 * All information about the parsing of the XML document is passed to
 * <tt>TagHandler</tt>'s by the {@link SAXPlusProcessor}.
 * <p>
 * The processing flow:
 * <ol type="1">
 * <li>The {@link #startTag startTag()}method is called first passing in the
 * name of the tag (TagHandlers don't <i>necessarily </i> know their own name).
 * </li>
 * <li>The {@link #text text()}method is called for text (if any) within this
 * tag.</li>
 * <ol type="a">
 * <li>If the tag is empty, contains only white space (no sub tags), or has
 * only sub tags (with only whitespace between them), then {@link #text text()}
 * is <i>never </i> called.</li>
 * <li>If the tag contains a mixture of text <i>and </i> sub tags, then
 * {@link #text text()}will be called once for each block of (non-whitespace)
 * text found between the sub tags.</li>
 * </ol>
 * <li>If a sub tag is encountered, {@link #startSubTag startSubTag()}is
 * called to determine the <tt>TagHandler</tt> for the sub tag. When the sub
 * tag is complete, {@link #endSubTag endSubTag()}is called.</li>
 * <li>When this tag is complete, {@link #endTag endTag()}is called. After
 * that, {@link #getResult getResult()}may (or may not) be called.</li>
 * <li>Finally, this sequence will repeat if more data arrives for this
 * handler.</li>
 * </ol>
 * <p>
 * All of these methods potentially throw {@link SAXException} to indicate a
 * problem in processing the data. If a {@link RuntimeException} is thrown
 * from any of these methods, it will be automatically wrapped in a 
 * {@link SAXException} and that wrapped exception will be throw by
 * {@link SAXPlusProcessor}.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface TagHandler {
    void startTag(NameDetail tagName, AttributeGroup attr) throws SAXException;

    void endTag() throws SAXException;

    /**
     * Delivers textual content within this tag. If this tag has no sub tags,
     * then this method is called at most once. 
     * If this tag is empty or has no text
     * other than whitespace, this method is <u>not</u> called. If this tag has
     * sub tags and only whitespace between the sub tags, this method is <u>not
     * </u> called. If there is a mixture of (non-whitespace) text and sub tags,
     * this method is called multiple times.
     * <p>
     * For example:
     * <pre>
     * &lt;apple&gt;
     *     &lt;excellent&gt;Red Delicious&lt;/excellent&gt;
     *     &lt;good&gt;Granny Smith&lt;/good&gt;
     * &lt;/apple&gt;
     * &lt;fresh value="yes" /&gt;
     * &lt;mango&gt;
     *      &lt;/mango&gt;
     * &lt;story&gt;They are &lt;bold&gt;very&lt;/bold&gt; tasty.&lt;/story&gt;
     * </pre>
     * The <tt>text()</tt> method is called:
     * <ul>
     * <li>exactly one time for <tt>excellent</tt> (no sub tags).</li>
     * <li>never for <tt>apple</tt> (only sub tags and whitespace).</li>
     * <li>never for <tt>fresh</tt> (empty element).</li>
     * <li>never for <tt>mango</tt> (only whitespace).</li>
     * <li>two times for <tt>story</tt> (once for <tt>"They are "</tt> and 
     * a second time for <tt>" tasty."</tt> [<tt>"very"</tt> is passed to 
     * the <tt>text()</tt> for the tag handler for <tt>bold</tt>, not for
     * <tt>story</tt>.]</li>
     * </ul>
     */
    void text(Value tagText) throws SAXException;

    /**
     * Returns the handler for the sub tag. Returns <tt>null</tt> if there is
     * not a handler for this sub tag.
     */
    TagHandler startSubTag(NameDetail subTagName) throws SAXException;

    /**
     * Called after a sub tag has completed.
     */
    void endSubTag(NameDetail subTagName, Value subTagResult)
            throws SAXException;

    /**
     * Called after {@link #endTag endTag()}to retrieve the results of the
     * processing of this tag (and all of its sub tags). 
     * 
     * @return the value calculated, <i>never</i> <tt>null</tt>. 
     * 
     * @exception SAXException if the result can not be assembled (e.g. a
     *                required piece of data is missing).
     */
    Value getResult() throws SAXException;
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.