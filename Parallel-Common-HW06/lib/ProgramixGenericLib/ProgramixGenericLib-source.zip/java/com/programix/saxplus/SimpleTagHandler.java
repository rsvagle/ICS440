package com.programix.saxplus;

import com.programix.value.*;

/**
 * Used to gather a <b>single</b> value from a tag--a very common case.
 * Used when a tag has either:
 * <ul>
 * <li>one attribute and nothing else (empty element)</li>
 * <li>just text content, zero attributes and zero sub tags</li>
 * </ul>
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class SimpleTagHandler extends BaseTagHandler implements TagHandler {
	private Value result;

	public SimpleTagHandler() {
	    result = ValueFactory.NULL_INSTANCE;
	}

	@Override
    public void startTag(NameDetail tagName, AttributeGroup attr) {
		if ( attr.getSize() == 1 ) {
            result = attr.get(0).getValue();
		} else {
            result = ValueFactory.NULL_INSTANCE;
		}
	}

	@Override
    public void text(Value tagText) {
        result = tagText;
	}

	@Override
    public Value getResult() {
		return result;
	}
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.