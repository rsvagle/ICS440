package com.programix.saxplus;

import com.programix.value.*;

/**
 * <tt>Attribute</tt> encapsulates the name and value information
 * for a single attribute of an XML element.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface Attribute {
	/**
	 * Returns the name information for this attribute.
	 */
	NameDetail getNameDetail();

	/**
	 * Shortcut for <tt>getNameData().getName()</tt>.
	 */
	String getName();

	/**
	 * Returns the value of this attribute.
	 */
	Value getValue();

	/**
	 * Shortcut for <tt>getValue().getString()</tt>.
	 */
	String getStringValue();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.