package com.programix.saxplus;

/**
 * Stores all of the detail about the name of a element or the name of
 * an attribute. The addition of "namespaces" to XML was very useful in
 * certain scenarios, but it sure complicates basic parsing. An instance of
 * [a class that implements] <tt>NameDetail</tt> holds all of the "local name"
 * "qualified name" and "namespace URI" information available. Very often, 
 * only the <i>plain old name</i> is needed, and this is what {@link #getName()}
 * returns.
 *  
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface NameDetail {
	/**
	 * Returns a simple name which is usually the "correct" tag or
	 * attribute name. If {@link #getLocalName()} returns a string that
     * is not {@link com.programix.util.StringTools#isEmpty(String) empty}, 
     * then this "local name" is used, otherwise the value returned from
     * {@link #getQName()} is used.
	 */
	String getName();

    /**
     * Returns the "local name" as reported by SAX parser.
     */
	String getLocalName();
    
    /**
     * Returns the "qualified name" as reported by SAX parser.
     */
	String getQName();
    
    /**
     * Returns the "namespace URI" as reported by the SAX parser.
     */
	String getURI();

	/**
	 * Returns the <tt>NameDetail</tt> for the containing tag. If
	 * this <tt>NameDetail</tt> is an attribute, then the element
	 * name that this attribute belongs to is returned. If this
	 * <tt>NameDetail</tt> is an element, then its containing
	 * element name is returned. If this is the root tag, then 
	 * <tt>null</tt> is returned.
	 */
	NameDetail getParent();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.