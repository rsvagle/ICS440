package com.programix.jnlp;

import javax.jnlp.*;

public class JNLPTools {
    public static final String BASIC_SERVICE_CLASSNAME = 
        "javax.jnlp.BasicService";
    
    public static final String CLIPBOARD_SERVICE_CLASSNAME = 
        "javax.jnlp.ClipboardService";
    
    public static final String FILE_OPEN_SERVICE_CLASSNAME = 
        "javax.jnlp.FileOpenService";
    
    public static final String FILE_SAVE_SERVICE_CLASSNAME = 
        "javax.jnlp.FileSaveService";
    
    public static final String PERSISTENCE_SERVICE_CLASSNAME = 
        "javax.jnlp.PersistenceService";
    
    public static final String PRINT_SERVICE_CLASSNAME = 
        "javax.jnlp.PrintService";
    
    private static final boolean launchedByJNLP;

    static {
        boolean result = false;

        try {
            Class.forName("javax.jnlp.ServiceManager");
            ServiceManager.lookup("javax.jnlp.BasicService");

            // No exception was thrown, BasicService is available
            result = true;
        } catch ( Exception x ) {
            // ignore and leave lauchnedByJNLP false
        } finally {
            launchedByJNLP = result;
        }
    }

    // no instances
    private JNLPTools() {
    }

    public static boolean wasAppLaunchedByJNLP() {
        return launchedByJNLP;
    }

    private static boolean isServiceAvailable(String name) {
        if ( wasAppLaunchedByJNLP() == false ) {
            return false;
        }
        
        try {
            getService(name);
            return true;
        } catch ( UnavailableException x ) {
            return false;
        }
    }
    
    private static Object getService(String name) throws UnavailableException {
        try {
            return ServiceManager.lookup(name);
        } catch ( UnavailableServiceException x ) {
            throw new UnavailableException("Could not locate: " + name, x);
        }
    }

    public static boolean isBasicServiceAvailable() {
        return isServiceAvailable(BASIC_SERVICE_CLASSNAME);
    }
    
    public static BasicService getBasicService() throws UnavailableException {
        return (BasicService) getService(BASIC_SERVICE_CLASSNAME);
    }

    public static boolean isClipboardServiceAvailable() {
        return isServiceAvailable(CLIPBOARD_SERVICE_CLASSNAME);
    }

    public static ClipboardService getClipboardService() 
            throws UnavailableException {
        
        return (ClipboardService) getService(CLIPBOARD_SERVICE_CLASSNAME);
    }

    public static boolean isFileOpenServiceAvailable() {
        return isServiceAvailable(FILE_OPEN_SERVICE_CLASSNAME);
    }

    public static FileOpenService getFileOpenService() 
            throws UnavailableException {
        
        return (FileOpenService) getService(FILE_OPEN_SERVICE_CLASSNAME);
    }

    public static boolean isFileSaveServiceAvailable() {
        return isServiceAvailable(FILE_SAVE_SERVICE_CLASSNAME);
    }

    public static FileSaveService getFileSaveService() 
            throws UnavailableException {
        
        return (FileSaveService) getService(FILE_SAVE_SERVICE_CLASSNAME);
    }

    public static boolean isPersistenceServiceAvailable() {
        return isServiceAvailable(PERSISTENCE_SERVICE_CLASSNAME);
    }

    public static PersistenceService getPersistenceService() 
            throws UnavailableException {
        
        return (PersistenceService) getService(PERSISTENCE_SERVICE_CLASSNAME);
    }

    public static boolean isPrintServiceAvailable() {
        return isServiceAvailable(PRINT_SERVICE_CLASSNAME);
    }

    public static PrintService getPrintService() throws UnavailableException {
        return (PrintService) getService(PRINT_SERVICE_CLASSNAME);
    }

    /**
     * Thrown when a JNLP service can not be loaded. This is a
     * {@link RuntimeException}, so callers are not required to catch it. 
     */
    public static class UnavailableException extends RuntimeException {
        public UnavailableException(String message, Throwable cause) {
            super(message, cause);
        }

        public UnavailableException(Throwable cause) {
            super(cause);
        }
    } // class UnavailableException
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.