package com.programix.jnlp;

import java.awt.print.*;

public class JNLPPrintTools {
    public static final Paper US_LETTER_ONE_INCH_MARGINS;

    static {
        Paper paper = new Paper();
        paper.setSize(8.5 * 72.0, 11.0 * 72.0);
        double x = 1.00 * 72.0;
        double y = 1.00 * 72.0;
        double w = 6.5 * 72.0;
        double h = 9.0 * 72.0;
        paper.setImageableArea(x, y, w, h);
        US_LETTER_ONE_INCH_MARGINS = paper;
    }

    private JNLPPrintTools() {
    }

    public static boolean print(Pageable pageable) throws PrinterException {
        if ( JNLPTools.isPrintServiceAvailable() ) {
            // there are two PrintService's javax.jnlp and java.awt.print
            javax.jnlp.PrintService ps = JNLPTools.getPrintService();
            return ps.print(pageable);
        } else {
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setPageable(pageable);

            if ( job.printDialog() ) {
                job.print();
                return true;
            }

            return false;
        }
    }
    
    public static boolean print(Printable printable, 
                                PageFormat pageFormat,
                                int numberOfPages
                            ) throws PrinterException {
        
        Book book = new Book();
        book.append(printable, pageFormat, numberOfPages);
        return print(book);
    }

    public static boolean print(Printable printable, 
                                Paper paper,
                                int numberOfPages
                            ) throws PrinterException {
        
        PageFormat pageFormat = new PageFormat();
        pageFormat.setPaper(paper);
        return print(printable, pageFormat, numberOfPages);
    }
    
    public static boolean print(Printable printable, 
                                int numberOfPages
                            ) throws PrinterException {
        
        return print(printable, US_LETTER_ONE_INCH_MARGINS, numberOfPages);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.