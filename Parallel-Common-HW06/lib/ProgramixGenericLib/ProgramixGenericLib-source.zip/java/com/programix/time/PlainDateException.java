package com.programix.time;

/**
 * Thrown to signal a problem processing a {@link PlainDate}. This exception
 * is a {@link RuntimeException}, so there is not requirement to catch it
 * when it is truly unexpected.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class PlainDateException extends RuntimeException {
    public PlainDateException() {
        super();
    }

    public PlainDateException(String message) {
        super(message);
    }
    
    public PlainDateException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public PlainDateException(Throwable cause) {
        super(cause);
    }
    
    public static PlainDateException createParse(String source) {
        return new PlainDateException(
            "Unable to parse '" + source + "' as a PlainDate.");
    }
    
    public static void throwParse(String source) throws PlainDateException {
        throw createParse(source);
    }
    
    public static PlainDateException createInvalid(int yearNumber, 
                                                   int monthNumber, 
                                                   int dayNumber) { 
        
        return new PlainDateException(
            "Invalid combination of year=" + yearNumber +
            ", month=" + monthNumber + 
            ", and day=" + dayNumber);
    }
    
    public static void throwInvalid(int yearNumber, 
                                    int monthNumber, 
                                    int dayNumber) throws PlainDateException {

        throw createInvalid(yearNumber, monthNumber, dayNumber);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.