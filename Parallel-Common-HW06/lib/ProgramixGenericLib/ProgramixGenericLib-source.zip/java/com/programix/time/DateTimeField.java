package com.programix.time;

import java.io.*;

/**
 * Used to specify a field in a date/time for the Gregorian calendar.
 * See each of the fields defined for specifics:
 * {@link #YEAR}, {@link #MONTH}, {@link #DAY},
 * {@link #HOUR}, {@link #MINUTE}, {@link #SECOND},
 * and {@link #MILLISECOND}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class DateTimeField implements Serializable {

    /**
     * The 4-digit year.
     * The field holding <tt>2004</tt> in <tt>2004-12-19 15:45:52.809</tt>.
     */
    public static final DateTimeField YEAR = new DateTimeField(0, "YEAR");

    /**
     * The month of the year.
     * The field holding <tt>12</tt> in <tt>2004-12-19 15:45:52.809</tt>.
     */
    public static final DateTimeField MONTH = new DateTimeField(1, "MONTH");

    /**
     * The day [date] of the month.
     * The field holding <tt>19</tt> in <tt>2004-12-19 15:45:52.809</tt>.
     */
    public static final DateTimeField DAY = new DateTimeField(2, "DAY");

    /**
     * The hour of the day in 24-hour format.
     * The field holding <tt>15</tt> in <tt>2004-12-19 15:45:52.809</tt>.
     */
    public static final DateTimeField HOUR = new DateTimeField(3, "HOUR");

    /**
     * The minute of the hour.
     * The field holding <tt>45</tt> in <tt>2004-12-19 15:45:52.809</tt>.
     */
    public static final DateTimeField MINUTE = new DateTimeField(4, "MINUTE");

    /**
     * The second of the minute.
     * The field holding <tt>52</tt> in <tt>2004-12-19 15:45:52.809</tt>.
     */
    public static final DateTimeField SECOND = new DateTimeField(5, "SECOND");

    /**
     * The millisecond of the second.
     * The field holding <tt>809</tt> in <tt>2004-12-19 15:45:52.809</tt>.
     */
    public static final DateTimeField MILLISECOND =
                                        new DateTimeField(6, "MILLISECOND");


    private static final DateTimeField[] VALUE_LIST = new DateTimeField[] {
            YEAR, MONTH, DAY, HOUR, MINUTE, SECOND, MILLISECOND};

    private final int code;
    private final String name;

    public DateTimeField(int code, String name) {
        this.code = code;
        this.name = name;
    }

    /**
     * Returns the name of this anchor. For example: "NORTH", "CENTER", etc.
     */
    public String getName() {
        return name;
    }

    /**
     * Use this method instead of <tt>==</tt> to be sure that serialization or
     * multiple class loaders have not resulted in multiple instances.
     */
    @Override
    public boolean equals(Object obj) {
        if ( this == obj ) {
            return true;
        } else if ( obj == null || !getClass().equals(obj.getClass()) ) {
            return false;
        }

        DateTimeField other = (DateTimeField) obj;
        return code == other.code;
    }

    @Override
    public int hashCode() {
        return code;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(getClass().getName() + "[");
        sb.append("name=" + name);
        sb.append("]");
        return sb.toString();
    }

    /**
     * Returns an array of all the legal values. A cloned copy is returned,
     * so no caution in how the array is used by the caller is required.
     */
    public static DateTimeField[] getValues() {
        return (DateTimeField[]) VALUE_LIST.clone();
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.