package com.programix.time;

import java.io.*;
import java.util.*;

import com.programix.math.*;

/**
 * Used to specify the format for a date/time for the Gregorian calendar.
 * Year is formatted using four digits, month as <tt>01</tt> to <tt>12</tt>,
 * day as <tt>01</tt> to <tt>28</tt>, <tt29</tt>, <tt>30</tt>,
 * or <tt>31</tt> (depending on the month and year).
 * Hour uses the 24-hour style as <tt>00</tt> to <tt>23</tt>.
 * Minute as <tt>00</tt> to <tt>59</tt>.
 * Second as <tt>00</tt> to <tt>59</tt>.
 * Millisecond as <tt>000</tt> to <tt>999</tt>.
 * Colons are used between the hour, minute, and second fields.
 * A period is used between the second and millisecond fields.
 * A space is used between the date and time sections.
 *
 * @see DateTools
 * @see DateTime
 * @see DateTimeField
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class DateTimeFormat
        implements Serializable, Comparable<DateTimeFormat> {

    private static int nextSerial = 0;
    private static List<DateTimeFormat> instanceList =
        new ArrayList<DateTimeFormat>();

    private static final int YEAR = 101;
    private static final int MONTH = 102;
    private static final int DAY = 103;
    private static final int HOUR = 104;
    private static final int MINUTE = 105;
    private static final int SECOND = 106;
    private static final int MILLISECOND = 107;

    private static final char DASH = '-';
    private static final char SLASH = '/';
    private static final char DOT = '.';
    private static final char COLON = ':';
    private static final char SPACE = ' ';
    private static final char NONE = '\u0000';

    // This variable declaration and construction order must never
    // change if there are serialized instances saved somewhere as
    // they will be misinterpreted when de-serialized. If any new
    // instances are to be created, they must be appended to the
    // end of the existing list. The order of the constants will also
    // be the sort order for Comparable.

    /**
     * Format: <tt>yyyy-mm-dd hh:mm:ss.fff</tt>.
     * Formats the date as year, month, day, hour, minute, second, millisecond
     * with dashes delimiting the date portion.
     * Example: <tt>2004-12-19 15:45:52.809</tt>.
     */
    public static final DateTimeFormat YMD_HMSF_DASH =
        new DateTimeFormat("YMD_HMSF_DASH", MILLISECOND, DASH);

    /**
     * Format: <tt>yyyy/mm/dd hh:mm:ss.fff</tt>.
     * Formats the date as year, month, day, hour, minute, second, millisecond
     * with slashes delimiting the date portion.
     * Example: <tt>2004/12/19 15:45:52.809</tt>.
     */
    public static final DateTimeFormat YMD_HMSF_SLASH =
        new DateTimeFormat("YMD_HMSF_SLASH", MILLISECOND, SLASH);

    /**
     * Format: <tt>yyyy.mm.dd hh:mm:ss.fff</tt>.
     * Formats the date as year, month, day, hour, minute, second, millisecond
     * with dots delimiting the date portion.
     * Example: <tt>2004.12.19 15:45:52.809</tt>.
     */
    public static final DateTimeFormat YMD_HMSF_DOT =
        new DateTimeFormat("YMD_HMSF_DOT", MILLISECOND, DOT);

    /**
     * Format: <tt>mm-dd-yyyy hh:mm:ss.fff</tt>.
     * Formats the date as month, day, year, hour, minute, second, millisecond
     * with dashes delimiting the date portion.
     * Example: <tt>12-19-2004 15:45:52.809</tt>.
     */
    public static final DateTimeFormat MDY_HMSF_DASH =
        new DateTimeFormat("MDY_HMSF_DASH", MILLISECOND, DASH);

    /**
     * Format: <tt>mm/dd/yyyy hh:mm:ss.fff</tt>.
     * Formats the date as month, day, year, hour, minute, second, millisecond
     * with slashes delimiting the date portion.
     * Example: <tt>12/19/2004 15:45:52.809</tt>.
     */
    public static final DateTimeFormat MDY_HMSF_SLASH =
        new DateTimeFormat("MDY_HMSF_SLASH", MILLISECOND, SLASH);

    /**
     * Format: <tt>mm.dd.yyyy hh:mm:ss.fff</tt>.
     * Formats the date as month, day, year, hour, minute, second, millisecond
     * with dots delimiting the date portion.
     * Example: <tt>12.19.2004 15:45:52.809</tt>.
     */
    public static final DateTimeFormat MDY_HMSF_DOT =
        new DateTimeFormat("MDY_HMSF_DOT", MILLISECOND, DOT);

    /**
     * Format: <tt>yyyy-mm-dd hh:mm:ss</tt>.
     * Formats the date as year, month, day, hour, minute, second
     * with dashes delimiting the date portion.
     * Example: <tt>2004-12-19 15:45:52</tt>.
     */
    public static final DateTimeFormat YMD_HMS_DASH =
        new DateTimeFormat("YMD_HMS_DASH", SECOND, DASH);

    /**
     * Format: <tt>yyyy/mm/dd hh:mm:ss</tt>.
     * Formats the date as year, month, day, hour, minute, second
     * with slashes delimiting the date portion.
     * Example: <tt>2004/12/19 15:45:52</tt>.
     */
    public static final DateTimeFormat YMD_HMS_SLASH =
        new DateTimeFormat("YMD_HMS_SLASH", SECOND, SLASH);

    /**
     * Format: <tt>yyyy.mm.dd hh:mm:ss</tt>.
     * Formats the date as year, month, day, hour, minute, second
     * with dots delimiting the date portion.
     * Example: <tt>2004.12.19 15:45:52</tt>.
     */
    public static final DateTimeFormat YMD_HMS_DOT =
        new DateTimeFormat("YMD_HMS_DOT", SECOND, DOT);

    /**
     * Format: <tt>yyyymmddhhmmss</tt>.
     * Formats the date as year, month, day, hour, minute, second
     * with nothing delimiting the date or time portion.
     * Example: <tt>20041219154552</tt>.
     */
    public static final DateTimeFormat YMD_HMS_NONE =
        new DateTimeFormat("YMD_HMS_NONE", SECOND, NONE, NONE, NONE);

    /**
     * Format: <tt>mm-dd-yyyy hh:mm:ss</tt>.
     * Formats the date as month, day, year, hour, minute, second
     * with dashes delimiting the date portion.
     * Example: <tt>12-19-2004 15:45:52</tt>.
     */
    public static final DateTimeFormat MDY_HMS_DASH =
        new DateTimeFormat("MDY_HMS_DASH", SECOND, DASH);

    /**
     * Format: <tt>mm/dd/yyyy hh:mm:ss</tt>.
     * Formats the date as month, day, year, hour, minute, second
     * with slashes delimiting the date portion.
     * Example: <tt>12/19/2004 15:45:52</tt>.
     */
    public static final DateTimeFormat MDY_HMS_SLASH =
        new DateTimeFormat("MDY_HMS_SLASH", SECOND, SLASH);

    /**
     * Format: <tt>mm.dd.yyyy hh:mm:ss</tt>.
     * Formats the date as month, day, year, hour, minute, second
     * with dots delimiting the date portion.
     * Example: <tt>12.19.2004 15:45:52</tt>.
     */
    public static final DateTimeFormat MDY_HMS_DOT =
        new DateTimeFormat("MDY_HMS_DOT", SECOND, DOT);

    /**
     * Format: <tt>yyyy-mm-dd hh:mm</tt>.
     * Formats the date as year, month, day, hour, minute
     * with dashes delimiting the date portion.
     * Example: <tt>2004-12-19 15:45</tt>.
     */
    public static final DateTimeFormat YMD_HM_DASH =
        new DateTimeFormat("YMD_HM_DASH", MINUTE, DASH);

    /**
     * Format: <tt>yyyy/mm/dd hh:mm</tt>.
     * Formats the date as year, month, day, hour, minute
     * with slashes delimiting the date portion.
     * Example: <tt>2004/12/19 15:45</tt>.
     */
    public static final DateTimeFormat YMD_HM_SLASH =
        new DateTimeFormat("YMD_HM_SLASH", MINUTE, SLASH);

    /**
     * Format: <tt>yyyy.mm.dd hh:mm</tt>.
     * Formats the date as year, month, day, hour, minute
     * with dots delimiting the date portion.
     * Example: <tt>2004.12.19 15:45</tt>.
     */
    public static final DateTimeFormat YMD_HM_DOT =
        new DateTimeFormat("YMD_HM_DOT", MINUTE, DOT);

    /**
     * Format: <tt>yyyymmddhhmm</tt>.
     * Formats the date as year, month, day, hour, minute
     * with nothing delimiting the date or time portion.
     * Example: <tt>200412191545</tt>.
     */
    public static final DateTimeFormat YMD_HM_NONE =
        new DateTimeFormat("YMD_HM_NONE", MINUTE, NONE, NONE, NONE);

    /**
     * Format: <tt>mm-dd-yyyy hh:mm</tt>.
     * Formats the date as month, day, year, hour, minute
     * with dashes delimiting the date portion.
     * Example: <tt>12-19-2004 15:45</tt>.
     */
    public static final DateTimeFormat MDY_HM_DASH =
        new DateTimeFormat("MDY_HM_DASH", MINUTE, DASH);

    /**
     * Format: <tt>mm/dd/yyyy hh:mm</tt>.
     * Formats the date as month, day, year, hour, minute
     * with slashes delimiting the date portion.
     * Example: <tt>12/19/2004 15:45</tt>.
     */
    public static final DateTimeFormat MDY_HM_SLASH =
        new DateTimeFormat("MDY_HM_SLASH", MINUTE, SLASH);

    /**
     * Format: <tt>mm.dd.yyyy hh:mm</tt>.
     * Formats the date as month, day, year, hour, minute
     * with dots delimiting the date portion.
     * Example: <tt>12.19.2004 15:45</tt>.
     */
    public static final DateTimeFormat MDY_HM_DOT =
        new DateTimeFormat("MDY_HM_DOT", MINUTE, DOT);

    /**
     * Format: <tt>yyyy-mm-dd</tt>.
     * Formats the date as year, month, day
     * with dashes delimiting the date portion.
     * Example: <tt>2004-12-19</tt>.
     */
    public static final DateTimeFormat YMD_DASH =
        new DateTimeFormat("YMD_DASH", DAY, DASH);

    /**
     * Format: <tt>yyyy/mm/dd</tt>.
     * Formats the date as year, month, day
     * with slashes delimiting the date portion.
     * Example: <tt>2004/12/19</tt>.
     */
    public static final DateTimeFormat YMD_SLASH =
        new DateTimeFormat("YMD_SLASH", DAY, SLASH);

    /**
     * Format: <tt>yyyy.mm.dd</tt>.
     * Formats the date as year, month, day
     * with dots delimiting the date portion.
     * Example: <tt>2004.12.19</tt>.
     */
    public static final DateTimeFormat YMD_DOT =
        new DateTimeFormat("YMD_DOT", DAY, DOT);

    /**
     * Format: <tt>yyyymmdd</tt>.
     * Formats the date as year, month, day
     * with nothing delimiting the date portion.
     * Example: <tt>20041219</tt>.
     */
    public static final DateTimeFormat YMD_NONE =
        new DateTimeFormat("YMD_NONE", DAY, NONE);

    /**
     * Format: <tt>mm-dd-yyyy</tt>.
     * Formats the date as month, day, year
     * with dashes delimiting the date portion.
     * Example: <tt>12-19-2004</tt>.
     */
    public static final DateTimeFormat MDY_DASH =
        new DateTimeFormat("MDY_DASH", DAY, DASH);

    /**
     * Format: <tt>mm/dd/yyyy</tt>.
     * Formats the date as month, day, year
     * with slashes delimiting the date portion.
     * Example: <tt>12/19/2004</tt>.
     */
    public static final DateTimeFormat MDY_SLASH =
        new DateTimeFormat("MDY_SLASH", DAY, SLASH);

    /**
     * Format: <tt>mm.dd.yyyy</tt>.
     * Formats the date as month, day, year
     * with dots delimiting the date portion.
     * Example: <tt>12.19.2004</tt>.
     */
    public static final DateTimeFormat MDY_DOT =
        new DateTimeFormat("MDY_DOT", DAY, DOT);

    /**
     * Format: <tt>mmddyyyy</tt>.
     * Formats the date as month, day, year
     * with nothing delimiting the date portion.
     * Example: <tt>12192004</tt>.
     */
    public static final DateTimeFormat MDY_NONE =
        new DateTimeFormat("MDY_NONE", DAY, NONE);


    private static final DateTimeFormat[] VALUES = (DateTimeFormat[])
        instanceList.toArray(new DateTimeFormat[instanceList.size()]);

    /**
     * An unmodifiable {@link List} of all the instances of
     * <tt>DateTimeFormat</tt>.
     */
    public static final List<DateTimeFormat> VALUE_LIST =
        Collections.unmodifiableList(instanceList);

    private final int serial;
    private final transient String name;

    private final transient int toField;
    private final transient char dateDelimiter;
    private final transient char timeDelimiter;
    private final transient char dateTimeDelimiter;
    private final transient boolean monthFirst;

    // private constructor to prevent outside instantiation
    private DateTimeFormat(String name,
                           int toField,
                           char dateDelimiter,
                           char timeDelimiter,
                           char dateTimeDelimiter) {

        this.serial = getSerial(this);
        this.name = name;
        this.toField = toField ;
        this.dateDelimiter = dateDelimiter;
        this.timeDelimiter = timeDelimiter;
        this.dateTimeDelimiter = dateTimeDelimiter;

        // The calculation of this may need to change at some future time
        // if there are names that start with 'M', but do not mean month:
        monthFirst = name.startsWith("M");
    }

    private DateTimeFormat(String name, int toField, char dateDelimiter) {
        this(name, toField, dateDelimiter, COLON, SPACE);
    }

    private DateTimeFormat(String name,
                           int toField,
                           char dateDelimiter,
                           char timeDelimiter) {

        this(name, toField, dateDelimiter, timeDelimiter, SPACE);
    }

    private static synchronized int getSerial(DateTimeFormat instance) {
        instanceList.add(instance);
        return nextSerial++ ;
    }

    /**
     * Returns an array of all the instances of <tt>DateTimeFormat</tt>.
     * A cloned copy is returned, so no special care is required.
     */
    public static DateTimeFormat[] getValues() {
        return (DateTimeFormat[]) VALUES.clone();
    }

    /**
     * Returns the instance whose {@link #getName} method returns
     * a <tt>String</tt> that matches the <tt>name</tt> passed in.
     * The matching is done ignoring any case differences and after
     * trimming any leading or trailing whitespace on the string
     * passed in.
     *
     * @param name the name to search for.
     * @return the matching instance
     * @throws IllegalArgumentException if no match is found.
     */
    public static DateTimeFormat valueOf(String name)
            throws IllegalArgumentException {

        String s = (name == null) ? "" : name.trim();
        for ( int i = 0; i < VALUES.length; i++ ) {
            if ( VALUES[i].name.equalsIgnoreCase(s) ) {
                return VALUES[i];
            }
        }

        throw new IllegalArgumentException("Can not find a match for '" + name
                + "'");
    }

    // Used during de-serialization
    private Object readResolve() {
        // Only return one of the few instances.
        return VALUES[serial];
    }

    @Override
    public boolean equals(Object obj) {
        return this == obj;
    }

    @Override
    public int hashCode() {
        return serial;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(getClass().getName() + "[");
        sb.append("serial=" + serial);
        sb.append(", name=" + name);
        sb.append("]");
        return sb.toString();
    }

    public int compareTo(DateTimeFormat other) {
        return serial - other.serial;
    }

    /**
     * Returns the name of this format.
     * For example: YMD_HMSF_DASH, MDY_HMS_SLASH, YMD_HM_DOT, etc.
     */
    public String getName() {
        return name;
    }

    /**
     * Formats the date/time stored in the specified {@link Calendar} appending
     * the text to the specified {@link StringBuffer}. The <tt>Calendar</tt>
     * holds the date/time and has an associated {@link TimeZone} to define
     * where the year, month, day, hour, etc. should be interpreted for.
     * If the passed <tt>StringBuffer</tt> is <tt>null</tt>, then a new
     * <tt>StringBuffer</tt> is constructed internally and returned.
     * For a lot more flexibility, see {@link DateTools}.
     *
     * @param cal holds the date/time and the time zone to use for formatting
     * the date/time.
     * @param appendTo the <tt>StringBuffer</tt> to append the formatted date
     * to. If <tt>null</tt> is passed in, then a brand new <tt>StringBuffer</tt>
     * is created internally (and returned).
     *
     * @return the same <tt>StringBuffer</tt> passed in, or if <tt>null</tt>
     * was passed in, then a new <tt>StringBuffer</tt>.
     *
     * @see DateTools
     * @see DateTime
     * @see DateTimeField
     */
    public StringBuffer format(Calendar cal, StringBuffer appendTo) {
        StringBuffer sb = (appendTo == null) ? new StringBuffer(32) : appendTo;

        int year = cal.get(Calendar.YEAR);
        int month = 1 + cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        if ( monthFirst ) {
            if ( toField >= MONTH ) {
                NumberTools.formatPadZero(month, 2, sb);

                if ( toField >= DAY ) {
                    delimiterAppendCheck(dateDelimiter, sb);
                    NumberTools.formatPadZero(day, 2, sb);
                }
            }

            if ( toField >= YEAR ) {
                delimiterAppendCheck(dateDelimiter, sb);
                NumberTools.formatPadZero(year, 4, sb);
            }
        } else {
            if ( toField >= YEAR ) {
                NumberTools.formatPadZero(year, 4, sb);

                if ( toField >= MONTH ) {
                    delimiterAppendCheck(dateDelimiter, sb);
                    NumberTools.formatPadZero(month, 2, sb);

                    if ( toField >= DAY ) {
                        delimiterAppendCheck(dateDelimiter, sb);
                        NumberTools.formatPadZero(day, 2, sb);
                    }
                }
            }
        }

        if ( toField >= HOUR ) {
            delimiterAppendCheck(dateTimeDelimiter, sb);
            NumberTools.formatPadZero(cal.get(Calendar.HOUR_OF_DAY), 2, sb);

            if ( toField >= MINUTE ) {
                delimiterAppendCheck(timeDelimiter, sb);
                NumberTools.formatPadZero(cal.get(Calendar.MINUTE), 2, sb);

                if ( toField >= SECOND ) {
                    delimiterAppendCheck(timeDelimiter, sb);
                    NumberTools.formatPadZero(cal.get(Calendar.SECOND), 2, sb);

                    if ( toField >= MILLISECOND ) {
                        sb.append('.');
                        NumberTools.formatPadZero(
                            cal.get(Calendar.MILLISECOND), 3, sb);
                    }
                }
            }
        }

        return sb;
    }

    private static void delimiterAppendCheck(char delimiter, StringBuffer sb) {
        if ( delimiter != NONE ) {
            sb.append(delimiter);
        }
    }

    /**
     * Formats the date/time stored in the specified <tt>Calendar</tt>
     * returning the text in a <tt>String</tt>.
     * Unlike {@link #format(Calendar, StringBuffer)}, this method <i>always</i>
     * creates a new <tt>StringBuffer</tt> instance and a new <tt>String</tt>
     * instance (so if you have a <tt>StringBuffer</tt> that you are already
     * using, calling the other method is more efficient).
     *
     * @param cal the date, time, and timezone to use for formatting
     * @return a newly created <tt>String</tt> with the formatted date/time.
     */
    public String format(Calendar cal) {
        return format(cal, null).toString();
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.