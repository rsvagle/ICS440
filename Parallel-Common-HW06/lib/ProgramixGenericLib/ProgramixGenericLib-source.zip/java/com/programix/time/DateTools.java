package com.programix.time;

import java.text.*;
import java.util.*;

import com.programix.util.*;

/**
 * Handy utilities for manipulating dates and times mostly focusing on
 * {@link DateTime} and {@link PlainDate}.
 * <p>
 * Time translations (moving the Java VM into the past or future) and
 * dilations (changing the speed that time runs) can be done by
 * setting an alternate {@link TimeSource} and then using the methods on this
 * class for retrieving the current time. The simplest way to get
 * the potentially alternate 'now' can be achieved by calling
 * {@link #getTime()} for a <tt>long</tt> and {@link #getNow()}
 * for a {@link DateTime}. By default, the <tt>TimeSource</tt>
 * simply returns the normal time from
 * {@link System#currentTimeMillis() System.currentTimeMillis()}.
 * <p>
 * <a name="TIME_INFO" id="TIME_INFO"><b><u>Time Information</u></b></a><br />
 * For more on time,
 * various systems for time measurement, time zones,
 * daylight saving time, leaps years, and leap seconds, visit some
 * of the following sites.
 * <dl>
 * <dt>Time Measurement:</dt>
 * <dd><a href="http://tycho.usno.navy.mil/">US Navy - Time Service</a></dd>
 * <dd><a href="http://tycho.usno.navy.mil/systime.html">US Navy -
 * Systems of Time</a></dd>
 * <dd><a href="http://en.wikipedia.org/wiki/Coordinated_Universal_Time"
 * >Wikipedia - UTC (Coordinated Universal Time)</a></dd>
 * <dd><a href="http://en.wikipedia.org/wiki/Universal_Time">Wikipedia -
 * UT (Universal Time)</a></dd>
 * <dd><a href="http://en.wikipedia.org/wiki/Greenwich_Mean_Time">Wikipedia -
 * GMT (Greenwich Mean Time)</a></dd>
 * <dt>Time Zones:</dt>
 * <dd><a href="http://en.wikipedia.org/wiki/Timezone">Wikipedia -
 * Time Zone</a></dd>
 * <dd><a href="http://www.timeanddate.com/worldclock/">DateAndTime.com -
 * Time Zones</a></dd>
 * <dt>Daylight Saving Time:</dt>
 * <dd><a href="http://en.wikipedia.org/wiki/Daylight_saving_time">Wikipedia -
 * Daylight Saving Time</a></dd>
 * <dd><a href="http://www.timeanddate.com/time/aboutdst.html">DateAndTime.com
 * - Daylight Saving Time</a></dd>
 * <dt>Leap Years:</dt>
 * <dd><a href="http://en.wikipedia.org/wiki/Leap_year">Wikipedia -
 * Leap Year</a></dd>
 * <dd><a href="http://www.timeanddate.com/date/leapyear.html">DateAndTime.com
 * - Leap Years</a></dd>
 * <dt>Leap Seconds:</dt>
 * <dd><a href="http://en.wikipedia.org/wiki/Leap_second">Wikipedia -
 * Leap Second</a></dd>
 * <dd><a href="http://tycho.usno.navy.mil/leapsec.html">US Navy -
 * Leap Seconds</a></dd>
 * <dd><a href="http://www.timeanddate.com/time/leapseconds.html"
 * >DateAndTime.com - Leap Seconds</a></dd>
 * <dt>Formatting the Date and Time:</dt>
 * <dd><a href="http://www.iso.org/iso/en/prods-services/popstds/datesandtime.html"
 * >International Organization for Standards - ISO 8601</a></dd>
 * <dd><a href="http://www.cl.cam.ac.uk/~mgk25/iso-time.html">Markus Kuhn -
 * Summary of ISO 8601</a></dd>
 * <dd><a href="http://www.w3.org/TR/NOTE-datetime">W3C -
 * Date and Time Formats</a></dd>
 * <dd><a href="http://en.wikipedia.org/wiki/Date_format">Wikipedia -
 * Calendar Date Formats</a></dd>
 * <dd><a href="http://www.hackcraft.net/web/datetime/">HackCraft - Date
 * and Time Formats on the Web</a></dd>
 * </dl>
 *
 * <p>
 * <a name="TZ_INFO" id="TZ_INFO"><b><u>Time Zone Issues</u></b></a><br />
 * Time zones can add a strange dimension to calculating what time of day
 * it is&mdash;and even what day it is. Currently (2006) there are many
 * time zones with many local peculiarities. They span from UTC-12 through
 * UTC+14 making a maximum gap of 2<u>6</u> hours between two locations
 * at the same moment in time. Daylight Saving Time (DST) is observed
 * in some locations and not in others. DST changes the gap between
 * the local time and UTC from its 'normal' winter-time gap.
 * London is on UTC+0 and in the winter is aligned with UTC, but in
 * the summer London is one hour ahead of UTC.
 * In the United States, DST has changed many times. In the US,
 * DST expands in 2007 to start on the second Sunday in March and
 * to continue through the first Sunday of November (to determine
 * if March 21 is or is not on DST, one must also know the year).
 * Some locations are not whole hour amounts offset from UTC.
 * The table below shows some time zone extremes.
 * Note that when it is 2006-12-21 10:30 UTC, it is Dec 20 in one place,
 * Dec 21 in another, and Dec 22 is yet another. If three people where in
 * those places and on a conference call, they would have three different
 * answers to the question of what "today" is!
 * <table border="1">
 * <tr align="center"><td nowrap="nowrap">UTC-11</td>
 *   <td nowrap="nowrap">UTC-6</td>
 *   <td nowrap="nowrap">UTC</td>
 *   <td nowrap="nowrap">UTC</td>
 *   <td nowrap="nowrap">UTC+14</td></tr>
 * <tr align="center"><td>Pacific/<br />Pago_Pago</td>
 *   <td>America/<br />Chicago</td>
 *   <td>UTC</td>
 *   <td>Europe/<br />London</td>
 *   <td>Pacific/<br />Kiritimati</td></tr>
 * <tr><td nowrap="nowrap"><small><tt>2006-12-21 01:00</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-12-21 06:00</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-12-21 12:00</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-12-21 12:00</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-12-22 02:00</tt></small></td></tr>
 * <tr><td nowrap="nowrap"><small><tt>2006-12-20 23:30</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-12-21 04:30</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-12-21 10:30</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-12-21 10:30</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-12-22 00:30</tt></small></td></tr>
 * <tr><td nowrap="nowrap"><small><tt>2006-06-21 01:00</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-06-21 07:00</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-06-21 12:00</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-06-21 13:00</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-06-22 02:00</tt></small></td></tr>
 * <tr><td nowrap="nowrap"><small><tt>2006-06-20 23:30</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-06-21 05:30</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-06-21 10:30</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-06-21 11:30</tt></small></td>
 * <td nowrap="nowrap"><small><tt>2006-06-22 00:30</tt></small></td></tr>
 * </table>
 *
 * @see PlainDate
 * @see PlainDateRange
 * @see DayOfWeek
 * @see DateTime
 * @see DateTimeRange
 * @see DateTimeFormat
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DateTools {
    /**
     * Number of milliseconds in a second (1,000).
     */
    public static final long MS_PER_SECOND = 1000L;

    /**
     * Typical number of milliseconds in a minute (60,000).
     * Watch out for leap seconds which occur once in a while, and
     * when they do, there are <tt>61</tt> seconds in a minute
     * (and more rarely <tt>59</tt> seconds in a minute) so
     * the value of this constant would technically be wrong.
     * See <a href="#TIME_INFO">time information</a> for explanations of
     * timezones, daylight saving time, leap years, leap seconds, and more.
     */
    public static final long MS_PER_MINUTE = MS_PER_SECOND * 60L;

    /**
     * Typical number of milliseconds in an hour (3,600,000).
     * Watch out for leap seconds which occur once in a while, and
     * when they do, there are <tt>61</tt> seconds in a minute
     * (and more rarely <tt>59</tt> seconds in a minute) so
     * the value of this constant would technically be wrong.
     * See <a href="#TIME_INFO">time information</a> for explanations of
     * timezones, daylight saving time, leap years, leap seconds, and more.
     */
    public static final long MS_PER_HOUR = MS_PER_MINUTE * 60L;

    /**
     * Typical number of milliseconds in a day (86,400,000).
     * In a timezone that is switching on or off
     * <a href="http://en.wikipedia.org/wiki/Daylight_saving_time">Daylight
     * Saving Time</a>, the day might only be 23 hours long, might be 25 hours
     * long, or in some locations another odd amount (if and when a timezone
     * goes on and off DST varies from year to year, see the
     * <a
     * href="http://en.wikipedia.org/wiki/Daylight_saving_time#United_States">
     * United States DST</a> history for example).
     * Also, watch out for leap seconds which occur once in a while, and
     * when they do, there are <tt>61</tt> seconds in a minute
     * (and more rarely <tt>59</tt> seconds in a minute) so
     * the value of this constant would technically be wrong.
     * See <a href="#TIME_INFO">time information</a> for explanations of
     * timezones, daylight saving time, leap years, leap seconds, and more.
     */
    public static final long MS_PER_DAY = MS_PER_HOUR * 24L;

    /**
     * Typical number of milliseconds in a week (604,800,000).
     * In a timezone that is switching on or off
     * <a href="http://en.wikipedia.org/wiki/Daylight_saving_time">Daylight
     * Saving Time</a>, the day might only be 23 hours long, might be 25 hours
     * long, or in some locations another odd amount (if and when a timezone
     * goes on and off DST varies from year to year, see the
     * <a
     * href="http://en.wikipedia.org/wiki/Daylight_saving_time#United_States">
     * United States DST</a> history for example).
     * Also, watch out for leap seconds which occur once in a while, and
     * when they do, there are <tt>61</tt> seconds in a minute
     * (and more rarely <tt>59</tt> seconds in a minute) so
     * the value of this constant would technically be wrong.
     * See <a href="#TIME_INFO">time information</a> for explanations of
     * timezones, daylight saving time, leap years, leap seconds, and more.
     */
    public static final long MS_PER_WEEK = MS_PER_DAY * 7L;

    private static final int YEAR_FIELD = GregorianCalendar.YEAR;
    private static final int MONTH_FIELD = GregorianCalendar.MONTH;
    private static final int DAY_FIELD = GregorianCalendar.DAY_OF_MONTH;
    private static final int HOUR_FIELD = GregorianCalendar.HOUR_OF_DAY;
    private static final int MINUTE_FIELD = GregorianCalendar.MINUTE;
    private static final int SECOND_FIELD = GregorianCalendar.SECOND;
    private static final int MILLISECOND_FIELD = GregorianCalendar.MILLISECOND;
    private static final int DOW_FIELD = GregorianCalendar.DAY_OF_WEEK;

    private static final int HELPER_POOL_SIZE = 50;
    private static final HelperPool HELPER_POOL =
            new HelperPool(HELPER_POOL_SIZE);

    private static final Object TIME_SOURCE_LOCK = new Object();

    /**
     * This implementation of {@link TimeSource} simply returns the time
     * from the OS by using {@link System#currentTimeMillis()}. Passing
     * <tt>null</tt> to {@link DateTools#setTimeSource} has the same effect
     * as using this class.
     */
    public static final TimeSource DEFAULT_TIME_SOURCE =
        new DefaultTimeSource();

    private static TimeSource currentTimeSource = DEFAULT_TIME_SOURCE;

    // no instances
    private DateTools() {
    }

    /**
     * This method returns the number of milliseconds since Jan 1, 1970
     * as reported by the current {@link TimeSource}.
     * The source of this <tt>long</tt> <i>may</i> or <i>may not</i> be from
     * {@link System#currentTimeMillis()}.
     * If no one has called {@link #setTimeSource(TimeSource)}, then the
     * familiar <tt>System.currentTimeMillis()</tt> is used by default.
     * <p>
     * There are some other similar methods to also look at:
     * {@link #getNow()},
     * {@link #getToday(TimeZone)},
     * {@link #getTodayLocal()}, and
     * {@link #getTodayUTC()}.
     *
     * @see #getTimeSource()
     * @see #setTimeSource(TimeSource)
     * @see #getNow()
     * @see #getToday(TimeZone)
     * @see #getTodayLocal()
     * @see #getTodayUTC()
     */
    public static long getTime() {
        synchronized ( TIME_SOURCE_LOCK ) {
            return currentTimeSource.getTime();
        }
    }

    /**
     * Used to change the {@link TimeSource} that {@link #getTime} uses.
     * If <tt>null</tt> is passed in, then {@link #DEFAULT_TIME_SOURCE}
     * is automatically substituted.
     *
     * @see #getTimeSource()
     * @see #getTime()
     */
    public static void setTimeSource(TimeSource newTimeSource) {
        synchronized ( TIME_SOURCE_LOCK ) {
            if ( newTimeSource == null ) {
                currentTimeSource = DEFAULT_TIME_SOURCE;
            } else {
                currentTimeSource = newTimeSource;
            }
        }
    }

    /**
     * Used to retrieve the {@link TimeSource} that {@link #getTime} is
     * currently using.
     * There is always a current {@link TimeSource} (<tt>null</tt> is
     * never returned).
     *
     * @see #setTimeSource(TimeSource)
     * @see #getTime()
     */
    public static TimeSource getTimeSource() {
        synchronized ( TIME_SOURCE_LOCK ) {
            return currentTimeSource;
        }
    }

    /*
     * If it is currently 3:10pm on
     * now (includes time)
     * today (sets time to noon)
     * yesterday (sets time to noon)
     * tomorrow (sets time to noon)
     * today-14d (noon 14 days ago)
     * today-2w (noon 2 weeks ago)
     * today-3m (noon 3 months ago,
     *           handles 31->31,30,29,28 30->30,29,28 29->29,28 28->28)
     * today-2y (noon 2 years ago)
     */
    /*
    private static DateTime parseForText(String dateTimeStr, Helper h)
            throws DateTimeException {

        String text = dateTimeStr.toLowerCase();

        if ( text.startsWith("now") ) {

        }

        return null;
    }
    */

    /**
     * Attempts to interpret the string passed in as a {@link DateTime},
     * defaulting to the specified timezone <i>if necessary</i>.
     * This method assumes that the specified timezone should be used to
     * interpret the time if (and only if) no understandable timezone
     * information is present in the supplied <tt>String</tt>.
     * <p>
     * Ideal Format:
     * <pre>
     * yyyy-mm-dd hh:mm:ss.fff
     * yyyy/mm/dd hh:mm:ss.fff
     * yyyy.mm.dd hh:mm:ss.fff
     * </pre>
     * (or many subsets going to something less than milliseconds).
     * <p>
     * Also accepted is the format commonly used in the USA:
     * <pre>
     * mm-dd-yyyy hh:mm:ss.fff
     * mm/dd/yyyy hh:mm:ss.fff
     * mm.dd.yyyy hh:mm:ss.fff
     * </pre>
     * (or many subsets going to something less than milliseconds).
     * <p>
     * Examples of source strings and the date/time that they imply:
     * <table border="1" cellpadding="2" cellspacing="0">
     * <tr bgcolor="#ccffcc"><td><b>Source (<tt>String</tt>)</b></td>
     *   <td><b>Result (<tt>DateTime</tt>)</b></td>
     *   <td><b>Comments</b></td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14 15:20:45.101"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.101</tt></td>
     *   <td>Ideal format</td></tr>
     * <tr><td nowrap="nowrap"><tt>"20050214 152045101"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.101</tt></td>
     *   <td>No delimiters</td></tr>
     * <tr><td nowrap="nowrap"><tt>"20050214152045101"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.101</tt></td>
     *   <td>Not even a date to time separator</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14 15:20:45.10"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.100</tt></td>
     *   <td>Fractional seconds to hundredths, trailing zero assumed</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005021415204510"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.100</tt></td>
     *   <td>Fractional seconds to hundredths, trailing zero assumed</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14 15:20:45.1"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.100</tt></td>
     *   <td>Fractional seconds to tenths, trailing zeros assumed</td></tr>
     * <tr><td nowrap="nowrap"><tt>"200502141520451"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.100</tt></td>
     *   <td>Fractional seconds to tenths, trailing zeros assumed</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14 15:20:45.00"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.000</tt></td>
     *   <td>Fractional seconds to hundredths, trailing zero assumed</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14 15:20:45.0"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.000</tt></td>
     *   <td>Fractional seconds to tenths, trailing zeros assumed</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14 15:20:45"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.500</tt></td>
     *   <td>Defaults to middle of second (500 ms)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14 15:20"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:30.000</tt></td>
     *   <td>Defaults to middle of minute (30 sec)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14 15"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:30:00.000</tt></td>
     *   <td>Defaults to middle of hour (30 min)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 12:00:00.000</tt></td>
     *   <td>Defaults to middle of day (noon)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005/02/14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 12:00:00.000</tt></td>
     *   <td>Slash date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005.02.14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 12:00:00.000</tt></td>
     *   <td>Dot date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005#02#14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 12:00:00.000</tt></td>
     *   <td>Crazy date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"20050214"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 12:00:00.000</tt></td>
     *   <td>No date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005/5/6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06 12:00:00.000</tt></td>
     *   <td>Slash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-5-6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06 12:00:00.000</tt></td>
     *   <td>Dash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005.5.6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06 12:00:00.000</tt></td>
     *   <td>Dot with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005^5^6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06 12:00:00.000</tt></td>
     *   <td>Crazy with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02-14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14 12:00:00.000</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02/14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14 12:00:00.000</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02.14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14 12:00:00.000</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"0214"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14 12:00:00.000</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2.14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14 12:00:00.000</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"0405"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-04-05 12:00:00.000</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"4/5"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-04-05 12:00:00.000</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02-14-2005 15:20:45.101"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.101</tt></td>
     *   <td>MDY (USA) format</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02142005 152045101"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.101</tt></td>
     *   <td>MDY (USA) format, no delimiters</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02142005152045101"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 15:20:45.101</tt></td>
     *   <td>MDY (USA) format, no delimiters</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02/14/2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 12:00:00.000</tt></td>
     *   <td>MDY (USA) with slash date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02.14.2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 12:00:00.000</tt></td>
     *   <td>MDY (USA) with dot date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02142005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14 12:00:00.000</tt></td>
     *   <td>MDY (USA) with no delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"5/6/2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06 12:00:00.000</tt></td>
     *   <td>MDY (USA) with slash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"5-6-2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06 12:00:00.000</tt></td>
     *   <td>MDY (USA) with dash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"5.6.2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06 12:00:00.000</tt></td>
     *   <td>MDY (USA) with dot with single digits</td></tr>
     * </table>
     * <p>
     * NOTE: Currently no support for a timezone in the supplied string is
     * present. This will change in a future release.
     *
     * @param dateTimeStr source to parse
     * @param tz TimeZone to use as the default if necessary.
     * @return the resulting time
     * @exception DateTimeException if the specified string can not be
     * successfully interpreted as a point in time.
     * Note that <tt>DateTimeException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    public static DateTime parse(String dateTimeStr, TimeZone tz)
            throws DateTimeException {

        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(h.parse(dateTimeStr, tz));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> interpreted by parsing the supplied
     * <tt>String</tt>, defaulting to the VM's timezone <i>if necessary</i>.
     * See {@link #parse(String, TimeZone)} for full details on parsing.
     * This method assumes the local VM's timezone should be used to
     * interpret the time if (and only if) no understandable timezone
     * information is present in the supplied <tt>String</tt>.
     * The local timezone is where the the Java VM
     * is running&mdash;be careful when two Java VMs are communicating and
     * each is in a different timezone.
     */
    public static DateTime parseLocal(String dateTimeStr)
            throws DateTimeException {

        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(h.parseLocal(dateTimeStr));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> interpreted by parsing the supplied
     * <tt>String</tt>, defaulting to the UTC timezone <i>if necessary</i>.
     * See {@link #parse(String, TimeZone)} for full details on parsing.
     * This method assumes the UTC timezone should be used to
     * interpret the time if (and only if) no understandable timezone
     * information is present in the supplied <tt>String</tt>.
     */
    public static DateTime parseUTC(String dateTimeStr)
            throws DateTimeException {

        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(h.parseUTC(dateTimeStr));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Formats the specified <tt>DateTime</tt> for the specified timezone.
     */
    public static String format(DateTimeFormat dtf,
                                DateTime dateTime,
                                TimeZone tz) {

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.format(dtf, dateTime.getTime(), tz);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Formats the specified <tt>DateTime</tt> for the VM's timezone.
     */
    public static String formatLocal(DateTimeFormat dtf, DateTime dateTime) {
        Helper h = HELPER_POOL.checkOut();
        try {
            return h.formatLocal(dtf, dateTime.getTime());
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Formats the specified <tt>DateTime</tt> for the UTC timezone.
     */
    public static String formatUTC(DateTimeFormat dtf, DateTime dateTime) {
        Helper h = HELPER_POOL.checkOut();
        try {
            return h.formatUTC(dtf, dateTime.getTime());
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Formats the specified <tt>DateTime</tt> for the specified timezone
     * using the specified pattern.
     * <p>
     * <b>NOTE:</b> This method is significantly less efficient than
     * {@link #format(DateTimeFormat, DateTime, TimeZone)}, so use
     * this other <tt>format</tt> method whenever possible.
     * <p>
     * The <tt>formatPattern</tt> is as defined by {@link SimpleDateFormat}
     * (<tt>DateTimeException</tt> is thrown if this format string
     * is considered invalid by <tt>SimpleDateFormat</tt>).
     */
    public static String format(String formatPattern,
                                DateTime dateTime,
                                TimeZone tz)
            throws DateTimeException {


        Helper h = HELPER_POOL.checkOut();
        try {
            return h.format(formatPattern, dateTime.getTime(), tz);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Formats the specified <tt>DateTime</tt> for the VM's timezone
     * using the specified pattern.
     * <p>
     * <b>NOTE:</b> This method is significantly less efficient than
     * {@link #formatLocal(DateTimeFormat, DateTime)}, so use
     * this other <tt>format</tt> method whenever possible.
     * <p>
     * The <tt>formatPattern</tt> is as defined by {@link SimpleDateFormat}
     * (<tt>DateTimeException</tt> is thrown if this format string
     * is considered invalid by <tt>SimpleDateFormat</tt>).
     */
    public static String formatLocal(String formatPattern, DateTime dateTime)
            throws DateTimeException {

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.formatLocal(formatPattern, dateTime.getTime());
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Formats the specified <tt>DateTime</tt> for the UTC timezone
     * using the specified pattern.
     * <p>
     * <b>NOTE:</b> This method is significantly less efficient than
     * {@link #formatUTC(DateTimeFormat, DateTime)}, so use
     * this other <tt>format</tt> method whenever possible.
     * <p>
     * The <tt>formatPattern</tt> is as defined by {@link SimpleDateFormat}
     * (<tt>DateTimeException</tt> is thrown if this format string
     * is considered invalid by <tt>SimpleDateFormat</tt>).
     */
    public static String formatUTC(String formatPattern, DateTime dateTime)
            throws DateTimeException {

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.formatUTC(formatPattern, dateTime.getTime());
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Formats the specified <tt>DateTime</tt> for the specified timezone.
     * Format of result is: <tt>yyyy-mm-dd hh:mm:ss.fff</tt>
     */
    public static String format(DateTime dateTime, TimeZone tz) {
        return format(DateTimeFormat.YMD_HMSF_DASH, dateTime, tz);
    }

    /**
     * Formats the specified <tt>DateTime</tt> for the VM's timezone.
     * Format of result is: <tt>yyyy-mm-dd hh:mm:ss.fff</tt>
     */
    public static String formatLocal(DateTime dateTime) {
        return formatLocal(DateTimeFormat.YMD_HMSF_DASH, dateTime);
    }

     /**
      * Formats the specified <tt>DateTime</tt> for the UTC timezone.
      * Format of result is: <tt>yyyy-mm-dd hh:mm:ss.fff</tt>
      */
    public static String formatUTC(DateTime dateTime) {
        return formatUTC(DateTimeFormat.YMD_HMSF_DASH, dateTime);
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>now</i> (the current
     * moment in time) as reported by {@link #getTime()}. This result includes
     * year, month, day, hour, minute, second, millisecond detail.
     */
    public static DateTime getNow() {
        return new DateTime(getTime());
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>noon today</i>
     * in the specified timezone for the date/time reported
     * by {@link #getTime()}.
     * This result includes the year, month, and day
     * with the hour set to 12 and the minutes, seconds, and milliseconds
     * all set to zero.
     */
    public static DateTime getToday(TimeZone tz) {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(h.setTimeToNoon(getTime(), tz));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>noon today</i>
     * in the VM's timezone for the date/time reported by {@link #getTime()}.
     * This result includes the year, month, and day
     * with the hour set to 12 and the minutes, seconds, and milliseconds
     * all set to zero.
     */
    public static DateTime getTodayLocal() {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(h.setTimeToNoonLocal(getTime()));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>noon today</i>
     * in the UTC timezone for the date/time reported by {@link #getTime()}.
     * This result includes the year, month, and day
     * with the hour set to 12 and the minutes, seconds, and milliseconds
     * all set to zero.
     */
    public static DateTime getTodayUTC() {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(h.setTimeToNoonUTC(getTime()));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>noon yesterday</i>
     * in the specified timezone for the date/time reported
     * by {@link #getTime()}.
     * This result includes the year, month, and day
     * with the hour set to 12 and the minutes, seconds, and milliseconds
     * all set to zero.
     */
    public static DateTime getYesterday(TimeZone tz) {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(
                h.addFieldThenSetToNoon(getTime(), DAY_FIELD, -1, tz));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>noon yesterday</i>
     * in the VM's timezone for the date/time reported by {@link #getTime()}.
     * This result includes the year, month, and day
     * with the hour set to 12 and the minutes, seconds, and milliseconds
     * all set to zero.
     */
    public static DateTime getYesterdayLocal() {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(
                h.addFieldLocalThenSetToNoon(getTime(), DAY_FIELD, -1));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>noon yesterday</i>
     * in the UTC timezone for the date/time reported by {@link #getTime()}.
     * This result includes the year, month, and day
     * with the hour set to 12 and the minutes, seconds, and milliseconds
     * all set to zero.
     */
    public static DateTime getYesterdayUTC() {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(
                h.addFieldUTCThenSetToNoon(getTime(), DAY_FIELD, -1));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>noon tomorrow</i>
     * in the specified timezone for the date/time reported
     * by {@link #getTime()}.
     * This result includes the year, month, and day
     * with the hour set to 12 and the minutes, seconds, and milliseconds
     * all set to zero.
     */
    public static DateTime getTomorrow(TimeZone tz) {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(
                h.addFieldThenSetToNoon(getTime(), DAY_FIELD, 1, tz));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>noon tomorrow</i>
     * in the VM's timezone for the date/time reported by {@link #getTime()}.
     * This result includes the year, month, and day
     * with the hour set to 12 and the minutes, seconds, and milliseconds
     * all set to zero.
     */
    public static DateTime getTomorrowLocal() {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(
                h.addFieldLocalThenSetToNoon(getTime(), DAY_FIELD, 1));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a <tt>DateTime</tt> that represents <i>noon tomorrow</i>
     * in the UTC timezone for the date/time reported by {@link #getTime()}.
     * This result includes the year, month, and day
     * with the hour set to 12 and the minutes, seconds, and milliseconds
     * all set to zero.
     */
    public static DateTime getTomorrowUTC() {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(
                h.addFieldUTCThenSetToNoon(getTime(), DAY_FIELD, 1));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a new <tt>DateTime</tt> shifted by the specified
     * number of milliseconds.
     * A negative <tt>numberOfMilliseconds</tt> goes back in time, a
     * positive number goes forward in time.
     * Timezones, daylight saving time, leap years, and leap seconds
     * have no effect on the calculations done in this method.
     * See <a href="#TIME_INFO">time information</a> for explanations of
     * timezones, daylight saving time, leap years, leap seconds, and more.
     */
    public static DateTime addMilliseconds(DateTime startTime,
                                           int numberOfMilliseconds) {

        return new DateTime(startTime.getTime() + numberOfMilliseconds);
    }

    /**
     * Returns a new <tt>DateTime</tt> shifted by the specified
     * number of seconds.
     * A negative <tt>numberOfSeconds</tt> goes back in time, a
     * positive number goes forward in time.
     * This method always uses {@link #MS_PER_SECOND} (1000)
     * for the number of milliseconds in one second.
     * Timezones, daylight saving time, leap years, and leap seconds
     * have no effect on this method.
     * See <a href="#TIME_INFO">time information</a> for explanations of
     * timezones, daylight saving time, leap years, leap seconds, and more.
     */
    public static DateTime addSeconds(DateTime startTime, int numberOfSeconds) {
        return new DateTime(
            startTime.getTime() + (MS_PER_SECOND * numberOfSeconds));
    }

    /**
     * Returns a new <tt>DateTime</tt> shifted by the specified
     * number of minutes.
     * A negative <tt>numberOfMinutes</tt> goes back in time, a
     * positive number goes forward in time.
     * This method always uses {@link #MS_PER_MINUTE} (60,000)
     * for the number of milliseconds in one minute
     * (which is <i>not</i> correct for the rare minutes
     * that are not exactly 60 seconds long because of leap seconds).
     * Timezones, daylight saving time, leap years, and leap seconds
     * have no effect on this method.
     * See <a href="#TIME_INFO">time information</a> for explanations of
     * timezones, daylight saving time, leap years, leap seconds, and more.
     */
    public static DateTime addMinutes(DateTime startTime, int numberOfMinutes) {
        return new DateTime(
            startTime.getTime() + (MS_PER_MINUTE * numberOfMinutes));
    }

    /**
     * Returns a new <tt>DateTime</tt> shifted by the specified
     * number of hours.
     * A negative <tt>numberOfHours</tt> goes back in time, a
     * positive number goes forward in time.
     * This method always uses {@link #MS_PER_HOUR} (3,600,000)
     * for the number of milliseconds in one hour
     * (which is <i>not</i> correct for the rare hours
     * that are not exactly 3,600 seconds long because of leap seconds).
     * Timezones, daylight saving time, leap years, and leap seconds
     * have no effect on this method.
     * See <a href="#TIME_INFO">time information</a> for explanations of
     * timezones, daylight saving time, leap years, leap seconds, and more.
     */
    public static DateTime addHours(DateTime startTime, int numberOfHours) {
        return new DateTime(
            startTime.getTime() + (MS_PER_HOUR * numberOfHours));
    }

    public static DateTime addDays(DateTime startTime, int numberOfDays) {
        return new DateTime(startTime.getTime() + (MS_PER_DAY * numberOfDays));
    }

    public static DateTime addDays(DateTime startTime,
                                   int numberOfDays,
                                   TimeZone tz) {

        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(
                h.addField(startTime.getTime(), DAY_FIELD, numberOfDays, tz));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    public static DateTime addDaysLocal(DateTime startTime, int numberOfDays) {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(
                h.addFieldLocal(startTime.getTime(), DAY_FIELD, numberOfDays));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    public static DateTime addDaysUTC(DateTime startTime, int numberOfDays) {
        Helper h = HELPER_POOL.checkOut();
        try {
            return new DateTime(
                h.addFieldUTC(startTime.getTime(), DAY_FIELD, numberOfDays));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /*
    public static DateTime addWeeks(DateTime startTime, int numberOfWeeks) {
        return new DateTime(
            startTime.getTime() + (MS_PER_WEEK * numberOfWeeks));
    }

    public static DateTime addMonths(DateTime startTime,
                                     int numberOfMonths,
                                     TimeZone tz) {

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.addMonths(startTime.getTime(), numberOfMonths, tz);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    public static DateTime addMonthsLocal(DateTime startTime,
                                          int numberOfMonths) {

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.addMonthsLocal(startTime.getTime(), numberOfMonths);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    public static DateTime addMonthsUTC(DateTime startTime,
                                        int numberOfMonths) {

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.addMonthsUTC(startTime.getTime(), numberOfMonths);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }
    */

    /**
     * Returns <tt>true</tt> if the specified year, month, and day
     * are a valid combination on the Gregorian calendar.
     * <p>
     * <table border="1">
     * <tr align="center"><td colspan="3">Example Results</td></tr>
     * <tr align="center"><td nowrap="nowrap">(year, month, day)</td>
     *      <td>Valid?</td><td>Comment</td></tr>
     * <tr align="center"><td>(2006, 1, 1)</td><td>true</td><td></td></tr>
     * <tr align="center"><td>(2006, 1, 31)</td><td>true</td><td></td></tr>
     * <tr align="center"><td>(2006, 1, 32)</td><td>false</td>
     *      <td>There are only 31 days in January</td></tr>
     * <tr align="center"><td>(2006, 2, 1)</td><td>true</td><td></td></tr>
     * <tr align="center"><td>(2006, 2, 28)</td><td>true</td><td></td></tr>
     * <tr align="center"><td>(2006, 2, 29)</td><td>false</td>
     *      <td>Feb2006 is not a leap year</td></tr>
     * <tr align="center"><td>(2008, 2, 29)</td><td>true</td>
     *      <td>February 29 is fine for 2008 (leap year)</td></tr>
     * <tr align="center"><td>(2006, 4, 30)</td><td>true</td><td></td></tr>
     * <tr align="center"><td>(2006, 4, 31)</td><td>false</td>
     *      <td>Only 30 days in April</td></tr>
     * <tr align="center"><td>(1896, 2, 29)</td><td>true</td>
     *      <td>Leap year (divisible by 4)</td></tr>
     * <tr align="center"><td>(1900, 2, 29)</td><td>false</td>
     *      <td>Not a leap year (divisible by 100)</td></tr>
     * <tr align="center"><td>(1904, 2, 29)</td><td>true</td>
     *      <td>Leap year (divisible by 4)</td></tr>
     * <tr align="center"><td>(1996, 2, 29)</td><td>true</td>
     *      <td>Leap year (divisible by 4)</td></tr>
     * <tr align="center"><td>(2000, 2, 29)</td><td>true</td>
     *      <td>Leap year (divisible by 400)</td></tr>
     * <tr align="center"><td>(2004, 2, 29)</td><td>true</td>
     *      <td>Leap year (divisible by 4)</td></tr>
     * <tr align="center"><td>(2096 2, 29)</td><td>true</td>
     *      <td>Leap year (divisible by 4)</td></tr>
     * <tr align="center"><td>(2100, 2, 29)</td><td>false</td>
     *      <td>Not a leap year (divisible by 100)</td></tr>
     * <tr align="center"><td>(1582, 10, 4)</td><td>true</td>
     *      <td>Last day of Julian calendar (default switchover
     *      to the Gregorian calendar in Java) *</td></tr>
     * <tr align="center"><td>(1582, 10, 5)</td><td>false</td>
     *      <td>Oct 5-14 do not exist in 1582 on the Gregorian
     *      calendar *</td></tr>
     * <tr align="center"><td>(1582, 10, 14)</td><td>false</td>
     *      <td>Oct 5-14 do not exist in 1582 on the Gregorian
     *      calendar *</td></tr>
     * <tr align="center"><td>(1582, 10, 15)</td><td>true</td>
     *      <td>Beginning of the Gregorian calendar *</td></tr>
     * </table>
     * <p>
     * * Note that the default Gregorian switchover is October 1582
     * for Java. This setting may be changed VM-wide and would change
     * the results above. For example, a switchover to the
     * Gregorian calendar took place in many countries in
     * September 1752.
     *
     * @param year the four digit year, for example 2006.
     * @param month the month number, from the set [1..12].
     * @param day the day of the month, from the set [1..31].
     */
    public static boolean isValidDate(int year, int month, int day) {
        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.localCal;

            cal.clear();
            cal.set(year, month - 1, day, 12, 0, 0);

            int calcYear = cal.get(YEAR_FIELD);
            int calcMonth = 1 + cal.get(MONTH_FIELD);
            int calcDay = cal.get(DAY_FIELD);

            return year == calcYear && month == calcMonth && day == calcDay;
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns the last day of the specified <tt>month</tt> in
     * the specified <tt>year</tt>.
     *
     * @param year the four digit year, for example 2006.
     * @param month the month number, from the set [1..12].
     * @return the last day of the month, from the set [1..31].
     */
    public static int getLastDayOfMonth(int year, int month) {
        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.localCal;

            cal.clear();
            cal.set(year, month - 1, 1, 12, 0, 0);

            return cal.getActualMaximum(DAY_FIELD);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    public static DayOfWeek getDayOfWeek(int year, int month, int day) {
        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.localCal;

            cal.clear();
            cal.set(year, month - 1, day, 12, 0, 0);

            return DayOfWeek.convertFromCalendar(cal.get(DOW_FIELD));
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /*
    public static PlainDate getNext(PlainDate startDate, DayOfWeek dow) {
        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.localCal;

            cal.clear();
            cal.set(startDate.getYear(),
                    startDate.getMonth() - 1,
                    startDate.getDay(),
                    12, 0, 0);


        } finally {
            HELPER_POOL.checkIn(h);
        }
    }
     */

    /**
     * Adds the specified number of days to the specified <tt>startDate</tt>.
     * If the <tt>numberOfDays</tt> passed in is zero, then this method
     * quickly and efficiently returns <tt>startDate</tt> as the result.
     *
     * @param startDate the point to start from
     * @param numberOfDays the number of days to add (this can be a negative
     * number to go backwards in time).
     * @return a new <tt>PlainDate</tt>.
     * If the <tt>numberOfDays</tt> is zero,
     * then the original <tt>startDate</tt> is simply returned.
     */
    public static PlainDate addDays(PlainDate startDate, int numberOfDays) {
        if ( numberOfDays == 0 ) {
            return startDate;
        }

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.addField(
                startDate.getYear(), startDate.getMonth(), startDate.getDay(),
                DAY_FIELD, numberOfDays);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Adds the specified number of weeks to the specified <tt>startDate</tt>.
     * If the <tt>numberOfWeeks</tt> passed in is zero, then this method
     * quickly and efficiently returns <tt>startDate</tt> as the result.
     *
     * @param startDate the point to start from
     * @param numberOfWeeks the number of weeks to add (this can be a negative
     * number to go backwards in time).
     * @return a new <tt>PlainDate</tt>.
     * If the <tt>numberOfWeeks</tt> is zero,
     * then the original <tt>startDate</tt> is simply returned.
     */
    public static PlainDate addWeeks(PlainDate startDate, int numberOfWeeks) {
        if ( numberOfWeeks == 0 ) {
            return startDate;
        }

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.addField(
                startDate.getYear(), startDate.getMonth(), startDate.getDay(),
                DAY_FIELD, numberOfWeeks * 7);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Adds the specified number of months to the specified <tt>startDate</tt>.
     * If the <tt>numberOfMonths</tt> passed in is zero, then this method
     * quickly and efficiently returns <tt>startDate</tt> as the result.
     * The resulting can date might be a bit surprising as times when different
     * length months are involved (28, 29, 30, 31):
     * <table border="1">
     * <tr><td rowspan="2"><tt>startDate</tt></td>
     * <td align="center" colspan="4"><tt>numberOfMonths</tt></td></tr>
     * <tr align="center">
     *  <td><tt>-1</tt></td><td><tt>1</tt></td>
     *  <td><tt>2</tt></td><td><tt>3</tt></td></tr>
     * <tr><td>2006-01-15</td>
     *  <td>200<u>5</u>-12-15</td><td>2006-02-15</td>
     *  <td>2006-03-15</td><td>2006-04-15</td></tr>
     * <tr><td>2006-01-30</td>
     *  <td>2005-12-30</td><td>2006-02-<u>28</u></td>
     *  <td>2006-03-30</td><td>2006-04-30</td></tr>
     * <tr><td>2006-01-31</td>
     *  <td>2005-12-31</td><td>2006-02-<u>28</u></td>
     *  <td>2006-03-31</td><td>2006-04-<u>30</u></td></tr>
     * <tr><td>200<u>8</u>-01-31</td>
     *  <td>2007-12-31</td><td>2008-02-<u>29</u></td>
     *  <td>2008-03-31</td><td>2008-04-30</td></tr>
     * <tr><td>2006-02-28</td>
     *  <td>2006-01-28</td><td>2006-03-28</td>
     *  <td>2006-04-28</td><td>2006-05-28</td></tr>
     * <tr><td>2006-02-28</td>
     *  <td>2006-01-28</td><td>2006-03-28</td>
     *  <td>2006-04-28</td><td>2006-05-28</td></tr>
     * <tr><td>2006-03-31</td>
     *  <td>2006-02-28</td><td>2006-04-30</td>
     *  <td>2006-05-31</td><td>2006-06-30</td></tr>
     * </table>
     *
     * @param startDate the point to start from
     * @param numberOfMonths the number of months to add (this can be a negative
     * number to go backwards in time).
     * @return a new <tt>PlainDate</tt>.
     */
    public static PlainDate addMonths(PlainDate startDate, int numberOfMonths) {
        if ( numberOfMonths == 0 ) {
            return startDate;
        }

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.addField(
                startDate.getYear(), startDate.getMonth(), startDate.getDay(),
                MONTH_FIELD, numberOfMonths);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Adds the specified number of years to the specified <tt>startDate</tt>.
     * If the <tt>numberOfYears</tt> passed in is zero, then this method
     * quickly and efficiently returns <tt>startDate</tt> as the result.
     * The resulting can date might be a bit surprising as times when leap
     * years are involved:
     * <table border="1">
     * <tr><td rowspan="2"><tt>startDate</tt></td>
     * <td align="center" colspan="5"><tt>numberOfYears</tt></td></tr>
     * <tr align="center">
     *  <td><tt>-1</tt></td><td><tt>1</tt></td>
     *  <td><tt>2</tt></td><td><tt>3</tt></td><td><tt>4</tt></td></tr>
     * <tr><td>2006-01-15</td>
     *  <td>2005-01-15</td><td>2007-01-15</td>
     *  <td>2008-01-15</td><td>2009-01-15</td><td>2010-01-15</td></tr>
     * <tr><td>2006-02-28</td>
     *  <td>2005-02-28</td><td>2007-02-28</td>
     *  <td>2008-02-28</td><td>2009-02-28</td><td>2010-02-28</td></tr>
     * <tr><td>2008-02-29</td>
     *  <td>2007-02-28</td><td>2009-02-28</td>
     *  <td>2010-02-28</td><td>2011-02-28</td><td>2012-02-29</td></tr>
     * </table>
     *
     * @param startDate the point to start from
     * @param numberOfYears the number of years to add (this can be a negative
     * number to go backwards in time).
     * @return a new <tt>PlainDate</tt>.
     * If the <tt>numberOfYears</tt> is zero,
     * then the original <tt>startDate</tt> is simply returned.
     */
    public static PlainDate addYears(PlainDate startDate, int numberOfYears) {
        if ( numberOfYears == 0 ) {
            return startDate;
        }

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.addField(
                startDate.getYear(), startDate.getMonth(), startDate.getDay(),
                YEAR_FIELD, numberOfYears);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Adds days (as needed) to roll the specified <tt>startDate</tt>
     * forward until the specified <tt>targetDayOfWeek</tt> is matched.
     * The number of days added ranges from <tt>0</tt> up to a maximum
     * of <tt>6</tt>.
     * If the day of the week for the <tt>startDate</tt> is already
     * the specified target day of the week, then the <tt>startDate</tt>
     * is simply returned (no change).
     * <p>
     * To find the first Monday in September 2007 (the answer is 2007-09-03):
     * <pre class="preshade">
     * PlainDate firstMondayInSeptember =
     *     PlainDate.create("2007-09-01").addDaysUntil(DayOfWeek.MONDAY);
     * </pre>
     * <p>
     * To find the first Monday in October 2007 (the starting date 2007-10-01
     * is actually the answer [no days need to be added]):
     * <pre class="preshade">
     * PlainDate firstMondayInOctober =
     *     PlainDate.create("2007-10-01").addDaysUntil(DayOfWeek.MONDAY);
     * </pre>
     * <p>
     * To find the first Wednesday in a month that an arbitrary date belongs
     * to (in this case the month is June 2007, and we start from the 18th
     * and go back to the first and then forward&mdash;if necessary&mdash;to
     * find Wednesday. In this case, the answer is 2007-06-06):
     * <p>
     * <pre class="preshade">
     * PlainDate randomDayInJune = PlainDate.create("2007-06-18");
     * PlainDate firstWednesdayInJune =
     *     randomDayInJune.getFirstDayOfCurrentMonth().addDaysUntil(
     *         DayOfWeek.WEDNESDAY);
     * </pre>
     * <p>
     * The next example takes an arbitrary date (in this case 2007-05-08)
     * and locates all of the occurrences of a particular day of the
     * week (in this case Thursday) in that date's month (May 2007).
     * The resulting dates printed are the five Thursdays that occur
     * in May 2007: 2007-05-03, 2007-05-10, 2007-05-17,
     * 2007-05-24, and 2007-05-31.
     * <pre class="preshade">
     * PlainDate startDate = PlainDate.create("2007-05-08");
     * DayOfWeek targetDayOfWeek = DayOfWeek.THURSDAY;
     *
     * PlainDate currDate =
     *     startDate.getFirstDayOfCurrentMonth().addDaysUntil(
     *         targetDayOfWeek);
     *
     * while ( currDate.getMonth() == startDate.getMonth() ) {
     *     System.out.println("currDate=" + currDate);
     *     currDate = currDate.addDays(1).addDaysUntil(targetDayOfWeek);
     * }
     * </pre>
     *
     * @param startDate the point to start from
     * @param targetDayOfWeek the desired day of the week
     * @return a new <tt>PlainDate</tt> whose day of the week matches the
     * specified target day of the week.
     * If the <tt>startDate</tt>'s day of the week was already a match
     * for the target, then the original <tt>startDate</tt> is simply returned.
     *
     * @see #subtractDaysUntil(PlainDate, DayOfWeek)
     * @see PlainDate#addDaysUntil(DayOfWeek)
     */
    public static PlainDate addDaysUntil(PlainDate startDate,
                                         DayOfWeek targetDayOfWeek) {

        DayOfWeek startDayOfWeek = startDate.getDayOfWeek();
        int daysToAdd = startDayOfWeek.getDaysUntil(targetDayOfWeek);
        return addDays(startDate, daysToAdd);
    }

    /**
     * Subtracts days (as needed) to roll the specified <tt>startDate</tt>
     * backward until the specified <tt>targetDayOfWeek</tt> is matched.
     * The number of days subtracted ranges from <tt>0</tt> up to a maximum
     * of <tt>6</tt>.
     * If the day of the week for the <tt>startDate</tt> is already
     * the specified target day of the week, then the <tt>startDate</tt>
     * is simply returned (no change).
     * <p>
     * To find the last Friday in July 2007 (the answer is 2007-07-27):
     * <pre class="preshade">
     * PlainDate randomDayInJuly = PlainDate.create("2007-07-04");
     * PlainDate lastFridayInJuly =
     *     randomDayInJuly.getLastDayOfCurrentMonth().subtractDaysUntil(
     *         DayOfWeek.FRIDAY);
     * </pre>
     *
     * @param startDate the point to start from
     * @param targetDayOfWeek the desired day of the week
     * @return a new <tt>PlainDate</tt> whose day of the week matches the
     * specified target day of the week.
     * If the <tt>startDate</tt>'s day of the week was already a match
     * for the target, then the original <tt>startDate</tt> is simply returned.
     *
     * @see #addDaysUntil(PlainDate, DayOfWeek)
     * @see PlainDate#subtractDaysUntil(DayOfWeek)
     */
    public static PlainDate subtractDaysUntil(PlainDate startDate,
                                              DayOfWeek targetDayOfWeek) {

        DayOfWeek startDayOfWeek = startDate.getDayOfWeek();
        int daysToSubtract = targetDayOfWeek.getDaysUntil(startDayOfWeek);
        return addDays(startDate, -daysToSubtract);
    }

    /**
     * Returns the moment in time for noon on the specific
     * <tt>year</tt>, <tt>month</tt>, and <tt>day</tt> in the
     * specified timezone.
     *
     * @param year the four digit year, for example 2006.
     * @param month the month number, from the set [1..12].
     * @param day the day of the month, from the set [1..31].
     * @param tz the timezone to use to determine the moment.
     */
    public static DateTime getDateTime(int year,
                                       int month,
                                       int day,
                                       TimeZone tz) {

        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.cal;

            cal.clear();
            cal.setTimeZone(tz);
            cal.set(year, month - 1, day, 12, 0, 0);
            return new DateTime(cal.getTimeInMillis());
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns the moment in time for noon on the specific
     * <tt>year</tt>, <tt>month</tt>, and <tt>day</tt> in the
     * VM's local timezone.
     *
     * @param year the four digit year, for example 2006.
     * @param month the month number, from the set [1..12].
     * @param day the day of the month, from the set [1..31].
     */
    public static DateTime getDateTimeLocal(int year,
                                            int month,
                                            int day) {

        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.localCal;

            cal.clear();
            cal.set(year, month - 1, day, 12, 0, 0);
            return new DateTime(cal.getTimeInMillis());
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns the moment in time for noon on the specific
     * <tt>year</tt>, <tt>month</tt>, and <tt>day</tt> in the
     * UTC timezone.
     *
     * @param year the four digit year, for example 2006.
     * @param month the month number, from the set [1..12].
     * @param day the day of the month, from the set [1..31].
     */
    public static DateTime getDateTimeUTC(int year,
                                          int month,
                                          int day) {

        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.utcCal;

            cal.clear();
            cal.set(year, month - 1, day, 12, 0, 0);
            return new DateTime(cal.getTimeInMillis());
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns the specified moment in time as a {@link PlainDate}
     * interpreted in the specified timezone.
     *
     * @param dateTime the moment in time used to determine the year/month/day.
     * @param tz the timezone to use to determine the year/month/day.
     */
    public static PlainDate getPlainDate(DateTime dateTime, TimeZone tz) {
        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.cal;

            cal.clear();
            cal.setTimeZone(tz);
            cal.setTimeInMillis(dateTime.getTime());

            int calcYear = cal.get(YEAR_FIELD);
            int calcMonth = 1 + cal.get(MONTH_FIELD);
            int calcDay = cal.get(DAY_FIELD);

            return PlainDate.create(calcYear, calcMonth, calcDay);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns the specified moment in time as a {@link PlainDate}
     * interpreted in the local VM timezone.
     *
     * @param dateTime the moment in time used to determine the year/month/day.
     */
    public static PlainDate getPlainDateLocal(DateTime dateTime) {
        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.localCal;

            cal.clear();
            cal.setTimeInMillis(dateTime.getTime());

            int calcYear = cal.get(YEAR_FIELD);
            int calcMonth = 1 + cal.get(MONTH_FIELD);
            int calcDay = cal.get(DAY_FIELD);

            return PlainDate.create(calcYear, calcMonth, calcDay);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns the specified moment in time as a {@link PlainDate}
     * interpreted in the UTC timezone.
     *
     * @param dateTime the moment in time used to determine the year/month/day.
     */
    public static PlainDate getPlainDateUTC(DateTime dateTime) {
        Helper h = HELPER_POOL.checkOut();
        try {
            GregorianCalendar cal = h.utcCal;

            cal.clear();
            cal.setTimeInMillis(dateTime.getTime());

            int calcYear = cal.get(YEAR_FIELD);
            int calcMonth = 1 + cal.get(MONTH_FIELD);
            int calcDay = cal.get(DAY_FIELD);

            return PlainDate.create(calcYear, calcMonth, calcDay);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Attempts to interpret the string passed in as a {@link PlainDate}.
     * <p>
     * Ideal Format:
     * <pre>
     * yyyy-mm-dd
     * yyyy/mm/dd
     * yyyy.mm.dd
     * yyyymmdd
     * </pre>
     * <p>
     * Also accepted is the format commonly used in the USA:
     * <pre>
     * mm-dd-yyyy
     * mm/dd/yyyy
     * mm.dd.yyyy
     * mmddyyyy
     * </pre>
     * <p>
     * Examples of source strings and the date that they imply:
     * <table border="1" cellpadding="2" cellspacing="0">
     * <tr bgcolor="#ccffcc"><td><b>Source (<tt>String</tt>)</b></td>
     *   <td><b>Result (<tt>PlainDate</tt>)</b></td>
     *   <td><b>Comments</b></td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>Ideal format</td></tr>
     * <tr><td nowrap="nowrap"><tt>"20050214"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>No delimiters</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005/02/14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>Slash date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005.02.14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>Dot date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005#02#14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>Crazy date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005/5/6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>Slash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-5-6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>Dash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005.5.6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>Dot with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005^5^6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>Crazy with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02-14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02/14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02.14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"0214"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2.14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"0405"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-04-05</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"4/5"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-04-05</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02-14-2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>MDY (USA) format</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02142005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>MDY (USA) format, no delimiters</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02/14/2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>MDY (USA) with slash date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02.14.2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>MDY (USA) with dot date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"5/6/2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>MDY (USA) with slash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"5-6-2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>MDY (USA) with dash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"5.6.2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>MDY (USA) with dot with single digits</td></tr>
     * </table>
     * <p>
     *
     * @param dateStr source to parse
     * @return the resulting date
     * @exception PlainDateException if the specified string can not be
     * successfully interpreted as date.
     * Note that <tt>PlainDateException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    public static PlainDate parsePlainDate(String dateStr)
            throws PlainDateException {

        Helper h = HELPER_POOL.checkOut();
        try {
            return h.parsePlainDate(dateStr);
        } finally {
            HELPER_POOL.checkIn(h);
        }
    }

    /**
     * Returns a {@link PlainDate} parsed from the specified <tt>dateStr</tt>
     * or <tt>null</tt> if <tt>dateStr</tt> is empty. That is, if
     * {@link StringTools#isEmpty(String)} deems <tt>dateStr</tt> to be
     * empty (null, zero-length string, or all whitespace), then
     * <tt>null</tt> is returned. If <tt>dateStr</tt> is not "empty" then
     * the parsing proceeds just as defined by {@link #parsePlainDate(String)}.
     *
     * @param dateStr the date to parse. It is OK to pass in <tt>null</tt>
     * or an empty <tt>String</tt> in.
     * @return the parsed date, or <tt>null</tt> if the passed <tt>String</tt>
     * is "empty".
     * @throws PlainDateException if the passed <tt>dateStr</tt> is <i>not</i>
     * empty and does evaluate to a valid date.
     */
    public static PlainDate parsePlainDateIgnoreEmpty(String dateStr)
            throws PlainDateException {

        return (StringTools.isEmpty(dateStr)) ? null : parsePlainDate(dateStr);
    }
    
    /**
     * Calculated the number of days from the <tt>startTime</tt> to the
     * <tt>endTime</tt>. 
     * The number returned is a <tt>double</tt> to account for 
     * fractional parts of a day.
     * The answer is a positive number if the endTime comes after the 
     * startTime.
     * The answer is a negative number if the endTime comes before
     * the startTime. 
     * The calculation uses {@link #MS_PER_DAY} and therefore assumes
     * that every day contains the same number of hours (look at
     * {@link #MS_PER_DAY} for details on the impact of daylight saving
     * time and all the other pesky).
     * 
     * @param startTime the time to subtract (subtrahend).
     * @param endTime the time to subtract from (minuend).
     * @return the number of days from startTime to endTime in fractional
     * days. If either the startTime or the endTime (or both) is null, then 
     * {@link Double#POSITIVE_INFINITY} is returned.
     */
    public static double calculateDayDifference(DateTime startTime, 
                                                DateTime endTime) {
        
        if ( startTime == null || endTime == null ) {
            return Double.POSITIVE_INFINITY;
        }
        
        double msDiff = endTime.getTime() - startTime.getTime();
        return msDiff / (double) MS_PER_DAY;
    }


    private static class DateParser {
        public static final int NO_INT_AVAILABLE = Integer.MIN_VALUE;

        private static final int DATE_SECTION = 1;
        private static final int TIME_SECTION = 2;
        private static final int TZ_SECTION = 3;

        private String srcStr;
        private char[] src;
        private int srcPtr;
        private int section;

        public DateParser() {
        }

        public void setSource(String source) {
            srcStr = source;
            src = source.toCharArray();
            srcPtr = 0;
            section = DATE_SECTION;
        }

        public void setSection(int nextSection) {
            switch ( nextSection ) {
                case DATE_SECTION:
                case TIME_SECTION:
                case TZ_SECTION:
                    section = nextSection;
                    break;

                default:
                    throw new IllegalArgumentException(
                        "Invalid section=" + nextSection);
            }
        }

        // maxDigits is the greatest number of digits that should be considered
        public int getNextIntInSection(int maxDigits) {
            if ( maxDigits < 1 ) {
                return NO_INT_AVAILABLE;
            }

            // Scan forward to position on the next digit char without going
            // into the 'time' section --unless is it currently ok to go into
            // the time section (or the time section is not delimited by T, t,
            // or space.
            if ( positionOnNextDigitInSection() == false ) {
                // there are no more digits in this section or we're at the end
                return NO_INT_AVAILABLE;
            }

            int val = 0;
            for ( int i = 0; (i < maxDigits) && isDigit(); i++, srcPtr++ ) {
                val = (val * 10) + (src[srcPtr] - '0');
            }

            return val;
        }

        public int getMilliseconds() throws DateTimeException {
            if ( section != TIME_SECTION ) {
                throw new DateTimeException("Not able to read milliseconds " +
                    "portion when not in the 'time section'");
            }

            // Scan forward to position on the next digit char without going
            // into the timezone section --unless is it currently ok to go into
            // the timezone section.
            if ( positionOnNextDigitInSection() == false ) {
                // there are no more digits in this section or we're at the end
                return NO_INT_AVAILABLE;
            }

            int val = 0;
            int digitCount = 0;
            while ( (digitCount < 3) && isDigit() ) {
                digitCount++;
                val = (val * 10) + (src[srcPtr] - '0');
                srcPtr++;
            }

            if ( digitCount == 3 ) {
                return val;
            } else if ( digitCount == 2 ) {
                return val * 10; // only went to hundredths, convert to millis
            } else if ( digitCount == 1 ) {
                return val * 100; // only went to tenths, convert to millis
            } else {
                return 0; // no fractions seconds digits available
            }
        }

        public int getRequiredNextIntInSection(int maxDigits)
                throws DateTimeException {

            int val = getNextIntInSection(maxDigits);

            if ( val == NO_INT_AVAILABLE ) {
                DateTimeException.throwParse(srcStr);
            }

            return val;
        }

        public boolean notAtEnd() {
            return srcPtr < src.length;
        }

        public boolean isDigit() {
            return notAtEnd() && '0' <= src[srcPtr] && src[srcPtr] <= '9';
        }

        public boolean isNotDigit() {
            return !isDigit();
        }

        // returns true if current char is one of { T, t, SP }
        public boolean isDateTimeDelimiter() {
            return notAtEnd() && (src[srcPtr] == 'T' ||
                                  src[srcPtr] == 't' ||
                                  src[srcPtr] == ' ');
        }

        public boolean isNotDateTimeDelimiter() {
            return !isDateTimeDelimiter();
        }

        // returns true if current char is one of { Z, z, +, - }
        public boolean isTimeTZDelimiter() {
            return notAtEnd() && (src[srcPtr] == 'Z' ||
                                  src[srcPtr] == 'z' ||
                                  src[srcPtr] == '+' ||
                                  src[srcPtr] == '-');
        }

        public boolean isNotTimeTZDelimiter() {
            return !isTimeTZDelimiter();
        }

        public boolean positionOnNextDigitInSection() {
            switch ( section ) {
                case DATE_SECTION:
                    while ( notAtEnd() &&
                            isNotDigit() && isNotDateTimeDelimiter() ) {

                        srcPtr++;
                    }
                    break;

                case TIME_SECTION:
                    while ( notAtEnd() &&
                            isNotDigit() && isNotTimeTZDelimiter() ) {

                        srcPtr++;
                    }
                    break;

                case TZ_SECTION:
                    throw new RuntimeException("TZ not supported yet.");
                    // break;

                default:
                    throw new RuntimeException(
                        "ERROR: unknown section: " + section);
            }

            return isDigit();
        }
    } // class DateParser

    private static class HelperPool {
        private Helper[] helperList;
        private int head;
        private int tail;
        private int size;

        public HelperPool(int count) {
            helperList = new Helper[count];
            head = 0;
            tail = 0;
            size = 0;

            for ( int i = 0; i < count; i++ ) {
                checkIn(new Helper());
            }
        }

        public synchronized Helper checkOut() throws DateTimeException {
            try {
                while ( size < 1 ) {
                    wait();
                }

                Helper helper = helperList[head];
                helperList[head] = null;
                head = (head + 1) % helperList.length;
                size--;

                return helper;
            } catch ( InterruptedException x ) {
                Thread.currentThread().interrupt();
                throw new DateTimeException(x);
            }
        }

        public synchronized void checkIn(Helper helper) {
            // it can 'never' be 'full'--there is just a fixed-size set of them

            if ( helper == null ) {
                return;  // just to be silently tolerant of a null checkin
            }

            helperList[tail] = helper;
            tail = (tail + 1) % helperList.length;
            size++;
            notifyAll();
        }

    } // class HelperPool

    private static class Helper {
        private int year;
        private int month;
        private int day;
        private int hour;
        private int minute;
        private int second;
        private int millisecond;

        private final TimeZone localTimeZone;
        private final TimeZone utcTimeZone;

        private final GregorianCalendar cal;
        private final GregorianCalendar localCal;
        private final GregorianCalendar utcCal;

        private final DateParser parser;

        private final SimpleDateFormat dateFormat;
        private final SimpleDateFormat localDateFormat;
        private final SimpleDateFormat utcDateFormat;

        private String localDateFormatLastPattern;
        private String utcDateFormatLastPattern;

        public Helper() {
            localTimeZone = TimeZone.getDefault();
            utcTimeZone = TimeZone.getTimeZone("UTC");

            cal = new GregorianCalendar(utcTimeZone, Locale.US);
            cal.setLenient(true);

            localCal = new GregorianCalendar(localTimeZone, Locale.US);
            localCal.setLenient(true);

            utcCal = new GregorianCalendar(utcTimeZone, Locale.US);
            utcCal.setLenient(true);

            parser = new DateParser();

            String pattern = "yyyy-MM-dd HH:mm:ss.SSS";
            dateFormat = new SimpleDateFormat(pattern, Locale.US);
            dateFormat.setTimeZone(utcTimeZone);

            localDateFormat = new SimpleDateFormat(pattern, Locale.US);
            localDateFormat.setTimeZone(localTimeZone);
            localDateFormat.applyPattern(pattern);
            localDateFormatLastPattern = pattern;

            utcDateFormat = new SimpleDateFormat(pattern, Locale.US);
            utcDateFormat.setTimeZone(utcTimeZone);
            utcDateFormat.applyPattern(pattern);
            utcDateFormatLastPattern = pattern;
        }

        private void clearTimeParts() {
            year = 0;
            month = 0;
            day = 0;
            hour = 0;
            minute = 0;
            second = 0;
            millisecond = 0;
        }

//        public void clear() {
//            year = 0;
//            month = 0;
//            day = 0;
//            hour = 0;
//            minute = 0;
//            second = 0;
//            millisecond = 0;
////            defaultTimeZone = null;
//
//            //cal.clear();
//        }

//        public void setDefaultTimeZone(TimeZone tz) {
//            this.defaultTimeZone = tz;
//        }
//
//        public void setDefaultTimeZoneLocal() {
//            setDefaultTimeZone(localTimeZone);
//        }
//
//        public void setDefaultTimeZoneUTC() {
//            setDefaultTimeZone(utcTimeZone);
//        }

        private void parse(String dateTimeStr) throws DateTimeException {
            // TODO - add timezone support to override "local"
            // TODO - add support for words like 'today-12d'

            String trimmedDateTimeStr = StringTools.trim(dateTimeStr);
            if ( trimmedDateTimeStr.length() == 0 ) {
                DateTimeException.throwParse(dateTimeStr);
            }

            clearTimeParts();

            // Look for: now, today, yesterday, tomorrow
            switch ( trimmedDateTimeStr.charAt(0) ) {
                case 'n':
                case 'N':
                case 't':
                case 'T':
                case 'y':
                case 'Y':
                      // FIXME - make this parsing do something here!
//                    DateTime textResult = parseForText(trimmedDateTimeStr, h);
//                    if ( textResult != null ) {
//                        return textResult;
//                    } else {
//                        break;
//                    }

                default:
                    break;
            }

            parser.setSource(trimmedDateTimeStr);

            // Note: Anytime a year must be assumed, there is no attempt
            // to parse the time and hour is set to noon and the result
            // is returned.

            // Throws an exception if an int is not available:
            int firstVal = parser.getRequiredNextIntInSection(4);

            if ( 1 <= firstVal && firstVal <= 12 ) {
                // Because using 2-digit years is evil, assume that we've got a
                // delimited MM-DD coming, possibly with a year, or possibly
                // wanting a default year to be assumed.
                month = firstVal;

                // Throws an exception if another int is not available:
                day = parser.getRequiredNextIntInSection(2);

                year = parser.getNextIntInSection(4);
                if ( year == DateParser.NO_INT_AVAILABLE ) {
                    // no year supplied, assume current year
                    cal.setTimeInMillis(getTime());
                    year = cal.get(YEAR_FIELD);
                    hour = 12; // assume noon on that day
                    return;
                }
            } else {
                // The first int is either a 4-digit year, or an un-delimited
                // MMDD for the first 4 digits.
                if ( firstVal <= 1231 ) {
                    // it is presumed to be MMDD
                    month = firstVal / 100;
                    day = firstVal % 100;

                    year = parser.getNextIntInSection(4);
                    if ( year == DateParser.NO_INT_AVAILABLE ) {
                        // no year supplied, assume current year
                        cal.setTimeInMillis(getTime());
                        year = cal.get(YEAR_FIELD);
                        hour = 12; // assume noon on that day
                        return;
                    }
                } else {
                    // it is a 4-digit year
                    year = firstVal;

                    // Throws an exception if another int is not available:
                    month = parser.getRequiredNextIntInSection(2);
                    day = parser.getRequiredNextIntInSection(2);
                }
            }

            // year, month, and day have been read and there might be time info
            parser.setSection(DateParser.TIME_SECTION);

            // If this exists, it should be the hour
            hour = parser.getNextIntInSection(2);
            if ( hour == DateParser.NO_INT_AVAILABLE ) {
                hour = 12; // assume noon on that day
                return;
            }

            // If this exists, it should be the minute
            minute = parser.getNextIntInSection(2);
            if ( minute == DateParser.NO_INT_AVAILABLE ) {
                minute = 30; // assume the middle of that hour
                return;
            }

            // If this exists, it should be the second
            second = parser.getNextIntInSection(2);
            if ( second == DateParser.NO_INT_AVAILABLE ) {
                second = 30; // assume the middle of that minute
                return;
            }

            // If this exists, it should be the millisecond
            millisecond = parser.getMilliseconds();
            if ( millisecond == DateParser.NO_INT_AVAILABLE ) {
                millisecond = 500; // assume the middle of that second
                return;
            }
        }

        public PlainDate parsePlainDate(String dateStr)
                throws PlainDateException {

            try {
                // TODO - add support for words like 'today-12d'

                String trimmedDateTimeStr = StringTools.trim(dateStr);
                if ( trimmedDateTimeStr.length() == 0 ) {
                    PlainDateException.throwParse(dateStr);
                }

                clearTimeParts();

                parser.setSource(trimmedDateTimeStr);

                // Throws an exception if an int is not available:
                int firstVal = parser.getRequiredNextIntInSection(4);

                if ( 1 <= firstVal && firstVal <= 12 ) {
                    // Because using 2-digit years is evil, assume that we've
                    // got a delimited MM-DD coming, possibly with a year,
                    // or possibly wanting a default year to be assumed.
                    month = firstVal;

                    // Throws an exception if another int is not available:
                    day = parser.getRequiredNextIntInSection(2);

                    year = parser.getNextIntInSection(4);
                    if ( year == DateParser.NO_INT_AVAILABLE ) {
                        // no year supplied, assume current year
                        cal.setTimeInMillis(getTime());
                        year = cal.get(YEAR_FIELD);
                    }
                } else {
                    // The first int is either a 4-digit year, or an
                    // un-delimited MMDD for the first 4 digits.
                    if ( firstVal <= 1231 ) {
                        // it is presumed to be MMDD
                        month = firstVal / 100;
                        day = firstVal % 100;

                        year = parser.getNextIntInSection(4);
                        if ( year == DateParser.NO_INT_AVAILABLE ) {
                            // no year supplied, assume current year
                            cal.setTimeInMillis(getTime());
                            year = cal.get(YEAR_FIELD);
                        }
                    } else {
                        // it is a 4-digit year
                        year = firstVal;

                        // Throws an exception if another int is not available:
                        month = parser.getRequiredNextIntInSection(2);
                        day = parser.getRequiredNextIntInSection(2);
                    }
                }

                return PlainDate.create(year, month, day);
            } catch ( DateTimeException x ) {
                throw PlainDateException.createParse(dateStr);
            }
        }

        private long calcTimeFromFields(TimeZone tz) {
            cal.clear();
            cal.setTimeZone(tz);
            cal.set(year, month - 1, day, hour, minute, second);
            cal.set(MILLISECOND_FIELD, millisecond);
            return cal.getTimeInMillis();
        }

        private long calcTimeFromFieldsLocal() {
            localCal.clear();
            localCal.set(year, month - 1, day, hour, minute, second);
            localCal.set(MILLISECOND_FIELD, millisecond);
            return localCal.getTimeInMillis();
        }

        private long calcTimeFromFieldsUTC() {
            utcCal.clear();
            utcCal.set(year, month - 1, day, hour, minute, second);
            utcCal.set(MILLISECOND_FIELD, millisecond);
            return utcCal.getTimeInMillis();
        }

        public long parse(String dateStr, TimeZone tz)
                throws DateTimeException {

            parse(dateStr);
            return calcTimeFromFields(tz);
        }

        public long parseLocal(String dateStr) throws DateTimeException {
            parse(dateStr);
            return calcTimeFromFieldsLocal();
        }

        public long parseUTC(String dateStr) throws DateTimeException {
            parse(dateStr);
            return calcTimeFromFieldsUTC();
        }

        public String format(DateTimeFormat dtf, long time, TimeZone tz) {
            cal.clear();
            cal.setTimeZone(tz);
            cal.setTimeInMillis(time);
            return dtf.format(cal);
        }

        public String formatLocal(DateTimeFormat dtf, long time) {
            localCal.clear();
            localCal.setTimeInMillis(time);
            return dtf.format(localCal);
        }

        public String formatUTC(DateTimeFormat dtf, long time) {
            utcCal.clear();
            utcCal.setTimeInMillis(time);
            return dtf.format(utcCal);
        }

        public String format(String formatPattern, long time, TimeZone tz)
                throws DateTimeException {

            try {
                dateFormat.setTimeZone(tz);
                dateFormat.applyPattern(formatPattern);
                return dateFormat.format(new Date(time));
            } catch ( IllegalArgumentException x ) {
                throw new DateTimeException(x);
            }
        }

        public String formatLocal(String formatPattern, long time)
                throws DateTimeException {

            try {
                // Check to see if this is different than what was used the
                // last time as applyPattern is not cheap to call.
                if ( ObjectTools.isDifferent(formatPattern,
                                             localDateFormatLastPattern) ) {

                    localDateFormat.applyPattern(formatPattern);
                    localDateFormatLastPattern = formatPattern;
                }

                return localDateFormat.format(new Date(time));
            } catch ( IllegalArgumentException x ) {
                throw new DateTimeException(x);
            }
        }

        public String formatUTC(String formatPattern, long time)
                throws DateTimeException {

            try {
                // Check to see if this is different than what was used the
                // last time as applyPattern is not cheap to call.
                if ( ObjectTools.isDifferent(formatPattern,
                                             utcDateFormatLastPattern) ) {

                    utcDateFormat.applyPattern(formatPattern);
                    utcDateFormatLastPattern = formatPattern;
                }

                return utcDateFormat.format(new Date(time));
            } catch ( IllegalArgumentException x ) {
                throw new DateTimeException(x);
            }
        }

        public PlainDate addField(int startYear,
                                  int startMonth,
                                  int startDay,
                                  int field,
                                  int fieldOffset) {

            utcCal.clear();
            utcCal.set(startYear, startMonth - 1, startDay, 12, 0, 0);
            utcCal.add(field, fieldOffset);

            int calcYear = utcCal.get(YEAR_FIELD);
            int calcMonth = 1 + utcCal.get(MONTH_FIELD);
            int calcDay = utcCal.get(DAY_FIELD);

            return PlainDate.create(calcYear, calcMonth, calcDay);
        }

        public long addField(long time,
                             int field,
                             int fieldOffset,
                             TimeZone tz) {

            cal.clear();
            cal.setTimeZone(tz);
            cal.setTimeInMillis(time);
            cal.add(field, fieldOffset);
            return cal.getTimeInMillis();
        }

        public long addFieldLocal(long time, int field, int fieldOffset) {
            localCal.clear();
            localCal.setTimeInMillis(time);
            localCal.add(field, fieldOffset);
            return localCal.getTimeInMillis();
        }

        public long addFieldUTC(long time, int field, int fieldOffset) {
            utcCal.clear();
            utcCal.setTimeInMillis(time);
            utcCal.add(field, fieldOffset);
            return utcCal.getTimeInMillis();
        }

        public long addFieldThenSetToNoon(long time,
                                          int field,
                                          int fieldOffset,
                                          TimeZone tz) {

            cal.clear();
            cal.setTimeZone(tz);
            cal.setTimeInMillis(time);
            cal.add(field, fieldOffset);
            setTimeToNoon(cal);
            return cal.getTimeInMillis();
        }

        public long addFieldLocalThenSetToNoon(long time,
                                               int field,
                                               int fieldOffset) {

            localCal.clear();
            localCal.setTimeInMillis(time);
            localCal.add(field, fieldOffset);
            setTimeToNoon(localCal);
            return localCal.getTimeInMillis();
        }

        public long addFieldUTCThenSetToNoon(long time,
                                             int field,
                                             int fieldOffset) {

            utcCal.clear();
            utcCal.setTimeInMillis(time);
            utcCal.add(field, fieldOffset);
            setTimeToNoon(utcCal);
            return utcCal.getTimeInMillis();
        }

        public void setTimeToNoon(GregorianCalendar gc) {
            gc.set(HOUR_FIELD, 12);
            gc.set(MINUTE_FIELD, 0);
            gc.set(SECOND_FIELD, 0);
            gc.set(MILLISECOND_FIELD, 0);
        }

        public long setTimeToNoon(long time, TimeZone tz) {
            cal.clear();
            cal.setTimeZone(tz);
            cal.setTimeInMillis(time);
            setTimeToNoon(cal);
            return cal.getTimeInMillis();
        }

        public long setTimeToNoonLocal(long time) {
            localCal.clear();
            localCal.setTimeInMillis(time);
            setTimeToNoon(localCal);
            return localCal.getTimeInMillis();
        }

        public long setTimeToNoonUTC(long time) {
            utcCal.clear();
            utcCal.setTimeInMillis(time);
            setTimeToNoon(utcCal);
            return utcCal.getTimeInMillis();
        }
    } // class Helper


    /**
     * Used to specify the source to use for milliseconds since Jan 1, 1970.
     * Some implementations may choose to <i><b>not</b></i> use
     * {@link System#currentTimeMillis()} as the source! For an implementation
     * of this that simply calls {@link System#currentTimeMillis()}, see
     * {@link DateTools#DEFAULT_TIME_SOURCE}.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static interface TimeSource {
        /**
         * Returns the number of milliseconds since 1970-01-01.
         * Some implementations may choose to <i><b>not</b></i> use
         * {@link System#currentTimeMillis()} as the source! This flexibility
         * allows a VM-wide offset or time acceleration to be implemented.
         * Keep in mind that if time is accelerated,
         * {@link Object#wait(long) wait(long msTimeout)} and
         * {@link Thread#sleep(long) Thread.sleep(long msDuration)}
         * times requested throughout the VM will likely last too long.
         */
        long getTime();
    } // interface TimeSource

    private static class DefaultTimeSource implements TimeSource {
        /**
         * This implementation always returns the <tt>long</tt> returned
         * from {@link System#currentTimeMillis()}.
         */
        public final long getTime() {
            return System.currentTimeMillis();
        }
    } // class DefaultTimeSource

    /**
     * Used to speed forward from 'now' to a specified time in the future.
     * After the speeding gets to the end time, the pace of time returns
     * to normal.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class AcceleratedTimeSource implements TimeSource {
        private double speedFactor;

        private long realStartTime;
        private long realEndTime;
        private long realEndToPretendEndTimeGap;

        public AcceleratedTimeSource(double speedFactor, long pretendEndTime) {
            if ( speedFactor <= 1.0 ) {
                throw new IllegalArgumentException(
                    "speed factor must be > 1.0");
            }

            this.speedFactor = speedFactor;

            realStartTime = System.currentTimeMillis();
            realEndTime = realStartTime +
                Math.round((pretendEndTime - realStartTime) / speedFactor);

            realEndToPretendEndTimeGap = pretendEndTime - realEndTime;
        }

        public long getTime() {
            long realCurrentTime = System.currentTimeMillis();

            if ( realCurrentTime < realEndTime ) {
                long realElapsedTime = realCurrentTime - realStartTime ;
                return realStartTime +
                        Math.round(realElapsedTime * speedFactor);
            } else {
                return realCurrentTime + realEndToPretendEndTimeGap;
            }
        }
    } // class AcceleratedTimeSource

    /**
     * Used to specify an offset (positive or negative) from 'now'
     * that should be used for the {@link TimeSource}.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class OffsetTimeSource implements TimeSource {
        private long offset;

        /**
         * Create an offset to apply to the real current time.
         *
         * @param offset the number of milliseconds to offset the real time
         * by to create the simulated time. A positive number is an offset
         * into the future; a negative is an offset into the past.
         */
        public OffsetTimeSource(long offset) {
            this.offset = offset;
        }

        /**
         * Create an offset to apply to the real current time.
         * The {@link DateTime} passed is the starting time to jump
         * to as soon as this {@link TimeSource} takes effect.
         *
         * @param startDate the date to use to calculate the offset from
         * now.
         */
        public OffsetTimeSource(DateTime startDate) {
            this(startDate.getTime() - System.currentTimeMillis());
        }

        public long getTime() {
            return System.currentTimeMillis() + offset;
        }
    } // class OffsetTimeSource
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.