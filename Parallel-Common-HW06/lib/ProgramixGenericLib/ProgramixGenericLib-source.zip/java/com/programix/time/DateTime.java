package com.programix.time;

import java.io.*;
import java.util.*;

import com.programix.util.*;

/**
 * Immutable encapsulation of a date and time as the number of
 * milliseconds that has elapsed since January 1, 1970 00:00:00.000 in
 * the UTC timezone. Although similar to {@link java.util.Date
 * java.util.Date}, instances of this class are immutable.
 * <p>
 * {@link DateTools} has handy utilities for formatting and parsing
 * <tt>DateTime</tt> instances to and from more human-readable <tt>String</tt>s.
 * <p>
 * <a id="PLAINDATE_V_DATETIME" name="PLAINDATE_V_DATETIME"
 * ><b><u><tt>PlainDate</tt> v. <tt>DateTime</tt></u></b></a><br />
 * The {@link DateTime} class has some of the same uses as a {@link PlainDate}
 * but <tt>DateTime</tt> represents a moment in time as the number of
 * milliseconds since January 1, 1970 began in UTC (see the
 * "Time Information" section in {@link DateTools}
 * for links to all kinds of information about dates and times and time zones).
 * To interpret a <tt>DateTime</tt> as a year, month, and day,
 * a time zone must be supplied to properly calculate what day it is
 * (even what month or what year it is!).
 * For example, consider it to be 12:30AM on January 1, 2007
 * [2007-01-01 00:30] in New York City.
 * That same moment in time is interpreted as 11:30PM on December 31, 2006
 * [2006-12-31 11:30] in Minneapolis, Minnesota. That's a different day,
 * a different month, and even a different year! Clearly the time zone used to
 * interpret a <tt>DateTime</tt> is critical.
 * <p>
 * The {@link PlainDate} class has some of the same uses as a {@link DateTime}
 * but <tt>PlainDate</tt> represents a year, month, and day without regard
 * to <i>any</i> time zone. Also, <tt>PlainDate</tt> does <i>not</i> contain any
 * time of day information (like hours, minutes, seconds, etc.).
 * <p>
 * This class uses the Immutability pattern. That is, instances are not
 * changeable after construction.
 *
 * @see PlainDate
 * @see DateTimeRange
 * @see PlainDateRange
 * @see DateTools
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class DateTime
        implements Comparable<DateTime>, Serializable, Cloneable {

    private final long time;

    /**
     * Primary constructor, based on the number of ms since Jan 1, 1970 UTC.
     * @param time number of milliseconds since Jan 1, 1970 in the UTC timezone.
     */
    public DateTime(long time) {
        this.time = time;
    }

    /**
     * Copies the time currently in the <tt>java.util.Date</tt> object
     * via {@link java.util.Date#getTime getTime()}. Note that the
     * <tt>java.sql</tt> types of
     * {@link java.sql.Timestamp java.sql.Timestamp},
     * {@link java.sql.Date java.sql.Date}, and
     * {@link java.sql.Time java.sql.Time} are all subclasses of
     * {@link java.util.Date java.util.Date}.
     * @throws IllegalArgumentException if null if passed.
     */
    public DateTime(java.util.Date utilDate) throws IllegalArgumentException {
        this(((java.util.Date)
            ObjectTools.paramNullCheck(utilDate, "utilDate")).getTime());
    }

    /**
     * Uses {@link DateTools#getTime()} as its source for the milliseconds
     * (which may be different that <tt>System.currentTimeMillis()</tt>).
     * If you want to be sure that {@link System#currentTimeMillis()} is being
     * used as the source of milliseconds, then call the other
     * {@link #DateTime(long)} constructor passing in the <tt>long</tt> value
     * yourself.
     */
    public DateTime() {
        this(DateTools.getTime());
    }

    /**
     * Returns the number of milliseconds since Jan 1, 1970 in the UTC timezone.
     */
    public long getTime() {
        return time;
    }

    /**
     * Returns a new <tt>java.util.{@link java.util.Date Date} object built
     * from the time stored in this instance.
     */
    public java.util.Date getAsUtilDate() {
        return new java.util.Date(time);
    }

    /**
     * Returns a new <tt>java.sql.{@link java.sql.Date Date} object built
     * from the time stored in this instance.
     */
    public java.sql.Date getAsSqlDate() {
        return new java.sql.Date(time);
    }

    /**
     * Returns a new <tt>java.sql.{@link java.sql.Timestamp Timestamp} object
     * built from the time stored in this instance.
     */
    public java.sql.Timestamp getAsSqlTimestamp() {
        return new java.sql.Timestamp(time);
    }

    /**
     * Returns a {@link PlainDate} derived from the time stored in
     * this instance interpreted in the specified time zone.
     */
    public PlainDate toPlainDate(TimeZone tz) {
        return DateTools.getPlainDate(this, tz);
    }

    /**
     * Returns a {@link PlainDate} derived from the time stored in
     * this instance interpreted in the local VM time zone.
     */
    public PlainDate toPlainDateLocal() {
        return DateTools.getPlainDateLocal(this);
    }

    /**
     * Returns a {@link PlainDate} derived from the time stored in
     * this instance interpreted in the UTC time zone.
     */
    public PlainDate toPlainDateUTC() {
        return DateTools.getPlainDateUTC(this);
    }

    /**
     * Returns <tt>true</tt> if the this instance's time comes <i>before</i>
     * the time passed as a parameter.
     * If they are equal, <tt>false</tt> is returned.
     * @see #before(long)
     * @throws IllegalArgumentException if null if passed.
     */
    public boolean before(DateTime otherDateTime)
            throws IllegalArgumentException {

        ObjectTools.paramNullCheck(otherDateTime, "otherDateTime");
        return time < otherDateTime.time;
    }

    /**
     * Returns <tt>true</tt> if the this instance's time comes <i>before</i>
     * the time passed as a parameter.
     * If they are equal, <tt>false</tt> is returned.
     * @see #before(DateTime)
     */
    public boolean before(long otherTime) {
        return time < otherTime;
    }

    /**
     * Returns <tt>true</tt> if the this instance's time comes <i>before</i>
     * or is the same as the time passed as a parameter.
     * @throws IllegalArgumentException if null if passed.
     */
    public boolean beforeOrEqualTo(DateTime otherDateTime)
            throws IllegalArgumentException {

        if ( this == otherDateTime ) {
            return true;
        }

        ObjectTools.paramNullCheck(otherDateTime, "otherDateTime");
        return time <= otherDateTime.time;
    }

    /**
     * Returns <tt>true</tt> if the this instance's time comes <i>before</i>
     * or is the same as the time passed as a parameter.
     * @see #before(DateTime)
     */
    public boolean beforeOrEqualTo(long otherTime) {
        return time <= otherTime;
    }

    /**
     * Returns <tt>true</tt> if the this instance's time comes <i>after</i>
     * the time passed as a parameter.
     * If they are equal, <tt>false</tt> is returned.
     * @see #after(long)
     * @throws IllegalArgumentException if null if passed.
     */
    public boolean after(DateTime otherDateTime)
            throws IllegalArgumentException {

        ObjectTools.paramNullCheck(otherDateTime, "otherDateTime");
        return time > otherDateTime.time;
    }

    /**
     * Returns <tt>true</tt> if the this instance's time comes <i>after</i>
     * the time passed as a parameter.
     * If they are equal, <tt>false</tt> is returned.
     * @see #after(DateTime)
     */
    public boolean after(long otherTime) {
        return time > otherTime;
    }

    /**
     * Returns <tt>true</tt> if the this instance's time comes <i>after</i>
     * or is the same as the time passed as a parameter.
     * @throws IllegalArgumentException if null if passed.
     */
    public boolean afterOrEqualTo(DateTime otherDateTime)
            throws IllegalArgumentException {

        if ( this == otherDateTime ) {
            return true;
        }

        ObjectTools.paramNullCheck(otherDateTime, "otherDateTime");
        return time >= otherDateTime.time;
    }

    /**
     * Returns <tt>true</tt> if the this instance's time comes <i>after</i>
     * or is the same as the time passed as a parameter.
     */
    public boolean afterOrEqualTo(long otherTime) {
        return time >= otherTime;
    }

    /**
     * Returns <tt>-1</tt> if this instance's time comes before the passed time,
     * <tt>0</tt> if they are the same, and <tt>1</tt> if this instance's time
     * comes after the passed time.
     * @throws IllegalArgumentException if null if passed.
     */
    public int compareTo(DateTime otherDateTime)
            throws IllegalArgumentException {

        if ( this == otherDateTime ) {
            return 0;
        }

        ObjectTools.paramNullCheck(otherDateTime, "otherDateTime");

        if ( time < otherDateTime.time ) {
            return -1;
        } else if ( time > otherDateTime.time ) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Returns <tt>-1</tt> if this instance's time comes before the passed time,
     * <tt>0</tt> if they are the same, and <tt>1</tt> if this instance's time
     * comes after the passed time.
     */
    public int compareTo(long otherTime) {
        if ( time < otherTime ) {
            return -1;
        } else if ( time > otherTime ) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Returns <tt>true</tt> if this instance's time matches the passed time
     * exactly to the millisecond. If <tt>null</tt> is passed, <tt>false</tt>
     * is returned.
     */
    public boolean equals(DateTime otherDateTime) {
        return (otherDateTime == null) ? false : (time == otherDateTime.time);
    }

    /**
     * Returns <tt>true</tt> if this instance's time matches the passed time
     * exactly to the millisecond. If <tt>null</tt> is passed in, <tt>false</tt>
     * is returned. If a type other than <tt>DateTime</tt> is passed in,
     * <tt>false</tt> is returned (<tt>ClassCastException</tt> is not thrown).
     */
    @Override
    public boolean equals(Object obj) {
        if ( this == obj ) {
            return true;
        } else if ( obj == null || !(obj instanceof DateTime) ) {
            return false;
        }

        DateTime other = (DateTime) obj;
        return time == other.time;
    }

    @Override
    public int hashCode() {
        return (int) time;
    }

    /**
     * Returns the time formatted for the UTC timezone as
     * <tt>yyyy-mm-dd hh:mm:ss.fff UTC</tt>.
     */
    @Override
    public String toString() {
        return DateTools.formatUTC(this) + " UTC";
    }

    /**
     * Simply returns a reference to <i>this</i> instance. No need to actually
     * clone since objects of this type are immutable.
     */
    @Override
    public Object clone() {
        return this;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.