package com.programix.time;

import java.io.*;
import java.util.*;

import com.programix.collections.*;
import com.programix.util.*;
import com.programix.value.*;

/**
 * Immutable encapsulation of a period of time as expressed by a starting
 * {@link DateTime} and an ending {@link DateTime}. Either the starting
 * date or the ending date or both can be <tt>null</tt>.
 * If you need a date span that does not include any time-of-day and/or
 * time zone information, see {@link PlainDateRange}.
 * <p>
 * {@link DateTools} has handy utilities for formatting and parsing
 * <tt>DateTime</tt> instances to and from more human-readable <tt>String</tt>s.
 *
 * @see DateTime
 * @see PlainDate
 * @see PlainDateRange
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class DateTimeRange
        implements Serializable, Comparable<DateTimeRange>, Cloneable {

    /**
     * This constant can be used to specify that either the start or end of of
     * the range is "open" (that is, it is not defined and can be considered to
     * stretch out to infinity).
     * A range with an open starting time would be considered to
     * "have always been" or considered to have an "unknown beginning time".
     * A range with an open end time would be considered to
     * "be for all future time" or considered to have an "unknown ending time".
     */
    public static final DateTime OPEN = null;

    /**
     * This <tt>DateTimeRange</tt> has both an undefined start <i>and</i>
     * an undefined end. This is a shareable instance as all instances
     * of {@link DateTimeRange} are immutable. In addition, there is no
     * need to create any other instances that have both ends open
     * (although is it permissible to create those instances).
     */
    public static final DateTimeRange BOTH_OPEN =
        new DateTimeRange(OPEN, OPEN);

    /**
     * Compares two ranges placing ranges that are considered "oldest"
     * first.
     * Open start times are considered to come before defined start times.
     * Open end times are considered to come after defined end times.
     * The following are listed in the order that would result by
     * using this {@link Comparator} (time-of-date is not shown for simplicity):
     * <pre>
     *    open    to 1997-02-02
     *    open    to 1997-09-09
     *    open    to 2000-02-02
     *    open    to 2000-03-03
     *    open    to    open
     * 1997-02-02 to 1997-02-02
     * 1997-02-03 to 1997-02-03
     * 1997-06-06 to 1997-09-09
     * 1997-06-06 to 1997-10-10
     * 1997-06-06 to    open
     * 1997-07-07 to 1997-08-08
     * 1997-08-08 to 1997-09-09
     * 1997-08-08 to    open
     * 1997-09-09 to    open
     * </pre>
     * <p>
     * Also see {@link #NEWEST_FIRST_COMPARATOR} is it is <i>not</i> simply
     * the reverse of this comparator.
     * <p>
     * For additional permutations, see {@link NullFirstComparator},
     * {@link NullLastComparator}, and {@link ReverseComparator}.
     */
    public static final Comparator<DateTimeRange> OLDEST_FIRST_COMPARATOR =
        new OldestFirstComparator();

    /**
     * Compares two ranges placing ranges that are considered "newest"
     * or "most recent" first.
     * Open end times are considered to come before defined end times.
     * Open start times are considered to come after defined start times.
     * The following are listed in the order that would result by
     * using this {@link Comparator} (time-of-date is not shown for simplicity):
     * <pre>
     * 1997-09-09 to    open
     * 1997-08-08 to    open
     * 1997-06-06 to    open
     *    open    to    open
     *    open    to 2000-03-03
     *    open    to 2000-02-02
     * 1997-06-06 to 1997-10-10
     * 1997-08-08 to 1997-09-09
     * 1997-06-06 to 1997-09-09
     *    open    to 1997-09-09
     * 1997-07-07 to 1997-08-08
     * 1997-02-03 to 1997-02-03
     * 1997-02-02 to 1997-02-02
     *    open    to 1997-02-02
     * </pre>
     * <p>
     * Also see {@link #OLDEST_FIRST_COMPARATOR} is it is <i>not</i> simply
     * the reverse of this comparator.
     * <p>
     * For additional permutations, see {@link NullFirstComparator},
     * {@link NullLastComparator}, and {@link ReverseComparator}.
     */
    public static final Comparator<DateTimeRange> NEWEST_FIRST_COMPARATOR =
        new NewestFirstComparator();


    private final DateTime start;
    private final DateTime end;

    /**
     * Creates a new instance with the specified <tt>start</tt> and
     * <tt>end</tt> times. The constant {@link #OPEN} (or <tt>null</tt>)
     * can be used to indicate that one end or the other is open-ended.
     * Both the <tt>start</tt> and the <tt>end</tt> can be open, and if
     * you prefer, there is a shared, immutable instance that can be
     * used instead: {@link #BOTH_OPEN}.
     *
     * @param start the beginning of the range. Use {@link #OPEN}
     * or <tt>null</tt> to indicate that the range is open-ended and has
     * no starting time.
     * @param end the ending of the range. Use {@link #OPEN}
     * or <tt>null</tt> to indicate that the range is open-ended and has
     * no end time.
     * @exception IllegalArgumentException if the <tt>start</tt> time
     * comes after the <tt>end</tt> time.
     *
     * @see #createLocal(String, String)
     * @see #createUTC(String, String)
     */
    public DateTimeRange(DateTime start, DateTime end)
            throws IllegalArgumentException {

        if ( start != OPEN && end != OPEN && start.after(end) ) {
            throw new IllegalArgumentException("The start time [" + start +
                "] must not be after the end time [" + end + "]");
        }

        this.start = start;
        this.end = end;
    }

    private static DateTime parseLocal(String s) {
        return StringTools.isEmpty(s) ? OPEN : DateTools.parseLocal(s);
    }

    private static DateTime parseUTC(String s) {
        return StringTools.isEmpty(s) ? OPEN : DateTools.parseUTC(s);
    }

    /**
     * Creates a new instance with the specified <tt>start</tt> and
     * <tt>end</tt> times parsed using the local timezone.
     * You can use <tt>null</tt> or an
     * {@link StringTools#isEmpty(String) empty} string
     * to indicate that one end or the other (or both) is open-ended.
     *
     * @param start the beginning of the time range.
     * Use <tt>null</tt> or an {@link StringTools#isEmpty(String) empty} string
     * to indicate that the range is open-ended and has no starting time.
     * @param end the ending of the time range.
     * Use <tt>null</tt> or an {@link StringTools#isEmpty(String) empty} string
     * to indicate that the range is open-ended and has no ending time.
     * @exception IllegalArgumentException if the <tt>start</tt> time
     * comes after the <tt>end</tt> time.
     * @exception DateTimeException if either <tt>String</tt> can not be
     * parsed as a <tt>DateTime</tt>.
     *
     * @see #createUTC(String, String)
     * @see #DateTimeRange(DateTime, DateTime)
     * @see DateTools#parseLocal(String)
     */
    public static DateTimeRange createLocal(String start, String end)
            throws IllegalArgumentException, DateTimeException {

        return new DateTimeRange(parseLocal(start), parseLocal(end));
    }

    /**
     * Creates a new instance with the specified <tt>start</tt> and
     * <tt>end</tt> times parsed using the UTC timezone.
     * You can use <tt>null</tt> or an
     * {@link StringTools#isEmpty(String) empty} string
     * to indicate that one end or the other (or both) is open-ended.
     * You can also use a {@link Value} who's {@link Value#isEmpty() isEmpty()}
     * method returns <tt>true</tt> to indicate that one end or the other
     * (or both) is open-ended.
     *
     * @param start the beginning of the time range.
     * Use <tt>null</tt> or an {@link StringTools#isEmpty(String) empty} string
     * to indicate that the range is open-ended and has no starting time.
     * @param end the ending of the time range.
     * Use <tt>null</tt> or an {@link StringTools#isEmpty(String) empty} string
     * to indicate that the range is open-ended and has no ending time.
     * @exception IllegalArgumentException if the <tt>start</tt> time
     * comes after the <tt>end</tt> time.
     * @exception DateTimeException if either <tt>String</tt> can not be
     * parsed as a <tt>DateTime</tt>.
     *
     * @see #createLocal(String, String)
     * @see #DateTimeRange(DateTime, DateTime)
     * @see DateTools#parseUTC(String)
     */
    public static DateTimeRange createUTC(String start, String end)
            throws IllegalArgumentException, DateTimeException {

        return new DateTimeRange(parseUTC(start), parseUTC(end));
    }

    /**
     * Creates a new instance with an open start and the specified
     * <tt>end</tt> date.
     *
     * @param end the end of the date range.
     */
    public static DateTimeRange createWithOpenStart(DateTime end) {
        return new DateTimeRange(OPEN, end);
    }

    /**
     * Creates a new instance with an open end time and the specified
     * <tt>start</tt> time.
     *
     * @param start the start of the date range.
     */
    public static DateTimeRange createWithOpenEnd(DateTime start) {
        return new DateTimeRange(start, OPEN);
    }

    /**
     * Returns a new instance with the specified <tt>start</tt> date
     * and this instance's end time.
     *
     * @param newStart the new start date for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end.
     * @see #DateTimeRange(DateTime, DateTime)
     */
    public DateTimeRange setStart(DateTime newStart)
            throws IllegalArgumentException {

        return new DateTimeRange(newStart, this.end);
    }

    /**
     * Returns a new instance with the specified <tt>newEnd</tt> date
     * and this instance's start date.
     *
     * @param newEnd the new end date for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end.
     * @see #DateTimeRange(DateTime, DateTime)
     */
    public DateTimeRange setEnd(DateTime newEnd)
            throws IllegalArgumentException {

        return new DateTimeRange(this.start, newEnd);
    }

    /**
     * Returns <tt>true</tt> if this range has a defined start date.
     * If no start is defined, then this range is open-ended and <tt>false</tt>
     * is returned.
     * @see #getStart()
     */
    public boolean hasDefinedStart() {
        return start != OPEN;
    }

    /**
     * Returns the start of this range. If no starting date was specified,
     * then this range is open-ended and {@link #OPEN}
     * (<tt>null</tt>) is returned.
     * @see #hasDefinedStart()
     * @see #getStartValue()
     */
    public DateTime getStart() {
        return start;
    }

    /**
     * Returns the start of this range as a <tt>Value</tt>.
     * If no starting date was specified, then this range is open-ended and
     * an empty <tt>Value</tt> is returned.
     * Unlike most of the other getters, a <tt>Value</tt> is always
     * returned&mdash;<tt>null</tt> is never returned.
     * @see #hasDefinedStart()
     * @see #getStart()
     */
    public Value getStartValue() {
        return ValueFactory.create(start);
    }

    /**
     * Returns <tt>true</tt> if this range has a defined end date.
     * If no end is defined, then this range is open-ended and <tt>false</tt>
     * is returned.
     * @see #getEnd()
     */
    public boolean hasDefinedEnd() {
        return end != OPEN;
    }

    /**
     * Returns the end of this range. If no ending date was specified,
     * then this range is open-ended and {@link #OPEN}
     * (<tt>null</tt>) is returned.
     * @see #hasDefinedEnd()
     */
    public DateTime getEnd() {
        return end;
    }

    /**
     * Returns the end of this range as a <tt>Value</tt>.
     * If no ending date was specified, then this range is open-ended and
     * an empty <tt>Value</tt> is returned.
     * Unlike most of the other getters, a <tt>Value</tt> is always
     * returned&mdash;<tt>null</tt> is never returned.
     * @see #hasDefinedEnd()
     * @see #getEnd()
     */
    public Value getEndValue() {
        return ValueFactory.create(end);
    }

    /**
     * Returns <tt>true</tt> if the specified <tt>DateTime</tt> falls
     * within this range (inclusive of both endpoints).
     * If <tt>null</tt> is passed in, then <tt>false</tt> is always
     * returned (regardless of the values of either endpoint).
     * If this instance has a defined start, but an unknown end, then
     * <tt>true</tt> is returned if the passed date is equal to or comes after
     * the start.
     * If this instance has a defined end, but an unknown start, then
     * <tt>true</tt> is returned if the passed date is equal to or comes before
     * the end.
     * If this instance has both ends open and the passed parameter is
     * not <tt>null</tt>, then <tt>true</tt> is returned.
     */
    public boolean contains(DateTime dateTime) {
        if ( dateTime == null ) {
            return false;
        }

        if ( start == OPEN ) {
            if ( end == OPEN ) {
                return true;
            } else {
                return dateTime.beforeOrEqualTo(end);
            }
        } else {
            if ( end == OPEN ) {
                return start.beforeOrEqualTo(dateTime);
            } else {
                return start.beforeOrEqualTo(dateTime) &&
                       dateTime.beforeOrEqualTo(end);
            }
        }
    }

    /**
     * Forces the specified <tt>DateTime</tt> into this range.
     * If the specified date is contained with this range
     * (see {@link #contains(DateTime)}), then the passed date
     * is simply returned (no forcing is necessary).
     * If the range has a defined start and the specified date comes
     * before that start, then the start is returned.
     * If the range has a defined end and the specified date comes
     * after that end, then the end is returned.
     * @param value the date to force into this range.
     * @return a date that is within this range.
     * @throws IllegalArgumentException if the specified date is <tt>null</tt>.
     */
    public DateTime forceIntoRange(DateTime value)
            throws IllegalArgumentException {

        if ( value == null ) {
            throw new IllegalArgumentException("Date to force can not be null");
        }

        // All scenarios and what to return:
        //
        //        start        end         contains     return
        //          |----val----|            true         val
        //    <----------val----|            true         val
        //          |----val------------>    true         val
        //    <----------val------------>    true         val
        //     val  |-----------|            false       start
        //     val  |------------------->    false       start
        //          |-----------|  val       false        end
        //    <-----------------|  val       false        end

        if ( contains(value) ) {
            return value;
        } else if ( hasDefinedStart() && value.beforeOrEqualTo(start) ) {
            return start;
        } else {
            return end;
        }
    }

    /**
     * Compares this instance to <tt>otherRange</tt> as defined by
     * {@link #OLDEST_FIRST_COMPARATOR}.
     * @throws IllegalArgumentException if null if passed.
     */
    public int compareTo(DateTimeRange otherRange)
            throws IllegalArgumentException {

        if ( this == otherRange ) {
            return 0;
        } else {
            return OLDEST_FIRST_COMPARATOR.compare(this, otherRange);
        }
    }

    /**
     * Returns <tt>true</tt> if this instance's start and end dates exactly
     * match the start and end dates of the passed instance.
     * If <tt>null</tt> is passed, <tt>false</tt> is returned.
     */
    public boolean equals(DateTimeRange otherDateTime) {
        return (this == otherDateTime) || (
                otherDateTime != null &&
                ObjectTools.isSame(start, otherDateTime.start) &&
                ObjectTools.isSame(end, otherDateTime.end)
            );
    }

    /**
     * Returns <tt>true</tt> if this instance's start and end dates exactly
     * match the start and end dates of the passed instance.
     * If <tt>null</tt> is passed, <tt>false</tt> is returned.
     * If a type other than <tt>DateTimeRange</tt> is passed in,
     * <tt>false</tt> is returned (<tt>ClassCastException</tt> is not thrown).
     */
    @Override
    public boolean equals(Object obj) {
        if ( this == obj ) {
            return true;
        } else if ( obj == null || !(obj instanceof DateTimeRange) ) {
            return false;
        }

        return equals((DateTimeRange) obj);
    }

    @Override
    public int hashCode() {
        return ((start == null) ? 0 : start.hashCode()) ^
               ((end == null) ? 0 : end.hashCode());
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(getClass().getName() + "[");
        sb.append("start=" + start);
        sb.append(", end=" + end);
        sb.append("]");
        return sb.toString();
    }

    /**
     * Simply returns a reference to <i>this</i> instance. No need to actually
     * clone since objects of this type are immutable.
     */
    @Override
    public Object clone() {
        return this;
    }

    private static class OldestFirstComparator
            implements Comparator<DateTimeRange> {

        public int compare(DateTimeRange dtr1, DateTimeRange dtr2) {
            try {
                if ( dtr1 == dtr2 ) {
                    return 0;
                }

                int startDiff = CollectionsTools.NULL_FIRST_COMPARABLE_ASC
                    .compare(dtr1.start, dtr2.start);

                if ( startDiff != 0 ) {
                    return startDiff;
                }

                // start's are both null or are both the same...

                int endDiff = CollectionsTools.NULL_LAST_COMPARABLE_ASC
                    .compare(dtr1.end, dtr2.end);

                if ( endDiff != 0 ) {
                    return endDiff;
                }

                return 0;
            } catch ( NullPointerException x ) {
                if ( dtr1 == null || dtr2 == null ) {
                    throw new IllegalArgumentException(
                        "One of the parameters passed to compare() is null. " +
                        "Wrap with NullFirstComparator or NullLastComparator " +
                        "if null should be considered valid in these " +
                        "comparisons.");
                } else {
                    throw x;  // throw the original if we get here
                }
            }
        }
    } // class OldestFirstComparator

    private static class NewestFirstComparator
            implements Comparator<DateTimeRange> {

        public int compare(DateTimeRange dtr1, DateTimeRange dtr2) {
            try {
                if ( dtr1 == dtr2 ) {
                    return 0;
                }

                int endDiff = CollectionsTools.NULL_LAST_COMPARABLE_ASC
                    .compare(dtr2.end, dtr1.end);

                if ( endDiff != 0 ) {
                    return endDiff;
                }

                // end's are both null or are both the same...

                int startDiff = CollectionsTools.NULL_FIRST_COMPARABLE_ASC
                    .compare(dtr2.start, dtr1.start);

                if ( startDiff != 0 ) {
                    return startDiff;
                }

                return 0;
            } catch ( NullPointerException x ) {
                if ( dtr1 == null || dtr2 == null ) {
                    throw new IllegalArgumentException(
                        "One of the parameters passed to compare() is null. " +
                        "Wrap with NullFirstComparator or NullLastComparator " +
                        "if null should be considered valid in these " +
                        "comparisons.");
                } else {
                    throw x;  // throw the original if we get here
                }
            }
        }
    } // class NewestFirstComparator
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.