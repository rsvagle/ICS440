package com.programix.time;

import java.io.*;
import java.util.*;

import com.programix.collections.*;
import com.programix.util.*;
import com.programix.value.*;

/**
 * Immutable encapsulation of a period of time as expressed by a starting
 * {@link PlainDate} and an ending {@link PlainDate}. Either the starting
 * date or the ending date or both can be <tt>null</tt>.
 * If you need a time span that also includes time-of-day and/or
 * time zone information, see {@link DateTimeRange}.
 * <p>
 * The {@link PlainDate} class itself and the utility
 * {@link DateTools} have handy utilities for formatting and parsing
 * <tt>PlainDate</tt> instances to and from more human-readable
 * <tt>String</tt>s.
 *
 * @see PlainDate
 * @see DateTime
 * @see DateTimeRange
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class PlainDateRange
        implements Serializable, Comparable<PlainDateRange>, Cloneable {

    /**
     * This constant can be used to specify that either the start or end of of
     * the range is "open" (that is, it is not defined and can be considered to
     * stretch out to infinity).
     * A range with an open starting date would be considered to
     * "have always been" or considered to have an "unknown beginning date".
     * A range with an open end date would be considered to
     * "be for all future time" or considered to have an "unknown ending date".
     */
    public static final PlainDate OPEN = null;

    /**
     * This <tt>PlainDateRange</tt> has both an undefined start <i>and</i>
     * an undefined end. This is a shareable instance as all instances
     * of {@link PlainDateRange} are immutable. In addition, there is no
     * need to create any other instances that have both ends open
     * (although is it permissible to create those instances).
     */
    public static final PlainDateRange BOTH_OPEN =
        new PlainDateRange(OPEN, OPEN);

    /**
     * Compares two ranges placing ranges that are considered "oldest"
     * first.
     * Open start dates are considered to come before defined start dates.
     * Open end dates are considered to come after defined end dates.
     * The following are listed in the order that would result by
     * using this {@link Comparator}:
     * <pre>
     *    open    to 1997-02-02
     *    open    to 1997-09-09
     *    open    to 2000-02-02
     *    open    to 2000-03-03
     *    open    to    open
     * 1997-02-02 to 1997-02-02
     * 1997-02-03 to 1997-02-03
     * 1997-06-06 to 1997-09-09
     * 1997-06-06 to 1997-10-10
     * 1997-06-06 to    open
     * 1997-07-07 to 1997-08-08
     * 1997-08-08 to 1997-09-09
     * 1997-08-08 to    open
     * 1997-09-09 to    open
     * </pre>
     * <p>
     * Also see {@link #NEWEST_FIRST_COMPARATOR} as it is <i>not</i> simply
     * the reverse of this comparator.
     * <p>
     * For additional permutations, see {@link NullFirstComparator},
     * {@link NullLastComparator}, and {@link ReverseComparator}.
     */
    public static final Comparator<PlainDateRange> OLDEST_FIRST_COMPARATOR =
        new OldestFirstComparator();

    /**
     * Compares two ranges placing ranges that are considered "newest"
     * or "most recent" first.
     * Open end dates are considered to come before defined end dates.
     * Open start dates are considered to come after defined start dates.
     * The following are listed in the order that would result by
     * using this {@link Comparator}:
     * <pre>
     * 1997-09-09 to    open
     * 1997-08-08 to    open
     * 1997-06-06 to    open
     *    open    to    open
     *    open    to 2000-03-03
     *    open    to 2000-02-02
     * 1997-06-06 to 1997-10-10
     * 1997-08-08 to 1997-09-09
     * 1997-06-06 to 1997-09-09
     *    open    to 1997-09-09
     * 1997-07-07 to 1997-08-08
     * 1997-02-03 to 1997-02-03
     * 1997-02-02 to 1997-02-02
     *    open    to 1997-02-02
     * </pre>
     * <p>
     * Also see {@link #OLDEST_FIRST_COMPARATOR} as it is <i>not</i> simply
     * the reverse of this comparator.
     * <p>
     * For additional permutations, see {@link NullFirstComparator},
     * {@link NullLastComparator}, and {@link ReverseComparator}.
     */
    public static final Comparator<PlainDateRange> NEWEST_FIRST_COMPARATOR =
        new NewestFirstComparator();


    private final PlainDate start;
    private final PlainDate end;

    /**
     * Creates a new instance with the specified <tt>start</tt> and
     * <tt>end</tt> dates. The constant {@link #OPEN} (or <tt>null</tt>)
     * can be used to indicate that one end or the other is open-ended.
     * Both the <tt>start</tt> and the <tt>end</tt> can be open, and if
     * you prefer, there is a shared, immutable instance that can be
     * used instead: {@link #BOTH_OPEN}.
     *
     * @param start the beginning of the date range. Use {@link #OPEN}
     * or <tt>null</tt> to indicate that the range is open-ended and has
     * no starting date.
     * @param end the ending of the date range. Use {@link #OPEN}
     * or <tt>null</tt> to indicate that the range is open-ended and has
     * no end date.
     * @exception IllegalArgumentException if the <tt>start</tt> date
     * comes after the <tt>end</tt> date.
     *
     * @see #PlainDateRange(Value, Value)
     * @see #PlainDateRange(String, String)
     */
    public PlainDateRange(PlainDate start, PlainDate end)
            throws IllegalArgumentException {

        if ( start != OPEN && end != OPEN && start.after(end) ) {
            throw new IllegalArgumentException("The start date [" + start +
                "] must not be after the end date [" + end + "]");
        }

        this.start = start;
        this.end = end;
    }

    /**
     * Creates a new instance with the specified <tt>start</tt> and
     * <tt>end</tt> dates.
     * You can use <tt>null</tt> or an
     * {@link StringTools#isEmpty(String) empty} string
     * to indicate that one end or the other (or both) is open-ended.
     *
     * @param start the beginning of the date range.
     * Use <tt>null</tt> or an {@link StringTools#isEmpty(String) empty} string
     * to indicate that the range is open-ended and has no starting date.
     * @param end the ending of the date range.
     * Use <tt>null</tt> or an {@link StringTools#isEmpty(String) empty} string
     * to indicate that the range is open-ended and has no end date.
     * @exception IllegalArgumentException if the <tt>start</tt> date
     * comes after the <tt>end</tt> date.
     * Or, if one of the <tt>String</tt>'s is not empty and can not be parsed
     * as a <tt>PlainDate</tt> (see {@link PlainDate#create(String)}).
     *
     * @see #PlainDateRange(PlainDate, PlainDate)
     * @see #PlainDateRange(Value, Value)
     * @see PlainDate#create(String)
     */
    public PlainDateRange(String start, String end)
            throws IllegalArgumentException{

        this(parse(start), parse(end));
    }

    /**
     * Creates a new instance with the specified <tt>start</tt> and
     * <tt>end</tt> dates.
     * You can use <tt>null</tt> for either parameter to indicate that
     * one end or the other (or both) is open-ended.
     * You can also use a {@link Value} who's {@link Value#isEmpty() isEmpty()}
     * method returns <tt>true</tt> to indicate that one end or the other
     * (or both) is open-ended.
     *
     * @param start the beginning of the date range.
     * Use <tt>null</tt> or an {@link Value#isEmpty() empty} <tt>Value</tt>
     * to indicate that the range is open-ended and has no starting date.
     * @param end the ending of the date range.
     * Use <tt>null</tt> or an {@link Value#isEmpty() empty} <tt>Value</tt>
     * to indicate that the range is open-ended and has no ending date.
     * @exception IllegalArgumentException if the <tt>start</tt> date
     * comes after the <tt>end</tt> date.
     * Or, if one of the <tt>Value</tt>'s is not empty and can not be parsed
     * as a <tt>PlainDate</tt> (see {@link Value#getPlainDateOrNull()}).
     *
     * @see #PlainDateRange(PlainDate, PlainDate)
     * @see #PlainDateRange(String, String)
     * @see PlainDate#create(String)
     */
    public PlainDateRange(Value start, Value end)
            throws IllegalArgumentException {

        this(parse(start), parse(end));
    }

    private static PlainDate parse(String s) throws IllegalArgumentException {
        try {
            return StringTools.isEmpty(s) ? OPEN : PlainDate.create(s);
        } catch ( Exception x ) {
            throw new IllegalArgumentException(x);
        }
    }

    private static PlainDate parse(Value value)
            throws IllegalArgumentException {

        try {
            return (value == null) ? null : value.getPlainDateOrNull();
        } catch ( Exception x ) {
            throw new IllegalArgumentException(x);
        }
    }

    /**
     * Creates a new instance with an open start and the specified
     * <tt>end</tt> date.
     *
     * @param end the end of the date range.
     */
    public static PlainDateRange createWithOpenStart(PlainDate end) {
        return new PlainDateRange(OPEN, end);
    }

    /**
     * Creates a new instance with an open end date and the specified
     * <tt>start</tt> date.
     *
     * @param start the start of the date range.
     */
    public static PlainDateRange createWithOpenEnd(PlainDate start) {
        return new PlainDateRange(start, OPEN);
    }

    /**
     * Returns a new instance with the specified <tt>newStart</tt> date
     * and this instance's end date.
     *
     * @param newStart the new start date for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end.
     * @see #PlainDateRange(PlainDate, PlainDate)
     */
    public PlainDateRange setStart(PlainDate newStart)
            throws IllegalArgumentException {

        return new PlainDateRange(newStart, this.end);
    }

    /**
     * Returns a new instance with the specified <tt>newStart</tt> date
     * and this instance's end date.
     *
     * @param newStart the new start date for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end
     * or if the start is not empty and can't be parsed.
     * @see #PlainDateRange(String, String)
     */
    public PlainDateRange setStart(String newStart)
            throws IllegalArgumentException {

        return new PlainDateRange(parse(newStart), this.end);
    }

    /**
     * Returns a new instance with the specified <tt>newStart</tt> date
     * and this instance's end date.
     *
     * @param newStart the new start date for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end
     * or if the start is not empty and can't be parsed.
     * @see #PlainDateRange(Value, Value)
     */
    public PlainDateRange setStart(Value newStart)
            throws IllegalArgumentException {

        return new PlainDateRange(parse(newStart), this.end);
    }

    /**
     * Returns a new instance with the specified <tt>newEnd</tt> date
     * and this instance's start date.
     *
     * @param newEnd the new end date for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end.
     * @see #PlainDateRange(PlainDate, PlainDate)
     */
    public PlainDateRange setEnd(PlainDate newEnd)
            throws IllegalArgumentException {

        return new PlainDateRange(this.start, newEnd);
    }

    /**
     * Returns a new instance with the specified <tt>newEnd</tt> date
     * and this instance's start date.
     *
     * @param newEnd the new end date for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end
     * or if the end is not empty and can't be parsed.
     * @see #PlainDateRange(String, String)
     */
    public PlainDateRange setEnd(String newEnd)
            throws IllegalArgumentException {

        return new PlainDateRange(this.start, parse(newEnd));
    }

    /**
     * Returns a new instance with the specified <tt>newEnd</tt> date
     * and this instance's start date.
     *
     * @param newEnd the new end date for the new instance or null.
     * @return the new range derived from this one.
     * @exception IllegalArgumentException if the start comes after the end
     * or if the end is not empty and can't be parsed.
     * @see #PlainDateRange(Value, Value)
     */
    public PlainDateRange setEnd(Value newEnd)
            throws IllegalArgumentException {

        return new PlainDateRange(this.start, parse(newEnd));
    }

    /**
     * Returns <tt>true</tt> if this range has a defined start date.
     * If no start is defined, then this range is open-ended and <tt>false</tt>
     * is returned.
     * @see #getStart()
     */
    public boolean hasDefinedStart() {
        return start != OPEN;
    }

    /**
     * Returns the start of this range. If no starting date was specified,
     * then this range is open-ended and {@link #OPEN}
     * (<tt>null</tt>) is returned.
     * @see #hasDefinedStart()
     * @see #getStartString()
     * @see #getStartValue()
     */
    public PlainDate getStart() {
        return start;
    }

    /**
     * Returns the start of this range as a <tt>String</tt>
     * in the ISO format yyyy-mm-dd.
     * If no starting date was specified, then this range is open-ended and
     * <tt>null</tt> is returned.
     * @see #hasDefinedStart()
     * @see #getStart()
     * @see #getStartValue()
     */
    public String getStartString() {
        return (start == null) ? null : start.formatYmdDash();
    }

    /**
     * Returns the start of this range as a <tt>Value</tt>.
     * If no starting date was specified, then this range is open-ended and
     * an empty <tt>Value</tt> is returned.
     * Unlike most of the other getters, a <tt>Value</tt> is always
     * returned&mdash;<tt>null</tt> is never returned.
     * @see #hasDefinedStart()
     * @see #getStart()
     * @see #getStartString()
     */
    public Value getStartValue() {
        return ValueFactory.create(start);
    }

    /**
     * Returns <tt>true</tt> if this range has a defined end date.
     * If no end is defined, then this range is open-ended and <tt>false</tt>
     * is returned.
     * @see #getEnd()
     */
    public boolean hasDefinedEnd() {
        return end != OPEN;
    }

    /**
     * Returns the end of this range. If no ending date was specified,
     * then this range is open-ended and {@link #OPEN}
     * (<tt>null</tt>) is returned.
     * @see #hasDefinedEnd()
     */
    public PlainDate getEnd() {
        return end;
    }

    /**
     * Returns the end of this range as a <tt>String</tt>
     * in the ISO format yyyy-mm-dd.
     * If no ending date was specified, then this range is open-ended and
     * <tt>null</tt> is returned.
     * @see #hasDefinedEnd()
     * @see #getEnd()
     * @see #getEndValue()
     */
    public String getEndString() {
        return (end == null) ? null : end.formatYmdDash();
    }

    /**
     * Returns the end of this range as a <tt>Value</tt>.
     * If no ending date was specified, then this range is open-ended and
     * an empty <tt>Value</tt> is returned.
     * Unlike most of the other getters, a <tt>Value</tt> is always
     * returned&mdash;<tt>null</tt> is never returned.
     * @see #hasDefinedEnd()
     * @see #getEnd()
     * @see #getEndString()
     */
    public Value getEndValue() {
        return ValueFactory.create(end);
    }

    /**
     * Returns <tt>true</tt> if the specified <tt>PlainDate</tt> falls
     * within this range (inclusive of both endpoints).
     * If <tt>null</tt> is passed in, then <tt>false</tt> is always
     * returned (regardless of the values of either endpoint).
     * If this instance has a defined start, but an unknown end, then
     * <tt>true</tt> is returned if the passed date is equal to or comes after
     * the start.
     * If this instance has a defined end, but an unknown start, then
     * <tt>true</tt> is returned if the passed date is equal to or comes before
     * the end.
     * If this instance has both ends open and the passed parameter is
     * not <tt>null</tt>, then <tt>true</tt> is returned.
     */
    public boolean contains(PlainDate plainDate) {
        if ( plainDate == null ) {
            return false;
        }

        if ( start == OPEN ) {
            if ( end == OPEN ) {
                return true;
            } else {
                return plainDate.beforeOrEqualTo(end);
            }
        } else {
            if ( end == OPEN ) {
                return start.beforeOrEqualTo(plainDate);
            } else {
                return start.beforeOrEqualTo(plainDate) &&
                       plainDate.beforeOrEqualTo(end);
            }
        }
    }

    /**
     * Forces the specified <tt>PlainDate</tt> into this range.
     * If the specified date is contained with this range
     * (see {@link #contains(PlainDate)}), then the passed date
     * is simply returned (no forcing is necessary).
     * If the range has a defined start and the specified date comes
     * before that start, then the start is returned.
     * If the range has a defined end and the specified date comes
     * after that end, then the end is returned.
     * @param value the date to force into this range.
     * @return a date that is within this range.
     * @throws IllegalArgumentException if the specified date is <tt>null</tt>.
     */
    public PlainDate forceIntoRange(PlainDate value)
            throws IllegalArgumentException {

        if ( value == null ) {
            throw new IllegalArgumentException("Date to force can not be null");
        }

        // All scenarios and what to return:
        //
        //        start        end         contains     return
        //          |----val----|            true         val
        //    <----------val----|            true         val
        //          |----val------------>    true         val
        //    <----------val------------>    true         val
        //     val  |-----------|            false       start
        //     val  |------------------->    false       start
        //          |-----------|  val       false        end
        //    <-----------------|  val       false        end

        if ( contains(value) ) {
            return value;
        } else if ( hasDefinedStart() && value.beforeOrEqualTo(start) ) {
            return start;
        } else {
            return end;
        }
    }

    /**
     * Compares this instance to <tt>otherRange</tt> as defined by
     * {@link #OLDEST_FIRST_COMPARATOR}.
     * @throws IllegalArgumentException if null if passed.
     */
    public int compareTo(PlainDateRange otherRange)
            throws IllegalArgumentException {

        if ( this == otherRange ) {
            return 0;
        } else {
            return OLDEST_FIRST_COMPARATOR.compare(this, otherRange);
        }
    }

    /**
     * Returns <tt>true</tt> if this instance's start and end dates exactly
     * match the start and end dates of the passed instance.
     * If <tt>null</tt> is passed, <tt>false</tt> is returned.
     */
    public boolean equals(PlainDateRange otherPlainDate) {
        return (this == otherPlainDate) || (
                otherPlainDate != null &&
                ObjectTools.isSame(start, otherPlainDate.start) &&
                ObjectTools.isSame(end, otherPlainDate.end)
            );
    }

    /**
     * Returns <tt>true</tt> if this instance's start and end dates exactly
     * match the start and end dates of the passed instance.
     * If <tt>null</tt> is passed, <tt>false</tt> is returned.
     * If a type other than <tt>PlainDateRange</tt> is passed in,
     * <tt>false</tt> is returned (<tt>ClassCastException</tt> is not thrown).
     */
    @Override
    public boolean equals(Object obj) {
        if ( this == obj ) {
            return true;
        } else if ( obj == null || !(obj instanceof PlainDateRange) ) {
            return false;
        }

        return equals((PlainDateRange) obj);
    }

    @Override
    public int hashCode() {
        return ((start == null) ? 0 : start.hashCode()) ^
               ((end == null) ? 0 : end.hashCode());
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(getClass().getName() + "[");
        sb.append("start=" + start);
        sb.append(", end=" + end);
        sb.append("]");
        return sb.toString();
    }

    /**
     * Simply returns a reference to <i>this</i> instance. No need to actually
     * clone since objects of this type are immutable.
     */
    @Override
    public Object clone() {
        return this;
    }

    private static class OldestFirstComparator
            implements Comparator<PlainDateRange> {

        public int compare(PlainDateRange pdr1, PlainDateRange pdr2) {
            try {
                if ( pdr1 == pdr2 ) {
                    return 0;
                }

                int startDiff = CollectionsTools.NULL_FIRST_COMPARABLE_ASC
                    .compare(pdr1.start, pdr2.start);

                if ( startDiff != 0 ) {
                    return startDiff;
                }

                // start's are both null or are both the same...

                int endDiff = CollectionsTools.NULL_LAST_COMPARABLE_ASC
                    .compare(pdr1.end, pdr2.end);

                if ( endDiff != 0 ) {
                    return endDiff;
                }

                return 0;
            } catch ( NullPointerException x ) {
                if ( pdr1 == null || pdr2 == null ) {
                    throw new IllegalArgumentException(
                        "One of the parameters passed to compare() is null. " +
                        "Wrap with NullFirstComparator or NullLastComparator " +
                        "if null should be considered valid in these " +
                        "comparisons.");
                } else {
                    throw x;  // throw the original if we get here
                }
            }
        }
    } // class OldestFirstComparator

    private static class NewestFirstComparator
            implements Comparator<PlainDateRange> {

        public int compare(PlainDateRange pdr1, PlainDateRange pdr2) {
            try {
                if ( pdr1 == pdr2 ) {
                    return 0;
                }

                int endDiff = CollectionsTools.NULL_LAST_COMPARABLE_ASC
                    .compare(pdr2.end, pdr1.end);

                if ( endDiff != 0 ) {
                    return endDiff;
                }

                // end's are both null or are both the same...

                int startDiff = CollectionsTools.NULL_FIRST_COMPARABLE_ASC
                    .compare(pdr2.start, pdr1.start);

                if ( startDiff != 0 ) {
                    return startDiff;
                }

                return 0;
            } catch ( NullPointerException x ) {
                if ( pdr1 == null || pdr2 == null ) {
                    throw new IllegalArgumentException(
                        "One of the parameters passed to compare() is null. " +
                        "Wrap with NullFirstComparator or NullLastComparator " +
                        "if null should be considered valid in these " +
                        "comparisons.");
                } else {
                    throw x;  // throw the original if we get here
                }
            }
        }
    } // class NewestFirstComparator
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.