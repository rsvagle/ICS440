package com.programix.time;

import java.io.*;
import java.util.*;

import com.programix.collections.*;

/**
 * An enumeration of the days of the week in the Gregorian calendar
 * and the US English language. Also following both Java's
 * placement of Sunday as the first day in {@link Calendar} (at
 * least as far as its constant value goes) and the traditions of
 * the US, Sunday (not Monday) is set as the first day of the week.
 * <p>
 * If instead you want to do sorting with <i>Monday</i> being the
 * first day of the week, there is a {@link Comparator} that handles that:
 * {@link #MONDAY_TO_SUNDAY_COMPARATOR}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class DayOfWeek implements Serializable, Comparable<DayOfWeek> {
    private static int nextSerial = 0;
    private static List<DayOfWeek> instanceList = new ArrayList<DayOfWeek>();

    // This variable declaration and construction order must never
    // change if there are serialized instances saved somewhere as
    // they will be misinterpreted when de-serialized. If any new
    // instances are to be created, they must be appended to the
    // end of the existing list. The order of the constants will also
    // be the sort order for Comparable.

    /**
     * The day of the week called Sunday. Default sorting considers
     * Sunday to be the first day of the week.
     * <table border="1">
     * <tr align="center"><td rowspan="2">Name</td>
     *      <td colspan="3">Display Name</td></tr>
     * <tr align="center"><td>Full</td><td>Medium</td><td>Short</td></tr>
     * <tr align="center">
     *      <td>SUNDAY</td><td>Sunday</td><td>Sun</td><td>Su</td></tr>
     * </table>
     * For access to all four names, use {@link #getName()},
     * {@link #getDisplayNameFull()}, {@link #getDisplayNameMedium()}, and
     * {@link #getDisplayNameShort()}.
     */
    public static final DayOfWeek SUNDAY =
        new DayOfWeek("SUNDAY", "Sunday", "Sun", "Su");

    /**
     * The day of the week called Monday. Default sorting considers
     * Sunday to be the first day of the week.
     * <table border="1">
     * <tr align="center"><td rowspan="2">Name</td>
     *      <td colspan="3">Display Name</td></tr>
     * <tr align="center"><td>Full</td><td>Medium</td><td>Short</td></tr>
     * <tr align="center">
     *      <td>MONDAY</td><td>Monday</td><td>Mon</td><td>Mo</td></tr>
     * </table>
     * For access to all four names, use {@link #getName()},
     * {@link #getDisplayNameFull()}, {@link #getDisplayNameMedium()}, and
     * {@link #getDisplayNameShort()}.
     */
    public static final DayOfWeek MONDAY =
        new DayOfWeek("MONDAY", "Monday", "Mon", "Mo");

    /**
     * The day of the week called Tuesday.
     * <table border="1">
     * <tr align="center"><td rowspan="2">Name</td>
     *      <td colspan="3">Display Name</td></tr>
     * <tr align="center"><td>Full</td><td>Medium</td><td>Short</td></tr>
     * <tr align="center">
     *      <td>TUESDAY</td><td>Tuesday</td><td>Tue</td><td>Tu</td></tr>
     * </table>
     * For access to all four names, use {@link #getName()},
     * {@link #getDisplayNameFull()}, {@link #getDisplayNameMedium()}, and
     * {@link #getDisplayNameShort()}.
     */
    public static final DayOfWeek TUESDAY =
        new DayOfWeek("TUESDAY", "Tuesday", "Tue", "Tu");

    /**
     * The day of the week called Wednesday.
     * <table border="1">
     * <tr align="center"><td rowspan="2">Name</td>
     *      <td colspan="3">Display Name</td></tr>
     * <tr align="center"><td>Full</td><td>Medium</td><td>Short</td></tr>
     * <tr align="center">
     *      <td>WEDNESDAY</td><td>Wednesday</td><td>Wed</td><td>We</td></tr>
     * </table>
     * For access to all four names, use {@link #getName()},
     * {@link #getDisplayNameFull()}, {@link #getDisplayNameMedium()}, and
     * {@link #getDisplayNameShort()}.
     */
    public static final DayOfWeek WEDNESDAY =
        new DayOfWeek("WEDNESDAY", "Wednesday", "Wed", "We");

    /**
     * The day of the week called Thursday.
     * <table border="1">
     * <tr align="center"><td rowspan="2">Name</td>
     *      <td colspan="3">Display Name</td></tr>
     * <tr align="center"><td>Full</td><td>Medium</td><td>Short</td></tr>
     * <tr align="center">
     *      <td>THURSDAY</td><td>Thursday</td><td>Thu</td><td>Th</td></tr>
     * </table>
     * For access to all four names, use {@link #getName()},
     * {@link #getDisplayNameFull()}, {@link #getDisplayNameMedium()}, and
     * {@link #getDisplayNameShort()}.
     */
    public static final DayOfWeek THURSDAY =
        new DayOfWeek("THURSDAY", "Thursday", "Thu", "Th");

    /**
     * The day of the week called Friday.
     * <table border="1">
     * <tr align="center"><td rowspan="2">Name</td>
     *      <td colspan="3">Display Name</td></tr>
     * <tr align="center"><td>Full</td><td>Medium</td><td>Short</td></tr>
     * <tr align="center">
     *      <td>FRIDAY</td><td>Friday</td><td>Fri</td><td>Fr</td></tr>
     * </table>
     * For access to all four names, use {@link #getName()},
     * {@link #getDisplayNameFull()}, {@link #getDisplayNameMedium()}, and
     * {@link #getDisplayNameShort()}.
     */
    public static final DayOfWeek FRIDAY =
        new DayOfWeek("FRIDAY", "Friday", "Fri", "Fr");

    /**
     * The day of the week called Saturday. Default sorting considers
     * Sunday to be the first day of the week and Saturday to be the last
     * day of the week.
     * <table border="1">
     * <tr align="center"><td rowspan="2">Name</td>
     *      <td colspan="3">Display Name</td></tr>
     * <tr align="center"><td>Full</td><td>Medium</td><td>Short</td></tr>
     * <tr align="center">
     *      <td>SATURDAY</td><td>Saturday</td><td>Sat</td><td>Sa</td></tr>
     * </table>
     * For access to all four names, use {@link #getName()},
     * {@link #getDisplayNameFull()}, {@link #getDisplayNameMedium()}, and
     * {@link #getDisplayNameShort()}.
     */
    public static final DayOfWeek SATURDAY =
        new DayOfWeek("SATURDAY", "Saturday", "Sat", "Sa");


    private static final DayOfWeek[] VALUES = instanceList
        .toArray(new DayOfWeek[instanceList.size()]);

    /**
     * An unmodifiable {@link List} of all the instances of <tt>DayOfWeek</tt>.
     */
    public static final List<DayOfWeek> VALUE_LIST =
        Collections.unmodifiableList(instanceList);

    /**
     * Sorts as Sunday, Monday, Tuesday, Wednesday, Thursday,
     * Friday, Saturday with no protection against <tt>null</tt>'s.
     */
    public static final Comparator<DayOfWeek> SUNDAY_TO_SATURDAY_COMPARATOR =
        new ComparableComparator<DayOfWeek>();

    /**
     * Sorts as <tt>null</tt>, Sunday, Monday, Tuesday, Wednesday, Thursday,
     * Friday, Saturday (with any <tt>null</tt>'s coming first).
     */
    public static final Comparator<DayOfWeek>
        SUNDAY_TO_SATURDAY_NULL_FIRST_COMPARATOR =
        new NullFirstComparator<DayOfWeek>(SUNDAY_TO_SATURDAY_COMPARATOR);

    /**
     * Sorts as Sunday, Monday, Tuesday, Wednesday, Thursday,
     * Friday, Saturday, <tt>null</tt> (with any <tt>null</tt>'s coming last).
     */
    public static final Comparator<DayOfWeek>
        SUNDAY_TO_SATURDAY_NULL_LAST_COMPARATOR =
        new NullLastComparator<DayOfWeek>(SUNDAY_TO_SATURDAY_COMPARATOR);

    /**
     * Sorts as Saturday, Friday, Thursday, Wednesday, Tuesday,
     * Monday, Sunday with no protection against <tt>null</tt>'s.
     */
    public static final Comparator<DayOfWeek> SATURDAY_TO_SUNDAY_COMPARATOR =
        new ReverseComparator<DayOfWeek>(new ComparableComparator<DayOfWeek>());

    /**
     * Sorts as <tt>null</tt>, Saturday, Friday, Thursday, Wednesday, Tuesday,
     * Monday, Sunday (with any <tt>null</tt>'s coming first).
     */
    public static final Comparator<DayOfWeek>
        SATURDAY_TO_SUNDAY_NULL_FIRST_COMPARATOR =
        new NullFirstComparator<DayOfWeek>(SATURDAY_TO_SUNDAY_COMPARATOR);

    /**
     * Sorts as Saturday, Friday, Thursday, Wednesday, Tuesday,
     * Monday, Sunday, <tt>null</tt> (with any <tt>null</tt>'s coming last).
     */
    public static final Comparator<DayOfWeek>
        SATURDAY_TO_SUNDAY_NULL_LAST_COMPARATOR =
        new NullLastComparator<DayOfWeek>(SATURDAY_TO_SUNDAY_COMPARATOR);

    /**
     * Sorts as
     * Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
     * with no protection against <tt>null</tt>'s.
     */
    public static final Comparator<DayOfWeek> MONDAY_TO_SUNDAY_COMPARATOR =
        new MondayFirstComparator();

    /**
     * Sorts as
     * <tt>null</tt>,
     * Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
     * (with any <tt>null</tt>'s coming first).
     */
    public static final Comparator<DayOfWeek>
        MONDAY_TO_SUNDAY_NULL_FIRST_COMPARATOR =
        new NullFirstComparator<DayOfWeek>(MONDAY_TO_SUNDAY_COMPARATOR);

    /**
     * Sorts as
     * Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday,
     * <tt>null</tt>
     * (with any <tt>null</tt>'s coming last).
     */
    public static final Comparator<DayOfWeek>
        MONDAY_TO_SUNDAY_NULL_LAST_COMPARATOR =
        new NullLastComparator<DayOfWeek>(MONDAY_TO_SUNDAY_COMPARATOR);

    /**
     * Sorts as
     * Sunday, Saturday, Friday, Thursday, Wednesday, Tuesday, Monday
     * with no protection against <tt>null</tt>'s.
     */
    public static final Comparator<DayOfWeek> SUNDAY_TO_MONDAY_COMPARATOR =
        new ReverseComparator<DayOfWeek>(MONDAY_TO_SUNDAY_COMPARATOR);

    /**
     * Sorts as
     * <tt>null</tt>,
     * Sunday, Saturday, Friday, Thursday, Wednesday, Tuesday, Monday
     * (with any <tt>null</tt>'s coming first).
     */
    public static final Comparator<DayOfWeek>
        SUNDAY_TO_MONDAY_NULL_FIRST_COMPARATOR =
        new NullFirstComparator<DayOfWeek>(SUNDAY_TO_MONDAY_COMPARATOR);

    /**
     * Sorts as
     * Sunday, Saturday, Friday, Thursday, Wednesday, Tuesday, Monday
     * <tt>null</tt>
     * (with any <tt>null</tt>'s coming last).
     */
    public static final Comparator<DayOfWeek>
        SUNDAY_TO_MONDAY_NULL_LAST_COMPARATOR =
        new NullLastComparator<DayOfWeek>(SUNDAY_TO_MONDAY_COMPARATOR);

    private final int serial;
    private final transient String name;
    private final transient String displayNameFull;
    private final transient String displayNameMedium;
    private final transient String displayNameShort;

    // private constructor to prevent outside instantiation
    private DayOfWeek(String name,
                     String displayNameFull,
                     String displayNameMedium,
                     String displayNameShort) {

        this.serial = getSerial(this);
        this.name = name;
        this.displayNameFull = displayNameFull;
        this.displayNameMedium = displayNameMedium;
        this.displayNameShort = displayNameShort;
    }

    private static synchronized int getSerial(DayOfWeek instance) {
        instanceList.add(instance);
        return nextSerial++ ;
    }

    /**
     * Returns an array of all the instances of <tt>DayOfWeek</tt>.
     * A cloned copy is returned, so no special care is required.
     */
    public static DayOfWeek[] getValues() {
        return (DayOfWeek[]) VALUES.clone();
    }

    /**
     * Returns the instance whose {@link #getName} method returns
     * a <tt>String</tt> that matches the <tt>name</tt> passed in.
     * The matching is done ignoring any case differences and after
     * trimming any leading or trailing whitespace on the string
     * passed in.
     *
     * @param name the name to search for.
     * @return the matching instance
     * @throws IllegalArgumentException if no match is found.
     */
    public static DayOfWeek valueOf(String name)
            throws IllegalArgumentException {

        String s = (name == null) ? "" : name.trim();
        for ( int i = 0; i < VALUES.length; i++ ) {
            if ( VALUES[i].name.equalsIgnoreCase(s) ) {
                return VALUES[i];
            }
        }

        throw new IllegalArgumentException("Can not find a match for '" + name
                + "'");
    }

    /**
     * Returns the instance whose {@link #getDisplayNameFull()} method returns
     * a <tt>String</tt> that matches the <tt>name</tt> passed in.
     * The matching is done ignoring any case differences and after
     * trimming any leading or trailing whitespace on the string
     * passed in.
     *
     * @param fullName the name to search for (Sunday, Monday, etc.)
     * @return the matching instance
     * @throws IllegalArgumentException if no match is found.
     */
    public static DayOfWeek valueOfDisplayNameFull(String fullName)
            throws IllegalArgumentException {

        String s = (fullName == null) ? "" : fullName.trim();
        for ( int i = 0; i < VALUES.length; i++ ) {
            if ( VALUES[i].displayNameFull.equalsIgnoreCase(s) ) {
                return VALUES[i];
            }
        }

        throw new IllegalArgumentException(
            "Can not find a match for '" + fullName + "'");
    }

    /**
     * Returns the instance whose {@link #getDisplayNameMedium()}
     * method returns
     * a <tt>String</tt> that matches the <tt>name</tt> passed in.
     * The matching is done ignoring any case differences and after
     * trimming any leading or trailing whitespace on the string
     * passed in.
     *
     * @param mediumName the name to search for (Sun, Mon, etc.)
     * @return the matching instance
     * @throws IllegalArgumentException if no match is found.
     */
    public static DayOfWeek valueOfDisplayNameMedium(String mediumName)
            throws IllegalArgumentException {

        String s = (mediumName == null) ? "" : mediumName.trim();
        for ( int i = 0; i < VALUES.length; i++ ) {
            if ( VALUES[i].displayNameMedium.equalsIgnoreCase(s) ) {
                return VALUES[i];
            }
        }

        throw new IllegalArgumentException(
            "Can not find a match for '" + mediumName + "'");
    }

    /**
     * Returns the instance whose {@link #getDisplayNameShort()}
     * method returns
     * a <tt>String</tt> that matches the <tt>name</tt> passed in.
     * The matching is done ignoring any case differences and after
     * trimming any leading or trailing whitespace on the string
     * passed in.
     *
     * @param shortName the name to search for (Su, Mo, Tu, etc.)
     * @return the matching instance
     * @throws IllegalArgumentException if no match is found.
     */
    public static DayOfWeek valueOfDisplayNameShort(String shortName)
            throws IllegalArgumentException {

        String s = (shortName == null) ? "" : shortName.trim();
        for ( int i = 0; i < VALUES.length; i++ ) {
            if ( VALUES[i].displayNameShort.equalsIgnoreCase(s) ) {
                return VALUES[i];
            }
        }

        throw new IllegalArgumentException(
            "Can not find a match for '" + shortName + "'");
    }

    /**
     * Returns one of the <tt>DayOfWeek</tt> instances converted
     * from the value from the "day of week" field of
     * {@link Calendar java.util.Calendar}.
     *
     * @param calendarDayOfWeek value from the "day of week" field of
     * {@link Calendar java.util.Calendar}.
     * @return one of the instances of this class
     * @throws IllegalArgumentException if the "day of week" code
     * passed in does not make sense.
     */
    public static DayOfWeek convertFromCalendar(int calendarDayOfWeek)
            throws IllegalArgumentException {

        switch ( calendarDayOfWeek ) {
            case Calendar.SUNDAY:
                return SUNDAY;
            case Calendar.MONDAY:
                return MONDAY;
            case Calendar.TUESDAY:
                return TUESDAY;
            case Calendar.WEDNESDAY:
                return WEDNESDAY;
            case Calendar.THURSDAY:
                return THURSDAY;
            case Calendar.FRIDAY:
                return FRIDAY;
            case Calendar.SATURDAY:
                return SATURDAY;

            default:
                throw new IllegalArgumentException(
                    "Unknown day of week value of: " + calendarDayOfWeek);
        }
    }

    // Used during de-serialization
    private Object readResolve() {
        // Only return one of the few instances.
        return VALUES[serial];
    }

    @Override
    public boolean equals(Object obj) {
        return this == obj;
    }

    @Override
    public int hashCode() {
        return serial;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(getClass().getName() + "[");
        sb.append("serial=" + serial);
        sb.append(", name=" + name);
        sb.append("]");
        return sb.toString();
    }

    /**
     * The "natural ordering" considers Sunday to be the first day of
     * the week. If you want to consider Monday to be the first day of
     * the week, then consider using {@link #MONDAY_TO_SUNDAY_COMPARATOR}.
     */
    public int compareTo(DayOfWeek other) {
        return serial - other.serial;
    }

    /**
     * Returns the name of the constant in Java (all caps: SUNDAY, MONDAY, etc).
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the full US English name of the day (Sunday, Monday,
     * Tuesday, Wednesday, Thursday, Friday, Saturday).
     */
    public String getDisplayNameFull() {
        return displayNameFull;
    }

    /**
     * Returns the 3-char US English abbreviation for the day
     * (Sun, Mon, Tue, Wed, Thu, Fri, Sat).
     */
    public String getDisplayNameMedium() {
        return displayNameMedium;
    }

    /**
     * Returns the 2-char US English abbreviation for the day
     * (Su, Mo, Tu, We, Th, Fr, Sa).
     */
    public String getDisplayNameShort() {
        return displayNameShort;
    }

    /**
     * Returns the number of days from this day of the week until
     * the specified <tt>target</tt> day of the week which is always
     * in the range 0..6. Zero is returned if the target is the same
     * day of the week as this instance. The largest value ever
     * returned is <tt>6</tt>.
     * <table border="1">
     * <tr align="center">
     * <td>This instance</td><td><tt>target</tt></td><td>Days Until</td>
     * </tr>
     * <tr align="center">
     * <td><tt>TUESDAY</tt></td><td><tt>WEDNESDAY</tt></td><td>1</td>
     * </tr>
     * <tr align="center">
     * <td><tt>TUESDAY</tt></td><td><tt>FRIDAY</tt></td><td>3</td>
     * </tr>
     * <tr align="center">
     * <td><tt>TUESDAY</tt></td><td><tt>SUNDAY</tt></td><td>5</td>
     * </tr>
     * <tr align="center">
     * <td><tt>TUESDAY</tt></td><td><tt>MONDAY</tt></td><td>6</td>
     * </tr>
     * <tr align="center">
     * <td><tt>TUESDAY</tt></td><td><tt>TUESDAY</tt></td><td>0</td>
     * </tr>
     * <tr align="center">
     * <td><tt>SATURDAY</tt></td><td><tt>MONDAY</tt></td><td>2</td>
     * </tr>
     * </table>
     */
    public int getDaysUntil(DayOfWeek target) {
        int diff = target.serial - serial;

        if ( diff < 0 ) {
            diff += 7;
        }

        return diff;
    }

    public boolean isSunday() {
        return this == SUNDAY;
    }

    public boolean isNotSunday() {
        return this != SUNDAY;
    }

    public boolean isMonday() {
        return this == MONDAY;
    }

    public boolean isNotMonday() {
        return this != MONDAY;
    }

    public boolean isTuesday() {
        return this == TUESDAY;
    }

    public boolean isNotTuesday() {
        return this != TUESDAY;
    }

    public boolean isWednesday() {
        return this == WEDNESDAY;
    }

    public boolean isNotWednesday() {
        return this != WEDNESDAY;
    }

    public boolean isThursday() {
        return this == THURSDAY;
    }

    public boolean isNotThursday() {
        return this != THURSDAY;
    }

    public boolean isFriday() {
        return this == FRIDAY;
    }

    public boolean isNotFriday() {
        return this != FRIDAY;
    }

    public boolean isSaturday() {
        return this == SATURDAY;
    }

    public boolean isNotSaturday() {
        return this != SATURDAY;
    }

    private static class MondayFirstComparator
            implements Comparator<DayOfWeek> {

        public int compare(DayOfWeek dow1, DayOfWeek dow2) {
            if ( dow1 == dow2 ) {
                return 0;
            }

            if ( dow1 == SUNDAY ) {
                return 1;
            }

            if ( dow2 == SUNDAY ) {
                return -1;
            }

            return dow1.serial - dow2.serial;
        }
    } // class MondayFirstComparator
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.