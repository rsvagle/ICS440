package com.programix.time;

import java.io.*;
import java.util.*;

import com.programix.math.*;
import com.programix.util.*;

/**
 * This class represents a simple calendar date without any time components
 * and without any sense of a time zone. It holds a year, month, and day.
 * <p>
 * <a id="PLAINDATE_V_DATETIME" name="PLAINDATE_V_DATETIME"
 * ><b><u><tt>PlainDate</tt> v. <tt>DateTime</tt></u></b></a><br />
 * The {@link DateTime} class has some of the same uses as a {@link PlainDate}
 * but <tt>DateTime</tt> represents a moment in time as the number of
 * milliseconds since January 1, 1970 began in UTC (see the
 * "Time Information" section in {@link DateTools}
 * for links to all kinds of information about dates and times and time zones).
 * To interpret a <tt>DateTime</tt> as a year, month, and day,
 * a time zone must be supplied to properly calculate what day it is
 * (even what month or what year it is!).
 * For example, consider it to be 12:30AM on January 1, 2007
 * [2007-01-01 00:30] in New York City.
 * That same moment in time is interpreted as 11:30PM on December 31, 2006
 * [2006-12-31 11:30] in Minneapolis, Minnesota. That's a different day,
 * a different month, and even a different year! Clearly the time zone used to
 * interpret a <tt>DateTime</tt> is critical.
 * <p>
 * The {@link PlainDate} class has some of the same uses as a {@link DateTime}
 * but <tt>PlainDate</tt> represents a year, month, and day without regard
 * to <i>any</i> time zone. Also, <tt>PlainDate</tt> does <i>not</i> contain any
 * time of day information (like hours, minutes, seconds, etc.).
 * <p>
 * This class uses the Immutability pattern. That is, instances are not
 * changeable after construction.
 *
 * @see DateTime
 * @see PlainDateRange
 * @see DateTimeRange
 * @see DateTools
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class PlainDate
        implements Comparable<PlainDate>, Serializable, Cloneable {

    private static final Factory factory = new Factory();

    private final int year;
    private final int month;
    private final int day;

    private transient String yearStr;
    private transient String monthStr;
    private transient String dayStr;

    private transient String ymdDash;
    private transient String mdySlash;

    private transient DayOfWeek dayOfWeek;

    private PlainDate(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    // Used to keep the instance count down during deserialization:
    private Object readResolve() {
        return create(year, month, day);
    }

    /**
     * Returns an instance of <tt>PlainDate</tt> for the specified
     * year, month, and day. If the combination of year, month,
     * and day is not valid, then an exception is thrown
     * (see {@link DateTools#isValidDate(int, int, int)}).
     *
     * @param year the four digit year, for example 2006.
     * @param month the month number, from the set [1..12].
     * @param day the day of the month, from the set [1..31].
     *
     * @throws PlainDateException if the specified year, month,
     * and day do not produce a valid combination.
     */
    public static PlainDate create(int year, int month, int day)
            throws PlainDateException {

        return factory.getPlainDate(year, month, day);
    }

    /**
     * Creates an instance by parsing the passed <tt>String</tt> into
     * a year, month, and day according to the specification stated below.
     * Also see {@link DateTools#parsePlainDate(String) parsePlainDate()}
     * method on {@link DateTools}.
     *
     * <p>
     * Ideal Format:
     * <pre>
     * yyyy-mm-dd
     * yyyy/mm/dd
     * yyyy.mm.dd
     * yyyymmdd
     * </pre>
     * <p>
     * Also accepted is the format commonly used in the USA:
     * <pre>
     * mm-dd-yyyy
     * mm/dd/yyyy
     * mm.dd.yyyy
     * mmddyyyy
     * </pre>
     * <p>
     * Examples of source strings and the date that they imply:
     * <table border="1" cellpadding="2" cellspacing="0">
     * <tr bgcolor="#ccffcc"><td><b>Source (<tt>String</tt>)</b></td>
     *   <td><b>Result (<tt>PlainDate</tt>)</b></td>
     *   <td><b>Comments</b></td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-02-14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>Ideal format</td></tr>
     * <tr><td nowrap="nowrap"><tt>"20050214"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>No delimiters</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005/02/14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>Slash date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005.02.14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>Dot date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005#02#14"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>Crazy date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005/5/6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>Slash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005-5-6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>Dash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005.5.6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>Dot with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2005^5^6"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>Crazy with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02-14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02/14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02.14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"0214"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"2.14"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-02-14</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"0405"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-04-05</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"4/5"</tt></td>
     *   <td nowrap="nowrap"><tt>2006-04-05</tt></td>
     *   <td>Default to current year (2006)</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02-14-2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>MDY (USA) format</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02142005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>MDY (USA) format, no delimiters</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02/14/2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>MDY (USA) with slash date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"02.14.2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-02-14</tt></td>
     *   <td>MDY (USA) with dot date delimiter</td></tr>
     * <tr><td nowrap="nowrap"><tt>"5/6/2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>MDY (USA) with slash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"5-6-2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>MDY (USA) with dash with single digits</td></tr>
     * <tr><td nowrap="nowrap"><tt>"5.6.2005"</tt></td>
     *   <td nowrap="nowrap"><tt>2005-05-06</tt></td>
     *   <td>MDY (USA) with dot with single digits</td></tr>
     * </table>
     *
     * @param dateStr formatted source to parse. Examples that work are:
     * "2006-01-31", "20060131", "01/31/2006", "01312006", "0131" (defaults
     * to the current year), and many more.
     * @throws PlainDateException if the passed string can not be interpreted
     * or if it represents an invalid date like 13-99-2005.
     */
    public static PlainDate create(String dateStr) throws PlainDateException {
        return DateTools.parsePlainDate(dateStr);
    }

    /**
     * Creates an instance for today in the specified time zone. The moment
     * in time is retrieved from {@link DateTools#getTime()} and then
     * the year, month, and day are derived using the specified time zone.
     */
    public static PlainDate createToday(TimeZone tz) {
        return DateTools.getPlainDate(DateTools.getNow(), tz);
    }

    /**
     * Creates an instance for today in the local VM time zone. The moment
     * in time is retrieved from {@link DateTools#getTime()} and then
     * the year, month, and day are derived using the local time zone.
     */
    public static PlainDate createTodayLocal() {
        return DateTools.getPlainDateLocal(DateTools.getNow());
    }

    /**
     * Creates an instance for today in the UTC time zone. The moment
     * in time is retrieved from {@link DateTools#getTime()} and then
     * the year, month, and day are derived using the UTC time zone.
     */
    public static PlainDate createTodayUTC() {
        return DateTools.getPlainDateUTC(DateTools.getNow());
    }

    /**
     * Creates an instance for yesterday in the specified time zone. The moment
     * in time is retrieved from {@link DateTools#getTime()} and then
     * the year, month, and day are derived using the specified time zone.
     */
    public static PlainDate createYesterday(TimeZone tz) {
        return DateTools.getPlainDate(DateTools.getYesterday(tz), tz);
    }

    /**
     * Creates an instance for yesterday in the local VM time zone. The moment
     * in time is retrieved from {@link DateTools#getTime()} and then
     * the year, month, and day are derived using the local time zone.
     */
    public static PlainDate createYesterdayLocal() {
        return DateTools.getPlainDateLocal(DateTools.getYesterdayLocal());
    }

    /**
     * Creates an instance for yesterday in the UTC time zone. The moment
     * in time is retrieved from {@link DateTools#getTime()} and then
     * the year, month, and day are derived using the UTC time zone.
     */
    public static PlainDate createYesterdayUTC() {
        return DateTools.getPlainDateUTC(DateTools.getYesterdayUTC());
    }

    /**
     * Creates an instance for tomorrow in the specified time zone. The moment
     * in time is retrieved from {@link DateTools#getTime()} and then
     * the year, month, and day are derived using the specified time zone.
     */
    public static PlainDate createTomorrow(TimeZone tz) {
        return DateTools.getPlainDate(DateTools.getTomorrow(tz), tz);
    }

    /**
     * Creates an instance for tomorrow in the local VM time zone. The moment
     * in time is retrieved from {@link DateTools#getTime()} and then
     * the year, month, and day are derived using the local time zone.
     */
    public static PlainDate createTomorrowLocal() {
        return DateTools.getPlainDateLocal(DateTools.getTomorrowLocal());
    }

    /**
     * Creates an instance for tomorrow in the UTC time zone. The moment
     * in time is retrieved from {@link DateTools#getTime()} and then
     * the year, month, and day are derived using the UTC time zone.
     */
    public static PlainDate createTomorrowUTC() {
        return DateTools.getPlainDateUTC(DateTools.getTomorrowUTC());
    }

    /**
     * Returns the four-digit year as an <tt>int</tt>.
     */
    public int getYear() {
        return year;
    }

    /**
     * Returns the month as a <tt>int</tt> in the range <tt>1..12</tt>
     */
    public int getMonth() {
        return month;
    }

    /**
     * Returns the day as a <tt>int</tt> in the range <tt>1..31</tt>
     * (as appropriate for the specific month).
     */
    public int getDay() {
        return day;
    }

    /**
     * Returns the {@link DayOfWeek} for this date.
     */
    public DayOfWeek getDayOfWeek() {
        synchronized ( this ) {
            if ( dayOfWeek == null ) {
                dayOfWeek = DateTools.getDayOfWeek(year, month, day);
            }
        }

        return dayOfWeek;
    }

    /**
     * Returns the year as a 4-digit string. For example: 1996, 2000, 2004.
     */
    public String getYearStr() {
        checkStringCache();
        return yearStr;
    }

    /**
     * Returns the month as a 2-digit string. For example: 01, 09, 12.
     */
    public String getMonthStr() {
        checkStringCache();
        return monthStr;
    }

    /**
     * Returns the day as a 2-digit string. For example: 01, 05, 10, 29, 31.
     */
    public String getDayStr() {
        checkStringCache();
        return dayStr;
    }

    private synchronized void checkStringCache() {
        if ( yearStr == null ) {
            yearStr = NumberTools.formatPadZero(year, 4);
            monthStr = NumberTools.formatPadZero(month, 2);
            dayStr = NumberTools.formatPadZero(day, 2);

            ymdDash = yearStr + "-" + monthStr + "-" + dayStr;
            mdySlash = monthStr + "/" + dayStr + "/" + yearStr;
        }
    }

    /**
     * Returns this date in a yyyy-mm-dd format.
     */
    public String formatYmdDash() {
        checkStringCache();
        return ymdDash;
    }

    /**
     * Returns this date in a yyyy/mm/dd format.
     */
    public String formatYmdSlash() {
        checkStringCache();
        return yearStr + "/" + monthStr + "/" + dayStr;
    }

    /**
     * Returns this date in a yyyy.mm.dd format.
     */
    public String formatYmdDot() {
        checkStringCache();
        return yearStr + "." + monthStr + "." + dayStr;
    }

    /**
     * Returns this date in a yyyymmdd format.
     */
    public String formatYmd() {
        checkStringCache();
        return yearStr + monthStr + dayStr;
    }

    /**
     * Returns this date in a mm-dd-yyyy format.
     */
    public String formatMdyDash() {
        checkStringCache();
        return monthStr + "-" + dayStr + "-" + yearStr;
    }

    /**
     * Returns this date in a mm/dd/yyyy format.
     */
    public String formatMdySlash() {
        checkStringCache();
        return mdySlash;
    }

    /**
     * Returns this date in a mm.dd.yyyy format.
     */
    public String formatMdyDot() {
        checkStringCache();
        return monthStr + "." + dayStr + "." + yearStr;
    }

    /**
     * Returns this date in a mmddyyyy format.
     */
    public String formatMdy() {
        checkStringCache();
        return monthStr + dayStr + yearStr;
    }

    /**
     * Converts this <tt>PlainDate</tt> into a {@link DateTime}
     * using noon for the time of day and using the specified
     * timezone. This <tt>PlainDate</tt>'s <tt>year</tt>, <tt>month</tt>,
     * and <tt>day</tt> are combined with <tt>12</tt> for the hour of
     * the day and a {@link DateTime} instance is created
     * interpreting those values in the specified timezone <tt>tz</tt>.
     *
     * @param tz the timezone to use to determine the moment.
     */
    public DateTime toDateTime(TimeZone tz) {
        return DateTools.getDateTime(year, month, day, tz);
    }

    /**
     * Converts this <tt>PlainDate</tt> into a {@link DateTime}
     * using noon for the time of day and using the local Java VM's
     * timezone. This <tt>PlainDate</tt>'s <tt>year</tt>, <tt>month</tt>,
     * and <tt>day</tt> are combined with <tt>12</tt> for the hour of
     * the day and a {@link DateTime} instance is created
     * interpreting those values in the local time zone.
     */
    public DateTime toDateTimeLocal() {
        return DateTools.getDateTimeLocal(year, month, day);
    }

    /**
     * Converts this <tt>PlainDate</tt> into a {@link DateTime}
     * using noon for the time of day and using the UTC
     * timezone. This <tt>PlainDate</tt>'s <tt>year</tt>, <tt>month</tt>,
     * and <tt>day</tt> are combined with <tt>12</tt> for the hour of
     * the day and a {@link DateTime} instance is created
     * interpreting those values in the UTC time zone.

     */
    public DateTime toDateTimeUTC() {
        return DateTools.getDateTimeUTC(year, month, day);
    }

    /**
     * Returns a new <tt>PlainDate</tt> for the first day of the
     * month for this instance's year and month.
     */
    public PlainDate getFirstDayOfCurrentMonth() {
        return create(year, month, 1);
    }

    /**
     * Returns a new <tt>PlainDate</tt> for the last day of the
     * month for this instance's year and month.
     */
    public PlainDate getLastDayOfCurrentMonth() {
        return create(year, month, DateTools.getLastDayOfMonth(year, month));
    }

    /**
     * Returns a new <tt>PlainDate</tt> offset from this instance
     * by the specified number of days.
     * See {@link DateTools#addDays(PlainDate, int)} for more detail.
     *
     * @param offset the number of days to add (can be a negative number
     * to go backwards in time).
     */
    public PlainDate addDays(int offset) {
        return DateTools.addDays(this, offset);
    }

    /**
     * Returns a new <tt>PlainDate</tt> offset from this instance
     * by the specified number of weeks.
     * See {@link DateTools#addWeeks(PlainDate, int)} for more detail.
     *
     * @param offset the number of weeks to add (can be a negative number
     * to go backwards in time).
     */
    public PlainDate addWeeks(int offset) {
        return DateTools.addWeeks(this, offset);
    }

    /**
     * Returns a new <tt>PlainDate</tt> offset from this instance
     * by the specified number of months.
     * See {@link DateTools#addMonths(PlainDate, int)} for more detail.
     *
     * @param offset the number of months to add (can be a negative number
     * to go backwards in time).
     */
    public PlainDate addMonths(int offset) {
        return DateTools.addMonths(this, offset);
    }

    /**
     * Returns a new <tt>PlainDate</tt> offset from this instance
     * by the specified number of years.
     * See {@link DateTools#addYears(PlainDate, int)} for more detail.
     *
     * @param offset the number of years to add (can be a negative number
     * to go backwards in time).
     */
    public PlainDate addYears(int offset) {
        return DateTools.addYears(this, offset);
    }


    /**
     * Adds days (as needed) to roll this <tt>PlainDate</tt>
     * forward until the specified <tt>targetDayOfWeek</tt> is matched.
     * The number of days added ranges from <tt>0</tt> up to a maximum
     * of <tt>6</tt>.
     * If the day of the week for this <tt>PlainDate</tt> is already
     * the specified target day of the week, then this <tt>PlainDate</tt>
     * is simply returned (no change).
     * <p>
     * To find the first Monday in September 2007 (the answer is 2007-09-03):
     * <pre class="preshade">
     * PlainDate firstMondayInSeptember =
     *     PlainDate.create("2007-09-01").addDaysUntil(DayOfWeek.MONDAY);
     * </pre>
     * <p>
     * To find the first Monday in October 2007 (the starting date 2007-10-01
     * is actually the answer [no days need to be added]):
     * <pre class="preshade">
     * PlainDate firstMondayInOctober =
     *     PlainDate.create("2007-10-01").addDaysUntil(DayOfWeek.MONDAY);
     * </pre>
     * <p>
     * To find the first Wednesday in a month that an arbitrary date belongs
     * to (in this case the month is June 2007, and we start from the 18th
     * and go back to the first and then forward&mdash;if necessary&mdash;to
     * find Wednesday. In this case, the answer is 2007-06-06):
     * <p>
     * <pre class="preshade">
     * PlainDate randomDayInJune = PlainDate.create("2007-06-18");
     * PlainDate firstWednesdayInJune =
     *     randomDayInJune.getFirstDayOfCurrentMonth().addDaysUntil(
     *         DayOfWeek.WEDNESDAY);
     * </pre>
     * <p>
     * The next example takes an arbitrary date (in this case 2007-05-08)
     * and locates all of the occurrences of a particular day of the
     * week (in this case Thursday) in that date's month (May 2007).
     * The resulting dates printed are the five Thursdays that occur
     * in May 2007: 2007-05-03, 2007-05-10, 2007-05-17,
     * 2007-05-24, and 2007-05-31.
     * <pre class="preshade">
     * PlainDate startDate = PlainDate.create("2007-05-08");
     * DayOfWeek targetDayOfWeek = DayOfWeek.THURSDAY;
     *
     * PlainDate currDate =
     *     startDate.getFirstDayOfCurrentMonth().addDaysUntil(
     *         targetDayOfWeek);
     *
     * while ( currDate.getMonth() == startDate.getMonth() ) {
     *     System.out.println("currDate=" + currDate);
     *     currDate = currDate.addDays(1).addDaysUntil(targetDayOfWeek);
     * }
     * </pre>
     *
     * @param targetDayOfWeek the desired day of the week
     * @return a new <tt>PlainDate</tt> whose day of the week matches the
     * specified target day of the week.
     * If this <tt>PlainDate</tt>'s day of the week was already a match
     * for the target, then this instance is simply returned.
     *
     * @see #subtractDaysUntil(DayOfWeek)
     * @see DateTools#addDaysUntil(PlainDate, DayOfWeek)
     */
    public PlainDate addDaysUntil(DayOfWeek targetDayOfWeek) {
        return DateTools.addDaysUntil(this, targetDayOfWeek);
    }

    /**
     * Subtracts days (as needed) to roll this <tt>PlainDate</tt>
     * backward until the specified <tt>targetDayOfWeek</tt> is matched.
     * The number of days subtracted ranges from <tt>0</tt> up to a maximum
     * of <tt>6</tt>.
     * If the day of the week for this <tt>PlainDate</tt> is already
     * the specified target day of the week, then this <tt>PlainDate</tt>
     * is simply returned (no change).
     * <p>
     * To find the last Friday in July 2007 (the answer is 2007-07-27):
     * <pre class="preshade">
     * PlainDate randomDayInJuly = PlainDate.create("2007-07-04");
     * PlainDate lastFridayInJuly =
     *     randomDayInJuly.getLastDayOfCurrentMonth().subtractDaysUntil(
     *         DayOfWeek.FRIDAY);
     * </pre>
     *
     * @param targetDayOfWeek the desired day of the week
     * @return a new <tt>PlainDate</tt> whose day of the week matches the
     * specified target day of the week.
     * If this <tt>PlainDate</tt>'s day of the week was already a match
     * for the target, then this instance is simply returned.
     *
     * @see #addDaysUntil(DayOfWeek)
     * @see DateTools#subtractDaysUntil(PlainDate, DayOfWeek)
     */
    public PlainDate subtractDaysUntil(DayOfWeek targetDayOfWeek) {
        return DateTools.subtractDaysUntil(this, targetDayOfWeek);
    }

    /**
     * Returns the integer number of years that this date is before the
     * specified <tt>otherPlainDate</tt>.
     * If this date is after the specified date, then a negative number
     * is returned.
     * <p>
     * To figure out how old someone is from a date of birth, you can
     * use code like this:
     * <pre class="preshade">
     * PlainDate dateOfBirth = PlainDate.create("2001-06-15");
     * int age = dateOfBirth.getYearsBefore(PlainDate.createTodayLocal());
     * </pre>
     *
     * @param otherPlainDate the date to measure to
     */
    public int getYearsBefore(PlainDate otherPlainDate) {
        boolean before = beforeOrEqualTo(otherPlainDate);
        int yearsBefore = 0;

        PlainDate start = (before) ? this : otherPlainDate;
        PlainDate end = (before) ? otherPlainDate : this;

        yearsBefore = end.year - start.year;

        if ( end.month < start.month ) {
            yearsBefore--;
        } else if ( end.month == start.month ) {
            if ( end.day < start.day ) {
                yearsBefore--;
            }
        }

        return (before) ? yearsBefore : -yearsBefore;
    }

    /**
     * Returns the date in the ISO format: yyyy-mm-dd.
     */
    @Override
    public String toString() {
        return formatYmdDash();
    }

    public boolean equals(PlainDate other) {
        return this == other;
    }

    @Override
    public boolean equals(Object other) {
        return this == other;
    }

    @Override
    public int hashCode() {
        return (year << 5) ^ (month << 3) ^ day;
    }

    /**
     * Returns <tt>-1</tt> if this instance's date comes before the passed date,
     * <tt>0</tt> if they are the same, and <tt>1</tt> if this instance's date
     * comes after the passed date.
     * @throws IllegalArgumentException if null if passed.
     */
    public int compareTo(PlainDate otherPlainDate)
            throws IllegalArgumentException {

        if ( this == otherPlainDate ) {
            return 0;
        }

        ObjectTools.paramNullCheck(otherPlainDate, "otherPlainDate");

        if ( year < otherPlainDate.year ) {
            return -1;
        } else if ( year > otherPlainDate.year ) {
            return 1;
        } else {
            if ( month < otherPlainDate.month ) {
                return -1;
            } else if ( month > otherPlainDate.month ) {
                return 1;
            } else {
                if ( day < otherPlainDate.day ) {
                    return -1;
                } else if ( day > otherPlainDate.day ) {
                    return 1;
                } else {
                    return 0;
                }
            }
        }
    }

    /**
     * Returns <tt>true</tt> if the this instance's date comes <i>before</i>
     * the date passed as a parameter.
     * If they are equal, <tt>false</tt> is returned.
     * @throws IllegalArgumentException if null if passed.
     */
    public boolean before(PlainDate otherPlainDate)
            throws IllegalArgumentException {

        return compareTo(otherPlainDate) < 0;
    }

    /**
     * Returns <tt>true</tt> if the this instance's date comes <i>before</i>
     * or is the same as the date passed as a parameter.
     * @throws IllegalArgumentException if null if passed.
     */
    public boolean beforeOrEqualTo(PlainDate otherPlainDate)
            throws IllegalArgumentException {

        return (this == otherPlainDate) || (compareTo(otherPlainDate) <= 0);
    }

    /**
     * Returns <tt>true</tt> if the this instance's date comes <i>after</i>
     * the date passed as a parameter.
     * If they are equal, <tt>false</tt> is returned.
     * @throws IllegalArgumentException if null if passed.
     */
    public boolean after(PlainDate otherPlainDate)
            throws IllegalArgumentException {

        return compareTo(otherPlainDate) > 0;
    }

    /**
     * Returns <tt>true</tt> if the this instance's date comes <i>after</i>
     * or is the same as the date passed as a parameter.
     * @throws IllegalArgumentException if null if passed.
     */
    public boolean afterOrEqualTo(PlainDate otherPlainDate)
            throws IllegalArgumentException {

        return (this == otherPlainDate) || (compareTo(otherPlainDate) >= 0);
    }

    /**
     * Simply returns this instance as instances are immutable and our
     * flyweight pattern keeps there from being more than one instance for
     * the same year, month, and day.
     */
    @Override
    public Object clone() {
        return this;
    }

    private static class Factory {
        private static final int MIN_FAST_YEAR = 1800;
        private static final int MAX_FAST_YEAR = 2099;

        private Year[] fastYearList;
        private Map<Integer, Year> yearMap;

        public Factory() {
            fastYearList = new Year[MAX_FAST_YEAR - MIN_FAST_YEAR + 1];

            for ( int i = 0; i < fastYearList.length; i++ ) {
                fastYearList[i] = new Year(MIN_FAST_YEAR + i);
            }

            yearMap = Collections.synchronizedMap(new HashMap<Integer, Year>());
        }

        public Year getYear(int year) {
            if ( MIN_FAST_YEAR <= year && year <= MAX_FAST_YEAR ) {
                return fastYearList[year - MIN_FAST_YEAR];
            }

            synchronized ( yearMap ) {
                Integer key = new Integer(year);
                Year y = (Year) yearMap.get(key);
                if ( y == null ) {
                    y = new Year(year);
                    yearMap.put(key, y);
                }

                return y;
            }
        }

        public PlainDate getPlainDate(int year, int month, int day)
                throws PlainDateException {

            return getYear(year).getMonth(month).getPlainDate(day);
        }
    } // class Factory

    private static class Year {
        private final int yearNumber;
        private Month[] monthList;

        public Year(int yearNumber) {
            this.yearNumber = yearNumber;
            this.monthList = new Month[12];
        }

        public synchronized Month getMonth(int monthNumber)
                throws PlainDateException {

            try {
                int idx = monthNumber - 1;

                Month m = monthList[idx];

                if ( m == null ) {
                    m = new Month(yearNumber, monthNumber);
                    monthList[idx] = m;
                }

                return m;
            } catch ( ArrayIndexOutOfBoundsException x ) {
                throw new PlainDateException("Invalid month=" + monthNumber +
                    " for year=" + yearNumber);
            }
        }
    } // class Year

    private static class Month {
        private final int yearNumber;
        private final int monthNumber;
        private PlainDate[] dayList;

        public Month(final int yearNumber, final int monthNumber) {
            this.yearNumber = yearNumber;
            this.monthNumber = monthNumber;

            int lastDayOfMonth =
                DateTools.getLastDayOfMonth(yearNumber, monthNumber);

            dayList = new PlainDate[lastDayOfMonth];
            for ( int i = 0; i < dayList.length; i++ ) {
                int dayNumber = i + 1;
                if ( DateTools.isValidDate(
                        yearNumber, monthNumber, dayNumber) ) {

                    dayList[i] =
                        new PlainDate(yearNumber, monthNumber, dayNumber);
                } else {
                    dayList[i] = null;
                }
            }
        }

        public PlainDate getPlainDate(int dayNumber) throws PlainDateException {
            try {
                PlainDate d = dayList[dayNumber - 1];

                if ( d == null ) {
                    PlainDateException.throwInvalid(
                        yearNumber, monthNumber, dayNumber);
                }

                return d;
            } catch ( ArrayIndexOutOfBoundsException x ) {
                throw PlainDateException.createInvalid(
                    yearNumber, monthNumber, dayNumber);
            }
        }
    } // class Month
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.