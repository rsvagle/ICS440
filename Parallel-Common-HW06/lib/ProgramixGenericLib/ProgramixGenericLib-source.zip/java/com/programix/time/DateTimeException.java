package com.programix.time;

/**
 * Thrown to signal a problem processing a {@link DateTime}. This exception
 * is a {@link RuntimeException}, so there is not requirement to catch it
 * when it is truly unexpected.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DateTimeException extends RuntimeException {
    public DateTimeException() {
        super();
    }

    public DateTimeException(String message) {
        super(message);
    }
    
    public DateTimeException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public DateTimeException(Throwable cause) {
        super(cause);
    }
    
    public static void throwParse(String source) 
            throws DateTimeException {
        
        throw new DateTimeException("Unable to parse '" + source 
            + "' as a DateTime.");
        
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.