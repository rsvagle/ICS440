package com.programix.gui.image;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;

import javax.swing.*;

import com.programix.io.*;

/**
 * A Swing component that can be used to simple show an image (picture) on a
 * component. Instances are <tt>Serializable</tt> as only the bytes
 * needed to re-created the image are transmitted. The internal
 * {@link BufferedImage} is declared to be (<tt>transient</tt>)
 * and is left behind. If the image was originally created from a
 * a <tt>byte[]</tt>, these bytes are retained for transmission.
 * If an image was used to create the <tt>Picture</tt>, then a
 * <tt>byte[]</tt> is created only on-demand (in the lossless, compressed
 * PNG format).
 * <p>
 * If you don't need a {@link JComponent} but just need a
 * {@link BufferedImage}, then you can use {@link ImageTools}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class Picture extends JComponent implements Serializable {
    private transient BufferedImage image;
    private byte[] imageBytes;
    private transient Insets tmpInsets;

    /**
     * The {@link BufferedImage} to be drawn on this {@link JComponent}.
     * The <tt>byte[]</tt> representation of the image is not created
     * during construction@mdash;only on demand.
     *
     * @param bufferedImage the image to draw on this component.
     */
    public Picture(BufferedImage bufferedImage) {
        this.image = bufferedImage;
    }

    /**
     * Creates a {@link BufferedImage} from the {@link Image} specified
     * and calls the constructor that takes a <tt>BufferedImage</tt>
     * parameter. If the {@link Image} reference passed in is actually
     * pointing to a {@link BufferedImage}, then this constructor is very
     * efficient and simply does an explicit cast and calls the
     * other constructor.
     *
     * @param image the {@link Image} to convert to a {@link BufferedImage}.
     */
    public Picture(Image image) {
        this(ImageTools.convertToBuffered(image));
    }

    /**
     * Creates a <tt>Picture</tt> by storing the specified bytes until
     * there is a demand for the {@link BufferedImage}. Typically,
     * the <tt>BufferedImage</tt> is created the first time that
     * {@link #paint(Graphics)} is called. For help is getting
     * a <tt>byte[]</tt> to use to create a
     *
     * @param imageBytes the formatted bytes that can be decoded into
     * an image.
     */
    public Picture(byte[] imageBytes) {
        this.imageBytes = imageBytes;
    }

    /**
     * Reads all the bytes from <tt>source</tt> and passes them to the
     * constructor that takes a <tt>byte[]</tt>.
     */
    public Picture(InputStream source) throws IOException {
        this(IOTools.readAll(source));
    }

    /**
     * Reads all the bytes from <tt>source</tt> and passes them to the
     * constructor that takes a <tt>byte[]</tt>.
     */
    public Picture(File source) throws IOException {
        this(IOTools.readAll(source));
    }

    /**
     * Reads all the bytes from <tt>source</tt> and passes them to the
     * constructor that takes a <tt>byte[]</tt>.
     */
    public Picture(URL source) throws IOException {
        this(IOTools.readAll(source));
    }

    /**
     * Reads all the bytes from the resource specified by
     * <tt>resourceName</tt> and passes them to the
     * constructor that takes a <tt>byte[]</tt>.
     */
    public Picture(String resourceName) throws IOException {
        this(IOTools.readAllFromResource(resourceName));
    }

    /**
     * Creates a Picture with no initial image.
     */
    public Picture() {
        this.imageBytes = null;
        this.image = null;
    }

    private synchronized void writeObject(ObjectOutputStream oos)
            throws IOException {

        getImageBytes(); // be sure that these are ready
        oos.defaultWriteObject();
    }

    /**
     * Clears out any current image (blanks out the picture).
     */
    public synchronized void clearImage() {
        setImageBytes(null);
    }

    public synchronized BufferedImage getImage() {
        if ( image == null ) {
            if ( imageBytes != null && imageBytes.length > 0 ) {
                image = ImageTools.createImage(imageBytes);
            } else {
                return null;
            }
        }

        return image;
    }

    public synchronized void setImage(BufferedImage bufferedImage) {
        this.image = bufferedImage;
        this.imageBytes = null;

        revalidate();
        repaint();
    }

    /**
     * Creates a {@link BufferedImage} from the {@link Image} specified
     * and calls the <tt>setImage</tt> method that takes a
     * <tt>BufferedImage</tt> parameter.
     * If the {@link Image} reference passed in is actually
     * pointing to a {@link BufferedImage}, then this method is very
     * efficient and simply does an explicit cast and calls the
     * other method.
     *
     * @param image the {@link Image} to convert to a {@link BufferedImage}.
     */
    public synchronized void setImage(Image image) {
        setImage(ImageTools.convertToBuffered(image));
    }

    public synchronized byte[] getImageBytes()
            throws ImageTools.ImageException {

        if ( imageBytes == null ) {
            if ( image != null ) {
                imageBytes = ImageTools.createPNGBytes(image);
            } else {
                return null;
            }
        }

        return imageBytes;
    }

    public synchronized void setImageBytes(byte[] imageBytes) {
        this.imageBytes = imageBytes;
        this.image = null;

        revalidate();
        repaint();
    }

    public synchronized int getImageWidth() {
        return (getImage() == null) ? 0 : getImage().getWidth();
    }

    public synchronized int getImageHeight() {
        return (getImage() == null) ? 0 : getImage().getHeight();
    }

    @Override
    public Dimension getPreferredSize() {
        if ( isPreferredSizeSet() ) {
            return super.getPreferredSize();
        } else {
            synchronized ( this ) {
                int imWidth = getImageWidth();
                int imHeight = getImageHeight();

                Insets insets = getInsets(tmpInsets);

                return new Dimension(
                    insets.left + insets.right + imWidth,
                    insets.top + insets.bottom + imHeight);
            }
        }
    }

    @Override
    protected synchronized void paintComponent(Graphics g) {
        try {
            BufferedImage im = getImage();

            if ( im != null ) {
                Insets insets = getInsets(tmpInsets);
                g.drawImage(im, insets.left, insets.top, null);
            }
        } catch ( ImageTools.ImageException x) {
            // ignore
        }
    }

    // TODO - 4/28/2005
    //  For copy and paste, consider Web Start and non-Web Start clients?
    //    paste()  [check for BufferedImage, Image, byte[], 'file path']
    //    copy()   [as a BufferedImage]
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.