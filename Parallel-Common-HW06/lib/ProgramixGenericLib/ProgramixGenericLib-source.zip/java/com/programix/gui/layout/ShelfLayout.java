package com.programix.gui.layout;

import java.awt.*;
import java.util.*;

import com.programix.gui.*;

/**
 * Lays out components in a single horizontal row (on a "shelf").
 * Each component added gets its preferred width.
 * The column gap specifies how many pixels are between each column
 * on the shelf (the inherited row gap has no effect on this layout as
 * there is always only one row).
 * The border gap specifies the distance between the laid out components
 * and the container's own border (if any).
 * <p>
 * The {@link AnchorPoint} specified for the layout manager indicates where the
 * contents of the container should be placed if there is extra room.
 * See {@link #getAnchorPoint}, {@link #setAnchorPoint}, and the
 * {@link AnchorPoint} that may be specified during construction.
 * <p>
 * When components are added to this container, an optional <i>constraint</i>
 * can be specified for each. If no constraint is specified (or if <tt>null</tt>
 * is used as the constraint), the default of {@link AnchorPoint#NORTH}
 * will be used.
 * <p>
 * <hr width="50%" align="left" />
 * Example: <img src="{@docRoot}/images/ShelfLayoutBasic.png"
 * width="400" height="150" alt="ShelfLayoutBasic"
 * align="top"><br clear="all" />
 * Could have been created from:
 * <pre class="preshade">
 * public static JPanel createBasicDemoPane() {
 *     JPanel shelf = new JPanel(new ShelfLayout());
 *     shelf.setBorder(
 *         BorderFactory.createMatteBorder(10, 10, 10, 10, Color.BLUE));
 *     shelf.add(makeLabel("1", 50, 20, Color.RED));
 *     shelf.add(makeLabel("2", 20, 50, Color.YELLOW));
 *     shelf.add(makeLabel("3", 35, 40, Color.GREEN), AnchorPoint.SOUTH);
 *     shelf.add(makeLabel("4", 50, 45, Color.MAGENTA));
 *     shelf.add(makeLabel("5", 55, 80, Color.ORANGE));
 *     shelf.add(makeLabel("6", 15, 25, Color.CYAN));
 *     return shelf;
 * }
 *
 * public static JLabel makeLabel(String text,
 *                                int prefWidth,
 *                                int prefHeight,
 *                                Color bgColor) {
 *
 *     JLabel label = new JLabel(text, JLabel.CENTER);
 *     label.setOpaque(true);
 *     label.setBackground(bgColor);
 *     label.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
 *     label.setPreferredSize(new Dimension(prefWidth, prefHeight));
 *     return label;
 * }
 * </pre>
 *
 * @see AnchorTableLayout
 * @see FormLayout
 * @see ColumnButtonLayout
 * @see RowButtonLayout
 * @see StackLayout
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ShelfLayout extends AbstractTableLayout implements LayoutManager2 {
    private AnchorPoint defaultCellAnchorPoint = AnchorPoint.NORTH;
    private Map<Component, Object> constraintMap;

    /**
     * Creates a single row (shelf) layout.
     *
     * @param colGap space between columns.
     *                 See {@link #setColumnGap setColumnGap()}.
     * @param borderGap space around the outside of the row.
     *                 See {@link #setBorderGap setBorderGap()}.
     * @param anchorPoint region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint()}.
     */
    public ShelfLayout(int colGap,
                       int borderGap,
                       AnchorPoint anchorPoint) {

        super(0, colGap, borderGap, anchorPoint);

    }

    /**
     * Creates a single row (shelf) layout.
     * Uses {@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT}.
     *
     * @param colGap space between columns.
     *                 See {@link #setColumnGap setColumnGap()}.
     * @param borderGap space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap()}.
     */
    public ShelfLayout(int colGap, int borderGap) {
        this(colGap, borderGap, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Creates a single row (shelf) layout.
     * Uses {@link #DEFAULT_COL_GAP DEFAULT_COL_GAP}.
     * Uses {@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP}.
     *
     * @param anchorPoint region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint()}.
     */
    public ShelfLayout(AnchorPoint anchorPoint) {
        this(DEFAULT_COL_GAP, DEFAULT_BORDER_GAP, anchorPoint);
    }

    /**
     * Creates a single row (shelf) layout.
     * Uses {@link #DEFAULT_COL_GAP DEFAULT_COL_GAP}.
     * Uses {@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT}.
     *
     * @param borderGap space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap()}.
     */
    public ShelfLayout(int borderGap) {
        this(DEFAULT_COL_GAP, borderGap, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Creates a single row (shelf) layout.
     * Uses {@link #DEFAULT_COL_GAP DEFAULT_COL_GAP}.
     * Uses {@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP}.
     * Uses {@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT}.
     */
    public ShelfLayout() {
        this(DEFAULT_COL_GAP, DEFAULT_BORDER_GAP, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Called by the graphical subsystem when a component is being removed
     * from the container.
     */
    @Override
    public synchronized void removeLayoutComponent(Component comp) {
        if ( constraintMap != null && comp != null ) {
            constraintMap.remove(comp);
        }
    }

    /**
     * Called by the graphical subsystem when a component is being added
     * to the container with constraints.
     */
    public synchronized void addLayoutComponent(Component comp,
                                                Object constraints) {

        if ( constraints instanceof AnchorPoint && comp != null ) {
            if ( constraintMap == null ) {
                constraintMap = new HashMap<Component, Object>(17);
            }

            constraintMap.put(comp, constraints);
        }
    }

    public synchronized Dimension maximumLayoutSize(Container target) {
        return new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE);
    }

    public synchronized float getLayoutAlignmentX(Container target) {
        return 0.5f;
    }

    public synchronized float getLayoutAlignmentY(Container target) {
        return 0.5f;
    }

    public synchronized void invalidateLayout(Container target) {
    }

    /**
     * Returns the current default <tt>AnchorPoint</tt> used to position
     * a component within its cell boundaries when no constraints are
     * specified during the add of the component.
     */
    public synchronized AnchorPoint getDefaultCellAnchorPoint() {
        return defaultCellAnchorPoint;
    }

    /**
     * Changes the current default <tt>AnchorPoint</tt> used to position
     * a component within its cell boundaries when no constraints are
     * specified during the add of the component.
     */
    public synchronized void setDefaultCellAnchorPoint(AnchorPoint ap) {
        this.defaultCellAnchorPoint = (ap == null) ? AnchorPoint.NORTH : ap;
    }

    @Override
    protected synchronized CellData createCellData(Container pane) {
        return new ShelfCellData(pane);
    }

    private class ShelfCellData extends CellData {
        protected ShelfCellData(Container pane) {
            super(pane);
        }

        @Override
        protected void calcRowAndColumnCounts() {
            colCount = comp.length;
            rowCount = 1;
        }

        @Override
        protected void calcRowHeightsAndColumnWidths() {
            rowHeight = new int[rowCount];
            colWidth = new int[colCount];

            for ( int i = 0; i < comp.length; i++ ) {
                int r = i / colCount;
                int c = i % colCount;

                rowHeight[r] = Math.max(rowHeight[r], compPrefSize[i].height);
                colWidth[c] = Math.max(colWidth[c], compPrefSize[i].width);
            }
        }

        @Override
        protected void layoutComponents() {
            // local references to facilitate speed of access
            AnchorPoint rap = defaultCellAnchorPoint;
            Map<Component, Object> cmap = constraintMap;

            Rectangle scratchRect = new Rectangle();

            for ( int c = 0; c < colCount; c++ ) {
                for ( int r = 0; r < rowCount; r++ ) {
                    int compIdx = (r * colCount) + c;
                    if ( compIdx >= comp.length ) {
                        // This happens only when we're on the last row
                        // and when that last row does not have enough
                        // components to fill the rest of the columns.
                        break;
                    }

                    Component child = comp[compIdx];

                    AnchorPoint ap = null;

                    if ( cmap != null ) {
                        ap = (AnchorPoint) cmap.get(child);
                    }

                    if ( ap == null ) {
                        ap = rap;
                    }

                    ap.calcBounds(
                        compPrefSize[compIdx].width,
                        compPrefSize[compIdx].height,
                        colWidth[c],
                        rowHeight[r],
                        scratchRect);

                    scratchRect.x += colX[c];
                    scratchRect.y += rowY[r];

                    child.setBounds(scratchRect);
                }
            }
        }
    } // class ShelfCellData
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.