package com.programix.gui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * A subclass of {@link JFrame} that just draws a frame outline when the
 * frame is being resized. When resize events have not come for a short time,
 * the full repainting is done. This tool can be used instead of <tt>JFrame</tt>
 * when a flickering resize is undesirable.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class SimpleResizeFrame extends JFrame {
    private PaintMode paintMode = new PaintMode();
    private ResizeListener resizeListener = new ResizeListener();

    public SimpleResizeFrame(String title) {
        super(title);

        addComponentListener(resizeListener);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        if ( paintMode.isSpecialPaint() ) {
            g.setColor(Color.DARK_GRAY);
            g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.drawRect(1, 1, getWidth() - 3, getHeight() - 3);
        }
    }

    @Override
    public void dispose() {
        // It appears that sometimes the listener is null when this
        // method is called... perhaps as a result of something that
        // happens in the superclass's constructor. Anyway, this
        // check is defensive to avoid a NullPointerException:
        ResizeListener listener = resizeListener;
        if ( listener != null ) {
            removeComponentListener(resizeListener);
            resizeListener.stopRequest();
        }

        super.dispose();
    }

    private class ResizeListener extends ComponentAdapter implements Runnable {
        private long endTime;

        private Thread internalThread;
        private volatile boolean noStopRequested;

        public ResizeListener() {
            endTime = Long.MIN_VALUE;

            noStopRequested = true;
            internalThread = new Thread(this, "ResizeListener");
            internalThread.start();
        }

        @Override
        public void componentResized(ComponentEvent e) {
//            System.out.println("getWidth()=" + getWidth() +
//                               ", getHeight()=" + getHeight());
            resetEndTime();
        }

        private synchronized void resetEndTime() {
            paintMode.setSpecialPaint(true);

            endTime = System.currentTimeMillis() + 250;
            notifyAll();
        }

        private synchronized long getEndTime() {
            return endTime;
        }

        public void run() {
            try {
                synchronized ( this ) {
                    while ( noStopRequested ) {
                        long now = System.currentTimeMillis();
                        long end = getEndTime();

                        if ( now >= end ) {
                            paintMode.setSpecialPaint(false);
                            wait();
                        } else {
                            long timeLeft = end - now;
                            wait(timeLeft);
                        }
                    }
                }
            } catch ( InterruptedException x ) {
                // ignore
            } finally {
                // Be sure that this gets done--even if an unexpected error
                // occurs, and even if someone stops this thread.
                paintMode.setSpecialPaint(false);
            }
        }

        public void stopRequest() {
            noStopRequested = false;
            internalThread.interrupt();
        }
    } // class ResizeListener

    private class PaintMode extends Object implements Runnable {
        private boolean specialPaint = false;

        public synchronized boolean isSpecialPaint() {
            return specialPaint;
        }

        public synchronized void setSpecialPaint(boolean specialPaint) {
            if ( this.specialPaint != specialPaint ) {
                this.specialPaint = specialPaint;
                SwingUtilities.invokeLater(this);
            }
        }

        // Called by the event thread
        public void run() {
            if ( isSpecialPaint() ) {
                getRootPane().setVisible(false);
            } else {
                getRootPane().setVisible(true);
                getRootPane().revalidate();

                invalidate();
                validate();
            }

            getRootPane().repaint();
            repaint();
        }
    } // class PaintMode
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.