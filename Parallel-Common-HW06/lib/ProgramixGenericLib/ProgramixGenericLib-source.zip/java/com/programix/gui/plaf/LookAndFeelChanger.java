package com.programix.gui.plaf;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.plaf.metal.*;

import com.programix.util.*;

/**
 * Used to cycle through a set of look and feels using a keystroke.
 * <p>
 * The methods (and constructors) of this class can be called by any thread
 * (not just by the event thread).
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class LookAndFeelChanger {
    private static final String ACTION_NAME =
        LookAndFeelChanger.class.getName();

    private final MetalLookAndFeel metalLookAndFeel = new MetalLookAndFeel();
    private View systemView = null;

    private final List<View> viewList = new ArrayList<View>();
    private int currentView = 0;

    /**
     * Creates a new changer and binds it to the specified component and
     * listens for the specified keystroke.
     *
     * @param bindTo component to bind to, if null, no keystroke assigned.
     * @param keyStroke the keystroke to listen for to show the next view.
     */
    public LookAndFeelChanger(JComponent bindTo, String keyStroke) {
        bind(bindTo, keyStroke);
    }

    /**
     * Creates a changer bound to the specified component that advanced the
     * view when <tt>F12</tt> is pressed.
     */
    public LookAndFeelChanger(JComponent bindTo) {
        this(bindTo, "F12");
    }

    /**
     * Creates a changes that is not bound to any component.
     */
    public LookAndFeelChanger() {
        this(null, null);
    }

    /**
     * Creates a standard changer, add all the standard metal views, and
     * shows the first view.
     */
    public static LookAndFeelChanger createStandard(JComponent bindTo,
                                                    String keyStroke) {

        LookAndFeelChanger changer = new LookAndFeelChanger(bindTo, keyStroke);
        changer.addStandardMetalViews();
        changer.showFirstLook();
        return changer;
    }

    public void bind(final JComponent bindTo,
                     final String keyStroke) {

        if ( SwingUtilities.isEventDispatchThread() == false ) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    bind(bindTo, keyStroke);
                }
            });

            return;
        }

        if ( bindTo != null && StringTools.isNotEmpty(keyStroke) ) {
            Action showNextAction = new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    showNextLook();
                }
            };

            bindTo.getInputMap(
                JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(
                    KeyStroke.getKeyStroke(keyStroke), ACTION_NAME);

            bindTo.getActionMap().put(ACTION_NAME, showNextAction);
        }
    }

    public void showFirstLook() {
        showNextLook(true);
    }

    public void showNextLook() {
        showNextLook(false);
    }

    private synchronized void showNextLook(final boolean resetToFirst) {
        if ( SwingUtilities.isEventDispatchThread() == false ) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    showNextLook(resetToFirst);
                }
            });

            return;
        }

        int viewCount = viewList.size();

        if ( viewCount < 1 ) {
            return; // nothing to switch to
        }

        View oldView = ( 0 <= currentView && currentView < viewCount ) ?
            ((View) viewList.get(currentView)) : null;

        View newView = null;
        int newViewIdx = (resetToFirst == true) ? 0 :
            ((currentView + 1) % viewCount);

        boolean stillLooking = true;
        for ( int i = 0; i < viewCount && stillLooking; i++ ) {
            try {
                newView = (View) viewList.get(newViewIdx);
                newView.activate();
                stillLooking = false;
            } catch ( Exception x ) {
                // View can not be activated, skip it for now...
                newViewIdx = (newViewIdx + 1) % viewCount;
            }
        }

        if ( stillLooking ) {
            // No view was successfully activated, nothing to do
            return;
        } else {
            currentView = newViewIdx;
        }

        //LookAndFeel lookAndFeel = UIManager.getLookAndFeel();
        //boolean decorate = lookAndFeel.getSupportsWindowDecorations();
        //System.out.println("lookAndFeel=" + lookAndFeel);
        //System.out.println("decorate=" + decorate);

        boolean decorationChange =
            (oldView == null) ||
            (oldView.useWindowDecorations() != newView.useWindowDecorations());

        if ( decorationChange ) {
            JFrame.setDefaultLookAndFeelDecorated(
                newView.useWindowDecorations());
            JDialog.setDefaultLookAndFeelDecorated(
                newView.useWindowDecorations());
        }

        Frame[] frame = Frame.getFrames();
        for ( int i = 0; i < frame.length; i++ ) {
            if ( decorationChange && (frame[i] instanceof JFrame) ) {
                int style = newView.useWindowDecorations()
                    ? JRootPane.FRAME : JRootPane.NONE;

                JFrame jf = (JFrame) frame[i];
                jf.getRootPane().setWindowDecorationStyle(style);

                jf.setVisible(false);
                jf.dispose();
                jf.setUndecorated(newView.useWindowDecorations());
                jf.setVisible(true);
            }

            SwingUtilities.updateComponentTreeUI(frame[i]);
            frame[i].validate();

            Window[] window = frame[i].getOwnedWindows();
            for ( int j = 0; j < window.length; j++ ) {
                Window win = window[j];

                if ( decorationChange && (win instanceof RootPaneContainer) ) {
                    RootPaneContainer rpc = (RootPaneContainer) win;

                    int style = JRootPane.NONE;
                    if ( newView.useWindowDecorations() ) {
                        if ( win instanceof JFrame ) {
                            style = JRootPane.FRAME;
                        } else if ( win instanceof JDialog ) {
                            style = JRootPane.PLAIN_DIALOG;
                        }
                    }

                    rpc.getRootPane().setWindowDecorationStyle(style);
                }

                SwingUtilities.updateComponentTreeUI(win);
                win.validate();
            }
        }
    }

    /**
     * Creates and adds a set of standard Metal themes.
     */
    public synchronized void addStandardMetalViews() {
        if ( SwingUtilities.isEventDispatchThread() == false ) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    addStandardMetalViews();
                }
            });

            return;
        }

        addMetalThemeView("javax.swing.plaf.metal.OceanTheme",
            "Ocean Theme");
        addMetalThemeView("com.programix.gui.plaf.theme.LargeOceanTheme",
            "Large Ocean Theme");
        addMetalThemeView("com.programix.gui.plaf.theme.ExtraLargeOceanTheme",
            "XL Ocean Theme");
        addMetalThemeView("javax.swing.plaf.metal.DefaultMetalTheme",
            "Steel Metal Theme");
        addMetalThemeView("com.programix.gui.plaf.theme.AquaMetalTheme",
            "Aqua Metal Theme");
        addMetalThemeView("com.programix.gui.plaf.theme.GreenMetalTheme",
            "Green Metal Theme");
        addMetalThemeView("com.programix.gui.plaf.theme.KhakiMetalTheme",
            "Khaki Metal Theme");
        addMetalThemeView("com.programix.gui.plaf.theme.ContrastMetalTheme",
            "High Contrast Metal Theme");
        addMetalThemeView(
            "com.programix.gui.plaf.theme.ExtraLargeContrastMetalTheme",
            "XL High Contrast Metal Theme");
    }

    /**
     * Returns true if the specified class is available.
     * Specifically, the class can be found and loaded, it can be instantiated
     * with a public zero-arg constructor, and it is a subclass of
     * {@link MetalTheme}.
     */
    public static boolean isMetalThemeAvailable(String metalThemeClassName) {
        try {
            Class<?> c = Class.forName(metalThemeClassName);
            Object obj = c.newInstance();
            return obj instanceof MetalTheme;
        } catch ( Throwable x ) {
            return false;
        }
    }

    /**
     * Creates a {@link MetalView} for the specified theme class. The view
     * is added to the list of views. If the view can not be created
     * (likely because the Metal theme class does not exist on this machine)
     * <tt>null</tt> is returned.
     *
     * @param themeClassName classname of a subclass of {@link MetalTheme}.
     * @param themeDisplayName user appropriate name for display
     */
    public synchronized void addMetalThemeView(
                final String themeClassName,
                final String themeDisplayName) {

        if ( SwingUtilities.isEventDispatchThread() == false ) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    addMetalThemeView(themeClassName, themeDisplayName);
                }
            });

            return;
        }

        if ( isMetalThemeAvailable(themeClassName) == false ) {
            return;
        }

        try {
            Class<?> c = Class.forName(themeClassName);
            MetalTheme theme = (MetalTheme) c.newInstance();

            MetalView view = new MetalView(theme, themeDisplayName);
            viewList.add(view);
        } catch ( Exception x ) {
            // quietly ignore and don't add a view
        }
    }

    /**
     * Gets the {@link View} for the default system look and feel. If there are
     * any problems locating and creating the default system look and feel,
     * an exception is thrown.
     * <p>
     * NOTE: This method must be called by the event handling thread (or else
     * an exception is thrown).
     *
     * @throws UnsupportedLookAndFeelException if the default system look
     * and feel is unavailable.
     * @throws IllegalStateException if not called by the event handling thread.
     */
    public synchronized View getSystemView()
            throws UnsupportedLookAndFeelException,
                   IllegalStateException {

        if ( SwingUtilities.isEventDispatchThread() == false ) {
            throw new IllegalStateException("getSystemView() may only be " +
                    "called by the event handling thread");
        }

        if ( systemView == null ) {
            systemView = new SystemView();
        }

        return systemView;
    }

    /**
     * Adds the view for the default system look and feel to the set of views.
     * <p>
     * NOTE: This method must be called by the event handling thread (or else
     * an exception is thrown).
     *
     * @return true if the view was created and added, false if the view could
     * not be created.
     * @throws IllegalStateException if not called by the event handling thread.
     */
    public synchronized boolean addSystemView() {
        if ( SwingUtilities.isEventDispatchThread() == false ) {
            throw new IllegalStateException("addSystemView() may only be " +
                    "called by the event handling thread");
        }

        try {
            viewList.add(getSystemView());
            return true;
        } catch ( UnsupportedLookAndFeelException x ) {
            return false;
        }
    }

    /**
     * Used to define a generic wrapper for a look and feel change. This
     * is useful when only the <i>theme</i> of a look and feel needs
     * to change.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static interface View {
        /**
         * Called when this <tt>View</tt> should become the current
         * <tt>View</tt>.
         * If <i>any</i> exception is thrown from this method, the look and
         * feel changer assumes that the change to this <tt>View</tt> was
         * unsuccessful and the changer automatically moves on to attempt
         * to activate the next view.
         * <p>
         * The implementation of this method should call:
         * <pre class="preshade">
         * UIManager.setLookAndFeel
         * </pre>
         * as appropriate. However, after <tt>activate</tt> returns
         * (without throwing an exception) the {@link LookAndFeelChanger} will
         * automatically call <tt>SwingUtilities.updateComponentTreeUI</tt>
         * for <i>all</i> of the frames and windows. If will also
         * {@link Component#validate() validate} each frame and window to
         * have components re-layout with the new look.
         * <p>
         * NOTE: This method must be called by the event handling thread (or
         * else an IllegalStateException is thrown).
         *
         * @exception Exception if this <tt>View</tt> can not be activated.
         * The stack trace will generally be sent to <tt>System.err</tt> and
         * the look and feel changer will attempt to activate the next view.
         */
        void activate() throws Exception;

        /**
         * Returns a name that describes this view in a format suitable for
         * display to the user.
         */
        String getDisplayName();

        /**
         * Returns true if this view is backed by a LookAndFeel that wants
         * to decorate the windows entirely.
         */
        boolean useWindowDecorations();
    } // interface View

    /**
     * An implementation of {@link View} that is useful for times when all
     * that needs to change is the {@link MetalTheme} of the
     * {@link MetalLookAndFeel}.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public class MetalView implements View {
        private MetalTheme theme;
        private String displayName;

        public MetalView(MetalTheme theme, String displayName) {
            this.theme = theme;
            this.displayName = displayName;
        }

        /**
         * Changes the current {@link MetalTheme} and then assures that
         * the current look and feel is the {@link MetalLookAndFeel}.
         */
        public void activate() throws Exception {
            if ( SwingUtilities.isEventDispatchThread() == false ) {
                throw new IllegalStateException("activate() may only be " +
                        "called by the event handling thread");
            }

            MetalLookAndFeel.setCurrentTheme(theme);
            UIManager.setLookAndFeel(metalLookAndFeel);
        }

        public String getDisplayName() {
            return displayName;
        }

        public boolean useWindowDecorations() {
            return true;
        }
    } // class MetalView

    public static class LookAndFeelView implements View {
        private LookAndFeel lookAndFeel;

        public LookAndFeelView(LookAndFeel lookAndFeel) {
            this.lookAndFeel = lookAndFeel;
        }

        public LookAndFeelView(String lookAndFeelClassName)
                throws UnsupportedLookAndFeelException {

            try {
                Class<?> c = Class.forName(lookAndFeelClassName);
                lookAndFeel = (LookAndFeel) c.newInstance();
            } catch ( Exception x ) {
                throw new UnsupportedLookAndFeelException(x.toString());
            }
        }

        public void activate() throws Exception {
            if ( SwingUtilities.isEventDispatchThread() == false ) {
                throw new IllegalStateException("activate() may only be " +
                        "called by the event handling thread");
            }

            UIManager.setLookAndFeel(lookAndFeel);
        }

        public String getDisplayName() {
            return lookAndFeel.getName();
        }

        public boolean useWindowDecorations() {
            return lookAndFeel.getSupportsWindowDecorations();
        }

        public LookAndFeel getLookAndFeel() {
            return lookAndFeel;
        }
    } // class LookAndFeelView

    private static class SystemView extends LookAndFeelView implements View {
        public SystemView() throws UnsupportedLookAndFeelException {
            super(UIManager.getSystemLookAndFeelClassName());
        }
    } // class SystemView
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.