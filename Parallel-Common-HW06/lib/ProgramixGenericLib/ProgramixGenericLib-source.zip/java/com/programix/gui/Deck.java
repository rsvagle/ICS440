package com.programix.gui;

import java.awt.*;
import java.util.*;

import javax.swing.*;

// TODO - look into focus grabbing ideas

/**
 * Stacks up panels on top of each each using a {@link CardLayout}, like
 * a <i>deck</i> of cards. A {@link Card Deck.Card} is created from
 * (and belongs to) a specific <tt>Deck</tt>. A <tt>Card</tt> can move
 * itself to the top of the <tt>Deck</tt> without knowing the name assigned
 * to it by the internal <tt>CardLayout</tt>.
 * <p>
 * The cards are kept in an order&mdash;the order that they were created.
 * As cards are removed, they are deleted from the chain. Each card has
 * the ability to show the "next" card or the "previous" card (if there is a
 * next or previous card). However, the order does not <i>have</i> to be used:
 * at any time, any card can become the front card.
 * <p>
 * This class is written to be multithread-safe. All <tt>public</tt> methods
 * can be called by any thread (not just the event thread!) at any time.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class Deck extends JPanel {
	private CardLayout cardLayout;
	private int autoCount;
	private Object lock;
	private Card head;
	private Card tail;

    private Map<String, Card> nameCardMap;

    /**
     * Creates a new deck with no cards initially in it.
     */
	public Deck() {
		lock = new Object();
		cardLayout = new CardLayout();
		setLayout(cardLayout);
		autoCount = 0;
		head = null;
		tail = null;
        nameCardMap = new HashMap<String, Card>();
	}

    /**
     * Creates a new card with the specified name and puts it at the end
     * of the deck. If an automatically generated card name is preferred,
     * see {@link #createCard()}.
     *
     * @param cardName the name to give the card, must be a unique name that
     * no other card this the deck already has.
     * @return the newly created card.
     * @throws IllegalArgumentException if there is already a card stored
     * under the specified name.
     */
	public Card createCard(String cardName) throws IllegalArgumentException {
		synchronized ( lock ) {
            Card card = new Card(cardName);

            Card firstCardForName = (Card) nameCardMap.put(cardName, card);
            if ( firstCardForName != null ) {
                // There was already a card stored under this name, put it
                // back and then complain.
                nameCardMap.put(cardName, firstCardForName); // ejects ours
                throw new IllegalArgumentException(
                    "Duplicate cardName of '" + cardName + "' in this deck");
            }

            if ( head == null ) {
                // there are no cards in the deck
                head = card;
                tail = card;
            } else {
                // there was a least one card already in the deck
                card.prevCard = tail;
                tail.nextCard = card;
                tail = card;
            }

            // FIXME - not mt-safe:
			add(card, cardName);
			revalidate();
			return card;
		}
	}

    /**
     * Creates a new card with a generated name and puts it at the end
     * of the deck. If a specific card name is preferred,
     * see {@link #createCard(String)}.
     * <p>
     * The generated name of the card is starts with <tt>"_auto"</tt> followed
     * by a integral number. This name is guaranteed to be unique for this
     * deck. The numbers used for the suffix are not recycled. If the rare
     * case of a duplicate name occurs (for example, if a card has already
     * been <i>manually</i> named <tt>"_auto46"</tt> and this would have
     * been the generated name, this method continues to increment the
     * number until a unique name is found, perhaps: <tt>"_auto47"</tt>).
     * As are all methods on this class, this method <i>is</i>
     * multithread-safe (there are no race condition risks by having
     * two threads call this method simultaneously).
     *
     * @return the newly created card.
     */
	public Card createCard() {
		synchronized ( lock ) {
            while ( true ) {
                try {
                    String name = "_auto" + String.valueOf(autoCount);
                    autoCount++;
                    return createCard(name);
                } catch ( IllegalArgumentException x ) {
                    // ignore and try again
                }
            }
		}
	}

	public void removeCard(Card card) {
		synchronized ( lock ) {
        }
    }

    public void removeCard(String cardName) {
		synchronized ( lock ) {
        }
    }

	public void removeAllCards() {
		synchronized ( lock ) {
//			tailPtr = null;
			removeAll();
			revalidate();
		}
	}

	private void removeCardFromDeck(Card card) {
		synchronized ( lock ) {
//			tailPtr = card.prevCard;
			remove(card);

			// Allows the focus to be freed from the missing components--
			// which also allows the keyboard menu nav to still work.
			GuiTools.clearGlobalFocus();

			revalidate();
		}
	}

	private void bringToTop(String cardName) {
		synchronized ( lock ) {
			cardLayout.show(this, cardName);

			// Allows the focus to be freed from the previous component,
			// which allows the keyboard menu nav to still work.
			GuiTools.clearGlobalFocus();
		}
	}

	private Card getCardForComponent(Component comp) {
	    while ( comp != null ) {
	        if ( comp instanceof Card ) {
	            return (Card) comp;
	        }
	        comp = comp.getParent();
	    }
	    return null;
	}

	private void junk() {
	    Deck.Card card = null;
	    Window window = SwingUtilities.windowForComponent(card);
	    if ( window != null ) {
	        Component focusOwner = window.getFocusOwner();
	        if ( focusOwner != null ) {
	            // a component in this window has the focus
	            Card cardWithFocus = getCardForComponent(focusOwner);
	            if ( cardWithFocus != null ) {

	            }
	        }
	    }
	}

	/**
	 * Always has an <i>initial</i> layout of <tt>GridLayout</tt> with one cell.
	 */
	public class Card extends JPanel {
		private String cardName;
		private Card prevCard;
		private Card nextCard;

        private Component firstFocusComp;
		private Runnable requestFocusTask;

		private Card(String cardName) {
			super(GuiTools.ONE_CELL_GRID);
			this.cardName = cardName;
            this.prevCard = null;
            this.nextCard = null;

			requestFocusTask = new Runnable() {
					public void run() {
						if ( firstFocusComp != null ) {
							firstFocusComp.requestFocus();
						} else {
							requestFocus();
						}
					}
				};
		}

		public void toFront() {
			synchronized ( lock ) {
				revalidate();
				bringToTop(cardName);
				SwingUtilities.invokeLater(requestFocusTask);
			}
		}

		/**
		 * Does nothing if there isn't a previous card
		 */
		public void showPreviousCard() {
			synchronized ( lock ) {
				if ( prevCard != null ) {
					prevCard.toFront();
				}
			}
		}

		public void remove() {
			synchronized ( lock ) {
				if ( prevCard != null ) {
					prevCard.nextCard = nextCard;
				}

				if ( nextCard != null ) {
					nextCard.prevCard = prevCard;
				}

				removeCardFromDeck(this);


				showPreviousCard();
			}
		}

		public void setFirstFocusComponent(Component firstFocusComp) {
			synchronized ( lock ) {
				this.firstFocusComp = firstFocusComp;
			}
		}

		public Deck getDeck() {
			return Deck.this;
		}
	} // inner class Card

/*
	public static void main(String[] args) {
		Deck d = new Deck();

		final Deck.Card card1 = d.createCard("card1");
		card1.add(new JLabel("card1"));

		final Deck.Card card2 = d.createCard("card2");
		card2.add(new JLabel("card2"));

		final boolean exitOnClose = true;
		final JFrame f = new JFrame("Deck Demo");
		f.setContentPane(d);
		f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		f.addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent e) {
					f.setVisible(false);
					f.dispose();
					if ( exitOnClose ) {
						System.exit(0);
					}
				}
			});

		f.pack();
		//f.setSize(600, 500);
		f.setVisible(true);

		try {
			Thread.sleep(3000);
		} catch ( InterruptedException x ) {
			Thread.currentThread().interrupt(); // reassert intr
			return;
		}

		SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					card2.toFront();
				}
			});
	}
*/
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.