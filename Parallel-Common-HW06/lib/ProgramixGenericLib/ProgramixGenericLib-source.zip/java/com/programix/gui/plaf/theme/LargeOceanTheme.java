package com.programix.gui.plaf.theme;

import java.awt.*;

import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.metal.*;

public class LargeOceanTheme extends OceanTheme {
    @Override
    public String getName() {
        return "Large Ocean";
    }

    private final FontUIResource controlFont = new FontUIResource("Dialog",
        Font.BOLD, 18);
    private final FontUIResource systemFont = new FontUIResource("Dialog",
        Font.PLAIN, 18);
    private final FontUIResource userFont = new FontUIResource("SansSerif",
        Font.PLAIN, 18);
    private final FontUIResource smallFont = new FontUIResource("Dialog",
        Font.PLAIN, 14);

    @Override
    public FontUIResource getControlTextFont() {
        return controlFont;
    }

    @Override
    public FontUIResource getSystemTextFont() {
        return systemFont;
    }

    @Override
    public FontUIResource getUserTextFont() {
        return userFont;
    }

    @Override
    public FontUIResource getMenuTextFont() {
        return controlFont;
    }

    @Override
    public FontUIResource getWindowTitleFont() {
        return controlFont;
    }

    @Override
    public FontUIResource getSubTextFont() {
        return smallFont;
    }

    @Override
    public void addCustomEntriesToTable(UIDefaults table) {
        super.addCustomEntriesToTable(table);

        final int internalFrameIconSize = 22;
        table.put("InternalFrame.closeIcon", MetalIconFactory
            .getInternalFrameCloseIcon(internalFrameIconSize));
        table.put("InternalFrame.maximizeIcon", MetalIconFactory
            .getInternalFrameMaximizeIcon(internalFrameIconSize));
        table.put("InternalFrame.iconifyIcon", MetalIconFactory
            .getInternalFrameMinimizeIcon(internalFrameIconSize));
        table.put("InternalFrame.minimizeIcon", MetalIconFactory
            .getInternalFrameAltMaximizeIcon(internalFrameIconSize));

        table.put("ScrollBar.width", new Integer(21));
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.