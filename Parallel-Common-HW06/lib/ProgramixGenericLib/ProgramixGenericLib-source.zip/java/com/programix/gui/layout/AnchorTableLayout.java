package com.programix.gui.layout;

import java.awt.*;
import java.util.*;

import com.programix.gui.*;
import com.programix.util.*;

/**
 * A {@link AbstractTableLayout table layout} that allows an
 * {@link AnchorPoint} to be specified
 * for some (or all) of child components added,
 * for some (or all) of the columns, and
 * for some (or all) of the column headers.
 * Specifically, an {@link AnchorPoint} is optionally specified for each
 * of the columns.
 * Additionally, a different {@link AnchorPoint} is optionally specified
 * for each of the columns in the table's <i>first row</i> (table header).
 * Furthermore, a different {@link AnchorPoint} is optionally specified for
 * each of the <tt>Component</tt>'s added to the table by specifying
 * an {@link AnchorPoint} as a constraint at the time that the
 * <tt>Component</tt> is added to its <tt>Container</tt>
 * (using the {@link Container#add(Component, Object)
 * add(Component comp, Object constraint)} method from {@link Container}).
 * <p>
 * Some subclasses of this layout manager will have defaults for columns.
 * Those defaults should be used unless a specific anchor has been specified
 * for the column.
 * If {@link #getColumnAnchorPoint(int) getColumnAnchorPoint(int colIdx)}
 * returns <tt>null</tt>, this indicates that there has not been a request to
 * override the default anchor point for all rows in the column.
 * If {@link #getColumnHeaderAnchorPoint(int)
 * getColumnHeaderAnchorPoint(int colIdx)}
 * returns <tt>null</tt>, this indicates that there has not been a request to
 * override the default anchor point for the first row in the column.
 * <p>
 * The anchor used is the first one found from the following (precedence):<ul>
 * <li>If an <tt>AnchorPoint</tt> was passed as the constraint when the
 * <tt>Component</tt> was added to the <tt>Container</tt>, then that
 * <tt>AnchorPoint</tt> is used.
 * <li>If the row is the first row and a column header anchor point has been
 * defined for the column, then that column header anchor point is used.</li>
 * <li>For any row, if a column anchor point has been defined for the
 * column, then that column anchor point is used.</li>
 * <li>For any row, the default column anchor point for the particular
 * layout manager (possibly a subclass of this class) is used for the column
 * if the layout manager has defined a default anchor point.</li>
 * <li>If none of the above are matched, then {@link AnchorPoint#CENTER}
 * is used.</li>
 * <p>
 * There's nothing in this class that prevents a single instance from
 * being used simultaneously by multiple containers. If this class is
 * a subclass, be sure that this is also true for the particular
 * subclass that is being used.
 *
 * @see FormLayout
 * @see ColumnButtonLayout
 * @see RowButtonLayout
 * @see StackLayout
 * @see ShelfLayout
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class AnchorTableLayout extends AbstractTableLayout
        implements LayoutManager2 {

    private AnchorPoint[] columnAnchorPoint = AnchorPoint.ZERO_LEN_ARRAY;
    private AnchorPoint[] columnHeaderAnchorPoint = AnchorPoint.ZERO_LEN_ARRAY;

    private Map<Component, Object> constraintMap;

    /**
     * Creates a table layout with the specified number of columns.
     *
     * @param columnCount number of columns in this table.
     *                 See {@link #setColumnCount(int) setColumnCount()}.
     * @param rowGap space between rows.
     *                 See {@link #setRowGap setRowGap()}.
     * @param colGap space between columns.
     *                 See {@link #setColumnGap setColumnGap}.
     * @param borderGap space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap()}.
     * @param anchorPoint region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint()}.
     */
    public AnchorTableLayout(int columnCount,
                             int rowGap,
                             int colGap,
                             int borderGap,
                             AnchorPoint anchorPoint) {

        super(rowGap, colGap, borderGap, anchorPoint);
        setColumnCount(columnCount);
    }

    /**
     * Creates a table layout with the specified number of columns.
     * Uses {@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT}.
     *
     * @param columnCount number of columns in this table.
     *                 See {@link #setColumnCount(int) setColumnCount()}.
     * @param rowGap space between rows.
     *                 See {@link #setRowGap setRowGap()}.
     * @param colGap space between columns.
     *                 See {@link #setColumnGap setColumnGap}.
     * @param borderGap space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap()}.
     */
    public AnchorTableLayout(int columnCount,
                             int rowGap,
                             int colGap,
                             int borderGap) {

        this(columnCount, rowGap, colGap, borderGap, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Creates a table layout with the specified number of columns.
     * Uses {@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP}.
     *
     * @param columnCount number of columns in this table.
     *                 See {@link #setColumnCount(int) setColumnCount()}.
     * @param rowGap space between rows.
     *                 See {@link #setRowGap setRowGap()}.
     * @param colGap space between columns.
     *                 See {@link #setColumnGap setColumnGap}.
     * @param anchorPoint region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint()}.
     */
    public AnchorTableLayout(int columnCount,
                             int rowGap,
                             int colGap,
                             AnchorPoint anchorPoint) {

        this(columnCount, rowGap, colGap, DEFAULT_BORDER_GAP, anchorPoint);
    }

    /**
     * Creates a table layout with the specified number of columns.
     * Uses {@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP}.
     * Uses {@link #DEFAULT_COL_GAP DEFAULT_COL_GAP}.
     * Uses {@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT}.
     *
     * @param columnCount number of columns in this table.
     *                 See {@link #setColumnCount(int) setColumnCount()}.
     * @param borderGap space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap()}.
     */
    public AnchorTableLayout(int columnCount, int borderGap) {
        this(columnCount, DEFAULT_ROW_GAP, DEFAULT_COL_GAP,
            borderGap, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Creates a table layout with the specified number of columns.
     * Uses {@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP}.
     * Uses {@link #DEFAULT_COL_GAP DEFAULT_COL_GAP}.
     *
     * @param columnCount number of columns in this table.
     *                 See {@link #setColumnCount(int) setColumnCount()}.
     * @param borderGap space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap()}.
     * @param anchorPoint region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint()}.
     */
    public AnchorTableLayout(int columnCount,
                             int borderGap,
                             AnchorPoint anchorPoint) {

        this(columnCount, DEFAULT_ROW_GAP, DEFAULT_COL_GAP,
            borderGap, anchorPoint);
    }

    /**
     * Creates a table layout with the specified number of columns.
     * Uses {@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP}.
     * Uses {@link #DEFAULT_COL_GAP DEFAULT_COL_GAP}.
     * Uses {@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP}.
     *
     * @param columnCount number of columns in this table.
     *                 See {@link #setColumnCount(int) setColumnCount()}.
     * @param anchorPoint region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint()}.
     */
    public AnchorTableLayout(int columnCount,
                             AnchorPoint anchorPoint) {

        this(columnCount, DEFAULT_ROW_GAP, DEFAULT_COL_GAP,
            DEFAULT_BORDER_GAP, anchorPoint);
    }

    /**
     * Creates a table layout with the specified number of columns.
     * Uses {@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP}.
     * Uses {@link #DEFAULT_COL_GAP DEFAULT_COL_GAP}.
     * Uses {@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP}.
     * Uses {@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT}.
     *
     * @param columnCount number of columns in this table.
     *                 See {@link #setColumnCount(int) setColumnCount()}.
     */
    public AnchorTableLayout(int columnCount) {
        this(columnCount, DEFAULT_ROW_GAP, DEFAULT_COL_GAP,
            DEFAULT_BORDER_GAP, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Called by the graphical subsystem when a component is being removed
     * from the container.
     */
    @Override
    public synchronized void removeLayoutComponent(Component comp) {
        if ( constraintMap != null && comp != null ) {
            constraintMap.remove(comp);
        }
    }

    /**
     * Called by the graphical subsystem when a component is being added
     * to the container with constraints.
     */
    public synchronized void addLayoutComponent(Component comp,
                                                Object constraints) {

        if ( constraints instanceof AnchorPoint && comp != null ) {
            if ( constraintMap == null ) {
                constraintMap = new HashMap<Component, Object>(17);
            }

            constraintMap.put(comp, constraints);
        }
    }

    public synchronized Dimension maximumLayoutSize(Container target) {
        return new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE);
    }

    public synchronized float getLayoutAlignmentX(Container target) {
        return 0.5f;
    }

    public synchronized float getLayoutAlignmentY(Container target) {
        return 0.5f;
    }

    public synchronized void invalidateLayout(Container target) {
    }

    /**
     * Returns the number of columns currently defined for this table.
     * @see #setColumnCount(int)
     */
    public synchronized int getColumnCount() {
        return columnAnchorPoint.length;
    }

    /**
     * Changes the number of columns in this table.
     * If additional columns are added, those columns will have <tt>null</tt>
     * initially set for their anchor points.
     *
     * @param columnCount new number of columns; must be at least one.
     * If this is the same as the current number of columns, this method
     * call does nothing.
     */
    public synchronized void setColumnCount(int columnCount) {
        if ( columnCount < 1 ) {
            throw new IllegalArgumentException("Invalid columnCount of " +
                columnCount + " must be at least 1.");
        }

        if ( columnCount != columnAnchorPoint.length ) {
            columnAnchorPoint =
                (AnchorPoint[]) ObjectTools.changeArraySize(
                    columnAnchorPoint, columnCount, null);

            columnHeaderAnchorPoint =
                (AnchorPoint[]) ObjectTools.changeArraySize(
                    columnHeaderAnchorPoint, columnCount, null);
        }
    }

    /**
     * Returns the {@link AnchorPoint} (if defined)
     * for the specified column. If no specific anchor has been defined
     * for the specified column, then <tt>null</tt> is returned.
     * The anchors for each column may be specified by using
     * {@link #setColumnAnchorPoint(int, AnchorPoint)}.
     *
     * @param columnIndex the desired column. Columns are numbered starting
     * from zero {0, 1, 2, ... (NumOfColumns - 1)}.
     * @return an {@link AnchorPoint} if there has previously been a
     * specific anchor defined. Or <tt>null</tt> if nothing has been
     * specified to override the default for the particular layout manager.
     * @throws IllegalArgumentException if <tt>columnIndex</tt> is
     * less than zero or greater than or equal to the number of columns.
     * @see #setColumnAnchorPoint(int, AnchorPoint)
     * @see #getColumnHeaderAnchorPoint(int)
     * @see #setColumnHeaderAnchorPoint(int, AnchorPoint)
     */
    public synchronized AnchorPoint getColumnAnchorPoint(int columnIndex)
            throws IllegalArgumentException {

        if ( columnIndex < 0 || columnIndex >= columnAnchorPoint.length ) {
            throw new IllegalArgumentException(
                "Invalid columnIndex of " + columnIndex);
        }

        return columnAnchorPoint[columnIndex];
    }

    /**
     * Set a specific {@link AnchorPoint} for a column. Passing in
     * <tt>null</tt> for the <tt>AnchorPoint</tt> will cause the column
     * to revert to the default anchor point for a column. Otherwise,
     * the <tt>AnchorPoint</tt> specified overrides any default (or calculated)
     * <tt>AnchorPoint</tt> that would have been used for the specified column.
     *
     * @param columnIndex the desired column. Columns are numbered starting
     * from zero {0, 1, 2, ... (NumOfColumns - 1)}.
     * @param anchor the <tt>AnchorPoint</tt> to use for this column.
     * If non-<tt>null</tt>, the specified anchor will override any
     * default for the column. If <tt>null</tt>, the column will revert
     * to using the default anchor for the column as defined by a
     * specific layout manager (subclass).
     * @throws IllegalArgumentException if <tt>columnIndex</tt> is
     * less than zero or greater than or equal to the number of columns.
     * @see #getColumnAnchorPoint(int)
     * @see #getColumnHeaderAnchorPoint(int)
     * @see #setColumnHeaderAnchorPoint(int, AnchorPoint)
     */
    public synchronized void setColumnAnchorPoint(int columnIndex,
                                                  AnchorPoint anchor)
            throws IllegalArgumentException {

        if ( columnIndex < 0 || columnIndex >= columnAnchorPoint.length ) {
            throw new IllegalArgumentException(
                "Invalid columnIndex of " + columnIndex);
        }

        columnAnchorPoint[columnIndex] = anchor;
    }

    /**
     * Returns the {@link AnchorPoint} (if defined)
     * for the specified column's <i>first row</i> (header).
     * If no specific anchor has been defined
     * for the specified column's header, then <tt>null</tt> is returned.
     * The anchors for each column's first row may be specified by using
     * {@link #setColumnHeaderAnchorPoint(int, AnchorPoint)}.
     * <p>
     * If this method returns <tt>null</tt>, then the anchor might be
     * specified by {@link #getColumnAnchorPoint(int)}. If that also
     * returns <tt>null</tt>, then the default anchor the specific
     * layout manager should be used.
     *
     * @param columnIndex the desired column. Columns are numbered starting
     * from zero {0, 1, 2, ... (NumOfColumns - 1)}.
     * @return an {@link AnchorPoint} if there has previously been a
     * specific anchor defined. Or <tt>null</tt> if nothing has been
     * specified to override the default for the particular layout manager.
     * @throws IllegalArgumentException if <tt>columnIndex</tt> is
     * less than zero or greater than or equal to the number of columns.
     * @see #setColumnHeaderAnchorPoint(int, AnchorPoint)
     * @see #getColumnAnchorPoint(int)
     * @see #setColumnAnchorPoint(int, AnchorPoint)
     */
    public synchronized AnchorPoint getColumnHeaderAnchorPoint(int columnIndex)
            throws IllegalArgumentException {

        if ( columnIndex < 0 || columnIndex >= columnAnchorPoint.length ) {
            throw new IllegalArgumentException(
                "Invalid columnIndex of " + columnIndex);
        }

        return columnHeaderAnchorPoint[columnIndex];
    }

    /**
     * Set a specific {@link AnchorPoint} for the specified column's
     * first row (header). Passing in
     * <tt>null</tt> for the <tt>AnchorPoint</tt> will cause the column
     * to revert to the default anchor point for a column (which may come
     * from {@link #getColumnAnchorPoint(int)} or the default for the
     * particular layout manager).
     * Otherwise, the <tt>AnchorPoint</tt> specified overrides any default
     * (or calculated) <tt>AnchorPoint</tt> that would have been used for
     * the specified column's first row.
     *
     * @param columnIndex the desired column. Columns are numbered starting
     * from zero {0, 1, 2, ... (NumOfColumns - 1)}.
     * @param anchor the <tt>AnchorPoint</tt> to use for the first row
     * of the specified column.
     * If non-<tt>null</tt>, the specified anchor will override any
     * default for the column's first row.
     * If <tt>null</tt>, the column will revert
     * to using the anchor for the column as defined by
     * {@link #getColumnAnchorPoint(int)}.
     * @throws IllegalArgumentException if <tt>columnIndex</tt> is
     * less than zero or greater than or equal to the number of columns.
     * @see #getColumnHeaderAnchorPoint(int)
     * @see #getColumnAnchorPoint(int)
     * @see #setColumnAnchorPoint(int, AnchorPoint)
     */
    public synchronized void setColumnHeaderAnchorPoint(int columnIndex,
                                                        AnchorPoint anchor)
            throws IllegalArgumentException {

        if ( columnIndex < 0 || columnIndex >= columnAnchorPoint.length ) {
            throw new IllegalArgumentException(
                "Invalid columnIndex of " + columnIndex);
        }

        columnHeaderAnchorPoint[columnIndex] = anchor;
    }

    /**
     * This implementation returns a an instance of {@link AnchorTableCellData}
     * with a default anchor for all columns of {@link AnchorPoint#CENTER}.
     * If this is appropriate for a subclass, then the subclass does not
     * need to override this method.
     */
    @Override
    protected synchronized CellData createCellData(Container pane) {
        return new AnchorTableCellData(pane, AnchorPoint.CENTER);
    }

    protected class AnchorTableCellData extends CellData {
        protected final AnchorPoint defaultAnchorForAllColumns;

        protected AnchorTableCellData(Container pane,
                                      AnchorPoint defaultAnchorForAllColumns) {

            super(pane);
            this.defaultAnchorForAllColumns = defaultAnchorForAllColumns;
        }

        protected AnchorTableCellData(Container pane) {
            this(pane, null);
        }

        @Override
        protected void calcRowAndColumnCounts() {
            colCount = columnAnchorPoint.length;
            rowCount = (comp.length + (colCount - 1)) / colCount;
        }

        @Override
        protected void calcRowHeightsAndColumnWidths() {
            rowHeight = new int[rowCount];
            colWidth = new int[colCount];

//            int availableWidth = paneSize.width -
//                ((bGap * 2) + paneInsets.left + paneInsets.right);
//
//            int availableHeight = paneSize.height -
//                ((bGap * 2) + paneInsets.top + paneInsets.bottom);
//
//            Rectangle scratchRect = new Rectangle();
//            clusterAnchorPoint.calcBounds(
//                compPrefSize[i].width, compPrefSize[i].height,
//                availableWidth, availableHeight,
//                scratchRect);


            for ( int i = 0; i < comp.length; i++ ) {
                int r = i / colCount;
                int c = i % colCount;

                rowHeight[r] = Math.max(rowHeight[r], compPrefSize[i].height);
                colWidth[c] = Math.max(colWidth[c], compPrefSize[i].width);
            }
        }

        @Override
        protected void layoutComponents() {
            // local references to facilitate speed of access
            AnchorPoint[] cap = columnAnchorPoint;
            AnchorPoint[] chap = columnHeaderAnchorPoint;
            Map<Component, Object> cmap = constraintMap;

            Rectangle scratchRect = new Rectangle();

            // Traverse the columns in the *outer* loop so that we don't
            // have to lookup column anchor information for every cell.
            for ( int c = 0; c < colCount; c++ ) {
                AnchorPoint columnAP = cap[c];
                if ( columnAP == null ) {
                    columnAP = getDefaultAnchor(c);
                    if ( columnAP == null ) {
                        columnAP = AnchorPoint.CENTER;
                    }
                }

                for ( int r = 0; r < rowCount; r++ ) {
                    int compIdx = (r * colCount) + c;
                    if ( compIdx >= comp.length ) {
                        // This happens only when we're on the last row
                        // and when that last row does not have enough
                        // components to fill the rest of the columns.
                        break;
                    }

                    Component child = comp[compIdx];

                    AnchorPoint ap = null;

                    if ( cmap != null ) {
                        ap = (AnchorPoint) cmap.get(child);
                    }

                    if ( ap == null ) {
                        if ( r == 0 && chap[c] != null ) {
                            ap = chap[c];
                        } else {
                            ap = columnAP;
                        }

                    }

                    ap.calcBounds(
                        compPrefSize[compIdx].width,
                        compPrefSize[compIdx].height,
                        colWidth[c],
                        rowHeight[r],
                        scratchRect);

                    scratchRect.x += colX[c];
                    scratchRect.y += rowY[r];

                    child.setBounds(scratchRect);
                }
            }
        }

        /**
         * Overridden in subclasses that want to specify a default anchor
         * to use for a column when a single default anchor for all columns
         * won't work. During construction, a default anchor to use for
         * <i>all</i> columns may be specified (this is the value returned
         * from this method if it is not overridden).
         * If the overridden version of this method returns <tt>null</tt>
         * this is the same as returning {@link AnchorPoint#CENTER}.
         * If the same default anchor should be used for all columns, there
         * is no need to override this method&mdash;just specify that
         * all-column default during construction.
         */
        protected AnchorPoint getDefaultAnchor(int colIdx) {
            return defaultAnchorForAllColumns;
        }
    } // class AnchorTableCellData
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.