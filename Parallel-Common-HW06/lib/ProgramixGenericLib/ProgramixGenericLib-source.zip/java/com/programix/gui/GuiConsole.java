package com.programix.gui;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.List;

import javax.swing.*;

import com.programix.gui.layout.*;
import com.programix.thread.*;
import com.programix.util.*;

public class GuiConsole extends JPanel {
    private JTextArea consoleTA;
    private JCheckBox lockCB;
    private JButton jumpBottomB;
    private Worker worker;

    public GuiConsole() {
        consoleTA = new JTextArea(30, 80);
        consoleTA.setFont(GuiTools.NUMBER_FONT);
        consoleTA.setLineWrap(true);
        consoleTA.setWrapStyleWord(false);
        consoleTA.setTabSize(4);
        consoleTA.setEditable(false);

        lockCB = new JCheckBox("Pause Auto-Scrolling", false);
        lockCB.setMnemonic(KeyEvent.VK_P);
        lockCB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                boolean paused = lockCB.isSelected();
                worker.setPaused(paused);
                jumpBottomB.setEnabled(!paused);
            }
        });

        jumpBottomB = new JButton("Jump to Bottom");
        jumpBottomB.setMnemonic(KeyEvent.VK_B);
        jumpBottomB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jumpToBottom();
            }
        });

        JPanel controlP = new JPanel(new RowButtonLayout());
        controlP.add(lockCB);
        controlP.add(jumpBottomB);

        setLayout(new BorderLayout(0, 0));
        add(new JScrollPane(consoleTA), BorderLayout.CENTER);
        add(controlP, BorderLayout.SOUTH);

        worker = new Worker();
    }

    public void jumpToBottom() {
        if ( SwingUtilities.isEventDispatchThread() == false ) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    jumpToBottom();
                }
            });
        }

        consoleTA.setCaretPosition(consoleTA.getText().length());
        worker.setPaused(false);
    }

    private void outln(String msg) {
        consoleTA.append(msg);
        consoleTA.append("\n");
    }

    private void outln(Object msg) {
        outln(String.valueOf(msg));
    }

    public static JFrame createFramedInstance() {
        return new FrameMaker().getFrame(10000);
    }

    /**
     * Use this method to launch another class's main method, after first
     * redirecting stderr, stdout to the GuiConsole. The first argument should
     * be the name of the class to run. The remaining arguments are passed
     * to the main() method of the class specified.
     */
    public static void main(String[] args) {
        final JFrame f = GuiConsole.createFramedInstance();

        if ( args.length < 1 ) {
            System.err.println(
                "Usage: java GuiConsole [-title <foo>] " +
                "<classname> [<arg> [<arg> ...]]");
            System.err.println(" Where classname is the fully qualified name " +
                "of the class to run");
            System.err.println(" and <arg> are the arguments to pass to that " +
                "class (if any).");
            return;
        }

        int argOffset = 0;
        String proposedTitle = null;

        if ( "-title".equalsIgnoreCase(args[0]) ) {
            if ( args.length < 3 ) {
                System.err.println(
                    "Must have two more parameters after -title");
                return;
            }

            argOffset = 2;
            proposedTitle = args[1];
        }

        String classname = args[argOffset];
        String[] remainingArg = new String[args.length - 1 - argOffset];
        System.arraycopy(
            args, argOffset + 1,
            remainingArg, 0, remainingArg.length);

        if ( proposedTitle == null ) {
            proposedTitle = "Console for: " + classname;
        }

        final String finalTitle = proposedTitle;
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                f.setTitle(finalTitle);
            }
        });

        try {
            Class<?> c = Class.forName(classname);
            Method mainMethod =
                c.getMethod("main", new Class[] { String[].class });

            mainMethod.invoke(null, new Object[] { remainingArg });
        } catch ( Exception x ) {
            x.printStackTrace();
        }
    }

    private static class FrameMaker implements Runnable {
        private volatile JFrame frame;
        private Waiter.Condition frameReady;
        private JPanel contentPane;
        private GuiConsole guiConsole;

        public FrameMaker() {
            Waiter waiter = new Waiter(this);
            frameReady = waiter.createCondition(new Waiter.Expression() {
                @Override
                public boolean isTrue() {
                    return frame != null;
                }
            });

            SwingUtilities.invokeLater(this);
        }

        public JFrame getFrame(long msTimeout)
                throws TimedOutException, InterruptException {

            frameReady.waitUntilTrueWithTimedOutException(msTimeout);
            return frame;
        }

        public void run() {
            contentPane = new JPanel(new BorderLayout());
            guiConsole = new GuiConsole();
            contentPane.add(guiConsole, BorderLayout.CENTER);

            //JFrame.setDefaultLookAndFeelDecorated(true);
            JFrame f = new JFrame("GuiConsole");
            f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            f.setContentPane(contentPane);

            //f.pack();
            //GuiTools.packAndCenterOnScreen(f);
            GuiTools.setSizeToMax(f);

            f.setVisible(true);
            f.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    shutdownRequested();
                }
            });

            frame = f;
            frameReady.getOwner().signalChange();
        }

        private void shutdownRequested() {
            try {
                /*
                JLabel exitL = GuiTools.createScaledLabel("Exiting...", 2.5);
                exitL.setOpaque(true);
                exitL.setBackground(Color.YELLOW);
                exitL.setForeground(Color.BLUE);

                JPanel exitP = new JPanel(new ShelfLayout());
                exitP.setOpaque(true);
                exitP.setBackground(Color.YELLOW);
                exitP.add(exitL);

                contentPane.add(exitP, BorderLayout.NORTH);
                contentPane.revalidate();
                 */

                JLabel exitL = GuiTools.createScaledLabel("Exiting...", 4.5);
                exitL.setOpaque(true);
                exitL.setBackground(new Color(255, 255, 0, 128));
                exitL.setForeground(Color.BLUE);
                exitL.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.BLACK),
                    BorderFactory.createEmptyBorder(30, 70, 30, 70)));

                JPanel glassPane = new JPanel(new StackLayout());
                glassPane.setOpaque(false);
                glassPane.setBackground(new Color(0, 0, 0, 96));
                glassPane.add(exitL);
                JRootPane rootPane = frame.getRootPane();
                rootPane.setGlassPane(glassPane);
                glassPane.setVisible(true);
            } finally {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        guiConsole.jumpToBottom();
                        new ShutdownTask(2000);
                    }
                });
            }
        }
    } // class FrameMaker

    private static class ShutdownTask implements Runnable {
        private long msDelay;

        public ShutdownTask(long msDelay) {
            this.msDelay = msDelay;
            Thread t = new Thread(this, "Shutdown-helper");
            t.setPriority(Thread.MAX_PRIORITY);
            t.start();
        }

        public void run() {
            try {
                ThreadTools.nap(msDelay);
            } finally {
                System.exit(0);
            }
        }
    } // class ShutdownTask

    private class Worker extends Object implements Runnable {
        private boolean redirected = false;
        private boolean paused = false;

        public Worker() {
            new Thread(this).start();
            waitUntilRedirected();
        }

        // Wait up to 5 seconds for the redirection to occurr before giving up
        // the wait.
        private synchronized boolean waitUntilRedirected() {
            try {
                if ( redirected ) {
                    return true;
                }

                long endTime = System.currentTimeMillis() + 5000;
                long msRemaining = 5000;
                while ( msRemaining > 0L ) {
                    wait(msRemaining);

                    if ( redirected ) {
                        return true;
                    }

                    msRemaining = endTime - System.currentTimeMillis();
                }

                return false;
            } catch ( InterruptedException x ) {
                // ignore
                return false;
            }
        }

        private synchronized void setRedirected() {
            redirected = true;
            notifyAll();
        }

        public synchronized void setPaused(boolean paused) {
            this.paused = paused;
            notifyAll();
        }

        private synchronized void waitWhilePaused()
                throws InterruptedException {

            while ( paused ) {
                wait();
            }
        }

        public void run() {
            try {
                ByteFIFO fifo = new ByteFIFO(512 * 1024);
                PipeIn pipeIn = new PipeIn(fifo);
                PipeOut pipeOut = new PipeOut(fifo);

                PrintStream ps = new PrintStream(pipeOut, true);
                System.setOut(ps);
                System.setErr(ps);

                setRedirected();

                BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                        new BufferedInputStream(pipeIn)));

                AppendTask appendTask = new AppendTask();

                String line = null;
                while ( (line = in.readLine()) != null ) {
                    waitWhilePaused();
                    appendTask.addLine(line);
                    SwingUtilities.invokeLater(appendTask);
                }
            } catch ( Exception x ) {
                outln("");
                outln(x);
            } finally {
                outln("");
                outln("*** Done appending stdout/stderr to screen. ***");
                ThreadTools.nap(2000);
            }
        }
    } // class Worker

    private class AppendTask extends Object implements Runnable {
        private List<String> list;

        public AppendTask() {
            list = new ArrayList<String>();
        }

        public synchronized void addLine(String msg) {
            list.add(msg);
        }

        public synchronized String[] getLines() {
            String[] line = StringTools.toArray(list);
            list.clear();
            return line;
        }

        // Called by the event thread
        public void run() {
            String[] line = getLines();
            for ( int i = 0; i < line.length; i++ ) {
                outln(line[i]);
            }
        }
    } // class AppendTask

    private static class ByteFIFO extends Object {
        private byte[] queue;
        private int capacity;
        private int size;
        private int head;
        private int tail;

        public ByteFIFO(int cap) {
            capacity = ( cap > 0 ) ? cap : 1; // at least 1
            queue = new byte[capacity];
            head = 0;
            tail = 0;
            size = 0;
        }

        public synchronized int getSize() {
            return size;
        }

        public synchronized boolean isEmpty() {
            return ( size == 0 );
        }

        public synchronized boolean isFull() {
            return ( size == capacity );
        }

        public synchronized void add(byte b) throws InterruptedException {
            waitWhileFull();

            queue[head] = b;
            head = ( head + 1 ) % capacity;
            size++;

            notifyAll(); // let any waiting threads know about change
        }

        public synchronized void add(byte[] list)
                throws InterruptedException {

            // For efficiency, the bytes are copied in blocks
            // instead of one at a time. As space becomes available,
            // more bytes are copied until all of them have been
            // added.

            int ptr = 0;

            while ( ptr < list.length ) {
                // If full, the lock will be released to allow
                // another thread to come in and remove bytes.
                waitWhileFull();

                int space = capacity - size;
                int distToEnd = capacity - head;
                int blockLen = Math.min(space, distToEnd);

                int bytesRemaining = list.length - ptr;
                int copyLen = Math.min(blockLen, bytesRemaining);

                System.arraycopy(list, ptr, queue, head, copyLen);
                head = ( head + copyLen ) % capacity;
                size += copyLen;
                ptr += copyLen;

                // Keep the lock, but let any waiting threads
                // know that something has changed.
                notifyAll();
            }
        }

        public synchronized byte remove() throws InterruptedException {
            waitWhileEmpty();

            byte b = queue[tail];
            tail = ( tail + 1 ) % capacity;
            size--;

            notifyAll(); // let any waiting threads know about change

            return b;
        }

        public synchronized void waitWhileEmpty() throws InterruptedException {
            while ( isEmpty() ) {
                wait();
            }
        }

        public synchronized void waitWhileFull() throws InterruptedException {
            while ( isFull() ) {
                wait();
            }
        }
    } // class ByteFIFO

    // TODO - make a more efficient implementation of read(byte[]....)
    private static class PipeIn extends InputStream {
        private ByteFIFO fifo;

        public PipeIn(ByteFIFO fifo) {
            this.fifo = fifo;
        }

        @Override
        public int read() throws IOException {
            try {
                byte b = fifo.remove();
                return ((int) b) & 0x0FF;
            } catch ( InterruptedException x ) {
                throw new IOException("interrupted io");
            }
        }

        @Override
        public int read(byte[] dest, int off, int len) throws IOException {
            dest[off] = (byte) read();
            return 1;
        }
    } // class PipeIn

    // TODO - make an efficient implementation of write(byte[]....)
    private static class PipeOut extends OutputStream {
        private ByteFIFO fifo;

        public PipeOut(ByteFIFO fifo) {
            this.fifo = fifo;
        }

        @Override
        public void write(int b) throws IOException {
            try {
                fifo.add((byte) b);
            } catch ( InterruptedException x ) {
                throw new IOException("interrupted io");
            }
        }
    } // class PipeOut
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.