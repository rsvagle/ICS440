package com.programix.gui;

import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

import com.programix.util.*;

/**
 * Used to specify where some item should be <i>anchored</i> relative to
 * its container if extra width or height is available in the container.
 * Some anchors also specify whether or not an item's width (or height)
 * should be flexed (stretched or shrunk) to match the available
 * width (or height).
 * See each of the sixteen anchors defined for specifics:
 * {@link #CENTER}, {@link #NORTH}, {@link #NORTHEAST}, {@link #EAST},
 * {@link #SOUTHEAST}, {@link #SOUTH}, {@link #SOUTHWEST},
 * {@link #WEST}, {@link #NORTHWEST},
 * {@link #TOP_FLEX_WIDTH}, {@link #CENTER_FLEX_WIDTH},
 * {@link #BOTTOM_FLEX_WIDTH}, {@link #LEFT_FLEX_HEIGHT},
 * {@link #CENTER_FLEX_HEIGHT}, {@link #RIGHT_FLEX_HEIGHT}, and
 * {@link #CENTER_FLEX_BOTH}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class AnchorPoint
        implements Serializable, Comparable<AnchorPoint> {

    private static int nextSerial = 0;
    private static List<AnchorPoint> instanceList =
        new ArrayList<AnchorPoint>();

    private static final int MIDDLE      = 0x0000; // all zeros, no net effect
    private static final int LEFT        = 0x0001;
    private static final int RIGHT       = 0x0002;
    private static final int TOP         = 0x0004;
    private static final int BOTTOM      = 0x0008;
    private static final int FLEX_NONE   = 0x0000; // all zeros, no net effect
    private static final int FLEX_WIDTH  = 0x0010;
    private static final int FLEX_HEIGHT = 0x0020;
    private static final int FLEX_BOTH   = FLEX_WIDTH | FLEX_HEIGHT;

    /**
     * Anchor in the CENTER region.
     * The width and height of the item being anchored within the container
     * are kept at their preferred values.
     * If extra vertical space (height) is available in the container, this
     * space is split evenly above and below the item.
     * If extra horizontal space (width) is available in the container, this
     * space is split evenly to the left and to the right of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>CENTER:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="center" valign="middle" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint CENTER =
                                new AnchorPoint(MIDDLE, MIDDLE, "CENTER");

    /**
     * Anchor in the NORTH (centered, top) region.
     * The width and height of the item being anchored within the container
     * are kept at their preferred values.
     * If extra vertical space (height) is available in the container, this
     * space is placed below the item.
     * If extra horizontal space (width) is available in the container, this
     * space is split evenly to the left and to the right of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>NORTH:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="center" valign="top" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint NORTH =
                                new AnchorPoint(MIDDLE, TOP, "NORTH");

    /**
     * Anchor in the NORTHEAST (top right) region.
     * The width and height of the item being anchored within the container
     * are kept at their preferred values.
     * If extra vertical space (height) is available in the container, this
     * space is placed below the item.
     * If extra horizontal space (width) is available in the container, this
     * space is placed to the left of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>NORTHEAST:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="right" valign="top" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint NORTHEAST =
                                new AnchorPoint(RIGHT, TOP, "NORTHEAST");

    /**
     * Anchor in the EAST (middle right) region.
     * The width and height of the item being anchored within the container
     * are kept at their preferred values.
     * If extra vertical space (height) is available in the container, this
     * space is split evenly above and below the item.
     * If extra horizontal space (width) is available in the container, this
     * space is placed to the left of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>EAST:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="right" valign="middle" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint EAST =
                                new AnchorPoint(RIGHT, MIDDLE, "EAST");

    /**
     * Anchor in the SOUTHEAST (bottom, right) region.
     * The width and height of the item being anchored within the container
     * are kept at their preferred values.
     * If extra vertical space (height) is available in the container, this
     * space is placed above the item.
     * If extra horizontal space (width) is available in the container, this
     * space is placed to the left of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>SOUTHEAST:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="right" valign="bottom" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint SOUTHEAST =
                                new AnchorPoint(RIGHT, BOTTOM, "SOUTHEAST");

    /**
     * Anchor in the SOUTH (centered, bottom) region.
     * The width and height of the item being anchored within the container
     * are kept at their preferred values.
     * If extra vertical space (height) is available in the container, this
     * space is placed above the item.
     * If extra horizontal space (width) is available in the container, this
     * space is split evenly on the left and on the right of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>SOUTH:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="center" valign="bottom" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint SOUTH =
                                new AnchorPoint(MIDDLE, BOTTOM, "SOUTH");

    /**
     * Anchor in the SOUTHWEST (bottom, left) region.
     * The width and height of the item being anchored within the container
     * are kept at their preferred values.
     * If extra vertical space (height) is available in the container, this
     * space is placed above the item.
     * If extra horizontal space (width) is available in the container, this
     * space is placed on the right of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>SOUTHWEST:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="left" valign="bottom" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint SOUTHWEST =
                                new AnchorPoint(LEFT, BOTTOM, "SOUTHWEST");

    /**
     * Anchor in the WEST (middle, left) region.
     * The width and height of the item being anchored within the container
     * are kept at their preferred values.
     * If extra vertical space (height) is available in the container, this
     * space is split evenly above and below the item.
     * If extra horizontal space (width) is available in the container, this
     * space is placed on the right of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>WEST:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="left" valign="middle" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint WEST =
                                new AnchorPoint(LEFT, MIDDLE, "WEST");

    /**
     * Anchor in the NORTHWEST (top, left) region.
     * The width and height of the item being anchored within the container
     * are kept at their preferred values.
     * If extra vertical space (height) is available in the container, this
     * space is placed below the item.
     * If extra horizontal space (width) is available in the container, this
     * space is placed on the right of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>NORTHWEST:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="left" valign="top" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint NORTHWEST =
                                new AnchorPoint(LEFT, TOP, "NORTHWEST");

    /**
     * Anchor in the top (northern) region, but match the width to the
     * available width of the container.
     * The item's height is set to the item's preferred height.
     * If extra vertical space (height) is available in the container, this
     * space is placed below the item.
     * If extra horizontal space (width) is available in the container,
     * the item is stretched to take up this space.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>TOP_FLEX_WIDTH:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="left" valign="top" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="50" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint TOP_FLEX_WIDTH =
        new AnchorPoint(LEFT, TOP, FLEX_WIDTH, "TOP_FLEX_WIDTH");

    /**
     * Anchor in the CENTER (middle) region, but match the width to the
     * available width of the container.
     * The item's height is set to the item's preferred height.
     * If extra vertical space (height) is available in the container, this
     * space is split evenly above and below the item.
     * If extra horizontal space (width) is available in the container,
     * the item is stretched to take up this space.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>CENTER_FLEX_WIDTH:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="left" valign="middle" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="50" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint CENTER_FLEX_WIDTH =
        new AnchorPoint(LEFT, MIDDLE, FLEX_WIDTH, "CENTER_FLEX_WIDTH");

    /**
     * Anchor in the bottom (southern) region, but match the width to the
     * available width of the container.
     * The item's height is set to the item's preferred height.
     * If extra vertical space (height) is available in the container, this
     * space is placed above the item.
     * If extra horizontal space (width) is available in the container,
     * the item is stretched to take up this space.
     *
     * <table border="0" cellspacing="2" cellpadding="0">
     * <tr>
     *  <td>BOTTOM_FLEX_WIDTH:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="left" valign="bottom" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="50" height="20">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint BOTTOM_FLEX_WIDTH =
        new AnchorPoint(LEFT, BOTTOM, FLEX_WIDTH, "BOTTOM_FLEX_WIDTH");

    /**
     * Anchor in the left (western) region, but match the height to the
     * available height of the container.
     * The item's width is set to the item's preferred width.
     * If extra vertical space (height) is available in the container,
     * the item is stretched to take up this space.
     * If extra horizontal space (width) is available in the container,
     * the space is placed to the right of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>LEFT_FLEX_HEIGHT:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="left" valign="top" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="50">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint LEFT_FLEX_HEIGHT =
        new AnchorPoint(LEFT, TOP, FLEX_HEIGHT, "LEFT_FLEX_HEIGHT");

    /**
     * Anchor in the CENTER (middle) region, but match the height to the
     * available height of the container.
     * The item's width is set to the item's preferred width.
     * If extra vertical space (height) is available in the container,
     * the item is stretched to take up this space.
     * If extra horizontal space (width) is available in the container,
     * the space is split evenly to the left and the right of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>CENTER_FLEX_HEIGHT:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="center" valign="top" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="50">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint CENTER_FLEX_HEIGHT =
        new AnchorPoint(MIDDLE, TOP, FLEX_HEIGHT, "CENTER_FLEX_HEIGHT");

    /**
     * Anchor in the right (eastern) region, but match the height to the
     * available height of the container.
     * The item's width is set to the item's preferred width.
     * If extra vertical space (height) is available in the container,
     * the item is stretched to take up this space.
     * If extra horizontal space (width) is available in the container,
     * the space is placed to the left of the item.
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>RIGHT_FLEX_HEIGHT:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="right" valign="top" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="20" height="50">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint RIGHT_FLEX_HEIGHT =
        new AnchorPoint(RIGHT, TOP, FLEX_HEIGHT, "RIGHT_FLEX_HEIGHT");

    /**
     * Anchor in the CENTER (middle) region, but
     * match the width to the available width of the container <i>and</i>
     * match the height to the available height of the container.
     * If extra vertical space (height) is available in the container,
     * the item is stretched to take up this space.
     * If extra horizontal space (width) is available in the container,
     * the item is stretched to take up this space.
     * With this <i>fully filling</i> option, the term <i>anchor</i> is
     * a bit of a misnomer as <i>all</i> of the excess space is consumed
     * by stretching in both directions (similarly, using <i>center</i>
     * as part of the name is an arbitrary choice).
     *
     * <table border="0" cellspacing="2" cellpadding="2">
     * <tr>
     *  <td>CENTER_FLEX_BOTH:</td>
     *  <td><table border="0" cellpadding="0" cellspacing="2" bgcolor="#000080">
     *   <tr><td><table border="0" cellpadding="0"
     *                  cellspacing="2" bgcolor="#ffffff" >
     *    <tr><td align="left" valign="top" width="50" height="50">
     *     <table border="0" cellpadding="0" cellspacing="0" bgcolor="#000080">
     *      <tr><td width="50" height="50">&nbsp;</td></tr>
     *     </table>
     *    </td></tr>
     *   </table></td></tr>
     *  </table></td>
     * </tr>
     * </table>
     */
    public static final AnchorPoint CENTER_FLEX_BOTH =
        new AnchorPoint(LEFT, TOP, FLEX_BOTH, "CENTER_FLEX_BOTH");

    /**
     * An array with exactly zero slots and a component type of
     * <tt>AnchorPoint</tt>. This object can be safely shared (including
     * simultaneously shared) by all as it is completely immutable.
     */
    public static final AnchorPoint[] ZERO_LEN_ARRAY = new AnchorPoint[0];

    private static final AnchorPoint[] VALUES = (AnchorPoint[])
            instanceList.toArray(new AnchorPoint[instanceList.size()]);

    /**
     * Unmodifiable {@link List} of all the instances of <tt>AnchorPoint</tt>.
     */
    public static final List<AnchorPoint> VALUE_LIST =
        Collections.unmodifiableList(instanceList);

    private final int serial;
    private final transient String name;
    private final transient int anchor;

    // Pre-calculate and store all of these values for super-fast method
    // calls for these answers. Note that because there are only 16 instances
    // of AnchorPoint per Java VM, this is not as memory wasteful as one
    // might initially think.
    private final transient boolean left;
    private final transient boolean horizontalMiddle;
    private final transient boolean right;
    private final transient boolean top;
    private final transient boolean verticalMiddle;
    private final transient boolean bottom;
    private final transient boolean flexWidth;
    private final transient boolean flexHeight;

    private AnchorPoint(int horiztonalPos,
                        int verticalPos,
                        int flexDirection,
                        String name) {

        this.serial = getSerial(this);
        this.name = name;
        this.anchor = horiztonalPos | verticalPos | flexDirection;

        flexWidth = (anchor & FLEX_WIDTH) != 0;
        flexHeight = (anchor & FLEX_HEIGHT) != 0;

        left = flexWidth || ((anchor & LEFT) != 0);
        right = flexWidth || ((anchor & RIGHT) != 0);
        horizontalMiddle = flexWidth || (!left && !right);

        top = flexHeight || ((anchor & TOP) != 0);
        bottom = flexHeight || ((anchor & BOTTOM) != 0);
        verticalMiddle = flexHeight || (!top && !bottom);
    }

    private AnchorPoint(int horiztonalPos, int verticalPos, String name) {
        this(horiztonalPos, verticalPos, FLEX_NONE, name);
    }

    private static synchronized int getSerial(AnchorPoint instance) {
        instanceList.add(instance);
        return nextSerial++;
    }


    /**
     * Returns an array of all the legal values. A cloned copy is returned,
     * so no caution is required.
     */
    public static AnchorPoint[] getValues() {
        return (AnchorPoint[]) VALUES.clone();
    }

    /**
     * Returns the instance whose {@link #getName} method returns
     * a <tt>String</tt> that matches the <tt>name</tt> passed in.
     * The matching is done ignoring any case differences and after
     * trimming any leading or trailing whitespace on the string
     * passed in.
     *
     * @param name the name to search for.
     * @return the matching instance
     * @throws IllegalArgumentException if no match is found.
     */
    public static AnchorPoint valueOf(String name)
            throws IllegalArgumentException {

        String s = StringTools.trim(name);
        for ( int i = 0; i < VALUES.length; i++ ) {
            if ( VALUES[i].name.equalsIgnoreCase(s) ) {
                return VALUES[i];
            }
        }

        throw new IllegalArgumentException(
            "Can not find a match for " + StringTools.quoteWrap(name));
    }

    private Object readResolve() {
        // Only return one of the few instances.
        return VALUES[serial];
    }

    @Override
    public boolean equals(Object obj) {
        return this == obj;
    }

    @Override
    public int hashCode() {
        return serial;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(getClass().getName() + "[");
        sb.append("serial=" + serial);
        sb.append(", name=" + name);
        sb.append("]");
        return sb.toString();
    }

    public int compareTo(AnchorPoint other) {
        return serial - other.serial;
    }

    /**
     * Returns the name of this anchor. For example: "NORTH", "CENTER", etc.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns <tt>true</tt> if the anchoring results in the
     * left side of the item being placed as far
     * left as possible in the container when the container has extra
     * width available.
     * Specifically, <tt>true</tt> is returned if the alignment is any of:
     * {@link #WEST}, {@link #NORTHWEST}, {@link #SOUTHWEST},
     * {@link #LEFT_FLEX_HEIGHT},
     * {@link #TOP_FLEX_WIDTH}, {@link #CENTER_FLEX_WIDTH},
     * {@link #BOTTOM_FLEX_WIDTH}, or {@link #CENTER_FLEX_BOTH}.
     */
    public boolean isLeft() {
        return left;
    }

    /**
     * Returns <tt>true</tt> if the anchoring results in the
     * right side of the item being placed as far
     * right as possible in the container when the container has extra
     * width available.
     * Specifically, <tt>true</tt> is returned if the alignment is any of:
     * {@link #EAST}, {@link #NORTHEAST}, {@link #SOUTHEAST},
     * {@link #RIGHT_FLEX_HEIGHT},
     * {@link #TOP_FLEX_WIDTH}, {@link #CENTER_FLEX_WIDTH},
     * {@link #BOTTOM_FLEX_WIDTH}, or {@link #CENTER_FLEX_BOTH}.
     */
    public boolean isRight() {
        return right;
    }

    /**
     * Returns <tt>true</tt> if the anchoring results in the
     * extra width being split between the left side and right side
     * of the item when the container has extra width available.
     * Specifically, <tt>true</tt> is returned if the alignment is any of:
     * {@link #CENTER}, {@link #NORTH}, {@link #SOUTH},
     * {@link #CENTER_FLEX_HEIGHT},
     * {@link #TOP_FLEX_WIDTH}, {@link #CENTER_FLEX_WIDTH},
     * {@link #BOTTOM_FLEX_WIDTH}, or {@link #CENTER_FLEX_BOTH}.
     */
    public boolean isHorizontalMiddle() {
        return horizontalMiddle;
    }

    /**
     * Returns <tt>true</tt> if the anchoring results in the
     * top side of the item being placed as far
     * up as possible in the container when the container has extra
     * height available.
     * Specifically, <tt>true</tt> is returned if the alignment is any of:
     * {@link #NORTH}, {@link #NORTHEAST}, {@link #NORTHWEST},
     * {@link #TOP_FLEX_WIDTH},
     * {@link #LEFT_FLEX_HEIGHT}, {@link #CENTER_FLEX_HEIGHT},
     * {@link #RIGHT_FLEX_HEIGHT}, {@link #CENTER_FLEX_BOTH}.
     */
    public boolean isTop() {
        return top;
    }

    /**
     * Returns <tt>true</tt> if the anchoring results in the
     * bottom side of the item being placed as far
     * down as possible in the container when the container has extra
     * height available.
     * Specifically, <tt>true</tt> is returned if the alignment is any of:
     * {@link #SOUTH}, {@link #SOUTHEAST}, {@link #SOUTHWEST},
     * {@link #BOTTOM_FLEX_WIDTH},
     * {@link #LEFT_FLEX_HEIGHT}, {@link #CENTER_FLEX_HEIGHT},
     * {@link #RIGHT_FLEX_HEIGHT}, {@link #CENTER_FLEX_BOTH}.
     */
    public boolean isBottom() {
        return bottom;
    }

    /**
     * Returns <tt>true</tt> if the anchoring results in the
     * extra height being split above and below
     * the item when the container has extra height available.
     * Specifically, <tt>true</tt> is returned if the alignment is any of:
     * {@link #CENTER}, {@link #EAST}, {@link #WEST},
     * {@link #CENTER_FLEX_WIDTH},
     * {@link #LEFT_FLEX_HEIGHT}, {@link #CENTER_FLEX_HEIGHT},
     * {@link #RIGHT_FLEX_HEIGHT}, {@link #CENTER_FLEX_BOTH}.
     */
    public boolean isVerticalMiddle() {
        return verticalMiddle;
    }

    /**
     * Returns <tt>true</tt> if the alignment is any of:
     * {@link #TOP_FLEX_WIDTH}, {@link #CENTER_FLEX_WIDTH},
     * {@link #BOTTOM_FLEX_WIDTH}, or {@link #CENTER_FLEX_BOTH}.
     */
    public boolean isFlexWidth() {
        return flexWidth;
    }

    /**
     * Returns <tt>true</tt> if the alignment is any of:
     * {@link #LEFT_FLEX_HEIGHT}, {@link #CENTER_FLEX_HEIGHT},
     * {@link #RIGHT_FLEX_HEIGHT}, or {@link #CENTER_FLEX_BOTH}.
     */
    public boolean isFlexHeight() {
        return flexHeight;
    }

    /**
     * Calculates the x and y offsets, width, and height
     * based on the anchor settings.
     *
     * @param width of the item to anchor.
     * @param height of the item to anchor.
     * @param availableWidth of the space to be anchored within.
     * @param availableHeight of the space to be anchored within.
     * @param dest <tt>Rectangle</tt> to load with offsets. If <tt>null</tt> is
     * passed, a new <tt>Rectangle</tt> is allocated.
     * @return passed <tt>dest</tt>, or a new <tt>Rectangle</tt> if
     * <tt>dest</tt> is <tt>null</tt>.
     */
    public Rectangle calcBounds(int width,
                                int height,
                                int availableWidth,
                                int availableHeight,
                                Rectangle dest) {

        if ( dest == null ) {
            dest = new Rectangle();
        }

        if ( left ) {
            dest.x = 0;
        } else {
            int extraWidth = Math.max(0, availableWidth - width);

            if ( right ) {
                dest.x = extraWidth;
            } else {
                dest.x = extraWidth / 2;
            }
        }

        if ( top ) {
            dest.y = 0;
        } else {
            int extraHeight = Math.max(0, availableHeight - height);
            if ( bottom ) {
                dest.y = extraHeight;
            } else {
                dest.y = extraHeight / 2;
            }
        }

        dest.width =
            (flexWidth || availableWidth < width) ? availableWidth : width;
        dest.height =
            (flexHeight || availableHeight < height) ? availableHeight : height;

        return dest;
    }

    /**
     * Calculates the x and y offsets, width, and height
     * based on the anchor settings always creating a new <tt>Rectangle</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return calcOffset(width, height, availableWidth, availableHeight, null);
     * </pre>
     */
    public Rectangle calcBounds(int width,
                                int height,
                                int availableWidth,
                                int availableHeight) {

        return calcBounds(width, height, availableWidth, availableHeight, null);
    }

    /**
     * Calculates the x and y offsets based on the anchor settings.
     *
     * @param width of the item to anchor.
     * @param height of the item to anchor.
     * @param availableWidth of the space to be anchored within.
     * @param availableHeight of the space to be anchored within.
     * @param dest <tt>Point</tt> to load with offsets. If <tt>null</tt> is
     * passed, a new <tt>Point</tt> is allocated.
     * @return passed <tt>dest</tt>, or a new <tt>Point</tt> if <tt>dest</tt>
     * is <tt>null</tt>.
     */
    public Point calcOffset(int width,
                            int height,
                            int availableWidth,
                            int availableHeight,
                            Point dest) {

        int extraWidth = Math.max(0, availableWidth - width);
        int extraHeight = Math.max(0, availableHeight - height);
        int offsetX = 0;
        int offsetY = 0;

        if ( left ) {
            offsetX = 0;
        } else if ( right ) {
            offsetX = extraWidth;
        } else {
            offsetX = extraWidth / 2;
        }

        if ( top ) {
            offsetY = 0;
        } else if ( bottom ) {
            offsetY = extraHeight;
        } else {
            offsetY = extraHeight / 2;
        }

        if ( dest == null ) {
            return new Point(offsetX, offsetY);
        }

        dest.setLocation(offsetX, offsetY);
        return dest;
    }

    /**
     * Calculates the offsets, always creating a new <tt>Point</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return calcOffset(width, height, availableWidth, availableHeight, null);
     * </pre>
     */
    public Point calcOffset(int width,
                            int height,
                            int availableWidth,
                            int availableHeight) {

        return calcOffset(width, height, availableWidth, availableHeight, null);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.