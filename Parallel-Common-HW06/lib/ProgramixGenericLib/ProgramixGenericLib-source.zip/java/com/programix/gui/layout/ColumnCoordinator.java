package com.programix.gui.layout;

import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

import javax.swing.*;

// FIXME - get this functional

/**
 * NOTE: This is not ready for use in this release! DO NOT USE!
 * <p>
 * Instances of this class are used in conjunction with some layout managers
 * to coordinate columns in two different containers.
 * Most subclasses of the {@link AbstractTableLayout} layout manager
 * can use a <tt>ColumnCoordinator</tt>.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ColumnCoordinator {
    private EntryStore entryStore;

    public ColumnCoordinator() {
        entryStore = new EntryStore();
    }

    /**
     * Adds the specified container to the containers being coordinated.
     */
    public void add(Container container) {
        entryStore.add(container);
        entryStore.revalidateAll();
    }

    /**
     * Removes the specified container from coordination.
     */
    public void remove(Container container) {
        ContainerEntry entry = entryStore.getEntry(container);
        entryStore.remove(entry);
        entryStore.revalidateAll();
    }

    /**
     * Removes any and all coordinated containers that are using the
     * specified layout manager. If the specified layout manager is
     * shared by multiple containers, then all of those containers will
     * be removed.
     */
    public void remove(LayoutManager layoutManager) {
        ContainerEntry[] entry = entryStore.getEntries(layoutManager);
        for ( int i = 0; i < entry.length; i++ ) {
            entryStore.remove(entry[i]);
        }
        entryStore.revalidateAll();
    }

    private static class ContainerEntry implements Serializable {
        public static final ContainerEntry[] ZERO_LEN_ARRAY =
            new ContainerEntry[0];

        private final Container con;
        private int[] columnPrefWidth;
        private ContainerEntry next;
        private ContainerEntry prev;

        public ContainerEntry(Container con) {
            if ( con == null ) {
                throw new IllegalArgumentException("con can not be null");
            }

            this.con = con;

            columnPrefWidth = new int[0];
        }

        public boolean isForContainer(Container container) {
            return con == container;
        }

        public boolean isUsingLayoutManager(LayoutManager lm) {
            return lm == con.getLayout();
        }

        public void setColumnPrefWidths(int[] newColPrefWidth) {
            this.columnPrefWidth =
                (newColPrefWidth != null) ? newColPrefWidth : new int[0];
        }

        public int getColumnCount() {
            return columnPrefWidth.length;
        }

        public int getColumnPrefWidth(int idx) {
            if ( 0 <= idx && idx < columnPrefWidth.length ) {
                return columnPrefWidth[idx];
            } else {
                return 0;
            }
        }

        public void revalidate() {
            if ( con instanceof JComponent ) {
                ((JComponent) con).revalidate();
            } else {
                con.invalidate();
                con.validate();
            }
        }

        public static ContainerEntry[] toArray(Collection<ContainerEntry> col) {
            return col.toArray(ZERO_LEN_ARRAY);
        }
    } // class ContainerEntry

    private static class EntryStore implements Serializable {
        private ContainerEntry head;
        private ContainerEntry tail;

        public EntryStore() {
            head = null;
            tail = null;
        }

        public ContainerEntry getEntry(Container con) {
            for ( ContainerEntry e = head; e != null; e = e.next ) {
                if ( e.isForContainer(con) ) {
                    return e;
                }
            }

            return null;
        }

        public ContainerEntry[] getEntries(LayoutManager lm) {
            List<ContainerEntry> list = null;
            for ( ContainerEntry e = head; e != null; e = e.next ) {
                if ( e.isUsingLayoutManager(lm) ) {
                    if ( list == null ) {
                        list = new ArrayList<ContainerEntry>();
                    }

                    list.add(e);
                }
            }

            return (list == null) ? ContainerEntry.ZERO_LEN_ARRAY :
                ContainerEntry.toArray(list);
        }

        public boolean contains(Container con) {
            for ( ContainerEntry e = head; e != null; e = e.next ) {
                if ( e.isForContainer(con) ) {
                    return true;
                }
            }

            return false;
        }

        public ContainerEntry add(Container con) {
            ContainerEntry e = getEntry(con);

            if ( e == null ) {
                e = new ContainerEntry(con);

                if ( head == null ) {
                    // was empty, adding the first one
                    head = e;
                    tail = e;
                } else {
                    // there's at least one already
                    tail.next = e;
                    e.prev = tail;
                    tail = e;
                }
            }

            return e;
        }

        public void remove(ContainerEntry entry) {
            if ( head == tail ) {
                // removing the last one
                head = null;
                tail = null;
            } else {
                // there's at least one more left
                if ( head == entry ) {
                    head = entry.next;
                    head.prev = null;
                } else if ( tail == entry ) {
                    tail = entry.prev;
                    tail.next = null;
                } else {
                    entry.next.prev = entry.prev;
                    entry.prev.next = entry.next;
                }
            }
        }

        public int[] getMaxPrefWidths() {
            int maxColumnCount = 0;

            for ( ContainerEntry e = head; e != null; e = e.next ) {
                maxColumnCount = Math.max(maxColumnCount, e.getColumnCount());
            }

            int[] maxPrefWidth = new int[maxColumnCount];
            for ( int col = 0; col < maxPrefWidth.length; col++ ) {
                for ( ContainerEntry e = head; e != null; e = e.next ) {
                    maxPrefWidth[col] =
                        Math.max(maxPrefWidth[col], e.getColumnPrefWidth(col));
                }
            }

            return maxPrefWidth;
        }

        public void revalidateAll() {
            for ( ContainerEntry e = head; e != null; e = e.next ) {
                e.revalidate();
            }
        }
    } // class EntryStore
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.