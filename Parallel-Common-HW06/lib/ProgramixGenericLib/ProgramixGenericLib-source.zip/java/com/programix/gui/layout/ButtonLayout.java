package com.programix.gui.layout;

import java.awt.*;

import com.programix.gui.*;

/**
 * Superclass for common functionality of {@link ColumnButtonLayout}
 * and {@link RowButtonLayout}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public abstract class ButtonLayout extends AbstractTableLayout {
    protected int requestedRowOrColCount;
    protected final boolean colDriven;

    protected ButtonLayout(int rowGap,
                           int colGap,
                           int borderGap,
                           AnchorPoint anchorPoint,
                           int requestedRowOrColCount,
                           boolean colDriven) {

        super(rowGap, colGap, borderGap, anchorPoint);
        this.requestedRowOrColCount = Math.max(1, requestedRowOrColCount);
        this.colDriven = colDriven;
    }

    @Override
    protected CellData createCellData(Container pane) {
        return new ButtonCellData(pane);
    }

    private class ButtonCellData extends CellData {
        public ButtonCellData(Container pane) {
            super(pane);
        }

        @Override
        protected void calcRowAndColumnCounts() {
            if ( colDriven ) {
                colCount = requestedRowOrColCount;
                rowCount = (comp.length + (colCount - 1)) / colCount;
            } else {
                rowCount = requestedRowOrColCount;
                colCount = (comp.length + (rowCount - 1)) / rowCount;
            }
        }

        @Override
        protected void calcRowHeightsAndColumnWidths() {
            int maxWidth = 0;
            int maxHeight = 0;
            for ( int i = 0; i < comp.length; i++ ) {
                maxHeight = Math.max(maxHeight, compPrefSize[i].height);
                maxWidth = Math.max(maxWidth, compPrefSize[i].width);
            }

            rowHeight = new int[rowCount];
            colWidth = new int[colCount];
            for ( int i = 0; i < comp.length; i++ ) {
                int c = i % colCount;
                int r = i / colCount;

                rowHeight[r] = maxHeight;
                colWidth[c] = maxWidth;
            }
        }

        @Override
        public void layoutComponents() {
            for ( int i = 0; i < comp.length; i++ ) {
                int r = i / colCount;
                int c = i % colCount;

                int width = colWidth[c];
                int height = rowHeight[r];
                int x = colX[c];
                int y = rowY[r];

                comp[i].setBounds(x, y, width, height);
            }
        }
    } // class FormCellData
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.