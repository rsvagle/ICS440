package com.programix.gui.plaf.theme;

import java.awt.*;

import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.metal.*;

public class ExtraLargeOceanTheme extends OceanTheme {
    @Override
    public String getName() {
        return "Extra-Large Ocean";
    }

    private final FontUIResource controlFont = new FontUIResource("Dialog",
        Font.BOLD, 24);
    private final FontUIResource systemFont = new FontUIResource("Dialog",
        Font.PLAIN, 24);
    private final FontUIResource userFont = new FontUIResource("SansSerif",
        Font.PLAIN, 24);
    private final FontUIResource smallFont = new FontUIResource("Dialog",
        Font.PLAIN, 20);

    @Override
    public FontUIResource getControlTextFont() {
        return controlFont;
    }

    @Override
    public FontUIResource getSystemTextFont() {
        return systemFont;
    }

    @Override
    public FontUIResource getUserTextFont() {
        return userFont;
    }

    @Override
    public FontUIResource getMenuTextFont() {
        return controlFont;
    }

    @Override
    public FontUIResource getWindowTitleFont() {
        return controlFont;
    }

    @Override
    public FontUIResource getSubTextFont() {
        return smallFont;
    }

    @Override
    public void addCustomEntriesToTable(UIDefaults table) {
        super.addCustomEntriesToTable(table);

        final int internalFrameIconSize = 30;
        table.put("InternalFrame.closeIcon", MetalIconFactory
            .getInternalFrameCloseIcon(internalFrameIconSize));
        table.put("InternalFrame.maximizeIcon", MetalIconFactory
            .getInternalFrameMaximizeIcon(internalFrameIconSize));
        table.put("InternalFrame.iconifyIcon", MetalIconFactory
            .getInternalFrameMinimizeIcon(internalFrameIconSize));
        table.put("InternalFrame.minimizeIcon", MetalIconFactory
            .getInternalFrameAltMaximizeIcon(internalFrameIconSize));

        table.put("ScrollBar.width", new Integer(25));
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.