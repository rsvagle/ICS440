package com.programix.gui.layout;

import com.programix.gui.*;

/**
 * Lays out components in a vertical stack (single column).
 * Each component added gets its preferred height.
 * The row gap specifies how many pixels are between each row
 * in the stack (the inherited column gap has no effect on this layout as
 * there is always only one column).
 * The border gap specifies the distance between the laid out components
 * and the container's own border (if any).
 * <p>
 * The {@link AnchorPoint} specified for the layout manager indicates where the
 * contents of the container should be placed if there is extra room.
 * See {@link #getAnchorPoint}, {@link #setAnchorPoint}, and the
 * {@link AnchorPoint} that may be specified during construction.
 * <p>
 * When components are added to this container, an optional <i>constraint</i>
 * can be specified for each. If no constraint is specified (or if <tt>null</tt>
 * is used as the constraint), the default of {@link AnchorPoint#CENTER}
 * will be used.
 * <p>
 * <hr width="50%" align="left" />
 * Example: <img src="{@docRoot}/images/StackLayoutBasic.png"
 * width="110" height="186" alt="StackLayoutBasic"
 * align="top"><br clear="all" />
 * Could have been created from:
 * <pre class="preshade">
 * public static JPanel createBasicDemoPane() {
 *     JPanel basicStack = new JPanel(new StackLayout());
 *     basicStack.setBorder(
 *         BorderFactory.createMatteBorder(10, 10, 10, 10, Color.BLUE));
 *     basicStack.add(makeLabel("apple", Color.RED));
 *     basicStack.add(makeLabel("banana", Color.YELLOW));
 *     basicStack.add(makeLabel("cherry", Color.GREEN));
 *     basicStack.add(makeLabel("grapefruit", Color.MAGENTA));
 *     basicStack.add(makeLabel("pear", Color.ORANGE));
 *     basicStack.add(makeLabel("watermelon", Color.CYAN));
 *     return basicStack;
 * }
 *
 * public static JLabel makeLabel(String text, Color bgColor) {
 *     JLabel label = new JLabel(text, JLabel.CENTER);
 *     label.setOpaque(true);
 *     label.setBackground(bgColor);
 *     label.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
 *     return label;
 * }
 * </pre>
 * <hr width="50%" align="left" />
 * Example: <img src="{@docRoot}/images/StackLayoutAnchor.png"
 * width="200" height="220" alt="StackLayoutAnchor"
 * align="top"><br clear="all" />
 * Could have been created from:
 * <pre class="preshade">
 * StackLayout stackLayout = new StackLayout(AnchorPoint.TOP_FLEX_WIDTH);
 * JPanel anotherStack = new JPanel(stackLayout);
 * anotherStack.setBorder(
 *     BorderFactory.createMatteBorder(10, 10, 10, 10, Color.BLUE));
 * anotherStack.add(
 *     makeLabel("apple", Color.RED), AnchorPoint.WEST);
 * anotherStack.add(
 *     makeLabel("banana", Color.YELLOW), AnchorPoint.CENTER);
 * anotherStack.add(
 *     makeLabel("cherry", Color.GREEN), AnchorPoint.EAST);
 * anotherStack.add(makeLabel("grapefruit", Color.MAGENTA));
 * anotherStack.add(
 *     makeLabel("pear", Color.ORANGE), AnchorPoint.CENTER_FLEX_WIDTH);
 * anotherStack.add(makeLabel("watermelon", Color.CYAN));
 * </pre>
 * <hr width="50%" align="left" />
 * Example: <img src="{@docRoot}/images/StackLayoutColumnAnchor.png"
 * width="200" height="220" alt="StackLayoutColumnAnchor"
 * align="top"><br clear="all" />
 * Could have been created from:
 * <pre class="preshade">
 * StackLayout stackLayout = new StackLayout(AnchorPoint.TOP_FLEX_WIDTH);
 * <b>stackLayout.setColumnAnchorPoint(0, AnchorPoint.WEST);</b>
 * JPanel anotherStack = new JPanel(stackLayout);
 * anotherStack.setBorder(
 *     BorderFactory.createMatteBorder(10, 10, 10, 10, Color.BLUE));
 * anotherStack.add(
 *     makeLabel("apple", Color.RED), AnchorPoint.WEST);
 * anotherStack.add(
 *     makeLabel("banana", Color.YELLOW), AnchorPoint.CENTER);
 * anotherStack.add(
 *     makeLabel("cherry", Color.GREEN), AnchorPoint.EAST);
 * anotherStack.add(makeLabel("grapefruit", Color.MAGENTA));
 * anotherStack.add(
 *     makeLabel("pear", Color.ORANGE), AnchorPoint.CENTER_FLEX_WIDTH);
 * anotherStack.add(makeLabel("watermelon", Color.CYAN));
 * </pre>
 *
 * @see AnchorTableLayout
 * @see FormLayout
 * @see ColumnButtonLayout
 * @see RowButtonLayout
 * @see ShelfLayout
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class StackLayout extends AnchorTableLayout {

    /**
     * Creates a single column (stack) layout.
     *
     * @param rowGap space between rows.
     *                 See {@link #setRowGap setRowGap()}.
     * @param borderGap space around the outside of the column.
     *                 See {@link #setBorderGap setBorderGap()}.
     * @param anchorPoint region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint()}.
     */
    public StackLayout(int rowGap,
                       int borderGap,
                       AnchorPoint anchorPoint) {

        super(1, rowGap, 0, borderGap, anchorPoint);
        super.setColumnCount(1);
    }

    /**
     * Creates a single column (stack) layout.
     * Uses {@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT}.
     *
     * @param rowGap space between rows.
     *                 See {@link #setRowGap setRowGap()}.
     * @param borderGap space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap()}.
     */
    public StackLayout(int rowGap, int borderGap) {
        this(rowGap, borderGap, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Creates a single column (stack) layout.
     * Uses {@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP}.
     * Uses {@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP}.
     *
     * @param anchorPoint region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint()}.
     */
    public StackLayout(AnchorPoint anchorPoint) {
        this(DEFAULT_ROW_GAP, DEFAULT_BORDER_GAP, anchorPoint);
    }

    /**
     * Creates a single column (stack) layout.
     * Uses {@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP}.
     * Uses {@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT}.
     *
     * @param borderGap space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap()}.
     */
    public StackLayout(int borderGap) {
        this(DEFAULT_ROW_GAP, borderGap, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Creates a single column (stack) layout.
     * Uses {@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP}.
     * Uses {@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP}.
     * Uses {@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT}.
     */
    public StackLayout() {
        this(DEFAULT_ROW_GAP, DEFAULT_BORDER_GAP, DEFAULT_ANCHOR_POINT);
    }

    /**
     * It is meaningless to set this to anything other than <tt>1</tt>
     * as this layout manager always has exactly one column.
     * This overriding version ignores the parameter passed in and
     * always passes <tt>1</tt> to the superclass' implementation.
     * There is no exception or warning if a value other that <tt>1</tt>
     * is passed; it is just ignored.
     */
    @Override
    public final synchronized void setColumnCount(int columnCount) {
        super.setColumnCount(1);
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.