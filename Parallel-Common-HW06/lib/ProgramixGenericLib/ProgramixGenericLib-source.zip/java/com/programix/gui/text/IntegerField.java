package com.programix.gui.text;

import java.awt.*;
import java.math.*;

import javax.swing.*;

import com.programix.math.*;
import com.programix.util.*;
import com.programix.value.*;

/**
 * A kind of {@link FormatField} (which is a {@link JTextField}) that
 * only allows the input of integer values.
 * The default range allows for
 * all possible <tt>int</tt> values).
 * By default, the numbers are formatted using a comma for the
 * "thousands" separator, but this can be turned off (or back on) with
 * {@link #setUseComma(boolean)}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class IntegerField extends FormatField {
    private IntegerRange validRange = IntegerRange.MIN_TO_MAX_INT;
    private boolean useComma = true;

    public IntegerField(IntegerRange validRange, Value initialValue) {
        setHorizontalAlignment(JTextField.RIGHT);
        setColumns(0);
        recalcSizeAndFilters();

        setValidRange(validRange);
        setValue(initialValue);
    }

    public IntegerField(IntegerRange validRange, Integer initialValue) {
        this(validRange, ValueFactory.create(initialValue));
    }

    public IntegerField(IntegerRange validRange, int initialValue) {
        this(validRange, ValueFactory.create(initialValue));
    }

    public IntegerField(IntegerRange validRange, String initialValue) {
        this(validRange, ValueFactory.create(initialValue));
    }

    public IntegerField(IntegerRange validRange) {
        this(validRange, ValueFactory.ZERO_LEN_STRING_INSTANCE);
    }

    public IntegerField() {
        this(IntegerRange.MIN_TO_MAX_INT,
             ValueFactory.ZERO_LEN_STRING_INSTANCE);
    }

    // initial as:
    //    Value
    //    int
    //    Integer
    //    String
    //    -none-

    private String format(int val) {
        return useComma ? NumberTools.formatComma(val) : String.valueOf(val);
    }

    @Override
    protected Value approveValue(Value proposedValue) {
        // TODO - is blank allowed?
        if ( proposedValue.isEmpty() ) {
            return proposedValue;
        }

        if ( proposedValue.isNotNumeric() ) {
            //signalWarning();
            return emptyReplacement;
        }

        int proposedInt =
            NumberTools.toIntForced(proposedValue.getBigDecimal());

        int boundedInt = validRange.forceIntoRange(proposedInt);

        if ( boundedInt != proposedInt ) {
            signalWarning();
        }

        return ValueFactory.create(format(boundedInt));
    }

    private void recalcSizeAndFilters() {
        int min = validRange.getStart().intValue();
        int max = validRange.getEnd().intValue();

        String minStr = format(min);
        String maxStr = format(max);

        int columnCount = Math.max(minStr.length(), maxStr.length());

        FilterChainDocument filterChainDocument = getFilterChainDocument();
        filterChainDocument.clear();

        String longestStr =
            (maxStr.length() >= minStr.length()) ? maxStr : minStr;

        Dimension origPrefSize = getPreferredSize();
        String origText = getText();
        Dimension calcPrefSize = origPrefSize;

        try {
            allowValueListenerNotification = false;
            setText(longestStr);
            setPreferredSize(null);  // clear any preset value
            calcPrefSize = getPreferredSize();
            calcPrefSize =
                new Dimension(calcPrefSize.width + 1, calcPrefSize.height);
            setPreferredSize(calcPrefSize);
            setText(origText);
        } finally {
            allowValueListenerNotification = true;
        }

        if ( ObjectTools.isDifferent(origPrefSize, calcPrefSize) ) {
            revalidate();
            Container parent = getParent();
            if ( parent instanceof JComponent ) {
                ((JComponent) parent).revalidate();
            }
        }

        String validChar = "";
        if ( useComma ) {
            validChar = (min < 0) ? "0123456789-," : "0123456789,";
        } else {
            validChar = (min < 0) ? "0123456789-" : "0123456789";
        }

        filterChainDocument.append(
            new FilterChainDocument.WinnowFilter(validChar));

        filterChainDocument.append(
            new FilterChainDocument.LengthFilter(columnCount));

        parseCurrentText();
    }

    @Override
    public void updateUI() {
        super.updateUI();

        // This is used as a test to see if this is being called during
        // construction of one of our superclasses--a time when we are not
        // yet prepared to handle any size calculations.
        if ( getFilterChainDocument() != null ) {
            recalcSizeAndFilters();
        }
    }

    /**
     * Sets the value specified as an <tt>int</tt>.
     */
    public void setValue(int newValue) {
        setValue(ValueFactory.create(newValue));
    }

    /**
     * Returns the current value as an <tt>int</tt>. This method
     * throws an exception if the field is empty, for an alternative
     * that can handle empty, see {@link #getInteger()}.
     * @throws ValueException if the field is empty or otherwise can't
     * be interpreted as an <tt>int</tt>.
     */
    public int getInt() throws ValueException {
        return getValue().getInt();
    }

    /**
     * Sets the value specified as a <tt>Number</tt> (which is the
     * superclass of <tt>Integer</tt>, <tt>BigDecimal</tt>, and more).
     * If the specified <tt>Number</tt> is a type that can have a fractional
     * part, then it is rounded off to the nearest integer.
     */
    public void setValue(Number newValue) {
        setValue(ValueFactory.create(newValue));
    }

    /**
     * Returns the current value as an <tt>Integer</tt> or
     * <tt>null</tt> if the field is empty.
     * Specifically, if {@link #isEmpty()} returns <tt>true</tt>
     * then this method returns <tt>null</tt>.
     */
    public Integer getInteger() {
        return isEmpty() ? null : getValue().getIntegerNumber();
    }

    /**
     * Returns the current value as an <tt>BigDecimal</tt> or
     * <tt>null</tt> if the field is empty.
     * Specifically, if {@link #isEmpty()} returns <tt>true</tt>
     * then this method returns <tt>null</tt>.
     */
    public BigDecimal getBigDecimal() {
        return isEmpty() ? null : getValue().getBigDecimal();
    }

    /**
     * Sets the allowable range of values.
     * If null is passed in, then {@link IntegerRange#MIN_TO_MAX_INT}
     * is used instead.
     * If the start of the range is open, then {@link Integer#MIN_VALUE}
     * is used instead.
     * If the end of the range is open, then {@link Integer#MAX_VALUE}
     * is used instead.
     */
    public void setValidRange(IntegerRange newRange) {
        if ( newRange == null ) {
            newRange = IntegerRange.MIN_TO_MAX_INT;
        } else {
            if ( newRange.hasDefinedStart() == false ) {
                newRange = newRange.setStart(Integer.MIN_VALUE);
            }

            if ( newRange.hasDefinedEnd() == false ) {
                newRange = newRange.setEnd(Integer.MAX_VALUE);
            }
        }

        if ( ObjectTools.isDifferent(validRange, newRange) ) {
            validRange = newRange;
            recalcSizeAndFilters();
        }
    }

    /**
     * Returns the current range of valid values.
     */
    public IntegerRange getValidRange() {
        return validRange;
    }

    /**
     * Changes the start of the valid range.
     */
    public void setValidRangeStart(Integer newStart) {
        setValidRange(validRange.setStart(newStart));
    }

    /**
     * Changes the start of the valid range.
     */
    public void setValidRangeStart(int newStart) {
        setValidRange(validRange.setStart(newStart));
    }

    /**
     * Changes the start of the valid range.
     */
    public void setValidRangeStart(String newStart) {
        setValidRange(validRange.setStart(newStart));
    }

    /**
     * Changes the start of the valid range.
     */
    public void setValidRangeStart(Value newStart) {
        setValidRange(validRange.setStart(newStart));
    }

    /**
     * Changes the end of the valid range.
     */
    public void setValidRangeEnd(Integer newEnd) {
        setValidRange(validRange.setEnd(newEnd));
    }

    /**
     * Changes the end of the valid range.
     */
    public void setValidRangeEnd(int newEnd) {
        setValidRange(validRange.setEnd(newEnd));
    }

    /**
     * Changes the end of the valid range.
     */
    public void setValidRangeEnd(String newEnd) {
        setValidRange(validRange.setEnd(newEnd));
    }

    /**
     * Changes the end of the valid range.
     */
    public void setValidRangeEnd(Value newEnd) {
        setValidRange(validRange.setEnd(newEnd));
    }

    /**
     * Sets the use of a comma as the thousands grouping character.
     */
    public void setUseComma(boolean useComma) {
        if ( this.useComma != useComma ) {
            this.useComma = useComma;
            recalcSizeAndFilters();
        }
    }

    /**
     * Returns true if commas are currently being used.
     */
    public boolean isUseComma() {
        return useComma;
    }

    /**
     * A pair of {@link IntegerField}'s that are linked together to
     * specify a range.
     * The maximum value that can be entered into the low-end of the
     * range is constrained by the current value in the high-end of
     * the range.
     * Similarly, the minimum value that can be entered into the
     * high-end of the range is constrained by the current value in
     * the low-end of the range.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class RangePair extends Object {
        private IntegerField loTF;
        private IntegerField hiTF;

        public RangePair(IntegerRange validRange) {
            loTF = new IntegerField(validRange);
            hiTF = new IntegerField(validRange);

            loTF.addValueListener(new FormatField.ValueListener() {
                public void valueChanged(FormatField tf) {
                    if ( loTF.isEmpty() ) {
                        hiTF.setValidRangeStart(
                            loTF.getValidRange().getStart());
                    } else {
                        hiTF.setValidRangeStart(loTF.getValue());
                    }
                }
            });

            hiTF.addValueListener(new FormatField.ValueListener() {
                public void valueChanged(FormatField tf) {
                    if ( hiTF.isEmpty() ) {
                        loTF.setValidRangeEnd(hiTF.getValidRange().getEnd());
                    } else {
                        loTF.setValidRangeEnd(hiTF.getValue());
                    }
                }
            });
        }

        public IntegerField getLowEndField() {
            return loTF;
        }

        public IntegerField getHighEndField() {
            return hiTF;
        }

        /**
         * Returns the current values of both the 'lo' and 'hi' fields
         * as a range. This is a handy way to capture both values.
         */
        public IntegerRange getValues() {
            return new IntegerRange(loTF.getInteger(), hiTF.getInteger());
        }

        /**
         * Allows both the values to be set together as this might be
         * necessary to allow them to both successfully be set.
         * For example, if the new 'lo' is greater than the old 'hi',
         * then the new 'hi' value must be set first (and vice versa).
         * @param valueRange the new lo and new hi values expressed in a range.
         */
        public void setValues(IntegerRange valueRange) {
            if ( valueRange.hasDefinedStart() == false ) {
                loTF.setValue(ValueFactory.ZERO_LEN_STRING_INSTANCE);
                if ( valueRange.hasDefinedEnd() == false ) {
                    hiTF.setValue(ValueFactory.ZERO_LEN_STRING_INSTANCE);
                } else {
                    hiTF.setValue(valueRange.getEnd());
                }
            } else if ( valueRange.hasDefinedEnd() == false ) {
                hiTF.setValue(ValueFactory.ZERO_LEN_STRING_INSTANCE);
                loTF.setValue(valueRange.getStart());
            } else {
                // BOTH a lo and hi value are non-null
                if ( loTF.getValidRange().contains(valueRange.getStart()) ) {
                    // New lo is within the currently allowed range for lo,
                    // so set lo first in case hi is coming down
                    loTF.setValue(valueRange.getStart());
                    hiTF.setValue(valueRange.getEnd());
                } else {
                    // New lo is out of the currently allowed range for lo,
                    // so maybe its higher and when we set the value for
                    // hi first, it'll allow lo to fit into the new range:
                    hiTF.setValue(valueRange.getEnd());
                    loTF.setValue(valueRange.getStart());
                }
            }
        }

        /**
         * Allows both the values to be set together as this might be
         * necessary to allow them to both successfully be set.
         * For example, if the <i>new</i> <tt>loValue</tt> is greater than the
         * <i>old</i> <tt>hiValue</tt>, then the <i>new</i> <tt>hiValue</tt>
         * must be set first to allow the new <tt>loValue</tt> to be
         * set without modification (and vice versa).
         *
         * @param loValue the new value for the 'lo' field.
         * <tt>null</tt> is permitted.
         * @param hiValue the new value for the 'hi' field.
         * <tt>null</tt> is permitted.
         *
         * @exception IllegalArgumentException if the <tt>loValue</tt> value
         * is greater than the <tt>hiValue</tt> value.
         */
        public void setValues(Integer loValue, Integer hiValue)
                throws IllegalArgumentException {

            setValues(new IntegerRange(loValue, hiValue));
        }

        /**
         * Allows both the values to be set together as this might be
         * necessary to allow them to both successfully be set.
         * For example, if the <i>new</i> <tt>loValue</tt> is greater than the
         * <i>old</i> <tt>hiValue</tt>, then the <i>new</i> <tt>hiValue</tt>
         * must be set first to allow the new <tt>loValue</tt> to be
         * set without modification (and vice versa).
         *
         * @param loValue the new value for the 'lo' field.
         * @param hiValue the new value for the 'hi' field.
         *
         * @exception IllegalArgumentException if the <tt>loValue</tt> value
         * is greater than the <tt>hiValue</tt> value.
         */
        public void setValues(int loValue, int hiValue)
                throws IllegalArgumentException {

            setValues(new IntegerRange(loValue, hiValue));
        }

        /**
         * Allows both the values to be set together as this might be
         * necessary to allow them to both successfully be set.
         * For example, if the <i>new</i> <tt>loValue</tt> is greater than the
         * <i>old</i> <tt>hiValue</tt>, then the <i>new</i> <tt>hiValue</tt>
         * must be set first to allow the new <tt>loValue</tt> to be
         * set without modification (and vice versa).
         *
         * @param loValue the new value for the 'lo' field.
         * <tt>null</tt> and {@link StringTools#isEmpty(String) empty}
         * strings are permitted.
         * @param hiValue the new value for the 'hi' field.
         * <tt>null</tt> and {@link StringTools#isEmpty(String) empty}
         * strings are permitted.
         *
         * @exception IllegalArgumentException if the <tt>loValue</tt> value
         * is greater than the <tt>hiValue</tt> value.
         */
        public void setValues(String loValue, String hiValue)
                throws IllegalArgumentException {

            setValues(new IntegerRange(loValue, hiValue));
        }

        /**
         * Allows both the values to be set together as this might be
         * necessary to allow them to both successfully be set.
         * For example, if the <i>new</i> <tt>loValue</tt> is greater than the
         * <i>old</i> <tt>hiValue</tt>, then the <i>new</i> <tt>hiValue</tt>
         * must be set first to allow the new <tt>loValue</tt> to be
         * set without modification (and vice versa).
         *
         * @param loValue the new value for the 'lo' field.
         * <tt>null</tt> and {@link Value#isEmpty() empty}
         * values are permitted.
         * @param hiValue the new value for the 'hi' field.
         * <tt>null</tt> and {@link Value#isEmpty() empty}
         * values are permitted.
         *
         * @exception IllegalArgumentException if the <tt>loValue</tt> value
         * is greater than the <tt>hiValue</tt> value.
         */
        public void setValues(Value loValue, Value hiValue)
                throws IllegalArgumentException {

            setValues(new IntegerRange(loValue, hiValue));
        }

        /**
         * Returns the currently valid range of values that can be entered
         * into both fields&mdash;this is the entire range.
         */
        public IntegerRange getValidRange() {
            return new IntegerRange(
                loTF.getValidRange().getStart(),
                hiTF.getValidRange().getEnd());
        }

        // TODO - setValidRange() which is trickier as is has to deal with
        // the current values and ranges of both fields to work correctly.
        //
        //        loValidRange    loValue        hiValue     hiValidRange
        //
        public void setValueRange(IntegerRange newValidRange) {
            /*
            Value oldLoValue = loTF.getValue();
            Value oldHiValue = hiTF.getValue();

            Value newLoValue = ValueFactory.ZERO_LEN_STRING_INSTANCE;
            Value newHiValue = ValueFactory.ZERO_LEN_STRING_INSTANCE;

            if ( oldLoValue.isNotEmpty() ) {
                int lo = oldLoValue.getInt();
                lo = newValidRange.forceIntoRange(lo);
            }
             */
        }
    } // class RangePair
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.