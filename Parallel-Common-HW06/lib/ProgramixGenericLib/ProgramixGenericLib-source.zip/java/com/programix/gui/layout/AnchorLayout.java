package com.programix.gui.layout;

import java.awt.*;
import java.io.*;

import com.programix.gui.*;

/**
 * This {@link LayoutManager} lays out a <b><i>single</i></b> component 
 * within a container "anchoring" it as specified by the {@link AnchorPoint}.
 * <p>
 * If at the time of layout there is more than one component in the
 * container, only the first component is used (the others are ignored). 
 * If there are not any components in the container, this layout manger quietly
 * does nothing.
 *  
 * @see AnchorPoint
 * @see AnchorTableLayout
 * @see FormLayout
 * @see ColumnButtonLayout
 * @see RowButtonLayout
 * @see StackLayout
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class AnchorLayout implements LayoutManager, Serializable {
    /**
     * The default anchor point used when the container is larger than is
     * needed for the child component. 
     * This default value is {@link AnchorPoint#NORTH}.
     */
    public static final AnchorPoint DEFAULT_ANCHOR_POINT = AnchorPoint.NORTH;

    /**
     * The default number of pixels to be placed around the outside of
     * all the child component before the edge of the container. 
     * Used as a padding. This default value is <tt>5</tt>.
     */
    public static final int DEFAULT_BORDER_GAP = 5;
    
    private int borderGap;
    private AnchorPoint anchorPoint;
    
    /**
     * Creates a layout using the specified border size and anchor.
     * 
     * @param borderGap - minimum blanks space around the outside of the 
     * child component. See {@link #setBorderGap setBorderGap}.
     * @param anchorPoint - region to anchor the component into when
     * there is extra space. See {@link #setAnchorPoint setAnchorPoint}.
     */
    public AnchorLayout(int borderGap, AnchorPoint anchorPoint) {
        setBorderGap(borderGap);
        setAnchorPoint(anchorPoint);
    }
    
    /**
     * Creates a layout using the specified anchor.
     * Uses {@link #DEFAULT_BORDER_GAP}.
     * 
     * @param anchorPoint - region to anchor the component into when
     * there is extra space. See {@link #setAnchorPoint setAnchorPoint}.
     */
    public AnchorLayout(AnchorPoint anchorPoint) {
        this(DEFAULT_BORDER_GAP, anchorPoint);
    }
    
    /**
     * Creates a layout using the specified border.
     * Uses {@link #DEFAULT_ANCHOR_POINT}.
     * 
     * @param borderGap - minimum blanks space around the outside of the 
     * child component. See {@link #setBorderGap setBorderGap}.
     */
    public AnchorLayout(int borderGap) {
        this(borderGap, DEFAULT_ANCHOR_POINT);
    }
    
    /**
     * Creates a layout using the {@link #DEFAULT_ANCHOR_POINT}
     * and the {@link #DEFAULT_BORDER_GAP}.
     */
    public AnchorLayout() {
        this(DEFAULT_BORDER_GAP, DEFAULT_ANCHOR_POINT);
    }
    
    /**
     * Called by the graphical subsystem when the container wants to re-layout
     * the components within it.
     */
    public void layoutContainer(Container parent) {
        if ( parent.getComponentCount() < 1 ) {
            return;
        }
        
        Dimension paneSize = parent.getSize();
        Insets paneInsets = parent.getInsets();
        
        Component child = parent.getComponent(0);
        Dimension childPrefSize = child.getPreferredSize();
        
        int availableWidth = paneSize.width -
            ((borderGap * 2) + paneInsets.left + paneInsets.right);
        
        int availableHeight = paneSize.height -
            ((borderGap * 2) + paneInsets.top + paneInsets.bottom);
        
        Rectangle rect = anchorPoint.calcBounds(
            childPrefSize.width, childPrefSize.height, 
            availableWidth, availableHeight);
        
        rect.x += borderGap + paneInsets.left;
        rect.y += borderGap + paneInsets.top;

        child.setBounds(rect);
    }

    /**
     * Called by the graphical subsystem when the container wants to know 
     * what to report its <i>preferred</i> size as. 
     */
    public Dimension preferredLayoutSize(Container parent) {
        Insets paneInsets = parent.getInsets();
        
        Dimension prefSize = new Dimension( 
            (borderGap * 2) + paneInsets.left + paneInsets.right,
            (borderGap * 2) + paneInsets.top + paneInsets.bottom);

        if ( parent.getComponentCount() > 0 ) {
            Component child = parent.getComponent(0);
            Dimension childPrefSize = child.getPreferredSize();
            
            prefSize.width += childPrefSize.width;
            prefSize.height += childPrefSize.height;
        }
        
        return prefSize;
    }
    
    /**
     * Called by the graphical subsystem when the container wants to know 
     * what to report its <i>minimum</i> size as. This layout manager
     * returns its <i>preferred</i> size also as its minimum size. 
     */
    public Dimension minimumLayoutSize(Container parent) {
        return preferredLayoutSize(parent);
    }
    
    /**
     * Called by the graphical subsystem when a component is being removed
     * from the container.
     * This layout manager does nothing for this request.
     */
    public void removeLayoutComponent(Component comp) {
    }

    /**
     * Called by the graphical subsystem when a component is being added
     * to the container.
     * This layout manager does nothing for this request.
     */
    public void addLayoutComponent(String name, Component comp) {
    }

    /**
     * Returns the number of pixels to pad the top, bottom, left, and right 
     * areas around the single child component. 
     * This eliminates the need to set an "empty border" on this container.
     * This is the minimum space between the outermost 
     * edges of the child component and the edge of the container.
     * The actual gap may be larger if the container has insets (and/or
     * a {@link javax.swing.border.Border}). 
     */
    public int getBorderGap() {
        return borderGap;
    }

    /**
     * Changes the number of pixels to pad the top, bottom, left, and right 
     * areas around the single child component. 
     * This eliminates the need to set an "empty border" on this container.
     * This is the minimum space between the outermost 
     * edges of the child component and the edge of the container.
     * The actual gap may be larger if the container has insets (and/or
     * a {@link javax.swing.border.Border}). 
     * Passed value is silently increased to <tt>0</tt> if a negative gap 
     * is specified. 
     */
    public void setBorderGap(int borderGap) {
        this.borderGap = Math.max(0, borderGap);
    }

    /**
     * Returns the region to cluster the single child component in when the 
     * container is bigger than the table requires. 
     */
    public AnchorPoint getAnchorPoint() {
        return anchorPoint;
    }

    /**
     * Changes the region to cluster the table in when the container is 
     * bigger than the table requires. 
     * If <tt>null</tt> is passed in, the {@link #DEFAULT_ANCHOR_POINT} will
     * be used instead. 
     */
    public void setAnchorPoint(AnchorPoint anchorPoint) {
        this.anchorPoint = 
            (anchorPoint != null) ? anchorPoint : DEFAULT_ANCHOR_POINT;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.