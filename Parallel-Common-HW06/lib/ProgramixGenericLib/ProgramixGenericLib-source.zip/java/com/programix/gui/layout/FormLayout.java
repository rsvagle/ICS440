package com.programix.gui.layout;

import java.awt.*;

import com.programix.gui.*;

/**
 * Lays out the components in two (typically) columns, generally with the
 * label in the left column and the input component in the right column.
 * The default number of columns is two, but this can be changed
 * via {@link AnchorTableLayout#setColumnCount(int) setColumnCount(int)}.
 * Each column may be a different width and each row may be a different height.
 * See {@link AnchorTableLayout} for further details.
 * <p>
 * When a component is smaller than the cell space allotted, it will not
 * necessarily be stretched, but anchored within the space
 * (see {@link AnchorPoint}).
 * Components in the left column are (by default) anchored as specified
 * by {@link AnchorPoint#EAST}.
 * Components in the right column are (by default) anchored as specified
 * by {@link AnchorPoint#WEST}.
 * This {@link LayoutManager} is very useful for laying out a standard form.
 * <p>
 * Example: <img src="{@docRoot}/images/FormLayoutDemo.png"
 * width="375" height="268" alt="FormLayoutDemo" align="top"><br clear="all" />
 * Could have been created from:
 * <pre class="preshade">
 * JPanel formPane = new JPanel(new FormLayout());
 * formPane.add(new JLabel("Last Name:"));
 * formPane.add(new JTextField(25));
 * formPane.add(new JLabel("First Name:"));
 * formPane.add(new JTextField(20));
 * formPane.add(new JLabel());
 * formPane.add(new JCheckBox("Active", true));
 * formPane.add(new JLabel("Date of Birth:"));
 * formPane.add(new JTextField(8));
 *
 * JTextArea ta = new JTextArea(5, 10);
 * ta.setWrapStyleWord(true);
 * ta.setLineWrap(true);
 * JScrollPane sp = new JScrollPane(ta);
 * formPane.add(new JLabel("Notes:"), AnchorPoint.NORTHEAST);
 * formPane.add(sp, AnchorPoint.CENTER_FLEX_BOTH);
 *
 * formPane.add(new JLabel("Age:"));
 * formPane.add(new JTextField(3));
 * formPane.add(new JLabel("Start Date:"));
 * formPane.add(new JTextField(8));
 * </pre>
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class FormLayout extends AnchorTableLayout {

    /**
     * Creates a standard two-column form layout.
     *
     * @param rowGap - space between rows.
     *                 See {@link #setRowGap setRowGap}.
     * @param colGap - space between columns.
     *                 See {@link #setColumnGap setColumnGap}.
     * @param borderGap - space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap}.
     * @param anchorPoint - region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint}.
     */
    public FormLayout(int rowGap,
                      int colGap,
                      int borderGap,
                      AnchorPoint anchorPoint) {

        super(2, rowGap, colGap, borderGap, anchorPoint);
    }

    /**
     * Creates a standard two-column form layout.
     * Uses {@link AbstractTableLayout#DEFAULT_ANCHOR_POINT}.
     *
     * @param rowGap - space between rows.
     *                 See {@link #setRowGap setRowGap}.
     * @param colGap - space between columns.
     *                 See {@link #setColumnGap setColumnGap}.
     * @param borderGap - space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap}.
     */
    public FormLayout(int rowGap, int colGap, int borderGap) {
        this(rowGap, colGap, borderGap, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Creates a standard two-column form layout.
     * Uses {@link AbstractTableLayout#DEFAULT_BORDER_GAP}.
     *
     * @param rowGap - space between rows.
     *                 See {@link #setRowGap setRowGap}.
     * @param colGap - space between columns.
     *                 See {@link #setColumnGap setColumnGap}.
     * @param anchorPoint - region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint}.
     */
    public FormLayout(int rowGap, int colGap, AnchorPoint anchorPoint) {
        this(rowGap, colGap, DEFAULT_BORDER_GAP, anchorPoint);
    }

    /**
     * Creates a standard two-column form layout.
     * Uses {@link AbstractTableLayout#DEFAULT_ROW_GAP}.
     * Uses {@link AbstractTableLayout#DEFAULT_COL_GAP}.
     * Uses {@link AbstractTableLayout#DEFAULT_ANCHOR_POINT}.
     *
     * @param borderGap - space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap}.
     */
    public FormLayout(int borderGap) {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP, borderGap, DEFAULT_ANCHOR_POINT);
    }

    /**
     * Creates a standard two-column form layout.
     * Uses {@link AbstractTableLayout#DEFAULT_ROW_GAP}.
     * Uses {@link AbstractTableLayout#DEFAULT_COL_GAP}.
     *
     * @param borderGap - space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap}.
     * @param anchorPoint - region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint}.
     */
    public FormLayout(int borderGap, AnchorPoint anchorPoint) {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP, borderGap, anchorPoint);
    }

    /**
     * Creates a standard two-column form layout.
     * Uses {@link AbstractTableLayout#DEFAULT_ROW_GAP}.
     * Uses {@link AbstractTableLayout#DEFAULT_COL_GAP}.
     * Uses {@link AbstractTableLayout#DEFAULT_BORDER_GAP}.
     *
     * @param anchorPoint - region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint}.
     */
    public FormLayout(AnchorPoint anchorPoint) {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP, DEFAULT_BORDER_GAP, anchorPoint);
    }

    /**
     * Creates a standard two-column form layout.
     * Uses {@link AbstractTableLayout#DEFAULT_ROW_GAP}.
     * Uses {@link AbstractTableLayout#DEFAULT_COL_GAP}.
     * Uses {@link AbstractTableLayout#DEFAULT_BORDER_GAP}.
     * Uses {@link AbstractTableLayout#DEFAULT_ANCHOR_POINT}.
     */
    public FormLayout() {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP,
            DEFAULT_BORDER_GAP, DEFAULT_ANCHOR_POINT);
    }

    @Override
    protected synchronized CellData createCellData(Container pane) {
        return new FormCellData(pane);
    }

    private class FormCellData extends AnchorTableCellData {
        public FormCellData(Container pane) {
            super(pane);
        }

        @Override
        protected AnchorPoint getDefaultAnchor(int colIdx) {
            return (colIdx % 2 == 0) ?
                AnchorPoint.EAST : AnchorPoint.WEST;
                //AnchorPoint.NORTHEAST : AnchorPoint.NORTHWEST;
        }
    } // class FormCellData
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.