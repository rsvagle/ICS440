package com.programix.gui;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.text.*;

import com.programix.gui.image.*;
import com.programix.math.*;
import com.programix.util.*;

public class GuiTools extends Object {
	public static final Font NUMBER_FONT;

	public static final GridLayout ONE_CELL_GRID = new GridLayout();

    private static final Map<Object, Object> FULL_HINTS;
	private static FocusListener selectAllFocusListener;

	static {
		int fontSize = 12;
		try {
			fontSize = (new JTextField()).getFont().getSize();
		} catch ( Throwable t ) {
			// ignore any problems... like no graphical subsystem!
		}

		NUMBER_FONT = new Font("Monospaced", Font.PLAIN, fontSize);

        RenderingHints full = new RenderingHints(
            RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON);
        full.put(RenderingHints.KEY_RENDERING,
            RenderingHints.VALUE_RENDER_QUALITY);
        full.put(RenderingHints.KEY_DITHERING,
            RenderingHints.VALUE_DITHER_DISABLE);
        full.put(RenderingHints.KEY_TEXT_ANTIALIASING,
            RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        full.put(RenderingHints.KEY_FRACTIONALMETRICS,
            RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        full.put(RenderingHints.KEY_INTERPOLATION,
            RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        full.put(RenderingHints.KEY_ALPHA_INTERPOLATION,
            RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        full.put(RenderingHints.KEY_RENDERING,
            RenderingHints.VALUE_RENDER_QUALITY);
        full.put(RenderingHints.KEY_STROKE_CONTROL,
            RenderingHints.VALUE_STROKE_PURE);
        FULL_HINTS = Collections.unmodifiableMap(full);

		selectAllFocusListener = new FocusListener() {
				public void focusGained(FocusEvent e) {
					Object src = e.getSource();
					if ( src instanceof JTextComponent ) {
						JTextComponent tc = (JTextComponent) src;
						tc.selectAll();
					}
				}

				public void focusLost(FocusEvent e) {
					Object src = e.getSource();
					if ( src instanceof JTextComponent ) {
						JTextComponent tc = (JTextComponent) src;
						tc.select(0, 0);
					}
				}
			};

	} // static init

	private GuiTools() {
	}

    /**
     * Returns the usable screen bounds for the screen where this window
     * is currently residing. This is the rectangle available after
     * subtracting insets for task bars, etc.
     */
   	public static Rectangle getUsableScreenBounds(Window window) {
		Toolkit toolkit = window.getToolkit();
		GraphicsConfiguration gc = window.getGraphicsConfiguration();
		Rectangle gcBounds = gc.getBounds();
		Insets gcInsets = toolkit.getScreenInsets(gc);

		int x = gcBounds.x + gcInsets.left;
		int y = gcBounds.y + gcInsets.top;
		int width = gcBounds.width - (gcInsets.left + gcInsets.right);
		int height = gcBounds.height - (gcInsets.top + gcInsets.bottom);

		return new Rectangle(x, y, width, height);
	}

	/**
	 * Returns the usable screen size for the screen where this window
     * is currently residing. This is the space available after
     * subtracting insets for task bars, etc.
	 */
   	public static Dimension getUsableScreenSize(Window window) {
        Rectangle rect = getUsableScreenBounds(window);
        return new Dimension(rect.width, rect.height);
	}

    // If necessary, window is shrunk and/or moved so that no part of it
    // hangs off the specified screen shape
   	private static Rectangle ensureOnScreen(Window window,
                                            Rectangle screenShape) {

        Rectangle origWindowShape = window.getBounds();
        if ( origWindowShape == null || screenShape == null ) {
            return null;
        }

		int newWidth = Math.min(origWindowShape.width, screenShape.width);
		int newHeight = Math.min(origWindowShape.height, screenShape.height);

        int newX = NumberTools.rangeBound(
                screenShape.x,
                origWindowShape.x,
                screenShape.x + (screenShape.width - newWidth));

        int newY = NumberTools.rangeBound(
                screenShape.y,
                origWindowShape.y,
                screenShape.y + (screenShape.height - newHeight));

        if ( newWidth != origWindowShape.width ||
             newHeight != origWindowShape.height ||
             newX != origWindowShape.x ||
             newY != origWindowShape.y
            ) {

            // something changed
            Rectangle newWindowShape =
                new Rectangle(newX, newY, newWidth, newHeight);

            window.setBounds(newWindowShape);
            window.validate();

            return newWindowShape;
        } else {
            return origWindowShape;
        }
	}

    /**
     * If necessary, window is shrunk and/or moved so that no part of it
     * hangs off the edges of the screen.
     * If the window is wider or taller than the screen (minus screen
     * insets), the window is resized.
     * If after any
     * resizing a portion of the window would not be visible because of the
     * location of the window, the window will be moved just enough to get
     * all of the window onto the screen.
     *
     * @param window the window to be moved and/or reduced in size.
     * @return the shape of the window after any moving or shrinking,
     * the original window bounds if no resizing or moving was needed,
     * or <tt>null</tt> if the window's <tt>getBounds()</tt> method
     * returns <tt>null</tt>.
     */
    public static Rectangle ensureOnScreen(Window window) {
        return ensureOnScreen(window, getUsableScreenBounds(window));
    }

    /**
     * Centers the specified window on the screen. If the window is wider or
     * taller than the screen dimensions, the window is shrunk only as much
     * as is necessary to fit entirely within the visible screen space.
     * Screen insets (for things like task bars) are taken into account.
     */
    public static void centerOnScreen(Window window) {
        Rectangle screenShape = getUsableScreenBounds(window);
        Rectangle windowShape = ensureOnScreen(window, screenShape);

        if ( windowShape != null && screenShape != null ) {
            int newX = screenShape.x +
                ((screenShape.width - windowShape.width) / 2);

            int newY = screenShape.y +
                ((screenShape.height - windowShape.height) / 2);

            if ( newX != windowShape.x || newY != windowShape.y ) {
                window.setLocation(newX, newY);
            }
        }
    }

    /**
     * Packs the specified window to get its preferred size, then centers
     * it on the screen. If the preferred window size is wider or taller than
     * the screen, then the window is shrunk to fit.
     * Screen insets (for things like task bars) are taken into account.
     */
    public static void packAndCenterOnScreen(Window window) {
        window.pack();
        centerOnScreen(window);
    }

    /**
     * Sets the specified window to the specified size, then centers
     * it on the screen. If the specified window size is wider or taller than
     * the screen, then the window is shrunk to fit.
     * Screen insets (for things like task bars) are taken into account.
     */
    public static void setSizeAndCenterOnScreen(Window window,
                                                int width,
                                                int height) {

        window.setSize(width, height);
        centerOnScreen(window);
    }

    /**
     * Resizes and/or moves the specified window so that it fills all of the
     * usable screen.
     * Screen insets (for things like task bars) are taken into account.
     */
    public static void setSizeToMax(Window window) {
        window.setBounds(getUsableScreenBounds(window));
    }

    /**
     * Centers <tt>topWindow</tt> over <tt>bottomWindow</tt>.
     * After centering, the top window is run through
     * {@link #ensureOnScreen(Window)} (as a result, the top window will always
     * be entirely on the visible screen&mdash;even at the sacrifice of
     * centering it over the bottom window).
     */
	public static void centerOnTop(Window topWindow, Window bottomWindow) {
        Rectangle screenShape = getUsableScreenBounds(topWindow);
        Rectangle topShape = ensureOnScreen(topWindow, screenShape);
        Rectangle bottomShape = bottomWindow.getBounds();

        if ( topShape != null && bottomShape != null ) {
            int newX = bottomShape.x +
                ((bottomShape.width - topShape.width) / 2);

            int newY = bottomShape.y +
                ((bottomShape.height - topShape.height) / 2);

            if ( newX != topShape.x || newY != topShape.y ) {
                topWindow.setLocation(newX, newY);
                topShape = ensureOnScreen(topWindow, screenShape);
            }
        }
	}

    /**
     * Packs the <tt>topWindow</tt> and then centers it over
     * <tt>bottomWindow</tt>.
     * After centering, the top window is run through
     * {@link #ensureOnScreen(Window)} (as a result, the top window will always
     * be entirely on the visible screen&mdash;even at the sacrifice of
     * centering it over the bottom window).
     */
	public static void packAndCenterOnTop(Window topWindow,
                                          Window bottomWindow) {

        topWindow.pack();
        centerOnTop(topWindow, bottomWindow);
	}

    /**
     * Sets the look and feel hint for <tt>JFrame</tt> and <tt>JDialog</tt>
     * that the entire window should try to use custom decorations.
     * This hint may or may not be observed by the current look and feel.
     *
     * @see JFrame#setDefaultLookAndFeelDecorated(boolean)
     * @see JDialog#setDefaultLookAndFeelDecorated(boolean)
     */
    public static void useWindowDecorations() {
        JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
    }

    /**
     * Removes focus from all components which allows keyboard navigation to
     * still work. This can be helpful when the focus is on a component that
     * is no longer visible.
     */
	public static void clearGlobalFocus() {
		// Allows the focus to be freed from the missing components--
		// which also allows the keyboard menu nav to still work.
		SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					KeyboardFocusManager focusManager =
						KeyboardFocusManager.getCurrentKeyboardFocusManager();
					focusManager.clearGlobalFocusOwner();
				}
			});
	}

	public static JLabel createScaledLabel(String text, double scale) {
		JLabel lab = new JLabel(text, JLabel.CENTER);
		Font f = lab.getFont();
		f = f.deriveFont((float) (f.getSize2D() * scale));
		lab.setFont(f);
		return lab;
	}

	public static JLabel createCenteredOpaqueLabel(String text) {
		JLabel lab = new JLabel(text, JLabel.CENTER);
		lab.setOpaque(true);
		return lab;
	}

	public static Font scaleFont(Font font, double scale) {
		return font.deriveFont((float) (font.getSize2D() * scale));
	}

	public static Component scaleFont(Component comp, double scale) {
		comp.setFont(scaleFont(comp.getFont(), scale));
        return comp;
	}

    public static void setHintsFull(Graphics2D g2) {
        g2.setRenderingHints(FULL_HINTS);
    }

    public static void setQualityHints(Graphics g) {
        if ( g instanceof Graphics2D ) {
            ((Graphics2D) g).setRenderingHints(FULL_HINTS);
        }
    }

	/**
	 * Forces viewport of scrollpane to use a backing store instead
	 * of the default "blit" that causes crud to show up on some
	 * screens.
	 */
	public static JScrollPane setScrollBackingStore(JScrollPane sp) {
		JViewport vp = sp.getViewport();
		vp.setScrollMode(JViewport.BACKINGSTORE_SCROLL_MODE);
		return sp;
	}

    /**
     * Adds a {@link FocusListener} to the specified {@link JTextComponent}
     * that selects all of the text when focus is gained. When the focus
     * is lost, none of the text remains selected.
     */
    public static void selectAllOnFocus(JTextComponent comp) {
        comp.addFocusListener(getSelectAllFocusListener());
    }

    /**
     * Returns a sharable {@link FocusListener} that can be any to any
     * sublcass of {@link JTextComponent}.
     */
	public static FocusListener getSelectAllFocusListener() {
		return selectAllFocusListener;
	}

   	public static void setPreferredSizeToLargest(JComponent[] comp) {
		if ( ObjectTools.isEmpty(comp) ) {
			return;
		}

		int maxWidth = 0;
		int maxHeight = 0;

		for ( int i = 0; i < comp.length; i++ ) {
			Dimension dim = comp[i].getPreferredSize();
			maxWidth = Math.max(maxWidth, dim.width);
			maxHeight = Math.max(maxHeight, dim.height);
		}

		Dimension prefSize = new Dimension(maxWidth, maxHeight);
		for ( int i = 0; i < comp.length; i++ ) {
			comp[i].setPreferredSize(prefSize);
		}
	}

	public static void setPreferredColumnSizes(
				JTable table,
				int minPrefWidth, // including padding
				int maxPrefWidth, // including padding
				int padding,
				int maxRowsToExamine
			) {

		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		int colCount = table.getColumnCount();
		int rowLimit = Math.min(table.getRowCount(), maxRowsToExamine);
		TableColumnModel colModel = table.getColumnModel();

		for ( int col = 0; col < colCount; col++ ) {
			int maxWidth = minPrefWidth;

			TableColumn tc = colModel.getColumn(col);
			TableCellRenderer rend = tc.getHeaderRenderer();

			if ( rend == null ) {
				rend = table.getTableHeader().getDefaultRenderer();
			}

			if ( rend != null ) {
				Component comp = rend.getTableCellRendererComponent(table,
					tc.getHeaderValue(), false, false, -1, col);

				maxWidth = comp.getPreferredSize().width;
			}

			for ( int row = 0; row < rowLimit; row++ ) {
				rend = table.getCellRenderer(row, col);
				if ( rend != null ) {
					Component comp = rend.getTableCellRendererComponent(table,
						table.getValueAt(row, col), false, false, row, col);

					maxWidth = Math.max(maxWidth,
						comp.getPreferredSize().width);

				}

				if ( maxWidth >= (maxPrefWidth - padding) ) {
					break;
				}
			}

			maxWidth += padding;
			int prefWidth =
				Math.min(Math.max(minPrefWidth, maxWidth), maxPrefWidth);

			tc.setMinWidth(5);
			tc.setMaxWidth(1000);
			tc.setPreferredWidth(prefWidth);
		}
	}

	public static void setPreferredColumnSizes(JTable table) {
		setPreferredColumnSizes(table, 20, 250, 5, 15);
	}

	public static void setAutoScrollToFocus(JScrollPane sp) {
		JViewport vp = sp.getViewport();

		ScrollFocusListener fl = new ScrollFocusListener(vp);

		Component[] comp = getAllComponents(vp);
		for ( int i = 0; i < comp.length; i++ ) {
			if ( comp[i].isFocusable() ) {
				comp[i].addFocusListener(fl);
			}
		}
	}

	private static class ScrollFocusListener extends FocusAdapter {
		private JViewport vp;

		public ScrollFocusListener(JViewport vp) {
			this.vp = vp;
		}

		@Override
        public void focusGained(FocusEvent e) {
			Component comp = e.getComponent();
			Dimension compSize = comp.getSize();

			Point p = SwingUtilities.convertPoint(comp, 0, 0, vp);
			Rectangle dest =
				new Rectangle(p.x, p.y, compSize.width, compSize.height);

			vp.scrollRectToVisible(dest);
		}
	} // ScrollFocusListener

	/**
	 * Creates an empty border for the outer border and an empty border
	 * for the inner border and then sandwiches the middle border in
	 * between.
	 */
	public static Border createSandwichBorder(
				int outerThickness,
				int innerThickness,
				Border middleBorder
			) {

		return createCompoundBorder(
				BorderFactory.createEmptyBorder(outerThickness,
						outerThickness, outerThickness, outerThickness),
				middleBorder,
				BorderFactory.createEmptyBorder(innerThickness,
						innerThickness, innerThickness, innerThickness)
			);
	}

	/**
	 * Combines 3 borders into 1 border.
	 */
	public static Border createCompoundBorder(
				Border outerBorder,
				Border middleBorder,
				Border innerBorder
			) {

		return BorderFactory.createCompoundBorder(
				outerBorder,
				BorderFactory.createCompoundBorder(
					middleBorder,
					innerBorder));
	}

    public static void setEmptyBorder(JComponent target, int thickness) {
        target.setBorder(BorderFactory.createEmptyBorder(
            thickness, thickness, thickness, thickness));
    }

	/**
	 * Gets all the components contained (recursively).
	 */
	public static Component[] getAllComponents(Container con) {
		List<Component> list = new ArrayList<Component>();
		list.addAll(Arrays.asList(con.getComponents()));

		for ( int ptr = 0; ptr < list.size(); ptr++ ) {
			Component c = (Component) list.get(ptr);
			if ( c instanceof Container ) {
				list.addAll(Arrays.asList(((Container) c).getComponents()));
			}
		}

		return (Component[]) list.toArray(new Component[0]);
	}

    /**
     * Creates an <tt>ImageIcon</tt> from the data stored in the
     * specified resource. The specified resource is <i>not</i> a filename,
     * but is a resource that can be loaded from JAR's, WAR's, etc.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return new ImageIcon(
     *     {@link ImageTools#createImageFromResource(String)
     * ImageTools.createImageFromResource}(imageResourceLocation));
     * </pre>
     * The exceptions declared to be thrown from this method are subclasses
     * of {@link RuntimeException}, so callers are not <i>required</i> to
     * catch them.
     */
    public static ImageIcon createIcon(String imageResourceLocation)
            throws ImageTools.ImageNotFoundException,
                   ImageTools.ImageException {

        return new ImageIcon(
            ImageTools.createImageFromResource(imageResourceLocation));
    }

    /**
     * Creates a <tt>TexturePaint</tt> from the data stored in the
     * specified resource. The specified resource is <i>not</i> a filename,
     * but is a resource that can be loaded from JAR's, WAR's, etc.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return new ImageIcon(
     *     {@link ImageTools#createImageFromResource(String)
     * ImageTools.createImageFromResource}(imageResourceLocation));
     * BufferedImage image =
     *     {@link ImageTools#createImageFromResource(String)
     * ImageTools.createImageFromResource}(imageResourceLocation);
     *
     * return new TexturePaint(image, new Rectangle2D.Double(0, 0,
     *     image.getWidth(), image.getHeight()));
     * </pre>
     * The exceptions declared to be thrown from this method are subclasses
     * of {@link RuntimeException}, so callers are not <i>required</i> to
     * catch them.
     */
    public static TexturePaint createTexturePaint(String imageResourceLocation)
            throws ImageTools.ImageNotFoundException,
                   ImageTools.ImageException {

        BufferedImage image =
            ImageTools.createImageFromResource(imageResourceLocation);

        return new TexturePaint(image, new Rectangle2D.Double(0, 0,
            image.getWidth(), image.getHeight()));
    }

    // TODO -- keep this?
//    public static JPanel wrapWithComponentOutliner(Container con) {
//
//    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.