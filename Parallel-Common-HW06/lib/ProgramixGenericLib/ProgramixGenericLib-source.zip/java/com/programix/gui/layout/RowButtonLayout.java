package com.programix.gui.layout;

import com.programix.gui.*;

/**
 * Lays out the components in row(s) forcing all of the components to be
 * the same size. This {@link java.awt.LayoutManager} is very useful for 
 * laying out a row of buttons (if you want a column of buttons, 
 * see {@link ColumnButtonLayout}. 
 * The buttons will <i>not</i> stretch if the container is
 * too tall or too wide, instead the buttons will stay clustered together in
 * the area indicated by the {@link AnchorPoint}. 
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class RowButtonLayout extends ButtonLayout {
    /**
     * The default number of rows to use, value is <tt>1</tt>.
     */
    public static final int DEFAULT_ROW_COUNT = 1;

    /**
     * Creates a layout for a row (or rows) of equally sized components.
     * 
     * @param rowGap - space between rows&mdash;if there is more than one row.
     *                 See {@link #setRowGap setRowGap}.
     * @param colGap - space between columns. 
     *                 See {@link #setColumnGap setColumnGap}. 
     * @param borderGap - space around the outside of the buttons.
     *                 See {@link #setBorderGap setBorderGap}.
     * @param anchorPoint - region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint}.
     * @param rowCount - the number of rows to create, very often just 1.
     *                 See {@link #setRowCount setRowCount}.
     */
    public RowButtonLayout(int rowGap,
                           int colGap,
                           int borderGap,
                           AnchorPoint anchorPoint,
                           int rowCount) {
        
        super(rowGap, colGap, borderGap, anchorPoint, rowCount, false);
    }

    /**
     * Creates a layout for exactly one row of equally sized components.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_ROW_COUNT DEFAULT_ROW_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #RowButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public RowButtonLayout(int rowGap,
                           int colGap,
                           int borderGap,
                           AnchorPoint anchorPoint) {
        
        this(rowGap, colGap, borderGap, anchorPoint, DEFAULT_ROW_COUNT);
    }

    /**
     * Creates a layout for exactly one row of equally sized components
     * anchored in the {@link AnchorPoint#NORTH} region.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT} (which is 
     *     <tt>{@link AnchorPoint#NORTH AnchorPoint.NORTH}</tt>)</li>
     * <li>{@link #DEFAULT_ROW_COUNT DEFAULT_ROW_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #RowButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public RowButtonLayout(int rowGap, int colGap, int borderGap) {
        this(rowGap, colGap, borderGap, 
             DEFAULT_ANCHOR_POINT, DEFAULT_ROW_COUNT);
    }

    /**
     * Creates a layout for exactly one row of equally sized components
     * anchored in the specified region.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_COL_GAP DEFAULT_COL_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_ROW_COUNT DEFAULT_ROW_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #RowButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public RowButtonLayout(int borderGap, AnchorPoint anchorPoint) {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP, borderGap, 
             anchorPoint, DEFAULT_ROW_COUNT); 
    }

    /**
     * Creates a layout for exactly one row of equally sized components
     * anchored in the specified region.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_COL_GAP DEFAULT_COL_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP} 
     *      (which is equal to <tt>5</tt>)</li>
     * <li>{@link #DEFAULT_ROW_COUNT DEFAULT_ROW_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #RowButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public RowButtonLayout(AnchorPoint anchorPoint) {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP, DEFAULT_BORDER_GAP, 
             anchorPoint, DEFAULT_ROW_COUNT); 
    }

    /**
     * Creates a layout for exactly one row of equally sized components
     * anchored in the {@link AnchorPoint#NORTH} region.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_COL_GAP DEFAULT_COL_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP} 
     *      (which is equal to <tt>5</tt>)</li>
     * <li>{@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT} (which is 
     *     <tt>{@link AnchorPoint#NORTH AnchorPoint.NORTH}</tt>)</li>
     * <li>{@link #DEFAULT_ROW_COUNT DEFAULT_ROW_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #RowButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public RowButtonLayout() {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP, DEFAULT_BORDER_GAP, 
             DEFAULT_ANCHOR_POINT, DEFAULT_ROW_COUNT); 
    }

    /**
     * Returns the number of rows that this layout will always have. The
     * number of columns is calculated based on the number of components
     * in the container.
     */
    public int getRowCount() {
        return requestedRowOrColCount;
    }
    
    /**
     * Changes the number of rows in this layout. 
     * Passed value is silently increased to <tt>1</tt> if a smaller count
     * is specified. 
     */
    public void setRowCount(int rowCount) {
        this.requestedRowOrColCount = Math.max(1, rowCount);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.