package com.programix.gui.layout;

import java.awt.*;

import javax.swing.*;

import com.programix.gui.*;

public class ComponentOutliner extends JComponent {
    private static final Color[] STANDARD_COLOR = new Color[] {
        new Color(255, 255, 255, 128), // white
        new Color(244, 172, 132, 128), // orange
        new Color(148, 252, 252, 128), // light blue
        new Color(252, 156, 204, 128), // pink
        new Color(252, 252, 156, 128), // yellow
        new Color( 52, 247, 148, 128)  // green
    };

    private volatile int depth = 0;
    private final Color[] depthColor;
    private Point scratchPoint = new Point();
    private Dimension scratchDim = new Dimension();

    public ComponentOutliner(Container con, Color[] depthColor) {
        super.setLayout(GuiTools.ONE_CELL_GRID);
        super.add(con);

        this.depthColor = depthColor;
        new Timer();
    }

    public ComponentOutliner(Container con) {
        this(con, STANDARD_COLOR);
    }

    private synchronized void nextDepth() {
        depth = (depth + 1) % depthColor.length;
        repaint();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        if ( getComponentCount() > 0 ) {
            Component c = getComponent(0);
            if ( c.isShowing() ) {
                outline(g, c, 0);
            }
        }
    }

    private void outline(Graphics g, Component comp, int level) {
        scratchPoint.x = comp.getX();
        scratchPoint.y = comp.getY();

        SwingUtilities.convertPointToScreen(scratchPoint, comp.getParent());
        SwingUtilities.convertPointFromScreen(scratchPoint, this);

        comp.getSize(scratchDim);

        g.setColor(depthColor[level]);
//        g.drawRect(scratchRect.x,
//            scratchRect.y,
//            scratchRect.width - 1,
//            scratchRect.height - 1);
        g.fillRect(scratchPoint.x,
            scratchPoint.y,
            scratchDim.width,
            scratchDim.height);

        if ( level < depth && comp instanceof Container ) {
            Container con = (Container) comp;
            Component[] c = con.getComponents();
            for ( int i = 0; i < c.length; i++ ) {
                if ( c[i].isShowing() ) {
                    outline(g, c[i], level + 1);
                }
            }
        }
    }

    private class Timer implements Runnable {
        public Timer() {
            new Thread(this).start();
        }

        public void run() {
            try {
                while ( true ) {
                    Thread.sleep(1000);
                    nextDepth();
                }
            } catch ( InterruptedException x ) {
                // ignore and return
            }
        }
    } // class Timer
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.