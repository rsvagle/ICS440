package com.programix.gui.plaf.theme;

import javax.swing.plaf.*;
import javax.swing.plaf.metal.*;

public class KhakiMetalTheme extends DefaultMetalTheme {

    @Override
    public String getName() {
        return "Sandstone";
    }

    private final ColorUIResource primary1 = new ColorUIResource(87, 87, 47);
    private final ColorUIResource primary2 = new ColorUIResource(159, 151, 111);
    private final ColorUIResource primary3 = new ColorUIResource(199, 183, 143);

    private final ColorUIResource secondary1 = new ColorUIResource(111, 111,
        111);
    private final ColorUIResource secondary2 = new ColorUIResource(159, 159,
        159);
    private final ColorUIResource secondary3 = new ColorUIResource(231, 215,
        183);

    @Override
    protected ColorUIResource getPrimary1() {
        return primary1;
    }

    @Override
    protected ColorUIResource getPrimary2() {
        return primary2;
    }

    @Override
    protected ColorUIResource getPrimary3() {
        return primary3;
    }

    @Override
    protected ColorUIResource getSecondary1() {
        return secondary1;
    }

    @Override
    protected ColorUIResource getSecondary2() {
        return secondary2;
    }

    @Override
    protected ColorUIResource getSecondary3() {
        return secondary3;
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.