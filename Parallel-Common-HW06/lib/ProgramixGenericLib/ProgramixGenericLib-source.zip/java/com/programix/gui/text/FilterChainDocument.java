package com.programix.gui.text;

import java.util.*;

import javax.swing.text.*;

import com.programix.util.*;

/**
 * This is a extension of {@link PlainDocument} that allows zero or more
 * filters to be applied to text that is trying to be inserted.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class FilterChainDocument extends PlainDocument {
    /**
     * {@link Filter} that translates any lower-case characters
     * to upper-case.
     */
    public static final Filter TO_UPPER_CASE_FILTER = new ToUpperCaseFilter();

    /**
     * {@link Filter} that translates any upper-case characters
     * to lower-case.
     */
    public static final Filter TO_LOWER_CASE_FILTER = new ToLowerCaseFilter();

    /**
     * {@link Filter} that keeps the characters as specified in
     * {@link StringTools#winnowAlpha(String)}.
     */
    public static final Filter ALPHA_FILTER = new AlphaFilter();

    /**
     * {@link Filter} that keeps the characters as specified in
     * {@link StringTools#winnowAlphaNumeric(String)}.
     */
    public static final Filter ALPHANUMERIC_FILTER = new AlphaNumericFilter();

    /**
     * {@link Filter} that keeps the characters as specified in
     * {@link StringTools#winnowDigit(String)}.
     */
    public static final Filter DIGIT_FILTER = new DigitFilter();

    /**
     * {@link Filter} that keeps the characters as specified in
     * {@link StringTools#winnowDecimal(String)}.
     */
    public static final Filter DECIMAL_FILTER = new DecimalFilter();

    private List<Filter> filterList;

    public FilterChainDocument(Filter firstFilter) {
        if ( firstFilter != null ) {
            append(firstFilter);
        }
    }

    public FilterChainDocument() {
        this(null);
    }

    public synchronized FilterChainDocument append(Filter filter) {
        if ( filterList == null ) {
            filterList = new ArrayList<Filter>(5);
        }

        filterList.add(filter);
        return this;
    }

    public synchronized void clear() {
        if ( filterList != null ) {
            filterList.clear();
        }
    }

    @Override
    public synchronized void insertString(int offset,
                                          String src,
                                          AttributeSet attr)
            throws BadLocationException {

        if ( filterList == null || filterList.size() < 1 ) {
            super.insertString(offset, src, attr);
        } else {
            String s = StringTools.nullToBlank(src);

            for ( Filter f : filterList ) {
                s = StringTools.nullToBlank(f.filter(offset, s, this));
            }

            super.insertString(offset, s, attr);
        }
    }

    /**
     * Interface that all filters for a {@link FilterChainDocument}
     * must implement.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static interface Filter {
        String filter(int offset, String src, Document doc);
    } // interface Filter

    /**
     * Implements the {@link Filter} interface and provides a new, single
     * {@link #filter(String)} <tt>abstract</tt> method for subclasses
     * to implement.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static abstract class BasicFilter implements Filter {
        /**
         * Calls the {@link #filter(String)} method ignoring
         * the <tt>offset</tt> and the <tt>doc</tt>.
         */
        public String filter(int offset, String src, Document doc) {
            return filter(src);
        }

        /**
         * Implement in subclasses for filters that don't need access
         * to the {@link Document} or the <tt>offset</tt> into the document
         * for the current <tt>String</tt> insertion.
         * @param src proposed characters to insert
         * @return the subset of the proposed characters to insert. If no
         * alterations are needed, the <tt>src</tt> may be returned.
         */
        protected abstract String filter(String src);
    } // class BasicFilter

    /**
     * Winnows out invalid characters from the <tt>source</tt> <tt>String</tt>
     * keeping <i>only</i> the characters specified as valid during
     * construction. For more on "winnowing", see
     * {@link StringTools#winnow(String, char[])}.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class WinnowFilter extends BasicFilter implements Filter {
        private char[] sortedValidChar;

        /**
         * Constructor used to specify the characters to keep as a
         * <tt>char[]</tt>.
         *
         * @param validChar characters to keep; does <i>not</tt> have to be
         * sorted at all.
         */
        public WinnowFilter(char[] validChar) {
            sortedValidChar = StringTools.toSortedCharArray(validChar);
        }

        /**
         * Constructor used to specify the characters to keep as a
         * <tt>String</tt>.
         *
         * @param validChar a <tt>String</tt> containing all the characters
         * to keep; does <i>not</tt> have to be sorted at all.
         */
        public WinnowFilter(String validChar) {
            sortedValidChar = StringTools.toSortedCharArray(validChar);
        }

        @Override
        protected String filter(String src) {
            return StringTools.winnow(src, sortedValidChar);
        }
    } // class WinnowFilter

    private static class AlphaFilter extends BasicFilter implements Filter {
        @Override
        protected String filter(String src) {
            return StringTools.winnowAlpha(src);
        }
    } // class AlphaFilter

    private static class AlphaNumericFilter
            extends BasicFilter implements Filter {

        @Override
        protected String filter(String src) {
            return StringTools.winnowAlphaNumeric(src);
        }
    } // class AlphaNumericFilter

    private static class DigitFilter extends BasicFilter implements Filter {
        @Override
        protected String filter(String src) {
            return StringTools.winnowDigit(src);
        }
    } // class DigitFilter

    private static class DecimalFilter extends BasicFilter implements Filter {
        @Override
        protected String filter(String src) {
            return StringTools.winnowDecimal(src);
        }
    } // class DecimalFilter

    private static class ToUpperCaseFilter extends BasicFilter implements Filter {
        @Override
        protected String filter(String src) {
            return (src == null) ? null : src.toUpperCase();
        }
    } // class ToUpperCaseFilter

    private static class ToLowerCaseFilter extends BasicFilter implements Filter {
        @Override
        protected String filter(String src) {
            return (src == null) ? null : src.toLowerCase();
        }
    } // class ToLowerCaseFilter

    /**
     * Filters content by only allowing a maximum number of characters to
     * be in the document. When the max length is present, insertion of
     * additional characters are ignored.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class LengthFilter extends Object implements Filter {
        private int maxLength;

        public LengthFilter(int maxLength) {
            this.maxLength = maxLength;
        }

        public String filter(int offset, String src, Document doc) {
            int spaceLeft = maxLength - doc.getLength();

            if ( spaceLeft <= 0 ) {
                return StringTools.ZERO_LEN_STRING;
            } else if ( spaceLeft >= src.length() ) {
                return src;
            } else {
                return src.substring(0, spaceLeft);
            }
        }
    } // class LengthFilter
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.