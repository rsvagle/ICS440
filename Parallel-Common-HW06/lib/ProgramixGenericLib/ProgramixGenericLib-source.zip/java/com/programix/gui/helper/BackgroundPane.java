package com.programix.gui.helper;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

import javax.swing.*;

import com.programix.gui.*;
import com.programix.gui.image.*;
import com.programix.gui.layout.*;
import com.programix.thread.*;

public class BackgroundPane {
    private static final Paint CLEAR_PAINT = Color.WHITE;
    private static final Paint SHADING = new Color(128, 128, 128, 128);

    private Deck deck;
    private Deck.Card childCard;
    private Deck.Card workingCard;

    private BufferedImage workingImage;
    private Graphics2D workingGraphics;
    private Dimension workingImageSize;
    private Picture workingPicture;

    private boolean working;

    public BackgroundPane() {
        deck = new Deck();
        childCard = deck.createCard();
        workingCard = deck.createCard();

        workingPicture = new Picture();
        workingCard.add(workingPicture);
    }

    public JComponent getVisualComponent() {
        return deck;
    }

    public void setChild(JComponent child) {
        childCard.removeAll();
        childCard.add(child);
    }

    private void createWorkingImageIfNeeded(Dimension size) {
        if ( workingImage == null ||
             workingImageSize == null ||
             workingImageSize.equals(size) == false ) {

            workingImageSize = size;
            workingImage = new BufferedImage(
                size.width, size.height, BufferedImage.TYPE_INT_ARGB);
            workingGraphics = workingImage.createGraphics();

            workingPicture.setImage(workingImage);
System.out.println("created new image");
        }
    }

    public void setWorking(final boolean working) {
        if ( SwingUtilities.isEventDispatchThread() == false ) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    setWorking(working);
                }
            });

            return;
        }

        if ( this.working == working ) {
            return; // no change in state
        }

        this.working = working;

        if ( working ) {
            createWorkingImageIfNeeded(workingCard.getSize());

            workingGraphics.setPaint(CLEAR_PAINT);
            workingGraphics.fillRect(
                0, 0, workingImageSize.width, workingImageSize.height);
System.out.println("cleared");

            childCard.paint(workingGraphics);
System.out.println("painted");

            workingGraphics.setPaint(SHADING);
            workingGraphics.fillRect(
                0, 0, workingImageSize.width, workingImageSize.height);

            workingPicture.repaint();
            workingCard.toFront();
        } else {
            childCard.toFront();
        }
    }

    private static class BackgroundWorker implements Runnable {
        private final BackgroundPane backgroundPane;
        private final long msDelay;

        public BackgroundWorker(BackgroundPane backgroundPane,
                                long msDelay) {

            this.backgroundPane = backgroundPane;
            this.msDelay = msDelay;

            new Thread(this).start();
        }

        @Override
        public void run() {
            ThreadTools.nap(msDelay);
            backgroundPane.setWorking(false);
        }
    } // class BackgroundWorker

    public static void main(String[] args) {
        final BackgroundPane backgroundPane = new BackgroundPane();

        JButton processB = new JButton("Process");
        processB.setMnemonic(KeyEvent.VK_P);
        processB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("pressed");
                backgroundPane.setWorking(true);
                new BackgroundWorker(backgroundPane, 5000);
            }
        });

        JPanel p = new JPanel(new FormLayout());
        p.add(new JLabel("Name:"));
        p.add(new JTextField(20));
        p.add(new JLabel("Address:"));
        p.add(new JTextField(30));
        p.add(new JLabel());
        p.add(processB);

        backgroundPane.setChild(p);


        JPanel contentPane = new JPanel(new GridLayout());
        contentPane.add(backgroundPane.getVisualComponent());

        JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
        //GuiTools.useWindowDecorations();

        JFrame f = new JFrame("BackgroundPane");
        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.setContentPane(contentPane);

        f.setSize(600, 450);
        //GuiTools.packAndCenterOnScreen(f);
        //GuiTools.setSizeAndCenterOnScreen(f, 600, 450);
        //GuiTools.setSizeToMax(f);
        f.setVisible(true);

        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.