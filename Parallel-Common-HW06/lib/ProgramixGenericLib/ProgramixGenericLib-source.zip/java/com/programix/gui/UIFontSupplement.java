package com.programix.gui;

/**
 * This class is used to find supplemental fonts for user interfaces.
 * These fonts are derived from the current look and feel. For example, 
 * the supplemental font may be scaled to be 1.5x larger than the 
 * default font for a label.  
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class UIFontSupplement {

}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.