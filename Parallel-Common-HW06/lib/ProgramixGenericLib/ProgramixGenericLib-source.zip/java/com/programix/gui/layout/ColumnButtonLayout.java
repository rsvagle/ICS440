package com.programix.gui.layout;

import com.programix.gui.*;

/**
 * Lays out the components in column(s) forcing all of the components to be
 * the same size. This {@link java.awt.LayoutManager} is very useful for 
 * laying out a column of buttons (if you want a row of buttons, 
 * see {@link RowButtonLayout}. 
 * The buttons will <i>not</i> stretch if the container is
 * too tall or too wide, instead the buttons will stay clustered together in
 * the area indicated by the {@link AnchorPoint}. 
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ColumnButtonLayout extends ButtonLayout {
    /**
     * The default number of columns to use, value is <tt>1</tt>.
     */
    public static final int DEFAULT_COLUMN_COUNT = 1;

    /**
     * Creates a layout for a column (or columns) of equally sized components.
     * 
     * @param rowGap - space between rows.
     *                 See {@link #setRowGap setRowGap}.
     * @param colGap - space between columns&mdash;if 
     *                 there is more than one column. 
     *                 See {@link #setColumnGap setColumnGap}. 
     * @param borderGap - space around the outside of the buttons.
     *                 See {@link #setBorderGap setBorderGap}.
     * @param anchorPoint - region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint}.
     * @param colCount - the number of columns to create, very often just 1.
     *                 See {@link #setColumnCount setColumnCount}.
     */
    public ColumnButtonLayout(int rowGap,
                              int colGap,
                              int borderGap,
                              AnchorPoint anchorPoint,
                              int colCount) {
        
        super(rowGap, colGap, borderGap, anchorPoint, colCount, true);
    }

    /**
     * Creates a layout for exactly one column of equally sized components.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_COLUMN_COUNT DEFAULT_COLUMN_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #ColumnButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public ColumnButtonLayout(int rowGap,
                              int colGap,
                              int borderGap,
                              AnchorPoint anchorPoint) {
        
        this(rowGap, colGap, borderGap, anchorPoint, DEFAULT_COLUMN_COUNT);
    }

    /**
     * Creates a layout for exactly one column of equally sized components
     * anchored in the {@link AnchorPoint#NORTH} region.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT} (which is 
     *     <tt>{@link AnchorPoint#NORTH AnchorPoint.NORTH}</tt>)</li>
     * <li>{@link #DEFAULT_COLUMN_COUNT DEFAULT_COLUMN_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #ColumnButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public ColumnButtonLayout(int rowGap, int colGap, int borderGap) {
        this(rowGap, colGap, borderGap, 
             DEFAULT_ANCHOR_POINT, DEFAULT_COLUMN_COUNT);
    }

    /**
     * Creates a layout for exactly one column of equally sized components
     * anchored in the specified region.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_COL_GAP DEFAULT_COL_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_COLUMN_COUNT DEFAULT_COLUMN_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #ColumnButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public ColumnButtonLayout(int borderGap, AnchorPoint anchorPoint) {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP, borderGap, 
             anchorPoint, DEFAULT_COLUMN_COUNT); 
    }
    
    /**
     * Creates a layout for exactly one column of equally sized components
     * anchored in the specified region.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_COL_GAP DEFAULT_COL_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP} 
     *      (which is equal to <tt>5</tt>)</li>
     * <li>{@link #DEFAULT_COLUMN_COUNT DEFAULT_COLUMN_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #ColumnButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public ColumnButtonLayout(AnchorPoint anchorPoint) {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP, DEFAULT_BORDER_GAP, 
             anchorPoint, DEFAULT_COLUMN_COUNT); 
    }
    
    /**
     * Creates a layout for exactly one column of equally sized components
     * anchored in the {@link AnchorPoint#NORTH} region.
     * Calls the main constructor passing in:
     * <ul>
     * <li>{@link #DEFAULT_ROW_GAP DEFAULT_ROW_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_COL_GAP DEFAULT_COL_GAP} 
     *      (which is equal to <tt>3</tt>)</li>
     * <li>{@link #DEFAULT_BORDER_GAP DEFAULT_BORDER_GAP} 
     *      (which is equal to <tt>5</tt>)</li>
     * <li>{@link #DEFAULT_ANCHOR_POINT DEFAULT_ANCHOR_POINT} (which is 
     *     <tt>{@link AnchorPoint#NORTH AnchorPoint.NORTH}</tt>)</li>
     * <li>{@link #DEFAULT_COLUMN_COUNT DEFAULT_COLUMN_COUNT} 
     *      (which is equal to <tt>1</tt>)</li>
     * </ul>
     * 
     * @see #ColumnButtonLayout(int, int, int, AnchorPoint, int) 
     */
    public ColumnButtonLayout() {
        this(DEFAULT_ROW_GAP, DEFAULT_COL_GAP, DEFAULT_BORDER_GAP,
             DEFAULT_ANCHOR_POINT, DEFAULT_COLUMN_COUNT); 
    }
    
    /**
     * Returns the number of columns that this layout will always have. The
     * number of rows is calculated based on the number of components
     * in the container.
     */
    public int getColumnCount() {
        return requestedRowOrColCount;
    }
    
    /**
     * Changes the number of columns in this layout. 
     * Passed value is silently increased to <tt>1</tt> if a smaller count
     * is specified. 
     */
    public void setColumnCount(int columnCount) {
        this.requestedRowOrColCount = Math.max(1, columnCount);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.