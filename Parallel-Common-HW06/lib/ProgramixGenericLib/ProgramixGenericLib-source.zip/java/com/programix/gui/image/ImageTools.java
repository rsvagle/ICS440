package com.programix.gui.image;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;

import javax.imageio.*;
import javax.imageio.stream.*;
import javax.swing.*;

import com.programix.io.*;
import com.programix.util.*;

/**
 * Collection of functions useful for working with {@link Image} and
 * {@link java.awt.image.BufferedImage}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ImageTools {
    public static final String PNG_FORMAT = "png";
    public static final String JPEG_FORMAT = "jpeg";

    // No instances
    private ImageTools() {
    }

    /**
     * Creates a {@link BufferedImage} by reading from the specified source
     * which should be presenting the data in a PNG, JPEG, GIF, etc. format.
     * The {@link InputStream} passed in is closed by this method.
     *
     * @param source origin of the image; stream is always closed by this method
     * @return the decoded image
     * @throws ImageException if there is no support for the image format
     * or if there is any problem reading from the stream.
     */
    public static BufferedImage createImage(InputStream source)
            throws ImageException {

        MemoryCacheImageInputStream iis = null;

        try {
            if ( (source instanceof BufferedInputStream) == false &&
                 (source instanceof ByteArrayInputStream) == false ) {

                source = new BufferedInputStream(source, 64 * 1024);
            }

            iis = new MemoryCacheImageInputStream(source);

            BufferedImage image = ImageIO.read(iis);
            if ( image == null ) {
                throw new ImageException("No suitable ImageReader found for " +
                        "the data in the specified source");
            }

            return image;
        } catch ( IOException x ) {
            throw new ImageException(x);
        } finally {
            closeQuietly(iis);
            IOTools.closeQuietly(source);
        }
    }

    /**
     * Creates a {@link BufferedImage} by reading from the specified file.
     * The image's data must be in a PNG, JPEG, GIF, or other format that can
     * be read by {@link ImageIO}.
     *
     * @param source origin of the image
     * @return the decoded image
     * @throws ImageNotFoundException if the specified file can not be found.
     * @throws ImageException if there is no support for the image format
     * or if there is any other problem reading from the stream.
     */
    public static BufferedImage createImage(File source)
            throws ImageNotFoundException, ImageException {

        if ( source == null ) {
            throw new ImageNotFoundException(
                "Can not create BufferedImage from null File reference");
        }

        try {
            return createImage(new FileInputStream(source));
        } catch ( FileNotFoundException x ) {
            throw new ImageNotFoundException(source.toString());
        }
    }

    /**
     * Creates a {@link BufferedImage} by reading from the specified file.
     * The image's data must be in a PNG, JPEG, GIF, or other format that can
     * be read by {@link ImageIO}.
     *
     * @param filename origin of the image
     * @return the decoded image
     * @throws ImageNotFoundException if the specified file can not be found.
     * @throws ImageException if there is no support for the image format
     * or if there is any other problem reading from the stream.
     */
    public static BufferedImage createImageFromFile(String filename)
            throws ImageNotFoundException, ImageException {

        if ( StringTools.isEmpty(filename) ) {
            throw new ImageNotFoundException(
                "Can not create BufferedImage from empty string");
        }

        return createImage(new File(filename));
    }

    /**
     * Creates a {@link BufferedImage} by reading from the specified
     * {@link URL}.
     * The image's data must be in a PNG, JPEG, GIF, or other format that can
     * be read by {@link ImageIO}.
     *
     * @param imageUrl origin of the image
     * @return the decoded image
     * @throws ImageException if there is no support for the image format
     * or if there is any other problem reading from the stream.
     */
    public static BufferedImage createImage(URL imageUrl)
            throws ImageException {

        if ( imageUrl == null ) {
            throw new ImageException(
                "Can not create BufferedImage from null URL reference");
        }

        try {
            return createImage(imageUrl.openStream());
        } catch ( IOException x ) {
            throw new ImageException(x);
        }
    }


    /**
     * Creates a {@link BufferedImage} by reading from the specified resource.
     * The image's data must be in a PNG, JPEG, GIF, or other format that can
     * be read by {@link ImageIO}.
     *
     * The underlying <tt>InputStream</tt> comes from the specified
     * <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * The {@link Class#getResource(String) getResource(String path)}
     * method on the {@link Class} object passed in is used
     * to locate the requested resource.
     * See {@link IOTools#getUrlForResource(String, Class)
     * IOTools.getUrlForResource(String, Class)} for the full explanation
     * of how the search for the <tt>URL</tt> is performed.
     * <p>
     * Works like this (with IOExceptions converted to ImageExceptions):
     * <pre class="preshade">
     * return {@link #createImage(InputStream) createImage}({@link
     * IOTools#getInputStreamForResource(String, Class)
     * IOTools.getInputStreamForResource}(
     *     resourceLocation, searchStartPoint));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @param searchStartPoint the <tt>Class</tt> to invoke
     * <tt>getResource</tt> on.
     * If <tt>null</tt>, <tt>IOTools.class</tt> is used.
     * @return the decoded image
     * @throws ImageNotFoundException if the specified resource can
     * not be found.
     * @throws ImageException if there is no support for the image format
     * or if there is any other problem reading from the stream.
     */
    public static BufferedImage createImageFromResource(
                String resourceLocation,
                Class<?> searchStartPoint
            ) throws ImageNotFoundException, ImageException {

        try {
            return createImage(IOTools.getInputStreamForResource(
                resourceLocation, searchStartPoint));
        } catch ( FileNotFoundException x ) {
            throw new ImageNotFoundException(resourceLocation);
        } catch ( IOException x ) {
            throw new ImageException(x);
        }
    }

    /**
     * Creates a {@link BufferedImage} by reading from the specified resource.
     * The image's data must be in a PNG, JPEG, GIF, or other format that can
     * be read by {@link ImageIO}.
     *
     * The underlying <tt>InputStream</tt> comes from the specified
     * <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * See {@link IOTools#getUrlForResource(String, Class)
     * IOTools.getUrlForResource(String, Class)} for the full explanation
     * of how the search for the <tt>URL</tt> is performed.
     * <p>
     * Works like this (with IOExceptions converted to ImageExceptions):
     * <pre class="preshade">
     * return {@link #createImage(InputStream) createImage}(
     * {@link IOTools#getInputStreamForResource(String)
     * IOTools.getInputStreamForResource}(resourceLocation));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @return the decoded image
     * @throws ImageNotFoundException if the specified resource can
     * not be found.
     * @throws ImageException if there is no support for the image format
     * or if there is any other problem reading from the stream.
     */
    public static BufferedImage createImageFromResource(
                String resourceLocation
            ) throws ImageNotFoundException, ImageException {

        try {
            return createImage(
                IOTools.getInputStreamForResource(resourceLocation));
        } catch ( FileNotFoundException x ) {
            throw new ImageNotFoundException(resourceLocation);
        } catch ( IOException x ) {
            throw new ImageException(x);
        }
    }

    /**
     * Creates a {@link BufferedImage} by reading from the specified
     * <tt>byte[]</tt>.
     * The image's data must be in a PNG, JPEG, GIF, or other format that can
     * be read by {@link ImageIO}.
     *
     * @param formattedImageBytes origin of the image
     * @return the decoded image
     * @throws ImageException if there is no support for the image format
     * or if there is any other problem reading from the stream.
     */
    public static BufferedImage createImage(byte[] formattedImageBytes)
            throws ImageException {

        if ( formattedImageBytes == null || formattedImageBytes.length == 0 ) {
            throw new ImageException(
                "Can not create BufferedImage from empty byte[]");
        }

        return createImage(new ByteArrayInputStream(formattedImageBytes));
    }

    /**
     * Writes out the specified image to the specified stream in the
     * specified  format. The {@link OutputStream} pass to this method
     * is <i>not</i> closed.
     *
     * @param image image to convert to bytes
     * @param destination stream for formatted bytes to be sent; this is
     * flushed, but not closed by this method.
     * @param format image format for output, like
     * {@link #PNG_FORMAT} or {@link #JPEG_FORMAT} or another other
     * format supported for writing.
     * @throws ImageException if there are any problems writing out
     * the formatted bytes.
     */
    public static void write(RenderedImage image,
                             OutputStream destination,
                             String format) throws ImageException {

        if ( image == null ) {
            throw new ImageException(
                "Image to write out as bytes can not be null");
        }

        if ( destination == null ) {
            throw new ImageException(
                "Destination for the image's formatted bytes can not be null");
        }

        if ( (destination instanceof BufferedOutputStream) == false &&
             (destination instanceof ByteArrayOutputStream) == false ) {

            destination = new BufferedOutputStream(destination, 64 * 1024);
        }

        format = (format == null) ? PNG_FORMAT : format;

        MemoryCacheImageOutputStream mout = null;

        try {
            mout = new MemoryCacheImageOutputStream(destination);

            ImageIO.write(image, format, mout);
            mout.flush();
            destination.flush();
        } catch ( IOException x ) {
            throw new ImageException(x);
        } finally {
            closeQuietly(mout);
        }
    }

    public static void writePNG(RenderedImage image, OutputStream destination)
            throws ImageException {

        write(image, destination, PNG_FORMAT);
    }

    public static void writeJPEG(RenderedImage image, OutputStream destination)
            throws ImageException {

        write(image, destination, JPEG_FORMAT);
    }

    public static byte[] createBytes(RenderedImage image,
                                     String format) throws ImageException {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        write(image, baos, format);
        return baos.toByteArray();
    }

    public static byte[] createPNGBytes(RenderedImage image)
            throws ImageException {

        return createBytes(image, PNG_FORMAT);
    }

    public static byte[] createJPEGBytes(RenderedImage image)
            throws ImageException {

        return createBytes(image, JPEG_FORMAT);
    }

    /**
     * Converts the passed {@link Image} into a {@link BufferedImage}
     * if necessary. That is, is a <tt>BufferedImage</tt> is passed in,
     * then that same object is simple returned. If <tt>null</tt> is
     * passed in, then an <tt>IllegalArgumentException</tt> is thrown.
     * If the passed image is not a <tt>BufferedImage</tt>, a new
     * <tt>BufferedImage</tt> is created and the original image is drawn
     * onto it.
     */
    public static BufferedImage convertToBuffered(Image image)
            throws IllegalArgumentException {

        if ( image instanceof BufferedImage ) {
            return (BufferedImage) image;
        }

        if ( image == null ) {
            throw new IllegalArgumentException("Image can not be null");
        }

        ImageIcon icon = new ImageIcon(image);
        BufferedImage buffImage = new BufferedImage(icon.getIconWidth(),
            icon.getIconHeight(), BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2 = buffImage.createGraphics();
        g2.drawImage(icon.getImage(), 0, 0, null);
        g2.dispose();

        return buffImage;
    }

    public static void closeQuietly(ImageInputStream iis) {
        try {
            if ( iis != null ) {
                iis.close();
            }
        } catch ( IOException x ) {
            // ignore
        }
    }

    public static void closeQuietly(ImageOutputStream ios) {
        try {
            if ( ios != null ) {
                ios.close();
            }
        } catch ( IOException x ) {
            // ignore
        }
    }


    /**
     * Thrown to indicate that there was a problem reading, writing,
     * converting, or other problems working with an {@link Image} or
     * {@link BufferedImage}. Conveniently, this is a {@link RuntimeException}
     * so callers are not <i>required</i> to deal with it.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class ImageException extends RuntimeException {
        public ImageException(String message, Throwable cause) {
            super(message, cause);
        }

        public ImageException(Throwable cause) {
            super(cause);
        }

        public ImageException(String message) {
            super(message);
        }

        public ImageException() {
            super();
        }
    } // class ImageException

    public static class ImageNotFoundException extends ImageException {
        public ImageNotFoundException(String location) {
            super(
                "Could not find image data at the location '" + location +"'");
        }
    } // class ImageNotFoundException
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.