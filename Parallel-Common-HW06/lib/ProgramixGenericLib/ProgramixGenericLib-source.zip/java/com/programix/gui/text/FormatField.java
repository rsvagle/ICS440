package com.programix.gui.text;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

import javax.swing.*;

import com.programix.thread.*;
import com.programix.util.*;
import com.programix.value.*;

/**
 * A special kind of <tt>JTextField</tt> that generally restricts the
 * characters that can be typed in the field and has the ability to
 * retrieve the state as a {@link Value}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class FormatField extends JTextField {
    private static final BackgroundFader WARNING_FADER =
        new BackgroundFader(Color.YELLOW);

    protected final Object lock = new Object();
    private final FilterChainDocument filterChainDocument =
        new FilterChainDocument();

    private Set<ValueListener> listenerSet = null;

    protected Value value = ValueFactory.ZERO_LEN_STRING_INSTANCE;
    protected String valueStr = StringTools.ZERO_LEN_STRING;

    protected Value emptyReplacement = ValueFactory.ZERO_LEN_STRING_INSTANCE;

    protected boolean allowValueListenerNotification = false;

    // TODO - consider these three indicators:
    // Need blankIsOk indicator
    // Need isCorrupt indicator
    // need leaveCruddyForEditing indicator

    public FormatField(int maxColumnCount,
                       int visibleColumnCount,
                       String validInputChar,
                       Value initialValue) {

        setDocument(filterChainDocument);
        setColumns(visibleColumnCount);

        if ( StringTools.isNotEmpty(validInputChar) ) {
            filterChainDocument.append(
                new FilterChainDocument.WinnowFilter(validInputChar));
        }

        if ( maxColumnCount > 0 ) {
            filterChainDocument.append(
                new FilterChainDocument.LengthFilter(maxColumnCount));
        }

        setValue(initialValue);

        addFocus();
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if ( e.getKeyCode() == KeyEvent.VK_ENTER ) {
                    parseCurrentText();
                }
            }
        });

        allowValueListenerNotification = true;
    }

    public FormatField(int maxColumnCount,
                       String validInputChar,
                       Value initialValue) {

        this(maxColumnCount, maxColumnCount, validInputChar, initialValue);
    }

    public FormatField(int maxColumnCount,
                       Value initialValue) {

        this(maxColumnCount, maxColumnCount, null, initialValue);
    }

    public FormatField(int maxColumnCount) {
        this(maxColumnCount, maxColumnCount, null, null);
    }

    public FormatField() {
        this(10, 10, null, null);
    }

    protected void parseCurrentText() {
        setText(getText());
    }

    /**
     * Overridden to call {@link #setValue(String) setValue(String)}.
     * <p>
     * If a subclass needs to override this method, the subclass should
     * call <tt>super.setText()</tt>.
     */
    @Override
    public void setText(String text) {
        setValue(text);
    }

    /**
     * Specifies the value to display and notifies any value listeners
     * if there is a visible change in the value. This method automatically
     * substitutes the "empty replacement" (see {@link #getEmptyReplacement()})
     * if the passed <tt>newValue</tt> is either <tt>null</tt> or if the
     * <tt>Value</tt>'s <tt>isEmpty()</tt> method returns <tt>true</tt>.
     * <p>
     * If a subclass needs to override this method, the subclass should
     * call <tt>super.setValue()</tt>.
     *
     * @param newValue the value to try. If <tt>null</tt>, then the empty
     * replacement is used instead.
     */
    public void setValue(Value newValue) {
        newValue = (newValue == null || newValue.isEmpty())
            ? emptyReplacement : newValue;

        newValue = approveValue(newValue);

        String newValueStr = newValue.getString();
        super.setText(newValueStr);

        value = newValue;

        if ( ObjectTools.isDifferent(valueStr, newValueStr) ) {
            valueStr = newValueStr;
            notifyValueListeners();
        }
    }

    /**
     * Gives subclasses a chance to approved the proposed new value.
     * If the subclass wants to override the proposed value, the subclass
     * should override this method to return a different value.
     * This method should also be overridden in subclasses that want to add
     * formatting for the displayed text.
     * <p>
     * The original version of this method on <tt>FormatField</tt>
     * simply returns the value unchanged.
     */
    protected Value approveValue(Value proposedValue) {
        return proposedValue;
    }

    /**
     * Returns the current contents of the field as a {@link Value}.
     * Unlike most of the other getters, a <tt>Value</tt> is always
     * returned&mdash;<tt>null</tt> is never returned.
     */
    public Value getValue() {
        return value;
    }

    /**
     * Sets the value specified as a <tt>String</tt>.
     * It is OK to pass <tt>null</tt> as it will displayed as a zero-length
     * <tt>String</tt> (or whatever has been specified as the
     * "empty replacement"&mdash;see {@link #setEmptyReplacement(Value)}).
     */
    public void setValue(String text) {
        setValue(ValueFactory.create(text));
    }

    /**
     * Returns the current value as a trimmed <tt>String</tt> or
     * <tt>null</tt> if the field is empty.
     * Note that this is different than what is returned from
     * {@link #getText()}.
     * Specifically, if {@link #isEmpty()} returns <tt>true</tt>
     * then this method returns <tt>null</tt>.
     */
    public String getString() {
        return isEmpty() ? null : getValue().getString();
    }

    /**
     * Returns <tt>true</tt> if the current value of this field is
     * <tt>null</tt>, a zero-length string, or a string of all whitespace.
     */
    public boolean isEmpty() {
        return getValue().isEmpty();
    }

    /**
     * Returns <tt>true</tt> if the current value of this field is not "empty"
     * (see {@link #isEmpty()}}.
     */
    public boolean isNotEmpty() {
        return getValue().isNotEmpty();
    }

    public FilterChainDocument getFilterChainDocument() {
        return filterChainDocument;
    }

    public FilterChainDocument appendFilter(
                FilterChainDocument.Filter filter) {

        return filterChainDocument.append(filter);
    }

    /**
     * Specifies the <tt>Value</tt> to substitute when the proposed
     * value is empty.
     * If no "empty replacement" is ever specified, then <tt>FormatField</tt>
     * defaults to use a zero-length string as the "empty replacement".
     */
    public void setEmptyReplacement(Value newEmptyReplacement) {
        this.emptyReplacement = (newEmptyReplacement != null) ?
            newEmptyReplacement :  ValueFactory.ZERO_LEN_STRING_INSTANCE;
    }

    /**
     * Specifies the <tt>String</tt> to substitute when the proposed
     * value is empty.
     * If no "empty replacement" is ever specified, then <tt>FormatField</tt>
     * defaults to use a zero-length string as the "empty replacement".
     */
    public void setEmptyReplacement(String emptyReplacement) {
        setEmptyReplacement(ValueFactory.create(emptyReplacement));
    }

    /**
     * Returns the current Value to substitute when the proposed value is empty.
     * If no "empty replacement" is ever specified, then <tt>FormatField</tt>
     * defaults to use a zero-length string as the "empty replacement".
     */
    public Value getEmptyReplacement() {
        return emptyReplacement;
    }

    protected void signalWarning() {
        WARNING_FADER.add(this);
    }

    private void addFocus() {
        addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                process(true);
            }

            public void focusLost(FocusEvent e) {
                process(false);
            }

            private void process(boolean gained) {
                if ( isEditable() ) {
                    if ( gained ) {
                        selectAll();
                    } else {
                        select(0, 0);
                        parseCurrentText();
                    }
                }
            }
        });
    }

    private void createListenerSetIfNeeded() {
        synchronized ( lock ) {
            listenerSet =
                Collections.synchronizedSet(new HashSet<ValueListener>(5));
        }
    }

    public void addValueListener(ValueListener l) {
        synchronized ( lock ) {
            createListenerSetIfNeeded();
            listenerSet.add(l);
        }
    }

    public void removeValueListener(ValueListener l) {
        synchronized ( lock ) {
            createListenerSetIfNeeded();
            listenerSet.remove(l);
        }
    }

    protected void notifyValueListeners() {
        synchronized ( lock ) {
            if ( listenerSet == null || !allowValueListenerNotification ) {
                return;
            }

            for ( ValueListener l : listenerSet ) {
                l.valueChanged(this);
            }
        }
    }

    /**
     * Implementations of this interface can use
     * {@link FormatField#addValueListener(ValueListener)}
     * to be notified when the value inside a {@link FormatField} changes.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static interface ValueListener {
        void valueChanged(FormatField tf);
    } // interface ValueListener


    private static class BackgroundFader {
        private Color[] colorList;
        private ComponentFIFO fifo;

        public BackgroundFader(Color initialColor) {
            int frameCount = 10;
            colorList = new Color[frameCount];
            colorList[0] = initialColor;

            int origRed = initialColor.getRed();
            int origGreen = initialColor.getGreen();
            int origBlue = initialColor.getBlue();

            for ( int i = 1; i < frameCount; i++ ) {
                int red = (int) (origRed +
                        (((255 - origRed) * i ) / frameCount));
                int green = (int) (origGreen +
                        (((255 - origGreen) * i ) / frameCount));
                int blue = (int) (origBlue +
                        (((255 - origBlue) * i ) / frameCount));
                colorList[i] = new Color(red, green, blue);
            }

            fifo = new ComponentFIFO();

            Runnable r = new Runnable() {
                public void run() {
                    runWork();
                }
            };

            Thread t = new Thread(r, "FormatField-Fader");
            t.start();
        }

        private void runWork() {
            while ( true ) {
                Component comp = fifo.remove();

                Color orig = new BgColorGetter(comp).getColor();

                try {
                    for ( int i = 0; i < colorList.length; i++ ) {
                        new BgColorSetter(comp, colorList[i]);
                        ThreadTools.nap(50);
                    }
                } finally {
                    new BgColorSetter(comp, orig);
                }
            }
        }

        public void add(Component comp) {
            fifo.add(comp);
        }
    } // class BackgroundFader

    private static class ComponentFIFO {
        private List<Component> fifo;
        private Waiter.Condition emptyCondition;
        private Waiter waiter;

        public ComponentFIFO() {
            fifo = new LinkedList<Component>();

            waiter = new Waiter(this);
            emptyCondition = waiter.createCondition(new Waiter.Expression() {
                @Override
                public boolean isTrue() {
                    return fifo.size() == 0;
                }
            });
        }

        public synchronized void add(Component comp) {
            fifo.add(comp);
            waiter.signalChange();
        }

        public synchronized Component remove() {
            emptyCondition.waitWhileTrue();
            waiter.signalChange();
            return (Component) fifo.remove(0);
        }
    } // class ComponentFIFO

    private static class BgColorGetter implements Runnable {
        private Component comp;
        private Color color;

        public BgColorGetter(Component comp) {
            this.comp = comp;
            SwingUtilities.invokeLater(this);
        }

        // called by event thread
        public synchronized void run() {
            color = comp.getBackground();
            notifyAll();
        }

        public synchronized Color getColor() {
            try {
                while ( color == null ) {
                    wait();
                }

                return color;
            } catch ( InterruptedException x ) {
                throw new InterruptException(x);
            }
        }
    } // class BgColorGetter

    private static class BgColorSetter implements Runnable {
        private Component comp;
        private Color color;

        public BgColorSetter(Component comp, Color color) {
            this.comp = comp;
            this.color = color;
            SwingUtilities.invokeLater(this);
        }

        // called by event thread
        public void run() {
            comp.setBackground(color);
        }
    } // class BgColorSetter
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.