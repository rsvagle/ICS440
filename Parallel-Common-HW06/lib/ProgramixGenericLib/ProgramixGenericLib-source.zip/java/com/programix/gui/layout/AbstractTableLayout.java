package com.programix.gui.layout;

import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

import com.programix.gui.*;
import com.programix.math.*;

/**
 * Generalized layout for components that are going to be laid out in rows
 * and columns.
 * <p>
 * There's nothing in this class that prevents a single instance from
 * being used simultaneously by multiple containers. This class is
 * <tt>abstract</tt>, so be sure that this is also true for the particular
 * subclass that is being used.
 *
 * @see AnchorTableLayout
 * @see FormLayout
 * @see ColumnButtonLayout
 * @see RowButtonLayout
 * @see StackLayout
 * @see ShelfLayout
 * @see ColumnCoordinator
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public abstract class AbstractTableLayout
        implements LayoutManager, Serializable {

    /**
     * The default number of pixels to be placed between rows when more
     * than one row is present.
     * This default value is <tt>3</tt>.
     */
    public static final int DEFAULT_ROW_GAP = 3;


    /**
     * The default number of pixels to be placed between columns when more
     * than one column is present.
     * This default value is <tt>3</tt>.
     */
    public static final int DEFAULT_COL_GAP = 3;

    /**
     * The default number of pixels to be placed around the outside of
     * all the table before the edge of the container. Used as a padding.
     * This default value is <tt>5</tt>.
     */
    public static final int DEFAULT_BORDER_GAP = 5;

    /**
     * The default anchor point used when the container is larger than is
     * needed for the table.
     * This default value is {@link AnchorPoint#NORTH}.
     */
    public static final AnchorPoint DEFAULT_ANCHOR_POINT = AnchorPoint.NORTH;

    /**
     * The number of pixels between rows when there is more than one row.
     */
    protected int rowGap;

    /**
     * The number of pixels between columns when there is more than one column.
     */
    protected int colGap;

    /**
     * The number of pixels to pad the top, bottom, left, and right areas
     * around the table. This is the minimum space between the outermost
     * rows and columns and the edge of the container.
     * This eliminates the need to set an "empty border" on this container.
     */
    protected int borderGap;

    /**
     * The region to cluster the table in when the container is bigger than
     * the table requires. The table will remain anchored in that region and
     * will not be stretched when their container is larger than needed.
     */
    protected AnchorPoint anchorPoint;

    /**
     * If true (the default) then components that are not visible
     * will be ignored during layout.
     */
    protected boolean ignoreInvisibleComponents = true;

    /**
     * If non-null, then this coordinates the widths of some or all
     * columns across containers--even those with different layout
     * managers. See {@link ColumnCoordinator} for details on how
     * to coordinate columns. Directly modifying this field is
     * discouraged. Use {@link #getColumnCoordinator()}
     * and {@link #setColumnCoordinator(ColumnCoordinator)} instead.
     */
    protected ColumnCoordinator columnCoordinator;

    /**
     * Creates a table layout.
     *
     * @param rowGap space between rows.
     *                 See {@link #setRowGap setRowGap()}.
     * @param colGap space between columns.
     *                 See {@link #setColumnGap setColumnGap}.
     * @param borderGap space around the outside of the form.
     *                 See {@link #setBorderGap setBorderGap()}.
     * @param anchorPoint region to anchor to when there is extra space
     *                 See {@link #setAnchorPoint setAnchorPoint()}.
     */
    protected AbstractTableLayout(int rowGap,
                                  int colGap,
                                  int borderGap,
                                  AnchorPoint anchorPoint) {

        setRowGap(rowGap);
        setColumnGap(colGap);
        setBorderGap(borderGap);
        setAnchorPoint(anchorPoint);
    }

    /**
     * Called by the graphical subsystem when the container wants to re-layout
     * the components within it.
     */
    public synchronized void layoutContainer(Container parent) {
        CellData cd = createCellData(parent);
        cd.calcPartA();

        if ( cd.hasAnyCells() ) {
            cd.calcPartB();
            cd.layoutComponents();
        }
    }

    /**
     * Called by the graphical subsystem when the container wants to know
     * what to report its <i>preferred</i> size as.
     */
    public synchronized Dimension preferredLayoutSize(Container parent) {
        CellData cd = createCellData(parent);
        cd.calcPartA();

        if ( cd.hasAnyCells() ) {
            return cd.getPreferredSize();
        } else {
            return new Dimension(0, 0);
        }
    }

    /**
     * Called by the graphical subsystem when the container wants to know
     * what to report its <i>minimum</i> size as. This layout manager
     * returns its <i>preferred</i> size also as its minimum size.
     */
    public synchronized Dimension minimumLayoutSize(Container parent) {
        return preferredLayoutSize(parent);
    }

    /**
     * Called by the graphical subsystem when a component is being removed
     * from the container.
     * This layout manager does nothing for this request.
     */
    public synchronized void removeLayoutComponent(Component comp) {
    }

    /**
     * Called by the graphical subsystem when a component is being added
     * to the container.
     * This layout manager does nothing for this request.
     */
    public synchronized void addLayoutComponent(String name, Component comp) {
    }

    /**
     * Returns the number of pixels placed between rows when more than
     * one row is present.
     */
    public synchronized int getRowGap() {
        return rowGap;
    }

    /**
     * Changes the number of pixels placed between rows when more than
     * one row is present. Passed value is silently increased to <tt>0</tt>
     * if a negative gap is specified.
     */
    public synchronized void setRowGap(int rowGap) {
        this.rowGap = Math.max(0, rowGap);
    }

    /**
     * Returns the number of pixels placed between columns when more than
     * one column is present.
     * If there is only one column, then the value returned is meaningless.
     */
    public synchronized int getColumnGap() {
        return colGap;
    }

    /**
     * Changes the number of pixels placed between columns when more than
     * one column is present. Passed value is silently increased to <tt>0</tt>
     * if a negative gap is specified.
     * If there is only one column, then calling this method is meaningless.
     */
    public synchronized void setColumnGap(int colGap) {
        this.colGap = Math.max(0, colGap);
    }

    /**
     * Returns the number of pixels to pad the top, bottom, left, and right
     * areas around the table. This is the minimum space between the outermost
     * rows and columns and the edge of the container.
     * This eliminates the need to set an "empty border" on this container.
     */
    public synchronized int getBorderGap() {
        return borderGap;
    }

    /**
     * Changes the number of pixels to pad the top, bottom, left, and right
     * areas around the table. This is the minimum space between the outermost
     * rows and columns and the edge of the container.
     * This eliminates the need to set an "empty border" on this container.
     * Passed value is silently increased to <tt>0</tt> if a negative gap
     * is specified.
     */
    public synchronized void setBorderGap(int borderGap) {
        this.borderGap = Math.max(0, borderGap);
    }

    /**
     * Returns the region to cluster the table in when the container is
     * bigger than the table requires.
     * The table will remain anchored in that region and will not be
     * stretched when its container is larger than needed.
     */
    public synchronized AnchorPoint getAnchorPoint() {
        return anchorPoint;
    }

    /**
     * Changes the region to cluster the table in when the container is
     * bigger than the table requires.
     * The table will remain anchored in that region and will not be
     * stretched when its container is larger than needed.
     * If <tt>null</tt> is passed in, the {@link #DEFAULT_ANCHOR_POINT} will
     * be used instead.
     */
    public synchronized void setAnchorPoint(AnchorPoint anchorPoint) {
        this.anchorPoint =
            (anchorPoint != null) ? anchorPoint : DEFAULT_ANCHOR_POINT;
    }

    /**
     * Returns <tt>true</tt> if components that are not currently visible
     * should be ignored during layout. The default value is <tt>true</tt>.
     */
    public synchronized boolean isIgnoreInvisibleComponents() {
        return ignoreInvisibleComponents;
    }

    /**
     * Indicated whether or not invisible components should be considered
     * during layout. The default value is <tt>true</tt> which indicates
     * that components that are not currently visible should be ignored.
     */
    public synchronized void setIgnoreInvisibleComponents(
                boolean ignoreInvisibleComponents
            ) {

        this.ignoreInvisibleComponents = ignoreInvisibleComponents;
    }

    /**
     * Returns the currently assigned {@link ColumnCoordinator} or
     * <tt>null</tt> none has been assigned. There can be zero or
     * one <tt>ColumnCoordinator</tt>'s assigned to a layout manager.
     * By default, a layout manager does not have a <tt>ColumnCoordinator</tt>.
     * See {@link ColumnCoordinator} for details.
     * <p>
     * NOTE: This method is generally for internal use.
     *
     * @return the current coordinator or null.
     */
    protected ColumnCoordinator getColumnCoordinator() {
        return columnCoordinator;
    }

    /**
     * Changes the currently assigned {@link ColumnCoordinator}.
     * There can be zero or one <tt>ColumnCoordinator</tt>'s assigned to a
     * layout manager. Passing <tt>null</tt> to this method clears the
     * associated coordinator and automatically tells the previous
     * coordinator (if there was one) that this layout manager is no
     * longer coordinating.
     * By default, a layout manager does not have a <tt>ColumnCoordinator</tt>.
     * See {@link ColumnCoordinator} for details.
     * <p>
     * NOTE: This method is generally for internal use. Most users
     * should call methods on {@link ColumnCoordinator} to alter a
     * container's participation in column coordination.
     *
     * @param newCoordinator the new coordinator or null.
     */
    protected void setColumnCoordinator(ColumnCoordinator newCoordinator) {
        if ( columnCoordinator != newCoordinator ) {
            // definitely a "new" one is being set
            ColumnCoordinator old = columnCoordinator;
            columnCoordinator = newCoordinator;

            if ( old != null ) {
                old.remove(this);
            }
        }
    }

    protected abstract CellData createCellData(Container pane);

    protected abstract class CellData {
        protected final Component[] comp;
        protected final Dimension[] compPrefSize;
        protected final Insets paneInsets;
        protected final Dimension paneSize;
        protected int widthOverhead; // includes insets, borderGap, all colGaps
        protected int heightOverhead;
        protected int panePrefWidth;
        protected int panePrefHeight;
        protected int rowCount;
        protected int colCount;
        protected int offsetX;
        protected int offsetY;
        protected int[] rowHeight;
        protected int[] colWidth;
        protected int[] colX;
        protected int[] rowY;

        // copies from outer class for speed
        protected final int rGap;
        protected final int cGap;
        protected final int bGap;
        protected final AnchorPoint clusterAnchorPoint;

        protected CellData(Container pane) {
            if ( isIgnoreInvisibleComponents() ) {
                Component[] tmpComp = pane.getComponents();
                List<Component> list = null;

                for ( int i = 0; i < tmpComp.length; i++ ) {
                    if ( tmpComp[i].isVisible() ) {
                        if ( list != null ) {
                            list.add(tmpComp[i]);
                        }
                    } else {
                        if ( list == null ) {
                            // Found our *first* invisible comp, need a list
                            // and add all those up until this one
                            list = new ArrayList<Component>(tmpComp.length);
                            for ( int j = 0; j < i; j++ ) {
                                list.add(tmpComp[j]);
                            }
                        }
                    }
                }

                if ( list == null ) {
                    // none were invisible, so use them all
                    comp = tmpComp;
                } else {
                    comp = (Component[]) list.toArray(new Component[0]);
                }
            } else {
                comp = pane.getComponents();
            }

            paneInsets = pane.getInsets();
            paneSize = pane.getSize();

            compPrefSize = new Dimension[comp.length];
            for ( int i = 0; i < comp.length; i++ ) {
                compPrefSize[i] = comp[i].getPreferredSize();
            }

            rGap = getRowGap();
            cGap = getColumnGap();
            bGap = getBorderGap();
            clusterAnchorPoint = getAnchorPoint();
        }

        public final boolean hasAnyCells() {
            return rowCount > 0 && colCount > 0;
        }

        protected final void calcPartA() {
            calcRowAndColumnCounts();

            if ( hasAnyCells() ) {
                calcRowHeightsAndColumnWidths();
                calcPanePrefSize();
            }
        }

        protected final void calcPartB() {
            if ( hasAnyCells() ) {
                calcAnchorImpact();
                calcRowAndColPositions();
            }
        }

        protected abstract void calcRowAndColumnCounts();
        protected abstract void calcRowHeightsAndColumnWidths();

        protected void calcPanePrefSize() {
            // Calculate overall preferred size of this container
            heightOverhead = paneInsets.top + paneInsets.bottom +
                (bGap * 2) + (rGap * (rowCount - 1));

            panePrefHeight = heightOverhead;
            for ( int r = 0; r < rowCount; r++ ) {
                panePrefHeight += rowHeight[r];
            }

            widthOverhead = paneInsets.left + paneInsets.right +
                (bGap * 2) + (cGap * (colCount - 1));

            panePrefWidth = widthOverhead;
            for ( int c = 0; c < colCount; c++ ) {
                panePrefWidth += colWidth[c];
            }
        }

        protected void calcAnchorImpact() {
            Rectangle rect = clusterAnchorPoint.calcBounds(
                panePrefWidth, panePrefHeight,
                paneSize.width, paneSize.height);

            offsetX = rect.x;
            offsetY = rect.y;

            int extraWidth = rect.width - panePrefWidth;
            int extraHeight = rect.height - panePrefHeight;

            // TODO - reconsider what to do about excess width and height as
            //        only 'flex' items should be stretched...

            if ( extraWidth < 0 ) {
                // shrink column widths to fit
                NumberTools.distributeExcessProportionally(
                    colWidth, extraWidth);
            } else if ( extraWidth > 0 && clusterAnchorPoint.isFlexWidth() ) {
                // spread extra width out among the columns
                NumberTools.distributeExcessProportionally(
                    colWidth, extraWidth);
            }

            if ( extraHeight < 0 ) {
                // shrink row heights to fit
                NumberTools.distributeExcessProportionally(
                    rowHeight, extraHeight);
            } else if ( extraHeight > 0 && clusterAnchorPoint.isFlexHeight() ) {
                // spread extra height out among the rows
                NumberTools.distributeExcessProportionally(
                    rowHeight, extraHeight);
            }
        }

        protected void calcRowAndColPositions() {
            rowY = new int[rowCount];
            rowY[0] = paneInsets.top + bGap + offsetY;
            for ( int r = 1; r < rowCount; r++ ) {
                rowY[r] = rowY[r - 1] + rowHeight[r -1] + rGap;
            }

            colX = new int[colCount];
            colX[0] = paneInsets.left + bGap + offsetX;
            for ( int c = 1; c < colCount; c++ ) {
                colX[c] = colX[c - 1] + colWidth[c - 1] + cGap;
            }
        }

        protected abstract void layoutComponents();

        protected Dimension getPreferredSize() {
            if ( rowCount < 1 || colCount < 1 ) {
                return new Dimension(0, 0);
            }

            return new Dimension(panePrefWidth, panePrefHeight);
        }
    } // class CellData
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.