package com.programix.gui.text;

import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;

public class TextDraw {
    private Graphics2D g2;
    private Font font;
    private FontRenderContext frc;
    private Paint paint;
    private TextLayout textLayout;
    private Rectangle2D textBounds;
    private boolean drawable;
    
    public TextDraw(Graphics2D g2, Font font, Paint paint) {
        setGraphics(g2);
        setFont(font);
        setPaint(paint);
    }

    public TextDraw(Graphics2D g2, Font font) {
        this(g2, font, Color.BLACK);
    }

    public TextDraw() {
        this(null, null, Color.BLACK);
    }

    private void updateFRC() {
        if ( g2 != null && font != null ) {
            g2.setFont(font);
            frc = g2.getFontRenderContext();
            drawable = true;
        } else {
            drawable = false;
        }
    }
    
    public void setFont(Font font) {
        this.font = font;
        updateFRC();
    }
    
    public void setGraphics(Graphics2D g2) {
        this.g2 = g2;
        updateFRC();
    }
    
    public void setPaint(Paint newPaint) {
        paint = (newPaint == null) ? Color.BLACK : newPaint;
    }
    
    private void updateTextLayout(String text) {
        textLayout = new TextLayout(text, font, frc);
        textBounds = textLayout.getBounds();
    }
    
    private void draw(double x, double y) {
        draw((float) x, (float) y);
    }

    private void draw(float x, float y) {
        g2.setPaint(paint);
        textLayout.draw(g2, x, y);
    }
    
    public void drawFromUpperLeft(String text, 
                                  double xUpperLeft, 
                                  double yUpperLeft
                              ) {
        if ( drawable ) {
            updateTextLayout(text);
            draw(xUpperLeft - textBounds.getX(), 
                 yUpperLeft - textBounds.getY());
        }
    }
    
    public void drawFromLowerLeft(String text, 
                                  double xLowerLeft, 
                                  double yLowerLeft
                              ) {
        if ( drawable ) {
            updateTextLayout(text);
            draw(xLowerLeft - textBounds.getX(), 
                 yLowerLeft - textBounds.getY() - textBounds.getHeight());
        }
    }

    public void drawToUpperRight(String text, 
                                 double xUpperRight, 
                                 double yUpperRight
                              ) {
        if ( drawable ) {
            updateTextLayout(text);
            draw(xUpperRight - textBounds.getX() - textBounds.getWidth(), 
                 yUpperRight - textBounds.getY());
        }
    }

    public void drawToLowerRight(String text, 
                                 double xLowerRight, 
                                 double yLowerRight
                              ) {
        if ( drawable ) {
            updateTextLayout(text);
            draw(xLowerRight - textBounds.getX() - textBounds.getWidth(), 
                 yLowerRight - textBounds.getY() - textBounds.getHeight());
        }
    }

    public void drawFromOnBaseline(String text, 
                                   double xStartingPoint, 
                                   double yBaseline
                              ) {
        if ( drawable ) {
            updateTextLayout(text);
            draw(xStartingPoint - textBounds.getX(), 
                 yBaseline);
        }
    }

    public void drawToOnBaseline(String text, 
                                 double xEndingPoint, 
                                 double yBaseline
                              ) {
        if ( drawable ) {
            updateTextLayout(text);
            draw(xEndingPoint - textBounds.getX() - textBounds.getWidth(), 
                 yBaseline);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.