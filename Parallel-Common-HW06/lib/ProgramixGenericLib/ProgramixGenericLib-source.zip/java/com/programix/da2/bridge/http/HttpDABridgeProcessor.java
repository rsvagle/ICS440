package com.programix.da2.bridge.http;

import java.io.*;
import java.net.*;

import com.programix.da2.*;
import com.programix.da2.bridge.*;
import com.programix.da2.exception.*;
import com.programix.io.*;
import com.programix.util.*;
import com.programix.value.*;

/**
 * This implementation of {@link DABridgeProcessor} that serializes
 * {@link DABridgeRequest}'s and {@link DABridgeResponse}'s over
 * a the HTTP (or HTTPS) protocol to a servlet. The actual type of object
 * serialized in both directions is a {@link TransferWrapper}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class HttpDABridgeProcessor implements DABridgeProcessor {
    /**
     * This constant is defined as <tt>"bridge.servlet.url"</tt> and is used
     * as the key in the config <tt>ValueMap</tt> to retrieve the
     * string representation of the URL to use to talk to the server.
     * If the URL starts with
     * "https" then the communication will be encrypted.
     */
    public static final String SERVLET_URL_KEY = "bridge.servlet.url";

    /**
     * This constant is defined as <tt>"bridge.content-type"</tt> and is used
     * as the optional key in the config <tt>ValueMap</tt> to retrieve the
     * Content-Type to send up to the server.
     * It defaults to {@link #CONTENT_TYPE_DEFAULT_VALUE} if not
     * present in the configuration.
     */
    public static final String CONTENT_TYPE_KEY = "bridge.content-type";

    public static final String CONTENT_TYPE_DEFAULT_VALUE = "image/png";

    /**
     * This constant is defined as <tt>"bridge.compression.threshold"</tt>
     * and is used as the optional key in the config <tt>ValueMap</tt>
     * to retrieve the minimum number of bytes to be sent up before
     * compression is used.
     * It defaults to {@link #COMPRESSION_THRESHOLD_DEFAULT_VALUE} if not
     * present in the configuration.
     */
    public static final String COMPRESSION_THRESHOLD_KEY =
        "bridge.compression.threshold";

    public static final int COMPRESSION_THRESHOLD_DEFAULT_VALUE = 1024;

    private URL servletUrl;
    private String servletUrlStr;
    private String contentType;
    private int compressionThreshold;


    /**
     * The required key needed in the config is {@link #SERVLET_URL_KEY}.
     */
    public void init(ValueMap config) throws DAException {
        try {
            servletUrlStr = config.getString(SERVLET_URL_KEY);
            servletUrl = new URL(servletUrlStr);

            contentType = config.getString(
                CONTENT_TYPE_KEY, CONTENT_TYPE_DEFAULT_VALUE);

            compressionThreshold = config.getInt(
                COMPRESSION_THRESHOLD_KEY, COMPRESSION_THRESHOLD_DEFAULT_VALUE);
        } catch ( Exception x ) {
            throw DATools.convert(x);
        }
    }

    public void shutdown() {
        // nothing to close
    }

    public DABridgeResponse process(DABridgeRequest req) throws DAException {
        DataOutputStream out = null;
        DataInputStream in = null;

        try {
            HttpURLConnection uc =
                (HttpURLConnection) servletUrl.openConnection();
            uc.setRequestMethod("POST");
            uc.setAllowUserInteraction(false); // system may not ask the user
            uc.setDoOutput(true); // we want to send things

            // To not be blocked by firewall or proxy server:
            uc.setRequestProperty("Content-Type", contentType);

            TransferWrapper requestTW =
                SerializationTools.wrap(req, compressionThreshold);

            uc.setRequestProperty("Content-Length",
                String.valueOf(requestTW.calcWriteToByteCount()));

            uc.connect();

            out = new DataOutputStream(
                new BufferedOutputStream(uc.getOutputStream()));
            requestTW.writeTo(out);
            out.flush();
            out.close();
            out = null;  // success, save closeQuietly() the work

            in = new DataInputStream(
                new BufferedInputStream(uc.getInputStream()));

            TransferWrapper responseTW = new TransferWrapper();
            responseTW.readFrom(in);
            in.close();
            in = null;  // success, save closeQuietly() the work

            return (DABridgeResponse) SerializationTools.unwrap(
                responseTW, DABridgeResponse.class);
        } catch ( Exception x ) {
            throw new DAException("Trouble communicating via url=" +
                StringTools.quoteWrap(servletUrlStr) + "; " +
                x.getMessage(), x);
        } finally {
            IOTools.closeQuietly(in, out);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.