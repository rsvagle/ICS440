package com.programix.da2.bridge;

import com.programix.da2.exception.*;
import com.programix.value.*;

/**
 * DO NOT USE this class yet.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DABridgeSessionProcessor implements DABridgeProcessor {
    private DABridgeSession.Manager sessionManager;

    public void init(ValueMap config) throws DAException {
        sessionManager = new DABridgeSession.Manager();

        // FIXME !!!
        throw new DAException("Not usable yet!");
    }

    public void shutdown() {
        // Do this?
        sessionManager.shutdown();
    }

    public DABridgeResponse process(DABridgeRequest req) throws DAException {
        // FIXME !!!
        throw new DABridgeDAException("Not implemented yet!");
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.