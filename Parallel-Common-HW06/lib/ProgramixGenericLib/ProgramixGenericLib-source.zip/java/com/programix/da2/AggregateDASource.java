package com.programix.da2;

import com.programix.da2.exception.*;
import com.programix.util.*;

/**
 * Used to combine multiple {@link DASource}'s into one aggregate
 * {@link DASource}. When a DA is requested, the {@link DASource}'s
 * are queried via {@link DASource#isAvailable(Class)} in the order
 * that they were appended and the first to return true is used.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class AggregateDASource implements DASource {
    private DASource[] source = new DASource[0];

    public AggregateDASource() {
    }

    public synchronized void appendSource(DASource daSource) {
        source = (DASource[]) ObjectTools.changeArraySize(
            source, source.length + 1, daSource);
    }

    /**
     * Wraps the specified {@link GenericDA} as a {@link DASource} and
     * appends it.
     */
    public void appendDA(GenericDA da) {
        appendSource(new DASourceAdapter(da));
    }

    public synchronized <T extends GenericDA> T getDA(Class<T> daInterfaceType)
            throws DAException {

        for ( int i = 0; i < source.length; i++ ) {
            if ( source[i].isAvailable(daInterfaceType) ) {
                return source[i].getDA(daInterfaceType);
            }
        }

        throw new DAException("Unable to get DA implementation for " +
            StringTools.quoteWrap(daInterfaceType.getName()) +
            " as none of the " + source.length + " DASource's support it");
    }

    public synchronized
            boolean isAvailable(Class<? extends GenericDA> daInterfaceType)
            throws DAException {

        for ( int i = 0; i < source.length; i++ ) {
            if ( source[i].isAvailable(daInterfaceType) ) {
                return true;
            }
        }

        return false;
    }

    public synchronized void shutdown() {
        for ( int i = 0; i < source.length; i++ ) {
            source[i].shutdown();
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.