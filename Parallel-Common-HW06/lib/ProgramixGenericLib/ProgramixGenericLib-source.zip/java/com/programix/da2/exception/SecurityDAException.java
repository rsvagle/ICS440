package com.programix.da2.exception;


/**
 * This kind of {@link DAException} is used to signal that there is
 * a security-based problem fulfilling the request.
 * Check out the subclasses (some of the subclasses are: 
 * {@link NotAuthorizedDAException}, {@link NotAuthenticatedDAException}).
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class SecurityDAException extends DAException {
    public SecurityDAException() {
        super();
    }

    public SecurityDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public SecurityDAException(String message) {
        super(message);
    }

    public SecurityDAException(Throwable cause) {
        super(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.