package com.programix.da2.bridge;

import java.security.*;
import java.util.*;

import com.programix.util.*;
import com.programix.value.*;

/**
 * Encapsulates information about a user's session including the session id,
 * and can store session-specific key-value pairs.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DABridgeSession extends Object {
	public static final int NEVER_TIMEOUT = -1;
	public static final int DEFAULT_TIMEOUT = -2;

    private static final DABridgeSession[] ZERO_LEN_ARRAY =
        new DABridgeSession[0];

    //private static final int SCRAM = 0x065;

	private final byte[] id;
    private final String idStr;

	private int idleTimeoutMinutes;
	private long lastUsedTime;

    private final ValueMap sessionStore;
	private final Manager manager;

    // TODO - add listener set for session's destruction

	private DABridgeSession(byte[] id, Manager manager) {
		this.id = id;
        this.idStr = StringTools.toHexString(id);

		updateLastUsedTime();
        this.sessionStore = new ValueMap(); // sync on ValueMap instance
		this.manager = manager;

		setIdleTimeoutMinutes(DEFAULT_TIMEOUT);
	}

	private byte[] getId() {
		return id;
	}

	public synchronized String getIdString() {
		return idStr;
	}

    // deliberate 'package' scope
	synchronized void updateLastUsedTime() {
		lastUsedTime = System.currentTimeMillis();
	}

	/**
     * Returns the time that this session last sent a response.
     * While in request/response cycle, this method shows the last time that
     * a response was sent&mdash;potentially from another concurrent thread.
	 */
    public synchronized long getLastUsedTime() {
		return lastUsedTime;
	}

    /**
     * Returns the difference between 'now' and the 'last used time'.
     */
    public synchronized long getIdleTime() {
        return System.currentTimeMillis() - getLastUsedTime();
    }

	/**
	 * Used to specify a shorter or longer timeout for this session.
	 * The default timeout comes from session manager.
	 */
	public synchronized void setIdleTimeoutMinutes(int minutes) {
		if ( minutes == DEFAULT_TIMEOUT ) {
			minutes = manager.getDefaultIdleTimeoutMinutes();
		}

		this.idleTimeoutMinutes = minutes;
	}

	public synchronized int getIdleTimeoutMinutes() {
		return idleTimeoutMinutes;
	}

	/**
	 * Removes this session from the list of sessions that the Session.Manager
	 * is monitoring. This session can continue to be used for the rest of
	 * the request&mdash;even to generate URI's&mdash;but subsequent request
	 * will not find this session, and a new session will be created.
	 */
	public void invalidate() {
		manager.removeSession(this);
	}

    /**
     * Returns the {@link ValueMap} that can be used to store session-specific
     * information. This activity on this <tt>ValueMap</tt> is synchronized
     * independently of the <tt>Session</tt> it belongs to (use the
     * {@link ValueMap#getLockObject() getLockObject()} method on
     * <tt>ValueMap</tt> if you need to perform multiple operations on the
     * <tt>ValueMap</tt> that must be done without interference).
     */
    public ValueMap getSessionStore() {
        return sessionStore;
    }

    public Value getSessionValue(String sessionStoreKey) {
        return sessionStore.get(sessionStoreKey);
    }

    /**
     * Used to specify a block of code that should be executed whenever
     * a new session is created.
     *
     * @see DABridgeSession
     * @see DABridgeSession.Manager
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public interface Initializer {
        void initializeSession(DABridgeSession session);
    }

//    /**
//     * Used to listen to sessions to be notified when the session
//     * is being destroyed.
//     *
//     * @see {@link DABridgeSession}
//     * @see {@link DABridgeSession.Manager}
//     *
//     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
//     */
//    public interface DestructionListener {
//        void destroyInProgress(DABridgeSession session);
//    }

    /**
     * Used to manage the sessions.
     *
     * @see DABridgeSession
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
	public static class Manager extends Object {
		private Map<IdWrapper, DABridgeSession> sessionMap;
		private int defaultIdleTimeoutMinutes;
		private Worker worker;
		private IdGenerator generator;
		private Initializer sessionInitializer;
        private final Object lock;

		public Manager(int defaultIdleTimeoutMinutes) {
			this.sessionMap = Collections.synchronizedMap(
			    new HashMap<IdWrapper, DABridgeSession>(1001, 0.25f));
            this.lock = sessionMap;
			this.defaultIdleTimeoutMinutes = defaultIdleTimeoutMinutes;
			this.generator = new IdGenerator();
			this.worker = new Worker(sessionMap);
		}

		public Manager() {
			this(60);
		}

		public int getDefaultIdleTimeoutMinutes() {
            synchronized ( lock ) {
    			return defaultIdleTimeoutMinutes;
            }
		}

		/**
		 * Retrieves the {@link Initializer} used to initialize
		 * sessions just after they are created. If null, no initialization
		 * occurs.
		 */
		public Initializer getSessionInitializer() {
            synchronized ( lock ) {
                return sessionInitializer;
            }
		}

		/**
		 * Specifies the {@link Initializer} used to initialize
		 * sessions just after they are created. If null, no initialization
		 * occurs.
		 */
		public void setSessionInitializer(
					Initializer sessionInitializer
				) {

            synchronized ( lock ) {
                this.sessionInitializer = sessionInitializer;
            }
		}

		/**
		 * Deletes all sessions and stops the internal thread that
		 * checks for timeouts.
		 */
		public void shutdown() {
			Map<IdWrapper, DABridgeSession> map = sessionMap;
			if ( map != null ) {
				synchronized ( map ) {
					sessionMap = null;
					map.clear();
					worker.stopRequest();
				}
			}
		}

		/**
		 * Looks up the specified session or creates a new session if
		 * the specified session does not exist or has expired.
		 */
		public DABridgeSession getSession(byte[] id) {
            DABridgeSession session = findSession(id);
            if ( session != null ) {
                return session;
            } else {
                return createSession();
            }
        }

		/**
		 * Looks up the specified session or creates a new session if
		 * the specified session does not exist or has expired.
		 */
		public DABridgeSession getSession(String idStr) {
			try {
				return getSession(StringTools.parseHexString(idStr));
			} catch ( Exception x ) {
				// something is mangled...
				return createSession();
			}
		}

		private DABridgeSession createSession() {
			byte[] id = generator.getNextId();
			DABridgeSession session = new DABridgeSession(id, this);
			sessionMap.put(new IdWrapper(id), session);

            Initializer si = getSessionInitializer();
			if ( si != null ) {
				si.initializeSession(session);
			}

			return session;
		}

		/**
		 * Searches for a session with the specified id. Returns that
		 * session if found, or <tt>null</tt> if no session with that
		 * id exists.
		 */
		private DABridgeSession findSession(byte[] id) {
			if ( id == null ) {
				return null;
			}

			DABridgeSession session =
                (DABridgeSession) sessionMap.get(new IdWrapper(id));
//			if ( session != null ) {
//				session.updateLastUsedTime();
//			}

			return session;
		}

		/**
		 * Searches for a session with the specified id and removes it if
		 * found. Returns the removed <tt>Session</tt> if found, or
		 * <tt>null</tt> if no session with that id was found.
		 */
		private DABridgeSession removeSession(byte[] id) {
			return (DABridgeSession) sessionMap.remove(new IdWrapper(id));
		}

		/**
		 * Searches for a session with the specified id and removes it if
		 * found. Returns <tt>true</tt> if found and removed, <tt>false</tt>
		 * otherwise.
		 */
		private boolean removeSession(DABridgeSession session) {
			return (removeSession(session.getId()) != null);
		}
	} // class Manager

	private static class Worker extends Object implements Runnable {
        private Map<IdWrapper, DABridgeSession> sessionMap;
		private Thread internalThread;
		private long sleepDuration;

		public Worker(Map<IdWrapper, DABridgeSession> sessionMap) {
			this.sessionMap = sessionMap;

			sleepDuration = 2 * 60 * 1000; // two minutes
			internalThread = new Thread(this);
			internalThread.start();
		}

		public void run() {
			try {
				while ( true ) {
					Thread.sleep(sleepDuration);

                    // Get a snapshot at a point in time because we don't
                    // want to block other threads.
                    DABridgeSession[] sess = (DABridgeSession[])
                        sessionMap.values().toArray(
                            DABridgeSession.ZERO_LEN_ARRAY);

                    for ( int i = 0; i < sess.length; i++ ) {
                        long keepLimit = System.currentTimeMillis() -
                            sess[i].getIdleTimeoutMinutes() * 60L * 1000L;

                        if ( sess[i].getLastUsedTime() < keepLimit ) {
                            sess[i].invalidate();
                        }
                    }
				}
			} catch ( InterruptedException x ) {
				// ignore
			}
		}

		public void stopRequest() {
			internalThread.interrupt();
		}
	} // inner class Worker

	private static class IdGenerator extends Object {
		private int count;
		private byte[] countBytes;
		private byte[] startBytes;
		private byte[] randomBytes;
		private SecureRandom randomGen;

		public IdGenerator() {
			count = 0;

			countBytes = new byte[4];
			randomBytes = new byte[4];

			randomGen = new SecureRandom();
			randomGen.nextBytes(randomBytes); // seeds and initializes

			// Rolls over in the year 2038
			int now = (int) (System.currentTimeMillis() / 1000);
			startBytes = new byte[4];
			for ( int i = 0; i < 4; i++ ) {
				startBytes[i] = (byte)( now & 0x00FF );
				now >>>= 8;
			}
		}

		public synchronized byte[] getNextId() {
			incrementCount();
			randomGen.nextBytes(randomBytes);
			byte[] id = new byte[12];

			id[0] = randomBytes[0];
			id[3] = randomBytes[1];
			id[6] = randomBytes[2];
			id[9] = randomBytes[3];

			id[1] = countBytes[0];
			id[2] = countBytes[1];
			id[4] = countBytes[2];
			id[5] = countBytes[3];

			id[7] = startBytes[0];
			id[8] = startBytes[1];
			id[10] = startBytes[2];
			id[11] = startBytes[3];

			// light scrambling
			byte key = (byte) 0xA9;
			id[0] = (byte)(id[0] ^ key);
			for ( int i = 1; i < id.length; i++ ) { // start with 1
				id[i] = (byte)(id[i] ^ id[i - 1]);
			}

			return id;
		}

		private void incrementCount() {
			count++;

			// Use XOR to scramble the count a bit
			int tmpCount = count ^ 0xCAFEBABE;
			for ( int i = 0; i < 4; i++ ) {
				countBytes[i] = (byte)( tmpCount & 0x00FF );
				tmpCount >>>= 8;
			}
		}
	} // inner class IdGenerator

    private static class IdWrapper extends Object {
		private byte[] id;
		private int hash;

		public IdWrapper(byte[] id) {
			this.id = id;

			hash = 0;
			int ptr = 0;
			for ( int i = 0; i < 7; i++ ) {
				hash = (hash << 5) ^ id[ptr];
				ptr = ( ptr + 1 ) % id.length;
			}
		}

		public byte[] getId() {
			return id;
		}

		@Override
        public boolean equals(Object obj) {
            if ( this == obj ) {
                return true;
            } else if ( obj == null || !getClass().equals(obj.getClass()) ) {
                return false;
            }

			IdWrapper other = (IdWrapper) obj;

			if ( hash != other.hash ) {
				return false;
			}

			if ( id.length != other.id.length ) {
				return false;
			}

			for ( int i = 0; i < id.length; i++ ) {
				if ( id[i] != other.id[i] ) {
					return false;
				}
			}

			return true;
		}

		@Override
        public int hashCode() {
			return hash;
		}
	} // static class IdWrapper
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.