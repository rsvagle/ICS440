package com.programix.da2.bridge;

import com.programix.da2.exception.*;
import com.programix.value.*;

/**
 * Used to process {@link DABridgeRequest}'s and produce 
 * {@link DABridgeResponse}'s.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface DABridgeProcessor {
    void init(ValueMap config) throws DAException;
    void shutdown();
    
    DABridgeResponse process(DABridgeRequest req) throws DAException;
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.