package com.programix.da2;

import com.programix.da2.exception.*;
import com.programix.value.*;

/**
 * Used to implementation the very useful "Data Access Layer" abstraction.
 * <p>
 * This interface is extended to provide a useful collection of methods. Each
 * method should perform a 'unit of work'. Most methods should declare that they
 * might throw {@link DAException} to indicate an underlying problem (such
 * as an {@link java.io.IOException}, {@link java.sql.SQLException}, etc.
 * Application-specific exceptions can be thrown in addition to
 * {@link DAException} and there are many pre-defined subclasses
 * of {@link DAException} (and developers can create additional subclasses
 * as desired).
 * <p>
 * {@link DAFactory} has many <code>create</code> methods to automate
 * the task of instantiating and initializing an instance.
 * <p>
 * NOTE: all implementations must have a public zero-argument constructor.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface GenericDA {

    /**
     * Called once just after construction to allow the implementation to
     * setup everything required to run. This method is called before any
     * other methods on this interface. If this method returns without
     * throwing an exception, access to the other methods is opened up.
     *
     * @param config all the settings needed to complete initialization
     * @throws DAException if initialization could not complete,
     * possibly chained to an underlying cause.
     */
    void init(ValueMap config) throws DAException;

    /**
     * This should be called when the DA is no longer needed to
     * clean up any potential resources being used behind the scenes.
     * Some implementations may have nothing to do when shutdown, but
     * other implementations might have important de-allocation duties
     * to perform.
     * <p>
     * No other methods should be called after this method.
     * Calling other methods after calling this method results in
     * undefined behavior (many times, a {@link ShutdownDAException} will be
     * thrown when attempting to invoke those other methods, but there is
     * no requirement that all methods do this).
     * <p>
     * Calling <tt>shutdown()</tt> more than one time must be allowed
     * and <tt>shutdown()</tt> must not complain.
     * Also note that <tt>shutdown()</tt> never throws <i>any</i>
     * exceptions&mdash;it just makes its best effort of close down everything.
     * Implementations must assure that this remains true.
     */
    void shutdown();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.