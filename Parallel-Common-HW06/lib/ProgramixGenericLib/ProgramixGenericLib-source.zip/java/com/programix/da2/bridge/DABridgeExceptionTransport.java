package com.programix.da2.bridge;

import java.io.*;
import java.lang.reflect.*;

import com.programix.da2.exception.*;
import com.programix.io.*;

/**
 * Wrapper to use to transport an exception over the serialization bridge
 * in a way that may allow for some useful information to still be
 * re-constructed if the receiving end does not have access to one of the
 * exception classes that was sent.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DABridgeExceptionTransport implements Serializable {
    // TODO - consider trucking over each exception in the chain
    // individually with it's stack trace and then re-chain them if
    // possible here to handle the missing classes that the client
    // might not know about.

    private byte[] serializedException;
    private String exceptionMessage;
    private String exceptionClassName;

    public DABridgeExceptionTransport(Exception exception) {
        try {
            serializedException = SerializationTools.toByteArray(exception);
        } catch ( Exception x ) {
            serializedException = null;
        }

        exceptionMessage = exception.getMessage();
        exceptionClassName = exception.getClass().getName();
    }

    public Exception getException() {
        // Plan A - Try to just do a normal deserialization of the exception.
        // This might not work if the exception (or one of the chained
        // exceptions) is not available on the local Java VM.
        try {
            return (Exception) SerializationTools.fromByteArray(
                serializedException);
        } catch ( Exception x ) {
            // ignore and fall back to Plan B
        }

        String msg = exceptionMessage +
            " [further detail lost in serialization; look on sender's end]";

        // Plan B - Try to create a new instance of the correct exception
        // type and pass into it's constructor the message String.
        try {
            Class<?> c = Class.forName(exceptionClassName);

            Constructor<?> constructor =
                c.getDeclaredConstructor(String.class);

            return (Exception) constructor.newInstance(msg);
        } catch ( Exception x ) {
            // ignore and fall back to Plan C
        }

        // Plan C - Create a DAException with at the very least the original
        // exception's message.
        return new DAException(exceptionClassName + ": " + msg);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.