package com.programix.da2.bridge;

import java.lang.reflect.*;
import java.security.*;
import java.util.*;

import com.programix.da2.*;
import com.programix.value.*;

public class DABridgeMethodMapper {
    public static final Comparator<Method> METHOD_COMPARATOR =
        new MethodComparator();

    private final Class<? extends GenericDA> daClass;
    private final SortedMap<Integer, Method> idMethodMap;
    private final SortedMap<Method, Integer> methodIdMap;

    public DABridgeMethodMapper(Class<? extends GenericDA> daClass) {
        this.daClass = daClass;

        idMethodMap = new TreeMap<Integer, Method>();
        methodIdMap = new TreeMap<Method, Integer>(METHOD_COMPARATOR);

        Method[] methodList = daClass.getMethods();
        for ( int i = 0; i < methodList.length; i++ ) {
            Method method = methodList[i];

            if ( isRestrictedMethod(method) ) {
                // skip the restricted methods - no ID for them
                continue;
            }

            Integer id = generateIdForMethod(method);

            // Ensure that this is not a duplicate (expected to be unlikely!)
            while ( idMethodMap.containsKey(id) ) {
                id = new Integer(id.intValue() + 1);
            }

            idMethodMap.put(id, method);
            methodIdMap.put(method, id);
        }
    }

    private Integer generateIdForMethod(Method method) {
        try {
            StringBuffer sb = new StringBuffer();
            sb.append(method.getName());
            sb.append("(");
            Class<?>[] parameterTypes = method.getParameterTypes();
            for ( int i = 0; i < parameterTypes.length; i++ ) {
                if ( i > 0 ) {
                    sb.append(", ");
                }

                sb.append(parameterTypes[i].getName());
            }
            sb.append(")");

            char[] ch = sb.toString().toCharArray();
            byte[] sigBytes = new byte[ch.length];
            for ( int i = 0; i < ch.length; i++ ) {
                sigBytes[i] = (byte) ch[i]; // just keep lower 8 bits
            }

            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hashBytes = md.digest(sigBytes);

            int id = 0;
            for ( int i = 0; i < hashBytes.length; i++ ) {
                id = (id << 2) ^ hashBytes[i];
            }

            return new Integer(id);
        } catch ( Exception x ) {
            throw new RuntimeException("Unable to create bridge; " +
                x.toString(), x);
        }
    }

    public Class<? extends GenericDA> getDaClass() {
        return daClass;
    }

    public int getUniqueIdForMethod(Method method) throws DABridgeDAException {
        Integer id = methodIdMap.get(method);
        if ( id != null ) {
            return id.intValue();
        }

        if ( isRestrictedMethod(method) ) {
            throw new DABridgeDAException(
                "Not allowed to invoke the restricted method=" + method);
        } else {
            throw new DABridgeDAException(
                "Unknown id for method=" + method);
        }
    }

    public Method getMethodForUniqueId(int id) throws DABridgeDAException {
        Method method = idMethodMap.get(new Integer(id));
        if ( method == null ) {
            throw new DABridgeDAException("Unknown method for id=" + id);
        }

        return method;
    }

    public static boolean isRestrictedMethod(Method method) {
        return isShutdownMethod(method) || isInitMethod(method);
    }

    public static boolean isShutdownMethod(Method method) {
        if ( "shutdown".equals(method.getName()) ) {
            if ( method.getParameterTypes().length == 0 ) {
                return true;
            }
        }

        return false;
    }

    public static boolean isInitMethod(Method method) {
        if ( "init".equals(method.getName()) ) {
            Class<?>[] parameterTypes = method.getParameterTypes();
            if ( parameterTypes.length == 1 ) {
                if ( parameterTypes[0].equals(ValueMap.class) ) {
                    return true;
                }
            }
        }

        return false;
    }

    private static class MethodComparator implements Comparator<Method> {
        public int compare(Method m1, Method m2) {
            int nameComp = m1.getName().compareTo(m2.getName());
            if ( nameComp != 0 ) {
                return nameComp;
            }

            Class<?>[] param1 = m1.getParameterTypes();
            Class<?>[] param2 = m2.getParameterTypes();

            if ( param1.length != param2.length ) {
                return param1.length - param2.length;
            }

            for ( int i = 0; i < param1.length; i++ ) {
                String paramType1 = param1[i].getName();
                String paramType2 = param2[i].getName();

                int paramTypeComp = paramType1.compareTo(paramType2);

                if ( paramTypeComp != 0 ) {
                    return paramTypeComp;
                }
            }

            return 0;
        }
    } // class MethodComparator
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.