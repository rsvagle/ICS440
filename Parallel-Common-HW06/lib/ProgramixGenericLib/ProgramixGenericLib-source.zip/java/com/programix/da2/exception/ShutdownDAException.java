package com.programix.da2.exception;

/**
 * This kind of {@link DAException} is thrown to indicate that
 * the attempted call can no be completed because the DA has been 
 * shutdown. 
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ShutdownDAException extends DAException {
    public ShutdownDAException() {
        super();
    }

    public ShutdownDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public ShutdownDAException(String message) {
        super(message);
    }

    public ShutdownDAException(Throwable cause) {
        super(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.