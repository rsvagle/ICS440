package com.programix.da2.bridge;

import com.programix.da2.*;
import com.programix.da2.bridge.http.*;
import com.programix.da2.exception.*;
import com.programix.value.*;

/**
 * Used to create common bridge implementations for the client side.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DABridgeFactory {

    private DABridgeFactory() {
    }
    
    public static DASource createHttpBridgeDASource(String url) 
            throws DAException {
        
        ValueMap config = new ValueMap();
        config.put(HttpDABridgeProcessor.SERVLET_URL_KEY, url);
        DABridgeProcessor processor = new HttpDABridgeProcessor();
        processor.init(config);
        
        return new DABridgeProxy(processor);
    }
    
    /**
     * Creates a {@link DABridgeProcessor} that has NO security and
     * NO sessions (all requests are honored) and uses the 
     * specified <tt>daSource</tt> for completing the processing
     * of the requests.
     * See {@link DABridgeNoSecurityNoSessionProcessor}.
     */
    public static DABridgeProcessor createNoSecurityProcessor(DASource daSource)
            throws DAException {
        
        ValueMap config = new ValueMap();
        config.put(DASource.class.getName(), daSource);
        DABridgeProcessor processor = 
            new DABridgeNoSecurityNoSessionProcessor();
        processor.init(config);
        
        return processor;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.