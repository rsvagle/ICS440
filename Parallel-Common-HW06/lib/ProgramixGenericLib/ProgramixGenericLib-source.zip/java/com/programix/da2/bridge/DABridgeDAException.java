package com.programix.da2.bridge;

import com.programix.da2.exception.*;

/**
 * Used for problems with the DABridge subsystem.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DABridgeDAException extends DAException {
    public DABridgeDAException() {
        super();
    }

    public DABridgeDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public DABridgeDAException(String message) {
        super(message);
    }

    public DABridgeDAException(Throwable cause) {
        super(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.