package com.programix.da2.bridge;

import java.io.*;

/**
 * This part of the Data Access Bridge system is used to encapsulate
 * a request for the invocation of a method on a Data Access interface
 * (both a normal response and exceptions).
 * See {@link DABridgeProcessor} and {@link DABridgeResponse}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DABridgeRequest implements Serializable {
    private String daInterfaceTypeName;
    private int methodId;
    private Object[] methodParamList;
    private byte[] sessionId;

    public DABridgeRequest(String daInterfaceTypeName,
                           int methodId,
                           Object[] methodParamList,
                           byte[] sessionId) {

        this.daInterfaceTypeName = daInterfaceTypeName;
        this.methodId = methodId;
        this.methodParamList = methodParamList;
        this.sessionId = sessionId;
    }

    public DABridgeRequest() {
    }

    public String getDaInterfaceTypeName() {
        return daInterfaceTypeName;
    }

    public void setDaInterfaceTypeName(String daInterfaceTypeName) {
        this.daInterfaceTypeName = daInterfaceTypeName;
    }

    public int getMethodId() {
        return methodId;
    }

    public void setMethodId(int methodId) {
        this.methodId = methodId;
    }

    public Object[] getMethodParamList() {
        return methodParamList;
    }

    public void setMethodParamList(Object[] methodParamList) {
        this.methodParamList = methodParamList;
    }

    public byte[] getSessionId() {
        return sessionId;
    }

    public void setSessionId(byte[] sessionId) {
        this.sessionId = sessionId;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.