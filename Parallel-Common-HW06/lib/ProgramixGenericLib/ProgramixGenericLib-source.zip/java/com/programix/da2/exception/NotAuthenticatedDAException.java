package com.programix.da2.exception;

/**
 * This kind of {@link SecurityDAException} is thrown to indicate
 * that the user has not been authenticated. 
 * Under some schemes, the application may be able to recover from
 * this by transparently re-logging-in the user or by prompting the
 * user to present his/her credentials.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class NotAuthenticatedDAException extends SecurityDAException {
    public NotAuthenticatedDAException() {
        super();
    }

    public NotAuthenticatedDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotAuthenticatedDAException(String message) {
        super(message);
    }

    public NotAuthenticatedDAException(Throwable cause) {
        super(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.