package com.programix.da2.bridge;

import java.lang.reflect.*;

import com.programix.da2.*;
import com.programix.da2.exception.*;
import com.programix.value.*;

/**
 * This part of the Data Access Bridge system is a {@link DASource} that
 * converts requests to be sent to the {@link DABridgeProcessor}
 * supplied at construction.
 * <p>
 * NOTE: Neither
 * the {@link GenericDA#init(ValueMap) init()} method nor the
 * the {@link GenericDA#shutdown() shutdown()} method are permitted to
 * be remotely.
 * Calling init() on any DA's retrieved from this proxy will result
 * in a {@link DABridgeDAException} being thrown.
 * Calling shutdown() on any DA's retrieved from this proxy will silently
 * do nothing.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DABridgeProxy implements DASource {
    private DABridgeProcessor processor;
    private byte[] sessionId;

    private DABridgeAdminDA adminDA;

    public DABridgeProxy(DABridgeProcessor processor) throws DAException {
        this.processor = processor;

        adminDA = (DABridgeAdminDA) getDA(DABridgeAdminDA.class);
    }

    @SuppressWarnings("unchecked")
    public <T extends GenericDA> T getDA(Class<T> daInterfaceType)
            throws DAException {

        try {
            return (T) Proxy.newProxyInstance(
                daInterfaceType.getClassLoader(),
                new Class<?>[] { daInterfaceType },
                new Handler(daInterfaceType));
        } catch ( Exception x ) {
            throw DATools.convert(x);
        }
    }

    public boolean isAvailable(Class<? extends GenericDA> daInterfaceType)
            throws DAException {

        return adminDA.isAvailable(daInterfaceType);
    }

    public void shutdown() {
        processor.shutdown();
    }

    private synchronized byte[] getSessionId() {
        return sessionId;
    }

    private synchronized void setSessionId(byte[] id) {
        this.sessionId = id;
    }

    private class Handler extends Object implements InvocationHandler {
        private Class<? extends GenericDA> daInterfaceType;
        private DABridgeMethodMapper mapper;

        public Handler(Class<? extends GenericDA> daInterfaceType) {
            this.daInterfaceType = daInterfaceType;

            mapper = new DABridgeMethodMapper(daInterfaceType);
        }

        public Object invoke(Object proxy,
                             Method method,
                             Object[] paramList) throws Throwable {

            if ( DABridgeMethodMapper.isShutdownMethod(method) ) {
                return null;
            }

            int methodId = mapper.getUniqueIdForMethod(method);

            DABridgeRequest req = new DABridgeRequest(
                daInterfaceType.getName(), methodId, paramList,
                getSessionId());

            DABridgeResponse res = processor.process(req);
            setSessionId(res.getSessionId());

            if ( res.isException() ) {
                throw res.getException();
            } else {
                return res.getResult();
            }
        }
    } // class Handler
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.