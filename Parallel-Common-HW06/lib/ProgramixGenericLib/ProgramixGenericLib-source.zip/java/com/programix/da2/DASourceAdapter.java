package com.programix.da2;

import com.programix.da2.exception.*;
import com.programix.util.*;

/**
 * Used to adapt a single {@link GenericDA} into being available as
 * a {@link DASource}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DASourceAdapter implements DASource {
    private GenericDA singleDA;

    /**
     * Wraps the specified {@link GenericDA}.
     *
     * @throws IllegalArgumentException if singleDA is null
     */
    public DASourceAdapter(GenericDA singleDA) throws IllegalArgumentException {
        ObjectTools.paramNullCheck(singleDA, "singleDA");
        this.singleDA = singleDA;
    }

    @SuppressWarnings("unchecked")
    public <T extends GenericDA> T getDA(Class<T> daInterfaceType)
            throws DAException {

        if ( daInterfaceType.isInstance(singleDA) ) {
            return (T) singleDA;
        } else {
            throw new DAException("Unable to get DA implementation for " +
                StringTools.quoteWrap(daInterfaceType.getName()) +
                " as the type of the single DA is " +
                StringTools.quoteWrap(singleDA.getClass().getName()) +
                " can not be cast to the requested type");
        }
    }

    public boolean isAvailable(Class<? extends GenericDA> daInterfaceType)
            throws DAException {

        return daInterfaceType.isInstance(singleDA);
    }

    public void shutdown() {
        singleDA.shutdown();
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.