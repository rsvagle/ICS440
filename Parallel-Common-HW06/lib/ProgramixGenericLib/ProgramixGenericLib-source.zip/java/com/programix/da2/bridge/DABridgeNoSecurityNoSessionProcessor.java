package com.programix.da2.bridge;

import java.lang.reflect.*;
import java.util.*;

import com.programix.da2.*;
import com.programix.da2.exception.*;
import com.programix.value.*;

/**
 * This {@link DABridgeProcessor} does no security checking and does not
 * keep track of any sessions.
 * The only required key is for a {@link DASource} stored under
 * the full class name for {@link DASource} (you can use
 * <tt>DASource.class.getName()</tt> to dynamically get the key.
 *
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DABridgeNoSecurityNoSessionProcessor implements DABridgeProcessor {
    private DAStore daStore;
    private DAMap daMap;

    public DABridgeNoSecurityNoSessionProcessor() {
    }

    public void init(ValueMap config) throws DAException {
        try {
            DASource daSource =
                config.getObject(DASource.class.getName(), DASource.class);

            DABridgeAdminDA adminDA = new AdminDAImpl(daSource);

            AggregateDASource aggregateDASource = new AggregateDASource();
            aggregateDASource.appendSource(daSource);
            aggregateDASource.appendSource(new DASourceAdapter(adminDA));

            daStore = new DAStore(aggregateDASource);
            daMap = new DAMap();
        } catch ( Exception x ) {
            throw DATools.convert(x);
        }
    }

    public void shutdown() {
        daStore.shutdown();
    }

    public DABridgeResponse process(DABridgeRequest req) throws DAException {
        return daMap.process(req);
    }

    private class DAMap {
        private Map<String, Entry> nameMap;

        public DAMap() {
            nameMap = new HashMap<String, Entry>();
        }

        public DABridgeResponse process(DABridgeRequest req)
                throws DAException {

            String daInterfaceTypeName = req.getDaInterfaceTypeName();

            Entry entry = null;

            synchronized ( this ) {
                entry = nameMap.get(daInterfaceTypeName);
                if ( entry == null ) {
                    entry = new Entry(daInterfaceTypeName);
                    nameMap.put(daInterfaceTypeName, entry);
                }
            }

            return entry.process(req);
        }
    } // class DAMap

    private class Entry {
        private final String daInterfaceTypeName;
        private final GenericDA da;
        private final DABridgeMethodMapper mapper;

        @SuppressWarnings("unchecked")
        public Entry(String daInterfaceTypeName) throws DABridgeDAException {
            try {
                this.daInterfaceTypeName = daInterfaceTypeName;

                Class<? extends GenericDA> daInterfaceType =
                    (Class<? extends GenericDA>) Class.forName(
                        daInterfaceTypeName);

                da = daStore.getDA(daInterfaceType);

                mapper = new DABridgeMethodMapper(daInterfaceType);
            } catch ( DABridgeDAException x ) {
                throw x;
            } catch ( Exception x ) {
                throw new DABridgeDAException(x);
            }
        }

        public String getDaInterfaceTypeName() {
            return daInterfaceTypeName;
        }

        public DABridgeResponse process(DABridgeRequest req)
                throws DAException {

            int methodId = req.getMethodId();
            Object[] paramList = req.getMethodParamList();

            Method method = mapper.getMethodForUniqueId(methodId);

            try {
                Object result = method.invoke(da, paramList);
                return new DABridgeResponse(result, null);
            } catch ( InvocationTargetException x ) {
                Throwable methodException = x.getCause();
                if ( methodException instanceof Exception ) {
                    return new DABridgeResponse(
                        (Exception) methodException, null);
                } else {
                    return new DABridgeResponse(
                        new DABridgeDAException(methodException), null);
                }
            } catch ( Exception x ) {
                throw DATools.convert(x);
            }
        }
    } // class Entry

    private static class AdminDAImpl extends Object implements DABridgeAdminDA {
        private DASource daSource;

        public AdminDAImpl(DASource daSource) {
            this.daSource = daSource;
        }

        public void init(ValueMap config) throws DAException {
            // nothing to do
        }

        public void shutdown() {
            // nothing to do
        }

        public boolean isAvailable(Class<? extends GenericDA> daInterfaceType)
                throws DAException {

            return daSource.isAvailable(daInterfaceType);
        }
    } // class AdminDAImpl
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.