package com.programix.da2.exception;

/**
 * This kind of {@link DAException} is thrown to indicate that there
 * was a communication problem while trying to process the request.
 * This should be used in scenarios where the situation might improve
 * (for example, when the network is back up).
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class CommunicationDAException extends DAException {
    public CommunicationDAException() {
        super();
    }

    public CommunicationDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public CommunicationDAException(String message) {
        super(message);
    }

    public CommunicationDAException(Throwable cause) {
        super(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.