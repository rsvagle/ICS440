package com.programix.da2;

import com.programix.da2.exception.*;

public interface DecoratorDA extends GenericDA {
    /**
     * Specifies the <i>decoree</i> that is to be decorated by this decorator.
     * This method will be called <i>after</i> the inherited method
     * {@link GenericDA#init(com.programix.value.ValueMap)
     * init}(ValueMap config) is called.
     * <p>
     * There's no guarantee about the exact type passed in other than it
     * is at the very least an implementation of {@link GenericDA}.
     * If you expect something more specific, then check inside your
     * implementation for this type and throw a {@link DAException}
     * if the type is not correct.
     *
     * @param decoree the <tt>GenericDA</tt> to be decorated, or wrapped by this
     * decorator.
     * @throws DAException if there are problems setting this source
     * on this instance (perhaps it is incompatible).
     */
    void setDecoree(GenericDA decoree) throws DAException;
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.