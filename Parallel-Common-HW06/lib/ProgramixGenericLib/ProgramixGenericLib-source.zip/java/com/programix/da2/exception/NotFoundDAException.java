package com.programix.da2.exception;

/**
 * This kind of {@link DataStateDAException} is thrown to indicate that there
 * is a problem the data was very unexpectedly not found. 
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class NotFoundDAException extends DataStateDAException {
    public NotFoundDAException(String message) {
        super(message);
    }

    public NotFoundDAException() {
        super();
    }
    
    public NotFoundDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotFoundDAException(Throwable cause) {
        super(cause);
    }

    public NotFoundDAException(String target, Object id) {
        this("No '" + target + "' found for id=" + id);
    }

    public NotFoundDAException(String target, int id) {
        this(target, String.valueOf(id));
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.