package com.programix.da2.bridge;

import java.io.*;

import com.programix.da2.exception.*;

/**
 * This part of the Data Access Bridge system is used to encapsulate
 * a response from the invocation of a method on a Data Access interface
 * (both a normal response and exceptions).
 * See {@link DABridgeProcessor} and {@link DABridgeRequest}.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DABridgeResponse implements Serializable {
    private Object payload;
    private byte[] sessionId;
    
    public DABridgeResponse(Object result, byte[] sessionId) {
        this.payload = result;
        this.sessionId = sessionId;
    }
    
    public DABridgeResponse(DABridgeExceptionTransport exceptionWrapper,
                            byte[] sessionId) {
        
        this.payload = exceptionWrapper;
        this.sessionId = sessionId;
    }

    public DABridgeResponse(Exception exception, byte[] sessionId) {
        this(new DABridgeExceptionTransport(exception), sessionId);
    }
    
    public boolean isResult() {
        return !isException();
    }
    
    public boolean isException() {
        return payload instanceof DABridgeExceptionTransport;
    }
    
    public Object getResult() throws DAException {
        if ( isResult() ) {
            return payload;
        } else {
            throw new DAException(getException());
        }
    }
    
    public Exception getException() throws DAException {
        if ( isException() ) {
            DABridgeExceptionTransport wrapper = 
                (DABridgeExceptionTransport) payload;
            return wrapper.getException();
        } else {
            throw new DAException("payload is not an exception");
        }
    }
    
    public byte[] getSessionId() {
        return sessionId;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.