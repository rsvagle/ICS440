package com.programix.da2.exception;

/**
 * This kind of {@link DataStateDAException} is thrown to indicate that there
 * is a problem accessing the data because it is currently locked. 
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class LockedDAException extends DataStateDAException {
    public LockedDAException(String message) {
        super(message);
    }

    public LockedDAException() {
        super();
    }
    
    public LockedDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public LockedDAException(Throwable cause) {
        super(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.