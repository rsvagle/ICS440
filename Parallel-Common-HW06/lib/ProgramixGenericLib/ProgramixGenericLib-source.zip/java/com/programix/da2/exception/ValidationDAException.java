package com.programix.da2.exception;


/**
 * This kind of {@link DAException} is thrown to indicate that there
 * was a problem validating the data. For example: required data missing,
 * an invalid combination of data elements, etc.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ValidationDAException extends DAException {
    public ValidationDAException() {
        super();
    }

    public ValidationDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public ValidationDAException(String message) {
        super(message);
    }

    public ValidationDAException(Throwable cause) {
        super(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.