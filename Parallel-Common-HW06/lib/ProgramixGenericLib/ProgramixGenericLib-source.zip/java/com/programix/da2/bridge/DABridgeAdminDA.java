package com.programix.da2.bridge;

import com.programix.da2.*;
import com.programix.da2.exception.*;

/**
 * This DA is used administratively by the DABridge subsystem.
 * Implementations of {@link DABridgeProcessor} must be written
 * to handle these.
 * <p>
 * Deliberate package scope.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
interface DABridgeAdminDA extends GenericDA {
    boolean isAvailable(Class<? extends GenericDA> daInterfaceType)
        throws DAException;
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.