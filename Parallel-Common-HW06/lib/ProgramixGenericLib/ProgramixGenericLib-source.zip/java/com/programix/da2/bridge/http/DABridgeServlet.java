package com.programix.da2.bridge.http;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.programix.da2.bridge.*;
import com.programix.da2.exception.*;
import com.programix.io.*;

/**
 * This is the servlet half of the HTTP bridge
 * (see {@link HttpDABridgeProcessor}).
 * This servlet does not enforce any security or session tracking
 * and passes along all requests to the {@link DABridgeProcessor}
 * specified during initialization (that processor is in charge of
 * any security policies).
 * Subclasses must implement the {@link #setup()} method and in this
 * method, they must call {@link #setProcessor}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public abstract class DABridgeServlet extends HttpServlet {
    private DABridgeProcessor processor;
    private int compressionThreshold = 1024;
    private String contentType = "image/png";
    private int postCount;

    @Override
    public final void init() throws ServletException {
        try {
            setup();

            if ( processor == null ) {
                throw new DABridgeDAException("Subclasses must set the " +
            		"DABridgeProcessor in their setup() method.");
            }
        } catch ( Exception x ) {
            throw new ServletException(
                "Failed to initialize DABridgeServlet", x);
        }
    }

    @Override
    public final void destroy() {
        processor.shutdown();
    }

    /**
     * Subclasses must implement this method to setup the
     * {@link DABridgeProcessor} that will be used to service client requests.
     * Subclasses must call {@link #setProcessor(DABridgeProcessor)}.
     *
     * @throws DAException if there is some reason that this servlet
     * should not be put into service.
     */
    protected abstract void setup() throws DAException;

    @Override
    protected void doGet(
                    HttpServletRequest req,
                    HttpServletResponse res
                ) throws ServletException, IOException {

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        out.println("<html>");
        out.println("<head>");
        out.println("<title>DABridgeServlet</title>");
        out.println("</head>");
        out.println("<body>");

        out.println("<p>DABridgeServlet has processed: " +
            getPostCount() + " post requests</p>");

        out.println("</body>");
        out.println("</html>");
    }

    public synchronized int getPostCount() {
        return postCount;
    }

    private synchronized void incrementPostCount() {
        postCount++;
    }

    public synchronized String getContentType() {
        return contentType;
    }

    public synchronized void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public synchronized int getCompressionThreshold() {
        return compressionThreshold;
    }

    public synchronized void setCompressionThreshold(int compressionThreshold) {
        this.compressionThreshold = compressionThreshold;
    }

    public synchronized DABridgeProcessor getProcessor() {
        return processor;
    }

    public synchronized void setProcessor(DABridgeProcessor processor) {
        this.processor = processor;
    }

    @Override
    protected void doPost(
                HttpServletRequest req,
                HttpServletResponse res
            ) throws ServletException, IOException {

        incrementPostCount();

        DataInputStream in = null;
        DataOutputStream out = null;
        try {
            in = new DataInputStream(
                new BufferedInputStream(req.getInputStream()));
            out = new DataOutputStream(
                new BufferedOutputStream(res.getOutputStream()));

            TransferWrapper requestTW = TransferWrapper.createFrom(in);
            TransferWrapper resultTW = null;

            DABridgeRequest bridgeReq = null;
            try {
                bridgeReq = SerializationTools.unwrap(
                    requestTW, DABridgeRequest.class);
            } catch ( Exception x ) {
                // Problem--request could not be de-serialized, try to send
                // the details of the exception back as a response instead.
                resultTW = wrapException(x, null);
            }

            if ( bridgeReq != null ) {
                DABridgeResponse bridgeRes = getProcessor().process(bridgeReq);

                try {
                    resultTW = SerializationTools.wrap(
                        bridgeRes, getCompressionThreshold());
                } catch ( Exception x ) {
                    // Problem--response could not be serialized, try to send
                    // the details of the exception back as a response instead.
                    resultTW = wrapException(x, bridgeRes.getSessionId());
                }
            }

            res.setContentType(getContentType());
            res.setContentLength(resultTW.calcWriteToByteCount());

            resultTW.writeTo(out);
            out.flush();
        } catch ( Exception x ) {
            String msg = "Unable to handle request from " +
                req.getRemoteHost() + "; " + x.getMessage();

            if ( x instanceof IOException ) {
                throw (IOException) new IOException(msg).initCause(x);
            } else {
                throw (ServletException) new ServletException(msg).initCause(x);
            }
        } finally {
            IOTools.closeQuietly(in, out);
        }
    }

    private TransferWrapper wrapException(Exception x, byte[] sessionId) {
        return SerializationTools.wrap(
            new DABridgeResponse(new DABridgeExceptionTransport(x), sessionId),
            getCompressionThreshold());
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.