package com.programix.da2;

import java.util.*;

import com.programix.da2.exception.*;

/**
 * An implementation of {@link DASource} that caches the
 * {@link GenericDA} implementations that it retrieves from the
 * underlying {@link DASource} that is passed during
 * construction. This cache can be cleared with the {@link #clearCache()}
 * method.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DAStore implements DASource {
    private DASource source;
    private Map<Class<? extends GenericDA>, GenericDA> cache;
    private Map<Class<? extends GenericDA>, Boolean> availableCache;
    private boolean shutdown;
    private final Object lockObject;

    public DAStore(DASource source) {
        this.source = source;

        lockObject = new Object();
        cache = new HashMap<Class<? extends GenericDA>, GenericDA>();
        availableCache = new HashMap<Class<? extends GenericDA>, Boolean>();
        shutdown = false;
    }

    private void shutdownCheck() throws ShutdownDAException {
        if ( shutdown ) {
            throw new ShutdownDAException();
        }
    }

    @SuppressWarnings("unchecked")
    public <T extends GenericDA> T getDA(Class<T> daInterfaceType)
            throws DAException {

        synchronized ( lockObject ) {
            shutdownCheck();

            T da = (T) cache.get(daInterfaceType);

            if ( da == null ) {
                da = source.getDA(daInterfaceType);
                DATools.checkType(daInterfaceType, da);
                cache.put(daInterfaceType, da);
                availableCache.put(daInterfaceType, Boolean.TRUE);
            }

            return da;
        }
    }

    public boolean isAvailable(Class<? extends GenericDA> daInterfaceType)
            throws DAException {

        synchronized ( lockObject ) {
            shutdownCheck();

            Boolean available = availableCache.get(daInterfaceType);
            if ( available == null ) {
                available = new Boolean(source.isAvailable(daInterfaceType));
                availableCache.put(daInterfaceType, available);
            }

            return available.booleanValue();
        }
    }

    public void shutdown() {
        synchronized ( lockObject ) {
            shutdown = true;

            for ( GenericDA da : cache.values() ) {
                da.shutdown();
            }

            cache.clear();
            availableCache.clear();

            source.shutdown();
        }
    }

    public void clearCache() {
        synchronized ( lockObject ) {
            cache.clear();
            availableCache.clear();
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.