package com.programix.da2;

import com.programix.da2.exception.*;
import com.programix.util.*;

/**
 * Contains various tools helpful in the work of the "data access layer".
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DATools {
    // no instances
    private DATools() {
    }

    /**
     * Takes the specified <tt>Throwable</tt> and wraps it in a
     * {@link DAException} (if necessary). If the type passed in is
     * already a <tt>DAException</tt> then that exception is simply
     * returned. This is useful in coding situations where only a
     * <tt>DAException</tt> is allowed to be thrown (and we don't want
     * to wrap a DAException within a DAException):
     * <pre class="preshade">
     * public String getSomething(int id) <b>throws DAException</b> {
     *     try {
     *         //...
     *
     *     } catch ( Exception x ) {
     *         throw <b>DATools.convert(x)</b>;
     *     }
     * }
     * </pre>
     */
    public static DAException convert(Throwable x) {
        if ( x instanceof DAException ) {
            // no need to re-wrap
            return (DAException) x;
        } else {
            return new DAException(x);
        }
    }

    /**
     * Returns a new {@link DAException} with that has the specified
     * cause chained to it and a message the starts with the specified
     * prefix and ends with the message from the cause.
     */
    public static DAException chainWithPrefix(String msg, Throwable cause) {
            return new DAException(msg + cause.getMessage(), cause);
    }


    public static void checkType(Class<? extends GenericDA> daInterfaceType,
                                 GenericDA daImplementation,
                                 String exceptionPrefix)
            throws DAException {

        if ( daInterfaceType == null ) {
            throw new DAException(
                exceptionPrefix + "Passed daInterfaceType is null");
        }

        if ( daImplementation == null ) {
            throw new DAException(
                exceptionPrefix + "Passed daImplementation is null");
        }

        if ( daInterfaceType.isInterface() == false ) {
            throw new DAException(exceptionPrefix +
                "Passed daInterfaceType=" +
                StringTools.quoteWrap(daInterfaceType.getName()) +
        		" is not an interface");
        }

        if ( GenericDA.class.isAssignableFrom(daInterfaceType) == false ) {
            throw new DAException(exceptionPrefix +
                "Passed daInterfaceType=" +
                StringTools.quoteWrap(daInterfaceType.getName()) +
                " which is not a subtype of " +
                StringTools.quoteWrap(GenericDA.class.getName()));
        }

        if ( daInterfaceType.isInstance(daImplementation) == false ) {
            throw new DAException(exceptionPrefix +
                "Passed daImplementation is of type " +
                StringTools.quoteWrap(daImplementation.getClass().getName()) +
                " which is not an implementation of passed daInterfaceType=" +
                StringTools.quoteWrap(daInterfaceType.getName()));
        }
    }

    public static void checkType(Class<? extends GenericDA> daInterfaceType,
                                 GenericDA daImplementation)
            throws DAException {

        checkType(
            daInterfaceType, daImplementation, StringTools.ZERO_LEN_STRING);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.