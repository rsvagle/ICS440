package com.programix.da2;

import java.util.*;

import com.programix.da2.exception.*;
import com.programix.thread.*;
import com.programix.util.*;

/**
 * Used to exchange {@link GenericDA}'s among friends.
 * The {@link #share(Class, GenericDA)} method is called to offer up
 * a DA for others to use.
 * The {@link #getDA(Class, long)} method is called to search for a DA
 * previously shared and/or to wait for it to be shared (the msTimeout
 * value is use to limit the amount of time that can be spent waiting).
 * <p>
 * This class can be used as a way to have several DA implementations
 * attempt to be simultaneously simultaneously initialized&mdash;even
 * if some DA implementations depend on other DA implementations (as long
 * as there isn't a circular dependence!)
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DAExchange {
    private Map<Class<? extends GenericDA>, GenericDA> shareMap;
    private final Object lockObject;
    private Waiter waiter;

    public DAExchange() {
        shareMap = new HashMap<Class<? extends GenericDA>, GenericDA>();
        lockObject = new Object();
        waiter = new Waiter(lockObject);
    }

    /**
     * Called to share the specified DA type and implementation.
     *
     * @param daInterfaceType the DA interface type to offer up for sharing.
     * @param daImplementation the implementation of the specified interface
     * type.
     */
    public void share(Class<? extends GenericDA> daInterfaceType,
                      GenericDA daImplementation)
            throws DAException {

        ObjectTools.paramNullCheck(daInterfaceType, "daInterfaceType");
        ObjectTools.paramNullCheck(daImplementation, "daImplementation");

        synchronized ( lockObject ) {
            shutdownCheck();

            if ( daInterfaceType.isInstance(daImplementation) ) {
                shareMap.put(daInterfaceType, daImplementation);
                waiter.signalChange();
            } else {
                throw new DAException(
                    "Sharing failed due to incompatible types. " +
                    "Implementation type of " +
                    daImplementation.getClass().getName() +
                    " can't be cast into interface type of " +
                    daInterfaceType.getClass().getName());
            }
        }
    }

    /**
     * Returns a DA of the specified daInterfaceType potentially waiting
     * for it to become available.
     *
     * @param daInterfaceType the DA type to search for (or wait for).
     * @param msTimeout the maximum number of milliseconds to wait for the
     * DA to become available.
     * @return the requested DA implementation
     * @throws NotYetAvailableDAException if the requested DA is still not
     * available after waiting for the specified timeout. Calling this
     * method again might be successful.
     * @throws DAException if something else goes wrong.
     */
    @SuppressWarnings("unchecked")
    public <T extends GenericDA> T getDA(final Class<T> daInterfaceType,
                                         long msTimeout)
            throws NotYetAvailableDAException, DAException {

        synchronized ( lockObject ) {
            shutdownCheck();

            GenericDA da = shareMap.get(daInterfaceType);
            if ( da != null ) {
                return (T) da;
            }

            Waiter.Condition daAvailable = waiter.createCondition(
                    new Waiter.Expression() {

                @Override
                public boolean isTrue() {
                    return shareMap.containsKey(daInterfaceType);
                }
            });

            try {
                daAvailable.waitUntilTrueWithTimedOutException(msTimeout);
                return (T) shareMap.get(daInterfaceType);
            } catch ( TimedOutException x ) {
                throw new NotYetAvailableDAException(
                    daInterfaceType.getName() + " not available after " +
                    "waiting " + msTimeout + " ms");
            } catch ( Exception x ) {
                throw new DAException(x);
            }
        }
    }

    public void shutdown() {
        synchronized ( lockObject ) {
            if ( waiter.isShutdown() ) {
                return;
            }

            for ( Iterator<GenericDA> iter = shareMap.values().iterator();
                  iter.hasNext(); ) {

                GenericDA da = iter.next();
                da.shutdown();
            }

            shareMap.clear();
            waiter.shutdown();
        }
    }

    /**
     * Creates a lightweight view of the {@link DAExchange}
     * as a {@link DASource}. Calling shutdown() on this DASource
     * will also shutdown the DAExchange.
     *
     * @throws ShutdownDAException if this has already been shutdown
     */
    public DASource createDASourceView() throws ShutdownDAException {
        shutdownCheck();
        return new DASourceView();
    }

    private void shutdownCheck() throws ShutdownDAException {
        if ( waiter.isShutdown() ) {
            throw new ShutdownDAException();
        }
    }

    private class DASourceView implements DASource {
        public DASourceView() {
        }

        @SuppressWarnings("unchecked")
        public <T extends GenericDA> T getDA(Class<T> daInterfaceType)
                throws DAException {

            synchronized ( lockObject ) {
                shutdownCheck();

                GenericDA da = shareMap.get(daInterfaceType);
                if ( da != null ) {
                    return (T) da;
                }

                throw new NotYetAvailableDAException(daInterfaceType);
            }
        }

        public boolean isAvailable(Class<? extends GenericDA> daInterfaceType)
                throws DAException {

            synchronized ( lockObject ) {
                shutdownCheck();
                return shareMap.containsKey(daInterfaceType);
            }
        }

        public void shutdown() {
            DAExchange.this.shutdown();
        }
    } // class DASourceView
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.