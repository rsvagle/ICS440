package com.programix.da2.exception;


/**
 * This kind of {@link DAException} is thrown to indicate that there
 * is a problem with the state of the data (such as locked by another user,
 * stale data, unexpectedly not found). 
 * Check out the subclasses (some of the subclasses are: 
 * {@link NotFoundDAException}, {@link StaleDataDAException}, 
 * {@link LockedDAException}).
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DataStateDAException extends DAException {
    public DataStateDAException() {
        super();
    }

    public DataStateDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataStateDAException(String message) {
        super(message);
    }

    public DataStateDAException(Throwable cause) {
        super(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.