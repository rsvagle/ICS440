package com.programix.da2;

import com.programix.da2.exception.*;

/**
 * A <i>source</i> of {@link GenericDA} implementations for either
 * the entire VM or for an individual user.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface DASource {
    /**
     * Searches for an implementation of the specified interface type.
     *
     * @param daInterfaceType the interface type for which an implementation
     * is desired.
     * @return an implementation of the specified type.
     * @throws DAException if either no implementation can be
     * found or if there is trouble creating/accessing the implementation.
     */
    <T extends GenericDA> T getDA(Class<T> daInterfaceType)
            throws DAException;

    /**
     * Searches for an implementation of the specified interface type
     * and returns <tt>true</tt> if one is available.
     * If this method returns true, then calling {@link #getDA(Class)}
     * with the same parameter is virtually guaranteed to succeed (barring
     * a communication breakdown, a call to shutdown,
     * or similar unforeseen problems).
     *
     * @param daInterfaceType the interface type for which an implementation
     * is desired.
     * @return <tt>true</tt> if an implementation is available, <tt>false</tt>
     * if not.
     * @throws DAException if a determination can not be made (perhaps
     * because of a communication error or other similar kinds of problems
     * that prevent a definitive answer from being found).
     */
    boolean isAvailable(Class<? extends GenericDA> daInterfaceType)
            throws DAException;

    /**
     * This should be called when the DASource is no longer needed to
     * clean up any potential resources being used behind the scenes.
     * Some implementations may have nothing to do when shutdown, but
     * other implementations might have important deallocation duties
     * to perform.
     * <p>
     * If there are any "cached" instances of <tt>GenericDA</tt> that this
     * source is holding, those are individually shutdown by calling this
     * method.
     * <p>
     * No other methods should be called after this method.
     * Calling other methods after calling this method results in
     * undefined behavior (many times, a {@link ShutdownDAException} will be
     * thrown when attempting to invoke those other methods, but there is
     * no requirement that all methods do this).
     * <p>
     * Calling <tt>shutdown()</tt> more than one time must be allowed
     * and <tt>shutdown()</tt> must not complain.
     * Also note that <tt>shutdown()</tt> never throws <i>any</i>
     * exceptions&mdash;it just makes its best effort of close down everything.
     * Implementations must assure that this remains true.
     */
    void shutdown();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.