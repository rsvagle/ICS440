package com.programix.da2.exception;

import com.programix.da2.*;

/**
 * This kind of {@link DAException} is used to signal that something
 * is not <i>yet</i> available or ready. This resource is still possibly
 * going to be ready at time future time.
 * This exception can be thrown to indicate that a method does not yet
 * have the ability to determine an answer&mdash;but may be able to determine
 * an answer in the future.
 * This exception can also be thrown to indicate that a DA is not yet
 * available but may become available in the future.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class NotYetAvailableDAException extends DAException {
    public NotYetAvailableDAException() {
        super();
    }

    public NotYetAvailableDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotYetAvailableDAException(String message) {
        super(message);
    }

    public NotYetAvailableDAException(Throwable cause) {
        super(cause);
    }

    public NotYetAvailableDAException(
            Class<? extends GenericDA> daInterfaceType) {

        super(daInterfaceType.getName() + " is not currently available, " +
    		"but may be at some time in the future");
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.