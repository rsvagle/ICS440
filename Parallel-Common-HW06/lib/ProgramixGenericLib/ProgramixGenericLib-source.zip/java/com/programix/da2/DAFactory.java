package com.programix.da2;

import java.io.*;
import java.lang.reflect.*;
import java.net.*;

import com.programix.da2.bridge.*;
import com.programix.da2.exception.*;
import com.programix.util.*;
import com.programix.value.*;

/**
 * Used to construct and initialize instances of data access implementations
 * using reflection.
 * <p>Common usage is (where <code>CustomerDA</code> is an interface
 * that extends the {@link GenericDA} interface):
 * <pre class="preshade">
 * {@link ValueMap} config = //...
 * CustomerDA cda = DAFactory.{@link
 *     #create(ValueMap, Class) create}(config, CustomerDA.class);</pre>
 * or
 * <pre class="preshade">
 * String filename = //...
 * CustomerDA cda = DAFactory.{@link
 *     #createFromFile(String, Class) create}(filename, CustomerDA.class);</pre>
 *
 * The configuration {@link ValueMap} passed in must contain the
 * class name of the class to be instantiated stored under the key
 * {@link #DA_IMPLEMENTATION_CLASSNAME}. Other key/value pairs in the map
 * are populated with whatever the specific data access
 * implementation needs for initialization.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DAFactory extends Object {
	/**
	 * The reserved key that retrieves the fully-qualified name
	 * (as a <tt>String</tt>)
	 * of the data access implementation class that will
	 * be instantiated via reflection.
	 * <p>
     * The value of this key is always:
	 * <pre class="preshade">
	 * da.impl.classname
	 * </pre>
     *
     * @see #create(ValueMap, Class)
	 */
	public static final String DA_IMPLEMENTATION_CLASSNAME =
			"da.impl.classname"; // keep value in sync with api docs!!!

	/**
	 * This reserved key is used to retrieve the URL
	 * (as a <tt>String</tt>) of a remote DASource available via HTTP or HTTPS.
	 * <p>
	 * The value of this key is always:
	 * <pre class="preshade">
	 * da.remote.source.url
	 * </pre>
	 *
	 * @see #create(ValueMap, Class)
	 */
	public static final String DA_REMOTE_SOURCE_URL =
	    "da.remote.source.url"; // keep value in sync with api docs!!!

	/**
	 * Used by this factory to facilitate the creation and initialization of
     * a chain of data access' if the outer 'wrappers' implement
     * {@link DecoratorDA}.
     * The reserved key <i>prefix</i> that when present in the configuration
     * {@link ValueMap} is used to extract a sub-map via the
     * {@link ValueMap#getNestedValueMap(String) getNestedValueMap(prefix)}
     * on <tt>ValueMap</tt>. This sub-map is then passed off to the decoree
     * of the {@link DecoratorDA}.
	 * <p>
     * The value of this key is always (note the trailing dot):
	 * <pre class="preshade">
	 * da.decoree.
	 * </pre>
     *
	 * @see #create(ValueMap, Class)
	 */
	public static final String DA_DECOREE_PREFIX =
	    "da.decoree."; // keep value in sync with api docs!!!

	private static final String CREATE_FAILED_PREFIX =
	    "Factory failed to create data access impl: ";

    // no instances
	private DAFactory() {
	}

	/**
	 * Constructs an instance of the data access implementation
	 * specified in the configuration.
	 * One of two special keys must be present, either:
	 * <ul>
	 * <li>{@link #DA_IMPLEMENTATION_CLASSNAME} with a <tt>String</tt> value
	 * which is the full class name of the implementation of the data
	 * access interface.</li>
	 * <li>{@link #DA_REMOTE_SOURCE_URL} with a <tt>String</tt> value
	 * which is the URL (using the http or https protocol) where a remote
	 * {@link DASource} is available
	 * </ul>
	 * If both happen to be present and non-empty, then the classname
	 * will be used.
	 * <p>
     * Immediately after the zero-argument constructor is invoked,
	 * the {@link GenericDA#init init(ValueMap conf)} of
     * <tt>GenericDA</tt> is invoked to initialize the configuration.
	 * <p>
     * If the <tt>targetType</tt> is not <tt>null</tt>, then an
	 * additional check is done to ensure that the constructed object
	 * can be type cast into that type (failures throw a
	 * <tt>DAException</tt> instead of a <tt>ClassCastException</tt>).
     * <p>
     * If the implementation happens to be not only a {@link GenericDA}
     * but also a {@link DecoratorDA} <i><b>and</b></i> there are config map
     * keys starting with the {@link #DA_DECOREE_PREFIX}, then this
     * create method will attempt to create the chain of decorated data access
     * implementations. This create method will attempt to extract a
     * sub-map using this reserved key <i>prefix</i> via the
     * {@link ValueMap#getNestedValueMap(String) getNestedValueMap(prefix)}
     * on <tt>ValueMap</tt>. This sub-map is then used to create the decoree
     * of the {@link DecoratorDA}. If you'd like to manually chain, then
     * make sure that there are no keys starting with the
     * prefix {@link #DA_DECOREE_PREFIX}.
	 *
	 * @param config key/value mapping with everything that is needed to
	 * initialize this data access implementation.
	 * @param daInterfaceType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>DAException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception DAException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
	 */
	@SuppressWarnings("unchecked")
    public static <T extends GenericDA> T create(ValueMap config,
	                                             Class<T> daInterfaceType)
            throws DAException {

        GenericDA da = null;

        String classname = config.getString(DA_IMPLEMENTATION_CLASSNAME, null);
        String url = config.getString(DA_REMOTE_SOURCE_URL, null);

        if ( StringTools.isNotEmpty(classname) ) {
            da = getDAFromClassname(config);
        } else if ( StringTools.isNotEmpty(url) ) {
            da = getDAFromRemoteSource(config, daInterfaceType);
            DATools.checkType(daInterfaceType, da, CREATE_FAILED_PREFIX);
            return (T) da;
        } else {
            throw new DAException(CREATE_FAILED_PREFIX +
                "One of the reserved keys, either " +
                StringTools.quoteWrap(DA_IMPLEMENTATION_CLASSNAME) + " or " +
                StringTools.quoteWrap(DA_REMOTE_SOURCE_URL) +
                " is required to be specified with a non-empty value");
        }

        try {
            DATools.checkType(daInterfaceType, da, CREATE_FAILED_PREFIX);

            da.init(config); // might throw DAException too...

            if ( da instanceof DecoratorDA ) {
                // Pull out the nested configuration settings for the source
                // to be decorated:
                ValueMap decoreeConfig =
                    config.getNestedValueMap(DA_DECOREE_PREFIX);

                if ( decoreeConfig.getSize() > 0 ) {
                    GenericDA decoree = create(decoreeConfig, GenericDA.class);
                    ((DecoratorDA) da).setDecoree(decoree);
                }
            }

            return (T) da;
        } catch ( DAException x ) {
            throw x;
        } catch ( Exception x ) {
            throw new DAException(CREATE_FAILED_PREFIX + x.getMessage(), x);
        }
	}

    @SuppressWarnings("unchecked")
    private static GenericDA getDAFromClassname(ValueMap config)
            throws DAException {

        String className = "";

        try {
            className = config.getString(DA_IMPLEMENTATION_CLASSNAME);

            if ( StringTools.isEmpty(className) ) {
                throw new DAException(CREATE_FAILED_PREFIX +
                    "Classname stored under key '" +
                    DA_IMPLEMENTATION_CLASSNAME + "' is empty");
            }

            Class<?> c = Class.forName(className);

            if ( c.isInterface() ) {
                throw new DAException(CREATE_FAILED_PREFIX + "'" + className +
                    "' is an interface (must be a concrete class)");
            }

            if ( c.isArray() ) {
                throw new DAException(CREATE_FAILED_PREFIX + "'" + className +
                    "' is an array type (must be a concrete class)");
            }

            if ( Modifier.isAbstract(c.getModifiers()) ) {
                throw new DAException(CREATE_FAILED_PREFIX + "'" + className +
                    "' is an abstract class (must be a concrete class)");
            }

            if ( GenericDA.class.isAssignableFrom(c) == false ) {
                throw new DAException(CREATE_FAILED_PREFIX + "'" + className +
                    "' does not implement '" + GenericDA.class.getName() +
                    "' (either directly or indirectly)");
            }

            // This is validated immediately above
            Class<? extends GenericDA> c2 = (Class<? extends GenericDA>) c;

            Constructor<? extends GenericDA> constructor =
                c2.getDeclaredConstructor();

            if ( Modifier.isPublic(constructor.getModifiers()) == false ) {
                throw new DAException(CREATE_FAILED_PREFIX + "'" + className +
                    "' does not have a public, zero-arg constructor");
            }

            return constructor.newInstance();
        } catch ( ValueMapRequiredKeyException x ) {
            throw new DAException(CREATE_FAILED_PREFIX +
                " Required key '" + DA_IMPLEMENTATION_CLASSNAME +
                "' not found in config.", x);
        } catch ( ClassNotFoundException x ) {
            throw new DAException(CREATE_FAILED_PREFIX +
                "Unable to find class '" + className + "'", x);
        } catch ( IllegalArgumentException x ) {
            throw new DAException(CREATE_FAILED_PREFIX + "'" + className +
                "' does not have a public, zero-arg constructor");
        } catch ( NoSuchMethodException x ) {
            throw new DAException(CREATE_FAILED_PREFIX + "'" + className +
                "' does not have a public, zero-arg constructor");
        } catch ( InstantiationException x ) {
            throw new DAException(CREATE_FAILED_PREFIX + "'" + className +
                "' does not have a public, zero-arg constructor");
        } catch ( IllegalAccessException x ) {
            throw new DAException(CREATE_FAILED_PREFIX + "'" + className +
                "' does not have a public, zero-arg constructor");
        } catch ( DAException x ) {
            throw x;
        } catch ( Exception x ) {
            throw new DAException(CREATE_FAILED_PREFIX + x.getMessage(), x);
        }
    }

    private static <T extends GenericDA>
            T getDAFromRemoteSource(ValueMap config, Class<T> daInterfaceType)
            throws DAException {

        String urlStr = null;
        try {
            // we know that this key exists and has a non-empty value
            urlStr = config.getString(DA_REMOTE_SOURCE_URL);

            DASource daSource =
                DABridgeFactory.createHttpBridgeDASource(urlStr);

            return daSource.getDA(daInterfaceType);
        } catch ( Exception x ) {
            throw new DAException(CREATE_FAILED_PREFIX +
                "Trouble with remote DASource url=" +
                StringTools.quoteWrap(urlStr) + " " +
                x.getMessage(), x);
        }
    }

	/**
	 * Create a data access instance using a <tt>Reader</tt>
	 * whose data is in the format described by {@link ValueMap}
     * (nearly identical to the format for a <code>Properties</code> file).
	 * Internally, the stream <i>will</i> be buffered and the stream
	 * <i>will</i> be closed.
	 *
	 * @param rawIn a stream whose contents can be loaded into
	 * a <tt>ValueMap</tt> with everything that is needed to
	 * initialize the instance of data access.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>DAException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception DAException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
	 */
	public static <T extends GenericDA> T create(Reader rawIn,
	                                             Class<T> targetType)
			throws DAException {

		try {
            return create(ValueMap.createFrom(rawIn), targetType);
        } catch ( DAException x ) {
            throw x;
        } catch ( Exception x ) {
            throw DATools.chainWithPrefix(CREATE_FAILED_PREFIX, x);
        }
	}

    /**
	 * Create a data access instance using an <tt>InputStream</tt>
	 * whose data is in the format described by {@link ValueMap}
     * (nearly identical to the format for a <code>Properties</code> file).
	 * Internally, the stream <i>will</i> be buffered and the stream
	 * <i>will</i> be closed.
	 *
	 * @param rawIn a stream whose contents can be loaded into
	 * a <tt>ValueMap</tt> with everything that is needed to
	 * initialize the instance of data access.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>DAException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception DAException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
	 */
	public static <T extends GenericDA> T create(InputStream rawIn,
	                                             Class<T> targetType)
			throws DAException {

		try {
            return create(ValueMap.createFrom(rawIn), targetType);
        } catch ( DAException x ) {
            throw x;
        } catch ( Exception x ) {
            throw DATools.chainWithPrefix(CREATE_FAILED_PREFIX, x);
        }
	}

    /**
     * Create a data access instance using an <tt>File</tt>
     * whose data is in the format described by {@link ValueMap}
     * (nearly identical to the format for a <code>Properties</code> file).
     *
     * @param file file with key/value mapping with everything that
     *            is needed to initialize the instance of data access.
     * @param targetType the class type that this instance is expected to be
     *            cast into. Use <tt>null</tt> to skip this check. If not
     *            <tt>null</tt> and the type does not match what is
     *            constructed, then a <tt>DAException</tt> is thrown.
     *
     * @return the constructed and initialized instance.
     *
     * @exception DAException if instance can not be constructed and
     *                initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(URL, Class)

     */
    public static <T extends GenericDA> T create(File file,
                                                 Class<T> targetType)
            throws DAException {

        try {
            return create(ValueMap.createFrom(file), targetType);
        } catch ( DAException x ) {
            throw x;
        } catch ( Exception x ) {
            throw DATools.chainWithPrefix(CREATE_FAILED_PREFIX, x);
        }
    }

    /**
     * Create a data access instance using the specified
     * <tt>filename</tt> whose data is in the format described by
     * {@link ValueMap}(nearly identical to the format for a
     * <code>Properties</code> file).
     *
     * @param filename file with key/value mapping with everything that is
     *            needed to initialize the instance of data access.
     * @param targetType the class type that this instance is expected to be
     *            cast into. Use <tt>null</tt> to skip this check. If not
     *            <tt>null</tt> and the type does not match what is
     *            constructed, then a <tt>DAException</tt> is thrown.
     *
     * @return the constructed and initialized instance.
     *
     * @exception DAException if instance can not be constructed and
     *                initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
     */
    public static <T extends GenericDA> T createFromFile(String filename,
                                                         Class<T> targetType)
            throws DAException {

        try {
            return create(ValueMap.createFromFile(filename), targetType);
        } catch ( DAException x ) {
            throw x;
        } catch ( Exception x ) {
            throw DATools.chainWithPrefix(CREATE_FAILED_PREFIX, x);
        }
    }

	/**
     * Create a data access instance using the specified
     * <tt>URL</tt> whose data is in the format described by
     * {@link ValueMap}(nearly identical to the format for a
     * <code>Properties</code> file).

	 * @param propertiesURL a URL whose contents can be loaded into
	 * a <tt>ValueMap</tt> with everything that is needed to
	 * initialize the instance of data access.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>DAException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception DAException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
	 */
	public static <T extends GenericDA> T create(URL propertiesURL,
	                                             Class<T> targetType)
			throws DAException {

        try {
            return create(ValueMap.createFrom(propertiesURL), targetType);
        } catch ( DAException x ) {
            throw x;
        } catch ( Exception x ) {
            throw DATools.chainWithPrefix(CREATE_FAILED_PREFIX, x);
        }
	}

    /**
     * Create a data access instance using the specified
     * <tt>resourceLocation</tt> whose data is in the format described by
     * {@link ValueMap}(nearly identical to the format for a
     * <code>Properties</code> file).
     *
     * @param resourceLocation resource with key/value mapping with
     *            everything that is
     *            needed to initialize the instance of data access.
     * @param targetType the class type that this instance is expected to be
     *            cast into. Use <tt>null</tt> to skip this check. If not
     *            <tt>null</tt> and the type does not match what is
     *            constructed, then a <tt>DAException</tt> is thrown.
     *
     * @return the constructed and initialized instance.
     *
     * @exception DAException if instance can not be constructed and
     *                initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
     */
    public static <T extends GenericDA>
            T createFromResource(String resourceLocation, Class<T> targetType)
            throws DAException {

        try {
            return create(
                ValueMap.createFromResource(resourceLocation), targetType);
        } catch ( DAException x ) {
            throw x;
        } catch ( Exception x ) {
            throw DATools.chainWithPrefix(CREATE_FAILED_PREFIX, x);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.