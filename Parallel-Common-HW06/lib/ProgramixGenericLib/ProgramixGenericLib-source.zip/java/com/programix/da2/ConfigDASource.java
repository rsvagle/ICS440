package com.programix.da2;

import java.util.*;

import com.programix.da2.exception.*;
import com.programix.util.*;
import com.programix.value.*;

/**
 * This {@link DASource} is used to hold one of more configuration
 * {@link ValueMap}'s and creates DA implementations on demand from
 * those configurations using {@link DAFactory} internally.
 * <p>
 * The first call to {@link #getDA(Class)} or {@link #isAvailable(Class)}
 * for a configured type will cause an attempt to create an instance
 * using the factory. If an instance is successfully created, it is
 * cached and used for subsequent requests (however, although there is
 * some caching in this class it is recommended to also wrap an instance
 * of this class with {@link DAStore}).
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ConfigDASource implements DASource {
    private Map<String, ValueMap> configMap;
    private Map<Class<? extends GenericDA>, GenericDA> daCache;

    private boolean shutdown;
    private final Object lockObject;

    public ConfigDASource() {
        configMap = new HashMap<String, ValueMap>();
        daCache = new HashMap<Class<? extends GenericDA>, GenericDA>();
        lockObject = new Object();
        shutdown = false;
    }

    private void shutdownCheck() throws ShutdownDAException {
        if ( shutdown ) {
            throw new ShutdownDAException();
        }
    }

    public void addConfig(String daInterfaceTypeName, ValueMap config) {
        synchronized ( lockObject ) {
            configMap.put(daInterfaceTypeName, config);
        }
    }

    public void addConfig(Class<? extends GenericDA> daInterfaceType,
                          ValueMap config) {

        addConfig(daInterfaceType.getName(), config);
    }

    @SuppressWarnings("unchecked")
    public <T extends GenericDA> T getDA(Class<T> daInterfaceType)
            throws DAException {

        synchronized ( lockObject ) {
            shutdownCheck();

            GenericDA da = daCache.get(daInterfaceType);
            if ( da != null ) {
                return (T) da;
            }

            ValueMap map = configMap.get(daInterfaceType.getName());

            if ( map == null ) {
                throw new DAException("Unable to get DA implementation for " +
                    StringTools.quoteWrap(daInterfaceType.getName()) +
                    " as there is no configuration ValueMap stored");
            }

            da = DAFactory.create(map, daInterfaceType);
            daCache.put(daInterfaceType, da);
            return (T) da;
        }
    }

    public boolean isAvailable(Class<? extends GenericDA> daInterfaceType)
            throws DAException {

        synchronized ( lockObject ) {
            shutdownCheck();

            if ( configMap.containsKey(daInterfaceType.getName()) == false ) {
                return false;
            } else {
                // Actually try to get one to find out how it goes
                try {
                    getDA(daInterfaceType);
                    return true;
                } catch ( Exception x ) {
                    return false;
                }
            }
        }
    }

    public void shutdown() {
        synchronized ( lockObject ) {
            shutdown = true;
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.