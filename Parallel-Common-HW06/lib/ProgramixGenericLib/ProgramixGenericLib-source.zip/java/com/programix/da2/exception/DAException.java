package com.programix.da2.exception;

/**
 * Thrown to indicate a technical problem with the 'Data Access Layer'.
 * For example, instead of throwing an {@link java.sql.SQLException}
 * if there were problems talking to the database, chain it to a
 * <code>DAException</code> and throw that instead. However, if there
 * was another kind of problem (like a required value missing) and if the
 * application <i>was</i> able to communicate with the network, file, database,
 * remote object, or whatever, a more specific subclass of
 * <code>DAExcepion</code> could be used or another application-specific
 * exception could be used.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DAException extends Exception {
    public DAException() {
        super();
    }

    public DAException(String message) {
        super(message);
    }

    public DAException(Throwable cause) {
        super(cause);
    }

    public DAException(String message, Throwable cause) {
        super(message, cause);
    }


    public static DAException convert(Throwable t) {
        if ( t instanceof DAException ) {
            return (DAException) t;
        } else {
            return new DAException(t);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.