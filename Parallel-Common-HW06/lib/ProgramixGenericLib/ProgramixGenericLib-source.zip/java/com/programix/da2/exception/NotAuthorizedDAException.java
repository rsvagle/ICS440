package com.programix.da2.exception;

/**
 * This kind of {@link SecurityDAException} is thrown to indicate
 * that the user is not authorized to perform the attempted action.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class NotAuthorizedDAException extends SecurityDAException {
    public NotAuthorizedDAException() {
        super();
    }

    public NotAuthorizedDAException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotAuthorizedDAException(String message) {
        super(message);
    }

    public NotAuthorizedDAException(Throwable cause) {
        super(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.