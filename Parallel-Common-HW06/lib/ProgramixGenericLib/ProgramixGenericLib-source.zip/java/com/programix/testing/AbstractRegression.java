package com.programix.testing;

import java.io.*;
import java.math.*;
import java.util.*;

import com.programix.math.*;
import com.programix.thread.*;
import com.programix.util.*;

/**
 * Base class to extend to facilitate the creation of regression tests.
 * Subclasses implement the {@link #runBundles} method. Users of this
 * the subclass instantiate it and then call {@link #runTestsAsync} or
 * call {@link #runTests}.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public abstract class AbstractRegression extends Object {
	private int failCount = 0;
	private int regressionCount = 0;
    private long testStartTime;
    private char[] elapsedDigit = new char[12];

    private boolean nextOutIsNewLine = true;
    private StringBuffer buf = new StringBuffer(512);

    private final OutputBuffer outputBuffer;

    private boolean prefixWithTime = true;
    private int timeFormatLength = elapsedDigit.length;
    private boolean prefixWithThreadName = true;
    private int threadNameLength = 8;

    protected AbstractRegression() {
        outputBuffer = new OutputBuffer(new ConsoleOutput(), 250);
    }

	public void setOutput(Output output) {
        outputBuffer.setRawOutput(output);
	}

	public synchronized int getFailCount() {
		return failCount;
	}

	public synchronized int getRegressionCount() {
		return regressionCount;
	}

	private synchronized void incrFailCount() {
		failCount++;
	}

	private synchronized void incrRegressionCount() {
		regressionCount++;
	}

    public synchronized boolean isPrefixWithThreadName() {
        return prefixWithThreadName;
    }

    public synchronized void setPrefixWithThreadName(
                                                 boolean prefixWithThreadName) {

        this.prefixWithThreadName = prefixWithThreadName;
    }

    public synchronized int getThreadNameLength() {
        return threadNameLength;
    }

    public synchronized void setThreadNameLength(int threadNameLength) {
        this.threadNameLength = threadNameLength;
    }

    public synchronized boolean isPrefixWithTime() {
        return prefixWithTime;
    }

    public synchronized void setPrefixWithTime(boolean prefixWithTime) {
        this.prefixWithTime = prefixWithTime;
    }

    public synchronized int getTimeFormatLength() {
        return timeFormatLength;
    }

    public synchronized void setTimeFormatLength(int timeFormatLength)
            throws IllegalArgumentException {

        if ( timeFormatLength > elapsedDigit.length ) {
            throw new IllegalArgumentException(
                "Formatted time length can not be more than "
                + elapsedDigit.length);
        }

        if ( timeFormatLength < 5 ) {
            throw new IllegalArgumentException(
                "Formatted time length can not be less than 5 ");
        }

        this.timeFormatLength = timeFormatLength;
    }

    // Give back time as: hh:mm:ss.ppp (up to 99:59:59.999, then rolls over)
    private synchronized String getElapsedTime() {
        updateElapsedTime();
        return new String(elapsedDigit);
    }

    private synchronized void updateElapsedTime() {
        long msTotal = System.currentTimeMillis() - testStartTime;

        int msPart = (int) (msTotal % 1000L);
        int secTotal = (int) (msTotal / 1000L);
        int secPart = secTotal % 60;
        int minTotal = secTotal / 60;
        int minPart = minTotal % 60;
        int hrTotal = minTotal / 60;
        int hrPart = hrTotal % 100;

        int ptr = elapsedDigit.length - 1;

        calcDigits(msPart, 3, elapsedDigit, ptr);
        ptr -= 3;

        elapsedDigit[ptr] = '.';
        ptr--;

        calcDigits(secPart, 2, elapsedDigit, ptr);
        ptr -= 2;

        elapsedDigit[ptr] = ':';
        ptr--;

        calcDigits(minPart, 2, elapsedDigit, ptr);
        ptr -= 2;

        elapsedDigit[ptr] = ':';
        ptr--;

        calcDigits(hrPart, 2, elapsedDigit, ptr);
    }

    private static void calcDigits(int val,
                                   int placeCount,
                                   char[] dst,
                                   int ptr) {

        for ( int i = 0; i < placeCount; i++ ){
            int placeVal = val % 10;
            val = val / 10;
            dst[ptr] = (char) ('0' + placeVal);
            ptr--;
        }
    }

	private synchronized void outGuts(String msg, boolean completeLine) {
        if ( nextOutIsNewLine && ( prefixWithTime || prefixWithThreadName ) ) {
            buf.setLength(0);

            if ( prefixWithTime ) {
                updateElapsedTime();

                int offset = elapsedDigit.length - timeFormatLength;
                buf.append(elapsedDigit, offset, timeFormatLength);
                buf.append('|');
            }

            if ( prefixWithThreadName ) {
                buf.append(
                    StringTools.padClip(
                        Thread.currentThread().getName(), threadNameLength));
                buf.append('|');
            }

            buf.append(msg);
            msg = buf.toString();
        }

        try {
            outputBuffer.add(msg, completeLine);
        } catch ( InterruptException x ) {
            x.printStackTrace();
            Thread.currentThread().interrupt();
        }
        nextOutIsNewLine = completeLine;
	}

	protected synchronized void out(String msg) {
        outGuts(msg, false);
	}

	protected synchronized void outln(String msg) {
        outGuts(msg, true);
    }

    protected synchronized void outln(Object msg) {
        String s = (msg == null) ? null : msg.toString();
	    outGuts(s, true);
	}

    protected synchronized void outln(String msg, boolean success) {
		incrRegressionCount();

		if ( success ) {
            out(" PASS: ");
            outln(msg);
		} else {
			incrFailCount();
            out(">FAIL: ");
            outln(msg);
		}
	}

	protected synchronized final void outln(
				String msg,
				boolean result,
				boolean expectedResult
			) {

		outln(msg + " [result=" + result + ", expected=" +
			expectedResult + "]", result == expectedResult);
	}

	protected synchronized final void outln(
				String msg,
				Object result,
				Object expectedResult
			) {

        if ( (result instanceof String) &&
             (expectedResult instanceof String) ) {

            outln(msg, (String) result, (String) expectedResult);
        } else {
            boolean success = (result == null)
                ? (expectedResult == null)
                : result.equals(expectedResult);

            outln(msg + " [result=" + result + ", expected=" +
                expectedResult + "]", success);
        }
	}

	protected synchronized final void outln(
				String msg,
				String result,
				String expectedResult
			) {

		boolean success = (result == null)
				? (expectedResult == null)
				: result.equals(expectedResult);

		outln(msg + " [result=" + StringTools.quoteWrap(result) +
            ", expected=" + StringTools.quoteWrap(expectedResult) +
            "]", success);
	}

    /**
     * Compares the BigDecimals without regard to scale differences.
     */
	protected synchronized final void outln(
				String msg,
				BigDecimal result,
				BigDecimal expectedResult
			) {

		boolean success = (result == null)
				? (expectedResult == null)
				: DecimalTools.equalTo(result, expectedResult);

		outln(msg + " [result=" + result + ", expected=" + expectedResult +
            "]", success);
	}

	protected synchronized final void outln(
				String msg,
				int result,
				int expectedResult
			) {

		outln(msg + " [result=" + result + ", expected=" +
			expectedResult + "]", result == expectedResult);
	}

	protected synchronized final void outln(
				String msg,
				int result,
				int expectedResult,
				int tolerance
			) {

		outln(msg + " [result=" + result + ", expected=" +
			expectedResult + ", tolerance=" + tolerance + "]",
			Math.abs(result - expectedResult) <= tolerance);
	}

	protected synchronized final void outln(
				String msg,
				long result,
				long expectedResult
			) {

		outln(msg + " [result=" + result + ", expected=" +
			expectedResult + "]", result == expectedResult);
	}

	protected synchronized final void outln(
				String msg,
				long result,
				long expectedResult,
				long tolerance
			) {

		outln(msg + " [result=" + result + ", expected=" +
			expectedResult + ", tolerance=" + tolerance + "]",
			Math.abs(result - expectedResult) <= tolerance);
	}

	protected synchronized final void outln(
				String msg,
				double result,
				double expectedResult,
				double tolerance
			) {

		outln(msg + " [result=" + result + ", expected=" +
			expectedResult + ", tolerance=" + tolerance + "]",
			Math.abs(result - expectedResult) <= tolerance);
	}

    protected synchronized final void outln(String msg,
                                            Object[] result,
                                            Object[] expectedResult) {

        if ( result == null || expectedResult == null ) {
            outln(msg, (Object) result, (Object) expectedResult);
            return;
        }

        if ( result.length != expectedResult.length ) {
            outln(msg + " [result.length=" + result.length +
                ", expected.length=" + expectedResult.length + "]", false);
            return;
        }

        for ( int i = 0; i < result.length; i++ ) {
            if ( ObjectTools.isDifferent(result[i], expectedResult[i]) ) {
                outln(msg + " [mismatch: result[" + i + "]=" + result[i] +
                    ", expected[" + i + "]=" + expectedResult[i], false);
                return;
            }
        }

        outln(msg + " [all objects match; result.length=" + result.length +
            ", expected.length=" + expectedResult.length + "]", true);

        // Changed to NOT print array contents and to use the more precise
        // pinpointing of where a mismatch occurred - PRH 9/2005
        //boolean success = ObjectTools.isSameArray(result, expectedResult);
        //
        //outln(msg + " " + ObjectTools.printArray(result, "result") +
        //    ", " + ObjectTools.printArray(expectedResult, "expect"), success);
    }

    protected synchronized final void outln(String msg,
                                            byte[] result,
                                            byte[] expectedResult) {

        if ( result == null || expectedResult == null ) {
            outln(msg, (Object) result, (Object) expectedResult);
            return;
        }

        if ( result.length != expectedResult.length ) {
            outln(msg + " [result.length=" + result.length +
                ", expected.length=" + expectedResult.length + "]", false);
            return;
        }

        for ( int i = 0; i < result.length; i++ ) {
            if ( result[i] != expectedResult[i] ) {
                outln(msg + " [byte mismatch: result[" + i + "]=" + result[i] +
                    ", expected[" + i + "]=" + expectedResult[i], false);
                return;
            }
        }

        outln(msg + " [all bytes match; result.length=" + result.length +
            ", expected.length=" + expectedResult.length + "]", true);
    }

    protected synchronized final void outln(String msg,
                                            int[] result,
                                            int[] expectedResult) {

        if ( result == null || expectedResult == null ) {
            outln(msg, (Object) result, (Object) expectedResult);
            return;
        }

        if ( result.length != expectedResult.length ) {
            outln(msg + " [result.length=" + result.length +
                ", expected.length=" + expectedResult.length + "]", false);
            return;
        }

        for ( int i = 0; i < result.length; i++ ) {
            if ( result[i] != expectedResult[i] ) {
                outln(msg + " [int mismatch: result[" + i + "]=" + result[i] +
                    ", expected[" + i + "]=" + expectedResult[i], false);
                return;
            }
        }

        outln(msg + " [all ints match; result.length=" + result.length +
            ", expected.length=" + expectedResult.length + "]", true);
    }

	private static String prefixName(String msg) {
		return Thread.currentThread().getName() + ": " + msg;
	}

	protected synchronized void outName(String msg) {
		out(prefixName(msg));
	}

	protected synchronized void outlnName(String msg) {
		outln(prefixName(msg));
	}

	protected synchronized void outlnName(String msg, boolean success) {
		outln(prefixName(msg), success);
	}

	protected synchronized void printStackTrace(Exception x) {
		outln("", false);
		String[] msg = stackTraceToStrings(x);
		for ( int i = 0; i < msg.length; i++ ) {
			outln("    " + msg[i]);
		}
	}

	public static String[] stackTraceToStrings(Exception x) {
		try {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			x.printStackTrace(pw);
			pw.flush();

			List<String> list = new ArrayList<String>();
			BufferedReader in = new BufferedReader(
					new StringReader(sw.toString()));
			String line = null;
			while ( ( line = in.readLine() ) != null ) {
				list.add(line.trim());
			}

			return (String[]) list.toArray(new String[0]);
		} catch ( IOException iox ) {
			return new String[] { x.toString() };
		}
	}

	// returns true if thread dies, false signals that a timeout occurred
	public boolean joinUp(Thread thread, long msTimeout)
				throws InterruptedException {

		thread.join(msTimeout);

		if ( thread.isAlive() ) {
			outln("thread '" + thread.getName() + "' didn't die within " +
				msTimeout + " ms [joinUp()]", false);

			return false;
		}

		return true;
	}

    /**
     * Starts up a background helper thread and has it call runTests();
     */
    public final void runTestsAsync() {
        Runnable r = new Runnable() {
            public void run() {
                try {
                    runTests();
                } catch ( RuntimeException x ) {
                    printStackTrace(x);
                }
            }
        };

        Thread t = new Thread(r, "RegrMain");
        t.start();
    }

	public final void runTests() {
        testStartTime = System.currentTimeMillis();
		outln("Starting regression for: " + getClass().getName());
		try {
			runBundles();
		} catch ( Exception x ) {
			printStackTrace(x);
		} finally {
			outln("Finished regression for: ");
			outln("    " + getClass().getName());
			outln("Done with " + regressionCount +
                " regression tests, duration: " + getElapsedTime());
			outln("Failure count = " + failCount);
			if ( failCount > 0 ) {
				outln("*** At least one test failed!!! ***");
			}

			try {
                outputBuffer.stopGracefully();
            } catch ( InterruptException x1 ) {
                x1.printStackTrace();
            }
		}
	}

	// Implement in subclasses -- plus a zero-arg constructor
	protected abstract void runBundles() throws Exception;


    protected abstract class BackgroundHelper {
        protected final long initialDelay;
        protected final String name;
        protected Thread internalThread;
        protected volatile boolean noStopRequested;

        protected BackgroundHelper(long initialDelay, String name) {
            this.initialDelay = initialDelay;
            this.name = name;

            noStopRequested = true;
        }

        protected void go() {
            noStopRequested = true;
            Runnable r = new Runnable() {
                public void run() {
                    runWork();
                }
            };

            internalThread = new Thread(r, name);
            internalThread.start();
        }

        private void runWork() {
            try {
                outln(name + " started...");
                if ( initialDelay > 0L ) {
                    outln(name + " pausing " + initialDelay +
                            "ms for 'initial delay'...");
                    Thread.sleep(initialDelay);
                }

                runBody();
            } catch ( InterruptedException x ) {
                if ( noStopRequested == true ) {
                    printStackTrace(x);
                }
            } catch ( Exception x ) {
                // If anything else falls through, this is not permissible,
                // count as failure:
                printStackTrace(x);
            } finally {
                outln(name + " done");
            }
        }

        protected abstract void runBody() throws InterruptedException;

        public void stopRequest() {
            noStopRequested = false;
            internalThread.interrupt();
        }

        public void waitUntilStopped() throws InterruptedException {
            internalThread.join();
        }
    } // class BackgroundHelper

    public class Timer {
        public static final long STANDARD_DEFAULT_TOLERANCE = 100L;

        private long startTime;
        private long defaultTolerance;

        public Timer(long defaultTolerance) {
            this.defaultTolerance = defaultTolerance;
            reset();
        }

        /**
         * Uses {@link #STANDARD_DEFAULT_TOLERANCE}.
         */
        public Timer() {
            this(STANDARD_DEFAULT_TOLERANCE);
        }

        public synchronized void reset() {
            startTime = System.currentTimeMillis();
        }

        public synchronized long getElapsedTime() {
            return System.currentTimeMillis() - startTime;
        }

        public synchronized long getAndResetElapsedTime() {
            long time = getElapsedTime();
            reset();
            return time;
        }

        public synchronized void outln(String msg,
                                       long expectedTime,
                                       long tolerance) {

            AbstractRegression.this.outln(msg,
                getElapsedTime(), expectedTime, tolerance);
        }

        public synchronized void outln(String msg, long expectedTime) {
            AbstractRegression.this.outln(msg,
                getElapsedTime(), expectedTime, defaultTolerance);
        }
    } // class Timer

    private class OutputBuffer implements Runnable {
        private final OutputBufferEntry[] fifo;
        private int head;
        private int tail;
        private int size;

        private Waiter waiter;
        private Waiter.Condition emptyCondition;
        private Waiter.Condition fullCondition;

        private Output rawOutput;
        private volatile boolean noStopRequested;
        private final Thread internalThread;

        public OutputBuffer(Output rawOutput, int fifoCapacity) {
            this.rawOutput = rawOutput;

            head = 0;
            tail = 0;
            size = 0;

            waiter = new Waiter(this);
            emptyCondition = waiter.createCondition(new Waiter.Expression() {
                @Override
                public boolean isTrue() {
                    return isEmpty();
                }
            });

            fullCondition = waiter.createCondition(new Waiter.Expression() {
                @Override
                public boolean isTrue() {
                    return isFull();
                }
            });

            fifo = new OutputBufferEntry[fifoCapacity];
            for ( int i = 0; i < fifo.length; i++ ) {
                fifo[i] = new OutputBufferEntry();
            }

            noStopRequested = true;
            internalThread = new Thread(this, "Regression-OutputBuffer");
            internalThread.start();
        }

        public synchronized void setRawOutput(Output rawOutput) {
            this.rawOutput = rawOutput;
        }

        public synchronized void run() {
            try {
                while ( noStopRequested ) {
                    waitWhileEmpty();

                    String message = fifo[head].message;
                    boolean sendNewLine = fifo[head].sendNewline;

                    // do not stand in the way of garbage collection
                    fifo[head].message = null;

                    head = (head + 1) % fifo.length;
                    size--;
                    notifyAll();

                    if ( sendNewLine ) {
                        rawOutput.outln(message);
                    } else {
                        rawOutput.out(message);
                    }
                }
            } catch ( InterruptException x ) {
                // ignore, and return
            }
        }

        public synchronized void add(String msg, boolean newLine)
                throws InterruptException {

            waitWhileFull();

            fifo[tail].message = msg;
            fifo[tail].sendNewline = newLine;

            tail = (tail + 1) % fifo.length;
            size++;
            notifyAll();
        }

        public synchronized boolean isEmpty() {
            return size == 0;
        }

        public synchronized boolean isNotEmpty() {
            return size > 0;
        }

        public synchronized boolean isFull() {
            return size == fifo.length;
        }

        public synchronized boolean isNotFull() {
            return size < fifo.length;
        }

        public boolean waitUntilEmpty(long msTimeout)
                throws InterruptException {

            return emptyCondition.waitUntilTrue(msTimeout);
        }

        public void waitUntilEmpty() throws InterruptException {
            emptyCondition.waitUntilTrue();
        }

        public void waitWhileEmpty() throws InterruptException {
            emptyCondition.waitWhileTrue();
        }

        public void waitWhileFull() throws InterruptException {
            fullCondition.waitWhileTrue();
        }

        public boolean stopGracefully(long maxTimeToWaitForEmpty,
                                      long maxTimeToWaitForStop)
                throws InterruptException {

            boolean empty = waitUntilEmpty(maxTimeToWaitForEmpty);
            stopRequest();
            boolean stopped = waitUntilStopped(maxTimeToWaitForStop);
            return empty && stopped;
        }

        public boolean stopGracefully(long maxTimeToWaitForEmpty)
                throws InterruptException {

            return stopGracefully(maxTimeToWaitForEmpty, 1000L);
        }

        // Wait up to 20 sec for empty, then up to 5 sec for full stop.
        // Returns false if either times out. If true is returned, then
        // the buffer is empty and the thread is stopped.
        public boolean stopGracefully() throws InterruptException {
            return stopGracefully(20000L, 5000L);
        }

        public void stopRequest() {
            noStopRequested = false;
            internalThread.interrupt();
        }

        public boolean waitUntilStopped(long msTimeout)
                throws InterruptException {

            try {
                internalThread.join(msTimeout);
                return internalThread.isAlive();
            } catch ( InterruptedException x ) {
                throw new InterruptException(x);
            }
        }

        public void waitUntilStopped() throws InterruptedException {
            internalThread.join();
        }
    } // class OutputBuffer

    private static class OutputBufferEntry {
        public String message;
        public boolean sendNewline;
    } // class OutputBufferEntry
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.