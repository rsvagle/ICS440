package com.programix.testing;

public interface Output {
	public void out(String msg);
	public void outln(String msg);
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.