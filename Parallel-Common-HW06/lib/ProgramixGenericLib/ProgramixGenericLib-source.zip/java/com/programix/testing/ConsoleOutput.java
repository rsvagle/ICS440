package com.programix.testing;

public class ConsoleOutput implements Output {
    public void out(String msg) {
        System.out.print(msg);
    }

    public void outln(String msg) {
        System.out.println(msg);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.