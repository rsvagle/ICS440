package com.programix.sql;

import java.sql.*;

import com.programix.value.*;

/**
 * Sets up a simple, thread-safe, unique id generator that uses a database
 * table to control concurrency.
 * <p> 
 * The {@link ValueMap} passed can be created from a file that looks 
 * something like this:
 * <pre class="preshade">
 * sql.id.generator.table.name=id_list
 * sql.id.generator.match.column.name=name
 * sql.id.generator.id.column.name=last_id
 * </pre>

 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class UniqueIDGenerator extends Object {
    public static final String TABLE_NAME_KEY = 
        "sql.id.generator.table.name";
    public static final String MATCH_COLUMN_KEY = 
        "sql.id.generator.match.column.name";
    public static final String ID_COLUMN_KEY = 
        "sql.id.generator.id.column.name";

	private final ConnectionSource connectionSource;
    private final String updateSql;
    private final String selectSql;

	public UniqueIDGenerator(ConnectionSource connectionSource,
                             String tableName,
                             String matchColumnName,
                             String idColumnName) {
        
		this.connectionSource = connectionSource;
    
        this.updateSql = 
            " UPDATE " + tableName +
            "    SET " + idColumnName + " = " + idColumnName + " + 1 " +
            "  WHERE " + matchColumnName + " = ? ";
        
        this.selectSql =
            " SELECT " + idColumnName + 
            "   FROM " + tableName +
            "  WHERE " + matchColumnName + " = ? ";
	}

	public UniqueIDGenerator(ConnectionSource connectionSource,
                             ValueMap config) throws ValueMapException {

        this(connectionSource,
             config.getString(TABLE_NAME_KEY),
             config.getString(MATCH_COLUMN_KEY),
             config.getString(ID_COLUMN_KEY));
    }
    
	public int generateUniqueID(String tableName) throws SQLException {
		Connection con = connectionSource.getConnection();
		boolean needsRollback = true;

		try {
			con.setAutoCommit(false);

			int nextId = generate(tableName, con);

			con.commit();
			needsRollback = false;

			return nextId;
		} finally {
			if ( needsRollback ) { 
				try { 
					con.rollback(); 
				} catch (Exception x) {
					// ignore
				} 
			}

			try { 
				con.setAutoCommit(true);
			} catch (Exception x) {
                // ignore
			} finally {
			    con.close();
            }
		}
	}

	// Called with a connection which is already in a transaction
	public int generateUniqueID(
				String tableName, 
				Connection con
			) throws SQLException {

		if ( con.getAutoCommit() ) {
			throw new SQLException("connection must be in a transaction");
		}

        return generate(tableName, con);
    }
    
    private int generate(String tableName, Connection con) throws SQLException {
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			// UPDATE requires exclusive access lock on the row to be
			// updated and keeps this exclusive lock until the end of
			// the transaction--giving a chance for the SELECT to be done.
            stmt = con.prepareStatement(updateSql);
            stmt.setString(1, tableName);
            stmt.executeUpdate();
            stmt.close();
            
            stmt = con.prepareStatement(selectSql);
            stmt.setString(1, tableName);
            rs = stmt.executeQuery();
            
			if ( rs.next() == false ) {
				throw new SQLException("Unsupported tablename: " + tableName);
			}

			return rs.getInt(1); 
		} finally {
            JDBCTools.closeQuietly(stmt, rs);
		}
	}
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.