package com.programix.sql;

import java.sql.*;
import java.util.*;

import com.programix.value.*;

/**
 * Sets up a simple, thread-safe, bottomless database connection pool.
 * When the pool is empty, {@link #checkOut()} always attempts to create
 * an additional connection. The "max idle count" value is used to indicate
 * the maximum number of idle connections kept in the pool; as checkins occur
 * beyond this level, those connections are automatically closed.
 * <p>
 * The {@link ValueMap} passed can be created from a file that looks
 * something like this:
 * <pre class="preshade">
 * sql.connection.pool.driver=org.hsqldb.jdbcDriver
 * sql.connection.pool.url=jdbc:hsqldb:hsql://localhost:3500
 * sql.connection.pool.username=appuser
 * sql.connection.pool.password=secret
 * sql.connection.pool.max.idle.count=5
 * </pre>
 * Where the "max idle count" is optional.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class BottomlessConnectionPool extends Object {
    public static final String DRIVER_KEY = "sql.connection.pool.driver";
    public static final String URL_KEY = "sql.connection.pool.url";
    public static final String USERNAME_KEY = "sql.connection.pool.username";
    public static final String PASSWORD_KEY = "sql.connection.pool.password";
    public static final String MAX_IDLE_COUNT_KEY =
        "sql.connection.pool.max.idle.count";
    public static final int DEFAULT_MAX_IDLE_COUNT = 3;

	private List<Connection> pool;
	private int idleLimit;
	private String url;
	private String user;
	private	String pass;

	public BottomlessConnectionPool(ValueMap config) throws SQLException {
		try {
            loadDriver(config.getString(DRIVER_KEY));

            url = config.getString(URL_KEY);
            user = config.getString(USERNAME_KEY);
            pass = config.getString(PASSWORD_KEY);
            idleLimit =
                config.getInt(MAX_IDLE_COUNT_KEY, DEFAULT_MAX_IDLE_COUNT);
        } catch ( ValueMapRequiredKeyException x ) {
            SQLException sqlX = new SQLException(x.getMessage());
            sqlX.initCause(x);
            throw sqlX;
        }

		pool = Collections.synchronizedList(new LinkedList<Connection>());
		for ( int i = 0; i < idleLimit; i++ ) {
			pool.add(createConnection());
		}
	}

    /**
     * Converts the <code>Map</code> to a {@link ValueMap} and calls the
     * main constructor. Equivalent to:
     * <pre class="preshade">
     * this(ValueMap.{@link ValueMap#createFrom(Map)}createFrom(config));
     * </pre>
     */
    public BottomlessConnectionPool(Map<?, ?> config) throws SQLException {
        this(ValueMap.createFrom(config));
    }

	private void loadDriver(String className) throws SQLException {
		try {
			Class.forName(className);
		} catch ( ClassNotFoundException x ) {
			throw new SQLException("Could not load class: " + className);
		}
	}

	private Connection createConnection() throws SQLException {
		return DriverManager.getConnection(url, user, pass);
	}

	public Connection checkOut() throws SQLException {
		synchronized ( pool ) {
			if ( pool.size() < 1 ) {
				// empty pool right now, create a new one
				return createConnection();
			}

			return (Connection) pool.remove(0);
		}
	}

	/**
     * Returns the specified connection to the pool. If <code>con</code> is
     * <code>null</code>, the check-in request is silently ignored.
	 */
    public void checkIn(Connection con) {
		if ( con == null ) {
			// be friendly and ignore these erroneous attempts--this
			// simplifies code on the outside.
			return;
		}

		synchronized ( pool ) {
			if ( pool.size() >= idleLimit ) {
				// full right now, discard this connection
                JDBCTools.closeQuietly(con);
			} else {
				pool.add(con);
			}
		}
	}

	public void close() {
	    Connection[] con = null;

		synchronized ( pool ) {
			idleLimit = 0; // in case any stragglers are checked in

            con = (Connection[]) pool.toArray(new Connection[0]);
			pool.clear();
		}

		if ( con != null ) {
            for ( int i = 0; i < con.length; i++ ) {
                JDBCTools.closeQuietly(con[i]);
            }
        }
	}
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.