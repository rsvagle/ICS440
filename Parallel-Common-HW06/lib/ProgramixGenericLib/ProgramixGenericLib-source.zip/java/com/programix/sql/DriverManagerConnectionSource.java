package com.programix.sql;

import java.sql.*;
import java.util.*;

import com.programix.value.*;

/**
 * An implementation of {@link ConnectionSource} that uses
 * {@link DriverManager} to create database {@link Connection}'s.
 * <p>
 * Configuration settings are specified by a {@link ValueMap} with 
 * settings such as:
 * <pre class="preshade"> 
 * sql.connection.driver=org.postgresql.Driver
 * sql.connection.url=jdbc:postgresql://localhost:5432/andrewdb
 * sql.connection.username=someone
 * sql.connection.password=something
 * sql.connection.extras.ssl=true
 * sql.connection.extras.loginTimeout=90
 * </pre> 
 * <p>
 * The required and additional settings are retrieved by code equivalent 
 * to this:
 * <pre class="preshade" >
 * ValueMap config = // the configuration settings initially passed in
 * 
 * Class.forName(config.{@link ValueMap#getString(String)
 * getString}({@link #DRIVER_KEY DRIVER_KEY}));
 * 
 * String url = config.{@link ValueMap#getString(String)
 * getString}({@link #URL_KEY URL_KEY});
 *  
 * ValueMap conInfo = config.{@link ValueMap#getNestedValueMap(String)
 * getNestedValueMap}({@link #EXTRAS_PREFIX EXTRAS_PREFIX});
 * 
 * if ( config.containsKey({@link #USERNAME_KEY USERNAME_KEY}) ) {
 *     conInfo.put("user", config.getString(USERNAME_KEY); 
 * }
 * 
 * if ( config.containsKey({@link #PASSWORD_KEY PASSWORD_KEY}) ) {
 *     conInfo.put("password", config.getString(PASSWORD_KEY); 
 * }
 * 
 * Connection con = DriverManager.{@link DriverManager#getConnection(
 * String, Properties) getConnection}(url, conInfo.{@link 
 * ValueMap#getProperties() getProperties}());
 * </pre> 
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DriverManagerConnectionSource implements ConnectionSource {
    
    /**
     * Required configuration key for the JDBC driver's classname.
     * The value of this constant is always:
     * <pre class="preshade" >
     * sql.connection.driver
     * </pre>
     */
    public static final String DRIVER_KEY = "sql.connection.driver";
    
    /**
     * Required configuration key for the URL to use to connect to
     * the database.
     * The value of this constant is always:
     * <pre class="preshade" >
     * sql.connection.url
     * </pre>
     */
    public static final String URL_KEY = "sql.connection.url";
    
    /**
     * Optional configuration key for the username to use to connect to
     * the database. 
     * Although this key is optional, most connections require it.
     * The value of this constant is always:
     * <pre class="preshade" >
     * sql.connection.username
     * </pre>
     */
    public static final String USERNAME_KEY = "sql.connection.username";
    
    /**
     * Optional configuration key for the password to use to connect to
     * the database.
     * Although this key is optional, most connections require it.
     * The value of this constant is always:
     * <pre class="preshade" >
     * sql.connection.password
     * </pre>
     */
    public static final String PASSWORD_KEY = "sql.connection.password";
    
    /**
     * Optional configuration key <i>prefix</i> for additional 
     * settings to use to connect to the database. These settings
     * are retrieved as a nested map using code like this: 
     * <pre class="preshade" >
     * ValueMap conInfo = config.{@link ValueMap#getNestedValueMap(String)
     * getNestedValueMap}(EXTRAS_PREFIX);
     * </pre> 
     * The value of this constant is always (note the trailing period):
     * <pre class="preshade" >
     * sql.connection.extras.
     * </pre>
     */
    public static final String EXTRAS_PREFIX = "sql.connection.extras.";
    
    private String conUrl;
    private Properties conProperties;

    public DriverManagerConnectionSource(ValueMap config) 
            throws SQLException {

        String driverClassname = null;
        
        try {
            driverClassname = config.getString(DRIVER_KEY);
            Class.forName(driverClassname);
            
            conUrl = config.getString(URL_KEY);
            ValueMap conMap = config.getNestedValueMap(EXTRAS_PREFIX);
            
            if ( config.containsKey(USERNAME_KEY) ) {
                conMap.put("user", config.getString(USERNAME_KEY));
            }
            
            if ( config.containsKey(PASSWORD_KEY) ) {
                conMap.put("password", config.getString(PASSWORD_KEY));
            }
            
            conProperties = conMap.getProperties();
        } catch ( ValueMapException x ) {
            throw new SQLChainedException(x.getMessage(), x);
        } catch ( ClassNotFoundException x ) {
            throw new SQLChainedException(
                "Could not find driver class '" + driverClassname + "'", x);
        }
    }
    
    public Connection getConnection(long msTimeout)
            throws SQLTimedOutException, SQLInterruptedException,
                   SQLShutdownException, SQLException {
        
        return DriverManager.getConnection(conUrl, conProperties);
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(conUrl, conProperties);
    }

    public void shutdown() {
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.