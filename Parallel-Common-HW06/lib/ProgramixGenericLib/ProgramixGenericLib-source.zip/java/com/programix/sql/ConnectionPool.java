package com.programix.sql;

import java.sql.*;
import java.util.*;

import com.programix.thread.*;
import com.programix.value.*;

/**
 * This implementation of {@link ConnectionSource} is a variable size
 * <i>pool</i> of database {@link java.sql.Connection}'s.
 * <p>
 * This pool is not "bottomless"
 * as the {@link #MAX_CONNECTION_COUNT_KEY} is specified (when the max number of
 * connections have be created, calls to {@link #getConnection()} block
 * waiting for an idle connection to be checked back into the pool.
 * <p>
 * This pool also has a {@link #HIGH_WATER_COUNT_KEY} which specifies the
 * preferred maximum number of <i>idle</i> connections the pool should
 * hold. When there are more than this many idle connections for a period
 * of time specified by {@link #SHRINK_DELAY_SECONDS_KEY}, a connection
 * is permanently removed from the pool and closed/destroyed.
 * <p>
 * A typical way to configure this pool is with a {@link ValueMap} with
 * settings such as:
 * <pre class="preshade">
 * # Settings specifically for the ConnectionPool:
 * sql.connection.pool.max.connection.count=50
 * sql.connection.pool.high.water.count=5
 * sql.connection.pool.shrink.delay.seconds=5
 * sql.connection.pool.health.check.query=SELECT max(1)
 *
 * # Settings for the DriverManagerConnectionSource used as the
 * # underlying ConnectionSource for this ConnectionPool:
 * sql.connection.driver=org.postgresql.Driver
 * sql.connection.url=jdbc:postgresql://localhost:5432/andrewdb
 * sql.connection.username=someone
 * sql.connection.password=something
 * sql.connection.extras.ssl=true
 * sql.connection.extras.loginTimeout=90
 * </pre>
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ConnectionPool implements ConnectionSource {

    /**
     * Optional configuration key specifying the maximum number of
     * connections that can exist in the pool&mdash;both idle and
     * those currently being used. Calls to get a connection from the
     * pool will block when there are no idle connections in the pool and
     * this max has been reached.
     * The value of this constant is always:
     * <pre class="preshade" >
     * sql.connection.pool.max.connection.count
     * </pre>
     */
    public static final String MAX_CONNECTION_COUNT_KEY =
        "sql.connection.pool.max.connection.count";

    /**
     * Optional configuration key specifying the "high water mark"
     * which indicates the number of idle connections over which the
     * pool will slowly drain. As long as the number of idle connections
     * remains greater than this high water mark, the pool will close
     * an idle connection every "shink delay seconds" (another configuration
     * parameter).
     * The value of this constant is always:
     * <pre class="preshade" >
     * sql.connection.pool.high.water.count
     * </pre>
     */
    public static final String HIGH_WATER_COUNT_KEY =
        "sql.connection.pool.high.water.count";

    /**
     * Optional configuration key specifying the number of seconds
     * to pause between the closing of idle connections when the pool
     * idle level is above the high water mark.
     * The value of this constant is always:
     * <pre class="preshade" >
     * sql.connection.pool.shrink.delay.seconds
     * </pre>
     */
    public static final String SHRINK_DELAY_SECONDS_KEY =
        "sql.connection.pool.shrink.delay.seconds";

    /**
     * Optional configuration key specifying the query statement to
     * use to confirm the health of a connection. This should be a
     * SELECT statement that is very fast to execute.
     * The value of this constant is always:
     * <pre class="preshade" >
     * sql.connection.pool.health.check.query
     * </pre>
     */
    public static final String HEALTH_CHECK_QUERY_KEY =
        "sql.connection.pool.health.check.query";

    /**
     * Default value used when the optional max connection count
     * parameter is not specified.
     * The value of this constant is <tt>50</tt> connections.
     */
    public static final int DEFAULT_MAX_CONNECTION_COUNT = 50;

    /**
     * Default value used when the optional high water count
     * parameter is not specified.
     * The value of this constant is <tt>5</tt> connections.
     */
    public static final int DEFAULT_HIGH_WATER_COUNT = 5;

    /**
     * Default value used when the optional shrink delay seconds
     * parameter is not specified.
     * The value of this constant is <tt>5</tt> seconds.
     */
    public static final int DEFAULT_SHRINK_DELAY_SECONDS = 5;

    /**
     * Default value used when the optional health check query
     * parameter is not specified.
     * The value of this constant is:
     * <pre class="preshade">
     * SELECT max(1)
     * </pre>
     */
    public static final String DEFAULT_HEALTH_CHECK_QUERY = "SELECT max(1)";

    private final ConnectionSource underlyingSource;
    private final String healthCheckQuery;
    private final int maxConnectionCount;
    private final int highWaterCount;
    private final int shrinkDelaySeconds;
    private final ExceptionHandler exceptionHandler;
    private final Object lockObject;

    private final Waiter masterWaiter;
    private final Counter totalConnectionCounter;

    private final ConnectionNodeList idleList;
    private final ConnectionNodeList inUseList;
    private final ConnectionNodeList healthCheckList;

    private final Filler filler;
    private final Drainer drainer;
    private final HealthChecker healthChecker;

    public ConnectionPool(ConnectionSource underlyingSource,
                          int maxConnectionCount,
                          int highWaterCount,
                          int shrinkDelaySeconds,
                          String healthCheckQuery,
                          ExceptionHandler exceptionHandler,
                          Object lockObject) {

        this.underlyingSource = underlyingSource;

        this.maxConnectionCount = Math.max(1, maxConnectionCount);
        this.highWaterCount =
            Math.max(1, Math.min(highWaterCount, maxConnectionCount));
        this.shrinkDelaySeconds = Math.max(1, shrinkDelaySeconds);

        this.healthCheckQuery = (healthCheckQuery == null)
            ? DEFAULT_HEALTH_CHECK_QUERY : healthCheckQuery;

        this.exceptionHandler = (exceptionHandler == null)
            ? new ConsoleExceptionHandler() : exceptionHandler;
        this.lockObject = (lockObject == null) ? this : lockObject;

        this.masterWaiter = new Waiter(this.lockObject);

        totalConnectionCounter = new Counter(0, masterWaiter);

        idleList = new ConnectionNodeList(masterWaiter);
        inUseList = new ConnectionNodeList();
        healthCheckList = new ConnectionNodeList();

        filler = new Filler();
        drainer = new Drainer();
        healthChecker = new HealthChecker();

        /*
        new Thread(new Runnable() {
            public void run() {
                while ( masterWaiter.isShutdown() == false ) {
                    try {
                        int idleCount = idleList.getSize();
                        int inUseCount = inUseList.getSize();
                        int healthCheckCount = healthCheckList.getSize();
                        int calcTotal =
                            idleCount + inUseCount + healthCheckCount;
                        System.out.println("ConTester: idle=" + idleCount +
                            ", inUse=" + inUseCount + ", hcCount=" +
                            healthCheckCount + ", calcTotal=" + calcTotal +
                            ", total=" + totalConnectionCounter.getCount());

                        ThreadTools.nap(1000);
                    } catch ( Exception x ) {
                        System.err.println("ConTester: " + x);
                    }
                }
            }
        }, "ConPoolTester").start();
        */
    }

    public ConnectionPool(ConnectionSource underlyingSource,
                          int maxConnectionCount,
                          int highWaterCount,
                          int shrinkDelaySeconds,
                          String healthCheckQuery,
                          ExceptionHandler exceptionHandler) {

        this(underlyingSource, maxConnectionCount, highWaterCount,
             shrinkDelaySeconds, healthCheckQuery, exceptionHandler, null);
    }

    public ConnectionPool(ConnectionSource underlyingSource,
                          int maxConnectionCount,
                          int highWaterCount,
                          int shrinkDelaySeconds,
                          String healthCheckQuery) {

        this(underlyingSource, maxConnectionCount, highWaterCount,
             shrinkDelaySeconds, healthCheckQuery, null, null);
    }

    public ConnectionPool(ConnectionSource underlyingSource,
                          int maxConnectionCount,
                          int highWaterCount,
                          int shrinkDelaySeconds) {

        this(underlyingSource, maxConnectionCount, highWaterCount,
             shrinkDelaySeconds, DEFAULT_HEALTH_CHECK_QUERY, null, null);
    }

    public ConnectionPool(ConnectionSource underlyingSource) {
        this(underlyingSource, DEFAULT_MAX_CONNECTION_COUNT,
             DEFAULT_HIGH_WATER_COUNT, DEFAULT_SHRINK_DELAY_SECONDS,
             DEFAULT_HEALTH_CHECK_QUERY, null, null);
    }

    public ConnectionPool(ConnectionSource underlyingSource,
                          ValueMap config,
                          ExceptionHandler exceptionHandler) {

        this(underlyingSource,
            config.getInt(MAX_CONNECTION_COUNT_KEY,
                          DEFAULT_MAX_CONNECTION_COUNT),
            config.getInt(HIGH_WATER_COUNT_KEY, DEFAULT_HIGH_WATER_COUNT),
            config.getInt(SHRINK_DELAY_SECONDS_KEY,
                          DEFAULT_SHRINK_DELAY_SECONDS),
            config.getString(HEALTH_CHECK_QUERY_KEY,
                             DEFAULT_HEALTH_CHECK_QUERY),
            exceptionHandler,
            null);
    }

    public ConnectionPool(ConnectionSource underlyingSource, ValueMap config) {
        this(underlyingSource, config, null);
    }

    public ConnectionPool(ValueMap config, ExceptionHandler exceptionHandler)
            throws SQLException {

        this(createConnectionSource(config), config, exceptionHandler);
    }

    public ConnectionPool(ValueMap config) throws SQLException {
        this(createConnectionSource(config), config, null);
    }

    /**
     * This method is used to create a {@link ConnectionSource} by
     * analyzing the <tt>config</tt> {@link ValueMap} to determine
     * which kind of <tt>ConnectionSource</tt> should be created.
     * <p>
     * If {@link DriverManagerConnectionSource#DRIVER_KEY} is
     * present, then a {@link DriverManagerConnectionSource} is created.
     */
    public static ConnectionSource createConnectionSource(ValueMap config)
            throws SQLException {

        if ( config.containsKey(DriverManagerConnectionSource.DRIVER_KEY) ) {
            return new DriverManagerConnectionSource(config);
        } else {
            throw new SQLException("Unsupported ConnectionSource creation " +
                "with the specified config.");
        }
    }

    public Connection getConnection(long msTimeout)
            throws SQLTimedOutException, SQLInterruptedException,
                   SQLShutdownException, SQLException {

        ConnectionNode node = null;
        try {
            node = idleList.removeFirst(msTimeout);
            inUseList.append(node);
            return new PooledConnection(node);
        } catch ( TimedOutException x ) {
            throw new SQLTimedOutException(x);
        } catch ( ShutdownException x ) {
            // Destroy in case we got one that didn't get into inUseList
            destroyNodeAndConnection(node);
            throw new SQLShutdownException(x);
        } catch ( InterruptException x ) {
            throw new SQLInterruptedException(x);
        }
    }

    public Connection getConnection() throws SQLInterruptedException,
            SQLShutdownException, SQLException {

        return getConnection(ThreadTools.NO_TIMEOUT);
    }

//    public void healthCheckPool() {
//        synchronized ( lockObject ) {
//            if ( inUseList.getSize() > 0 ) {
//                ConnectionNode node = inUseList.head;
//                while ( node != null ) {
////                    node.needsHealthCheck = true;
//                    node = node.next;
//                }
//            }
//
//            if ( idleList.getSize() > 0 ) {
//                ConnectionNode node = idleList.head;
//                while ( node != null ) {
////                    node.needsHealthCheck = true;
//                    node = node.next;
//                }
//            }
//        }
//    }

    private void healthCheck(Connection con) throws SQLException {
        Statement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery(healthCheckQuery);
        } finally {
            JDBCTools.closeQuietly(stmt, rs);
        }
    }

    private boolean isHealthy(Connection con) {
        try {
            healthCheck(con);
            return true;
        } catch ( SQLException x ) {
            exceptionHandler.handle(x);
            return false;
        }
    }

    private void checkIn(ConnectionNode node, boolean requestHealthCheck) {
        if ( node == null ) {
            return;
        }

        try {
            inUseList.remove(node);

            if ( requestHealthCheck ) {
                node.healthCheckRequestTimestamp = System.currentTimeMillis();
                healthCheckList.append(node);
            } else {
                idleList.append(node);
            }
        } catch ( IllegalStateException x ) {
            destroyNodeAndConnection(node);
            exceptionHandler.handle(x);
        } catch ( ShutdownException x ) {
            // this is being checked in late, destroy
            destroyNodeAndConnection(node);
        }
    }

    private void destroyNodeAndConnection(ConnectionNode node) {
        if ( node != null ) {
            node.clearLinks();
            JDBCTools.closeQuietly(node.con);
            totalConnectionCounter.decrementIfNotShutdown();
        }
    }

    private void destroyOneIdleConnection() {
        try {
            destroyNodeAndConnection(idleList.removeFirst(5000L));
        } catch ( TimedOutException x ) {
            // Ignore, should only be extremely rare, and the caller
            // will try again if appropriate.
        } catch ( ShutdownException x ) {
            // ignore, must be all done now.
        } catch ( InterruptException x ) {
            // ignore
        } catch ( Exception x ) {
            // surprise--never expect to get here, so log it
            exceptionHandler.handle(x);
        }
    }

    private void createOneIdleConnection(long msTimeout) throws SQLException {
        try {
            Connection con = underlyingSource.getConnection(msTimeout);
            healthCheck(con);
            ConnectionNode node = new ConnectionNode(con);

            synchronized ( totalConnectionCounter.getLockObject() ) {
                totalConnectionCounter.increment();
                idleList.append(node);
            }
        } catch ( SQLException x ) {
            throw x;
        } catch ( Exception x ) {
            throw new SQLChainedException(x);
        }
    }

    public void shutdown() {
        filler.stopRequest();
        healthChecker.stopRequest();
        drainer.stopRequest();

        new Thread(new Runnable() {
            public void run() {
                shutdownBackgroundHelper();
            }
        }, "ConnectionPool.ShutdownHelper").start();
    }

    private void shutdownBackgroundHelper() {
        try {
            // give them up to 2 seconds to be done, then plow ahead anyway
            filler.waitUntilStopped(2000L);
            drainer.waitUntilStopped(2000L);
            healthChecker.waitUntilStopped(2000L);

            List<ConnectionNode> destroyList = new ArrayList<ConnectionNode>();
            emptyConListHelper(idleList, destroyList);
            emptyConListHelper(healthCheckList, destroyList);
            emptyConListHelper(inUseList, destroyList);

            healthCheckList.shutdown();
            inUseList.shutdown();
            idleList.shutdown();

            for ( ConnectionNode node : destroyList ) {
                destroyNodeAndConnection(node);
            }
        } catch ( Exception x ) {
            // ignore
        } finally {
            masterWaiter.shutdown();
        }
    }

    private void emptyConListHelper(ConnectionNodeList cnl,
                                    List<ConnectionNode> dst) {
        synchronized ( cnl.lockObject ) {
            if ( cnl.waiter.isShutdown() == false ) {
                ConnectionNode[] node = healthCheckList.removeAll();
                for ( int i = 0; i < node.length; i++ ) {
                    dst.add(node[i]);
                }
            }
        }
    }

    private abstract class Worker {
        protected Thread internalThread;
        protected volatile boolean keepGoing;

        public Worker() {
            keepGoing = true;
        }

        protected void start() {
            internalThread = new Thread(new Runnable() {
                public void run() {
                    try {
                        runWork();
                    } catch ( InterruptException x ) {
                        // ignore
                    } catch ( ShutdownException x ) {
                        // ignore
                    }
                }
            }, getClass().getName());

            internalThread.start();
        }

        protected abstract void runWork()
            throws InterruptException, ShutdownException;

        public void stopRequest() {
            keepGoing = false;
            internalThread.interrupt();
        }

        public void waitUntilStopped(long msTimeout)
                throws TimedOutException, InterruptException {

            try {
                internalThread.join(msTimeout);

                if ( internalThread.isAlive() ) {
                    throw new TimedOutException(msTimeout);
                }
            } catch ( InterruptedException x ) {
                throw new InterruptException(x);
            }
        }
    }

    private class Filler extends Worker {
        private final Waiter.Condition shouldFillCondition;

        public Filler() {
            shouldFillCondition =
                idleList.waiter.createCondition(new Waiter.Expression() {
                    @Override
                    public boolean isTrue() {
                        int idleCount = idleList.getSize();
                        int totalCount = totalConnectionCounter.getCount();

                        if ( totalCount >= maxConnectionCount ) {
                            return false;
                        } else if ( totalCount < highWaterCount ) {
                            return true;
                        } else if ( idleCount < 1 ) {
                            return true;
                        } else {
                            return false;
                        }
                    }
                });

            start();
        }

        @Override
        protected void runWork() throws InterruptException, ShutdownException {
            long delayBetweenFailedAttempts = 1000L;

            while ( keepGoing ) {
                shouldFillCondition.waitUntilTrue();

                try {
                    createOneIdleConnection(120000L);
                    delayBetweenFailedAttempts = 1000L; // got one, so reset
                } catch ( Exception x ) {
                    exceptionHandler.handle(x);
                    ThreadTools.nap(delayBetweenFailedAttempts);
                    delayBetweenFailedAttempts =
                        Math.min(32000L, delayBetweenFailedAttempts * 2L);
                }
            }
        }
    } // class Filler

    private class Drainer extends Worker {
        private final Waiter.Condition overHighWater;
        private final long shrinkDelayMilliseconds;

        public Drainer() {
            shrinkDelayMilliseconds =
                Math.max(1000L, shrinkDelaySeconds * 1000L);

            overHighWater = idleList.waiter.createCondition(
                new Waiter.Expression() {

                @Override
                public boolean isTrue() {
                    return idleList.getSize() > highWaterCount;
                }
            });

            start();
        }

        @Override
        protected void runWork() throws InterruptException, ShutdownException {
            while ( keepGoing ) {
                overHighWater.waitUntilTrue();

                // Wait a bit to be sure that we don't immediately
                // fall below the high water mark again.
                overHighWater.waitWhileTrue(shrinkDelayMilliseconds);

                if ( overHighWater.isTrue() ) {
                    destroyOneIdleConnection();
                }
            }
        }
    } // class Drainer

    private class HealthChecker extends Worker {
        public HealthChecker() {
            start();
        }

        @Override
        protected void runWork() throws InterruptException, ShutdownException {
            while ( keepGoing ) {
                ConnectionNode node =
                    healthCheckList.removeFirst(ThreadTools.NO_TIMEOUT);

                if ( isHealthy(node.con) ) {
                    //node.needsHealthCheck = false;
                    idleList.append(node);
                } else {
                    destroyNodeAndConnection(node);
                }
            }
        }
    } // class HealthChecker

    private static class ConnectionNodeList {
        private final Object lockObject;

        private ConnectionNode head;
        private ConnectionNode tail;

        private int size;
        private final Waiter waiter;
        private Waiter.Condition emptyCondition;

        private ConnectionNodeList(Waiter proposedWaiter,
                                   Object proposedLockObject) {

            if ( proposedWaiter != null ) {
                waiter = proposedWaiter;
                lockObject = proposedWaiter.getLockObject();
            } else {
                lockObject =
                    (proposedLockObject == null) ? this : proposedLockObject;
                waiter = new Waiter(lockObject);
            }

            emptyCondition = waiter.createCondition(new Waiter.Expression() {
                @Override
                public boolean isTrue() {
                    return isEmpty();
                }
            });
        }

        public ConnectionNodeList(Waiter waiter) {
            this(waiter, null);
        }

        public ConnectionNodeList(Object lockObject) {
            this(null, lockObject);
        }

        public ConnectionNodeList() {
            this(null);
        }

        public boolean isEmpty() {
            synchronized ( lockObject ) {
                return size == 0;
            }
        }

        public boolean isNotEmpty() {
            return !isEmpty();
        }

        public int getSize() {
            synchronized ( lockObject ) {
                return size;
            }
        }

        public void append(ConnectionNode node) throws ShutdownException {
            synchronized ( lockObject ) {
                waiter.shutdownCheck();

                node.clearLinks();
                node.owner = this;

                if ( isEmpty() ) {
                    head = node;
                    tail = node;
                } else {
                    tail.next = node;
                    node.prev = tail;
                    tail = node;
                }

                size++;
                waiter.signalChange();
            }
        }

        public ConnectionNode removeFirst(long msTimeout)
            throws InterruptException, TimedOutException, ShutdownException {

            synchronized ( lockObject ) {
                waiter.shutdownCheck();

                waitWhileEmpty(msTimeout);

                ConnectionNode node = head;

                if ( size == 1 ) {
                    // removing the only one left
                    head = null;
                    tail = null;
                } else {
                    // there will be a least one left after this removal
                    head = head.next;
                    head.prev = null;
                }
                node.clearLinks();

                size--;
                waiter.signalChange();

                return node;
            }
        }

        public void remove(ConnectionNode node)
                throws IllegalStateException, ShutdownException {

            synchronized ( lockObject ) {
                waiter.shutdownCheck();

                if ( node.owner != this ) {
                    throw new IllegalStateException("Attempting to remove a " +
                        "specific a ConnectionNode from a " +
                        "ConnectionNodeList, but the node " +
                        "does not belong to the list.");
                }

                if ( size == 1 ) {
                    // removing the only one left
                    head = null;
                    tail = null;
                } else if ( node == head ) {
                    head = node.next;
                    head.prev = null;
                } else if ( node == tail ) {
                    tail = node.prev;
                    tail.next = null;
                } else {
                    node.next.prev = node.prev;
                    node.prev.next = node.next;
                }
                node.clearLinks();

                size--;
                waiter.signalChange();
            }
        }

        public ConnectionNode[] removeAll() throws ShutdownException {
            synchronized ( lockObject ) {
                waiter.shutdownCheck();

                ConnectionNode[] node = new ConnectionNode[size];
                for ( int i = 0; i < node.length; i++ ) {
                    node[i] = head;
                    head = head.next;
                    node[i].clearLinks();
                }

                head = null;
                tail = null;
                size = 0;
                waiter.signalChange();

                return node;
            }
        }

        public void waitWhileEmpty(long msTimeout)
            throws InterruptException, TimedOutException, ShutdownException {

            emptyCondition.waitWhileTrueWithTimedOutException(msTimeout);
        }

        public void waitUntilEmpty(long msTimeout)
            throws InterruptException, TimedOutException, ShutdownException {

            emptyCondition.waitUntilTrueWithTimedOutException(msTimeout);
        }

        public void shutdown() {
            waiter.shutdown();
        }
    } // class ConnectionNodeList

    private class ConnectionNode {
        public final Connection con;

        public volatile ConnectionNode next;
        public volatile ConnectionNode prev;
        public volatile ConnectionNodeList owner;

        public volatile long healthCheckRequestTimestamp;

        public ConnectionNode(Connection con) {
            this.con = con;
        }

        public void clearLinks() {
            next = null;
            prev = null;
            owner = null;
        }
    } // class ConnectionNode

    // TODO - deal with the methods available on different versions... ugh!
    public class PooledConnection implements Connection {
        private volatile ConnectionNode node;
        private volatile Connection con;

        private PooledConnection(ConnectionNode cn) {
            init(cn);
        }

        private synchronized void init(ConnectionNode cn) {
            this.node = cn;
            this.con = node.con;
        }

        public synchronized void closeAndHealthCheck() {
            try {
                checkIn(node, true);
            } finally {
                node = null;
                con = null;
            }
        }

        public synchronized void close() {
            try {
                checkIn(node, false);
            } finally {
                node = null;
                con = null;
            }
        }

        public void clearWarnings() throws SQLException {
            con.clearWarnings();
        }

        public void commit() throws SQLException {
            con.commit();
        }

        public Statement createStatement() throws SQLException {
            return con.createStatement();
        }

        public Statement createStatement(int resultSetType,
                                         int resultSetConcurrency,
                                         int resultSetHoldability)
                throws SQLException {

            return con.createStatement(resultSetType, resultSetConcurrency,
                resultSetHoldability);
        }

        public Statement createStatement(int resultSetType,
                                         int resultSetConcurrency)
                throws SQLException {
            return con.createStatement(resultSetType, resultSetConcurrency);
        }

        public boolean getAutoCommit() throws SQLException {
            return con.getAutoCommit();
        }

        public String getCatalog() throws SQLException {
            return con.getCatalog();
        }

        public int getHoldability() throws SQLException {
            return con.getHoldability();
        }

        public DatabaseMetaData getMetaData() throws SQLException {
            return con.getMetaData();
        }

        public int getTransactionIsolation() throws SQLException {
            return con.getTransactionIsolation();
        }

        public Map<String,Class<?>> getTypeMap() throws SQLException {
            return con.getTypeMap();
        }

        public SQLWarning getWarnings() throws SQLException {
            return con.getWarnings();
        }

        public boolean isClosed() throws SQLException {
            return con.isClosed();
        }

        public boolean isReadOnly() throws SQLException {
            return con.isReadOnly();
        }

        public String nativeSQL(String sql) throws SQLException {
            return con.nativeSQL(sql);
        }

        public CallableStatement prepareCall(String sql,
                                             int resultSetType,
                                             int resultSetConcurrency,
                                             int resultSetHoldability)
                throws SQLException {
            return con.prepareCall(sql, resultSetType, resultSetConcurrency,
                resultSetHoldability);
        }

        public CallableStatement prepareCall(String sql,
                                             int resultSetType,
                                             int resultSetConcurrency)
                throws SQLException {
            return con.prepareCall(sql, resultSetType, resultSetConcurrency);
        }

        public CallableStatement prepareCall(String sql) throws SQLException {
            return con.prepareCall(sql);
        }

        public PreparedStatement prepareStatement(String sql,
                                                  int resultSetType,
                                                  int resultSetConcurrency,
                                                  int resultSetHoldability)
                throws SQLException {
            return con.prepareStatement(sql, resultSetType,
                resultSetConcurrency, resultSetHoldability);
        }

        public PreparedStatement prepareStatement(String sql,
                                                  int resultSetType,
                                                  int resultSetConcurrency)
                throws SQLException {
            return con.prepareStatement(sql, resultSetType,
                resultSetConcurrency);
        }

        public PreparedStatement prepareStatement(String sql,
                                                  int autoGeneratedKeys)
                throws SQLException {
            return con.prepareStatement(sql, autoGeneratedKeys);
        }

        public PreparedStatement prepareStatement(String sql,
                                                  int[] columnIndexes)
                throws SQLException {
            return con.prepareStatement(sql, columnIndexes);
        }

        public PreparedStatement prepareStatement(String sql,
                                                  String[] columnNames)
                throws SQLException {
            return con.prepareStatement(sql, columnNames);
        }

        public PreparedStatement prepareStatement(String sql)
                throws SQLException {
            return con.prepareStatement(sql);
        }

        public void releaseSavepoint(Savepoint savepoint) throws SQLException {
            con.releaseSavepoint(savepoint);
        }

        public void rollback() throws SQLException {
            con.rollback();
        }

        public void rollback(Savepoint savepoint) throws SQLException {
            con.rollback(savepoint);
        }

        public void setAutoCommit(boolean autoCommit) throws SQLException {
            con.setAutoCommit(autoCommit);
        }

        public void setCatalog(String catalog) throws SQLException {
            con.setCatalog(catalog);
        }

        public void setHoldability(int holdability) throws SQLException {
            con.setHoldability(holdability);
        }

        public void setReadOnly(boolean readOnly) throws SQLException {
            con.setReadOnly(readOnly);
        }

        public Savepoint setSavepoint() throws SQLException {
            return con.setSavepoint();
        }

        public Savepoint setSavepoint(String name) throws SQLException {
            return con.setSavepoint(name);
        }

        public void setTransactionIsolation(int level) throws SQLException {
            con.setTransactionIsolation(level);
        }

        public void setTypeMap(Map<String,Class<?>> arg0) throws SQLException {
            con.setTypeMap(arg0);
        }

        public Array createArrayOf(String typeName, Object[] elements)
                throws SQLException {
            return con.createArrayOf(typeName, elements);
        }

        public Blob createBlob() throws SQLException {
            return con.createBlob();
        }

        public Clob createClob() throws SQLException {
            return con.createClob();
        }

        public NClob createNClob() throws SQLException {
            return con.createNClob();
        }

        public SQLXML createSQLXML() throws SQLException {
            return con.createSQLXML();
        }

        public Struct createStruct(String typeName, Object[] attributes)
                throws SQLException {
            return con.createStruct(typeName, attributes);
        }

        public Properties getClientInfo() throws SQLException {
            return con.getClientInfo();
        }

        public String getClientInfo(String name) throws SQLException {
            return con.getClientInfo(name);
        }

        public boolean isValid(int timeout) throws SQLException {
            return con.isValid(timeout);
        }

        public boolean isWrapperFor(Class<?> iface) throws SQLException {
            return con.isWrapperFor(iface);
        }

        public void setClientInfo(Properties properties)
                throws SQLClientInfoException {
            con.setClientInfo(properties);
        }

        public void setClientInfo(String name, String value)
                throws SQLClientInfoException {
            con.setClientInfo(name, value);
        }

        public <T> T unwrap(Class<T> iface) throws SQLException {
            return con.unwrap(iface);
        }
    } // class PooledConnection
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.