package com.programix.sql;

import java.sql.*;

/**
 * This subclass of {@link SQLException} is thrown to indicate that the object
 * that a method was invoked against has been shutdown. The shutdown may have
 * occurred at some point in the past, or the shutdown may have occurred during
 * the time that the caller was inside the method.
 * See {@link com.programix.thread.ShutdownException ShutdownException} in the
 * <tt>com.programix.thread</tt> package for general shutdown handling (this
 * class exists so that in places where only an <tt>SQLException</tt> is
 * allowed, this subclass can be used to signal more specific information).
 * <p>
 * This is a subclass of {@link SQLException} so callers are not <i>required</i>
 * to catch anything more specific than <tt>SQLException</tt> if they are not
 * interested. However, if the caller is interested, this exception is a way to
 * probe to find out more about what caused the exception.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class SQLShutdownException extends SQLException {
    public SQLShutdownException(String message, Throwable cause) {
        super(message);
        initCause(cause);
    }
    
    public SQLShutdownException(Throwable cause) {
        initCause(cause);
    }
    
    public SQLShutdownException(String message) {
        super(message);
    }
    
    public SQLShutdownException() {
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.