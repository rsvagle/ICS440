package com.programix.sql;

import java.sql.*;

/**
 * This subclass of {@link SQLException} is thrown to facilitate the chaining of
 * exceptions of other types. This class exists so that in places where only an
 * <tt>SQLException</tt> is allowed, this subclass can be used to signal more
 * specific information).
 * <p>
 * This is a subclass of {@link SQLException} so callers are not <i>required</i>
 * to catch anything more specific than <tt>SQLException</tt> if they are not
 * interested. However, if the caller is interested, this exception is a way to
 * probe to find out more about what caused the exception.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class SQLChainedException extends SQLException {
    public SQLChainedException(String message, Throwable cause) {
        super(message);
        initCause(cause);
    }
    
    public SQLChainedException(Throwable cause) {
        initCause(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.