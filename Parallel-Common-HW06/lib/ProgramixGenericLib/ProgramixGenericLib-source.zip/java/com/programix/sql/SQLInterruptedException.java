package com.programix.sql;

import java.sql.*;

/**
 * This subclass of {@link SQLException} is thrown to indicate that the calling
 * thread was interrupted while waiting for an operation to complete. The
 * interrupt may have occurred at some point in the past, or the interrupt may
 * have occurred during the time that the caller was inside the method. See
 * {@link java.lang.InterruptedException InterruptedException} in the
 * <tt>java.lang</tt> package for general interrupt handling (this
 * class exists so that in places where only an <tt>SQLException</tt> is
 * allowed, this subclass can be used to signal more specific information).
 * <p>
 * During construction of an instance of this exception, the interrupt flag
 * is asserted (or reasserted) so that any code that follows will also have
 * the chance to throw an InterruptedException. Specifically, this
 * is done during construction: <tt>Thread.currentThread().interrupt()</tt>
 * <p>
 * This is a subclass of {@link SQLException} so callers are not <i>required</i>
 * to catch anything more specific than <tt>SQLException</tt> if they are not
 * interested. However, if the caller is interested, this exception is a way to
 * probe to find out more about what caused the exception.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class SQLInterruptedException extends SQLException {
    public SQLInterruptedException(String message, Throwable cause) {
        super(message);
        initCause(cause);
        Thread.currentThread().interrupt();
    }
    
    public SQLInterruptedException(Throwable cause) {
        initCause(cause);
        Thread.currentThread().interrupt();
    }
    
    public SQLInterruptedException(String message) {
        super(message);
        Thread.currentThread().interrupt();
    }
    
    public SQLInterruptedException() {
        Thread.currentThread().interrupt();
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.