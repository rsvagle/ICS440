package com.programix.sql;

import java.sql.*;

/**
 * Interface used to mark a generic source of JDBC connections.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface ConnectionSource {
    
    /**
     * Returns a {@link Connection} (potentially from a shared resource pool).
     * This connection may be checked out from a shared pool of connections or
     * may be from some other source. When done with a <tt>Connection</tt>,
     * be sure to <tt>close</tt> it to potentially return it to a pool. Due to
     * the fact that this <tt>Connection</tt> might be in a shared pool, you
     * must ensure that after you have called <tt>close</tt>, your code does
     * not do anything more with this <tt>Connection</tt> or anything it
     * created (like a {@link Statement}, or a {@link ResultSet}).
     * <p>
     * Calls to this method may block while waiting for a <tt>Connection</tt>
     * if there is a maximum number of connections allowed in an underlying
     * resource pool. 
     * 
     * @param msTimeout the maximum amount of time to wait for a connection
     * to become available.
     * 
     * @throws SQLTimedOutException if the specific maximum waiting time
     * is exceeded and still no connection is available.
     * Only some implementations (ones that support timeout detection) 
     * throw this specific <tt>SQLException</tt>. 
     * This is a subclass of <tt>SQLException</tt> so callers can optionally
     * ignore this specific kind of exception by simply catching 
     * <tt>SQLException</tt>. 
     * 
     * @throws SQLInterruptedException if calling thread is interrupted while
     * waiting for a connection to become available.
     * Only some implementations (ones that support interrupt detection) 
     * throw this specific <tt>SQLException</tt>. 
     * This is a subclass of <tt>SQLException</tt> so callers can optionally
     * ignore this specific kind of exception by simple catching 
     * <tt>SQLException</tt>. 
     * 
     * @throws SQLShutdowException if this <tt>ConnectionSource</tt> is
     * shutdown while the caller is waiting (or was shutdown earlier).
     * Only some implementations (ones that support being shutdown) 
     * throw this specific <tt>SQLException</tt>. 
     * This is a subclass of <tt>SQLException</tt> so callers can optionally
     * ignore this specific kind of exception by simple catching 
     * <tt>SQLException</tt>. 
     * 
     * @throws SQLException if there is trouble getting a connection.
     */
    Connection getConnection(long msTimeout)
            throws SQLTimedOutException, SQLInterruptedException,
                   SQLShutdownException, SQLException;
    
    /**
     * Returns a {@link Connection} (potentially from a shared resource pool).
     * This connection may be checked out from a shared pool of connections or
     * may be from some other source. When done with a <tt>Connection</tt>,
     * be sure to <tt>close</tt> it to potentially return it to a pool. Due to
     * the fact that this <tt>Connection</tt> might be in a shared pool, you
     * must ensure that after you have called <tt>close</tt>, your code does
     * not do anything more with this <tt>Connection</tt> or anything it
     * created (like a {@link Statement}, or a {@link ResultSet}).
     * <p>
     * Calls to this method may block while waiting for a <tt>Connection</tt>
     * if there is a maximum number of connections allowed in an underlying
     * resource pool. 
     * 
     * @throws SQLInterruptedException if calling thread is interrupted while
     * waiting for a connection to become available.
     * Only some implementations (ones that support interrupt detection) 
     * throw this specific <tt>SQLException</tt>. 
     * This is a subclass of <tt>SQLException</tt> so callers can optionally
     * ignore this specific kind of exception by simple catching 
     * <tt>SQLException</tt>. 
     * 
     * @throws SQLShutdowException if this <tt>ConnectionSource</tt> is
     * shutdown while the caller is waiting (or was shutdown earlier).
     * Only some implementations (ones that support being shutdown) 
     * throw this specific <tt>SQLException</tt>. 
     * This is a subclass of <tt>SQLException</tt> so callers can optionally
     * ignore this specific kind of exception by simple catching 
     * <tt>SQLException</tt>. 
     * 
     * @throws SQLException if there is trouble getting a connection.
     */
    Connection getConnection() throws SQLException;
    
    /**
     * Call this when done with the <tt>ConnectionSource</tt> to allow
     * any underlying allocated resources to be released. 
     */
    void shutdown();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.