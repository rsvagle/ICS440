package com.programix.sql;

import java.sql.*;

/**
 * This subclass of {@link SQLException} is thrown by some methods to indicate
 * that a timeout occurred on an SQL-related activity. See
 * {@link com.programix.thread.TimedOutException TimedOutException} in the
 * <tt>com.programix.thread</tt> package for general time out handling (this
 * class exists so that in places where only an <tt>SQLException</tt> is
 * allowed, this subclass can be used to signal more specific information).
 * <p>
 * This is a subclass of {@link SQLException} so callers are not <i>required</i>
 * to catch anything more specific than <tt>SQLException</tt> if they are not
 * interested. However, if the caller is interested, this exception is a way to 
 * probe to find out more about what caused the exception.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class SQLTimedOutException extends SQLException {
    public SQLTimedOutException(String message, Throwable cause) {
        super(message);
        initCause(cause);
    }
    
    public SQLTimedOutException(Throwable cause) {
        initCause(cause);
    }
    
    public SQLTimedOutException(String message) {
        super(message);
    }
    
    public SQLTimedOutException(long msTimeout) {
        this("Waiting timed out after " + msTimeout + " milliseconds.");
    }
    
    public SQLTimedOutException() {
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.