package com.programix.sql;

import java.sql.*;

public class JDBCTools {
    // no instances
    private JDBCTools() {
    }
    
    /**
     * Closes the specified <tt>Connection</tt> and suppresses any 
     * <tt>SQLException</tt>'s that may be thrown. 
     * There is no need to avoid passing a <tt>null</tt>
     * reference because if a <tt>null</tt> reference is passed to this
     * method, the request to close is silently ignored.
     */
    public static void closeQuietly(Connection con) {
        try {
            if ( con != null ) {
                con.close();
            }
        } catch ( SQLException x ) {
            // ignore
        }
    }

    /**
     * Closes the specified <tt>Statement</tt> and suppresses any 
     * <tt>SQLException</tt>'s that may be thrown. 
     * There is no need to avoid passing a <tt>null</tt>
     * reference because if a <tt>null</tt> reference is passed to this
     * method, the request to close is silently ignored.
     * This method works for {@link Statement}, {@link PreparedStatement},
     * and {@link CallableStatement}.
     */
    public static void closeQuietly(Statement stmt) {
        try {
            if ( stmt != null ) {
                stmt.close();
            }
        } catch ( SQLException x ) {
            // ignore
        }
    }

    /**
     * Closes the specified <tt>ResultSet</tt> and suppresses any 
     * <tt>SQLException</tt>'s that may be thrown. 
     * There is no need to avoid passing a <tt>null</tt>
     * reference because if a <tt>null</tt> reference is passed to this
     * method, the request to close is silently ignored.
     */
    public static void closeQuietly(ResultSet rs) {
        try {
            if ( rs != null ) {
                rs.close();
            }
        } catch ( SQLException x ) {
            // ignore
        }
    }

    /**
     * Closes the <tt>ResultSet</tt>, <tt>Statement</tt>, and 
     * <tt>Connection</tt> [in that order].
     * Any <tt>SQLException</tt>'s that may be thrown are silently suppressed.
     * There is no need to avoid passing <tt>null</tt> references
     * because if any <tt>null</tt> reference is passed to this
     * method, the request to close that particular item is silently ignored.
     * Equivalent to:
     * <pre class="preshade">
     * closeQuietly(rs);
     * closeQuietly(stmt);
     * closeQuietly(con);
     * </pre>
     */
    public static void closeQuietly(
            Connection con, Statement stmt, ResultSet rs) {
        
        closeQuietly(rs);
        closeQuietly(stmt);
        closeQuietly(con);
    }
    
    /**
     * Closes the <tt>Statement</tt> and 
     * <tt>Connection</tt> [in that order].
     * Any <tt>SQLException</tt>'s that may be thrown are silently suppressed.
     * There is no need to avoid passing <tt>null</tt> references
     * because if any <tt>null</tt> reference is passed to this
     * method, the request to close that particular item is silently ignored.
     * Equivalent to:
     * <pre class="preshade">
     * closeQuietly(stmt);
     * closeQuietly(con);
     * </pre>
     */
    public static void closeQuietly(Connection con, Statement stmt) {
        closeQuietly(con, stmt, null);
    }

    /**
     * Closes the <tt>ResultSet</tt> and <tt>Statement</tt> [in that order].
     * Any <tt>SQLException</tt>'s that may be thrown are silently suppressed.
     * There is no need to avoid passing <tt>null</tt> references
     * because if any <tt>null</tt> reference is passed to this
     * method, the request to close that particular item is silently ignored.
     * Equivalent to:
     * <pre class="preshade">
     * closeQuietly(rs);
     * closeQuietly(stmt);
     * </pre>
     */
    public static void closeQuietly(Statement stmt, ResultSet rs) {
        closeQuietly(null, stmt, rs);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.