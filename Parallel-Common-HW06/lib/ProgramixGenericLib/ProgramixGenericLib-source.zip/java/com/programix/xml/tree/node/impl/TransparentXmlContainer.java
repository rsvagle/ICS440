package com.programix.xml.tree.node.impl;

import com.programix.xml.tree.node.type.*;

/**
 * A generic container with neither a start nor an end tag.
 * {@link TransparentXmlContainer} is commonly used to gather child
 * elements together without actually nesting those children within another tag.
 * When {@link TransparentXmlContainer} is encountered during document
 * tree traversal, it is simply skipped and its children are processed
 * as if they had appeared (in order) in place of the
 * {@link TransparentXmlContainer} element.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class TransparentXmlContainer extends AbstractXmlContainerNode
        implements XmlNode, XmlContainerNode {

    public TransparentXmlContainer() {
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.