package com.programix.xml.tree.node.type;


/**
 * Basic XML element with a start tag and an end tag.
 * May or may not have attributes (see ).
 * May or may not have child nodes (see ).
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface XmlCoreElement extends XmlNode, XmlWhitespaceWrapDetectable {
    public static final XmlCoreElement[] ZERO_LEN_ARRAY = new XmlCoreElement[0];

    /**
     * Returns the tag name for this element, never null.
     */
    String getName();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.