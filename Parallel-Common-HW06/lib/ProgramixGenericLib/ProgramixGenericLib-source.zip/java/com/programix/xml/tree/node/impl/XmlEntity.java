package com.programix.xml.tree.node.impl;

import com.programix.util.*;
import com.programix.xml.tree.*;
import com.programix.xml.tree.node.type.*;

/**
 * Represents an XML entity as an <tt>XmlNode</tt>.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class XmlEntity extends AbstractXmlNode implements XmlNode {
    private String entity;

    /**
     * Creates an entity with the specified text. When processed, this
     * text will be prefixed with &amp; and suffixed with ; (for example,
     * the text <tt>"lt"</tt> passed in would produce <tt>&amp;lt;</tt>
     * in the XML output).
     *
     * @param text the entity body (without the &amp; prefix and ; suffix)
     * @throws XmlException if the specified text is null or trims to
     * a zero-length string.
     */
    public XmlEntity(String text) throws XmlException {
        if ( StringTools.isEmpty(text) ) {
            throw new XmlException("text must not be null or blank");
        }
        entity = "&" + StringTools.trim(text) + ";";
    }

    /**
     * Returns the formatted entity text with the leading ampersand and the
     * trailing semicolon.
     */
    public String getEntityText() {
        return entity;
    }

    /**
     * Creates the <tt>&amp;lt;</tt> entity for <tt>"&lt;"</tt>
     * (less than).
     */
    public static XmlEntity createLt() {
        return new XmlEntity("lt");
    }

    /**
     * Creates the <tt>&amp;gt;</tt> entity for <tt>"&gt;"</tt>
     * (greater than).
     */
    public static XmlEntity createGt() {
        return new XmlEntity("gt");
    }

    /**
     * Creates the <tt>&amp;amp;</tt> entity for <tt>"&amp;"</tt>
     * (ampersand).
     */
    public static XmlEntity createAmp() {
        return new XmlEntity("amp");
    }

    /**
     * Creates the <tt>&amp;quot;</tt> entity for <tt>"&quot;"</tt>
     * (double quote).
     */
    public static XmlEntity createQuot() {
        return new XmlEntity("quot");
    }

    /**
     * Creates the <tt>&amp;apos;</tt> entity for <tt>"&apos;"</tt>
     * (apostrophe or single quote).
     */
    public static XmlEntity createApos() {
        return new XmlEntity("apos");
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.