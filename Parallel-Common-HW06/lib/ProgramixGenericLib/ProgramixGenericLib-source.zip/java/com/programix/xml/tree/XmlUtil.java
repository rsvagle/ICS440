package com.programix.xml.tree;

import com.programix.util.*;
import com.programix.value.*;

/**
 * Miscellaneous utilities and tools for use with HTMLObjects.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class XmlUtil {
    // no instances
    private XmlUtil() {
    }

    /**
     * Processes the string passed in substituting the any of the special
     * markup language characters with their markup entities.
     * Specifically, the following replacements occur:
     * <pre>
     * &lt;    &amp;lt;
     * &gt;    &amp;gt;
     * &amp;    &amp;amp;
     * &quot;    &amp;quot;
     * &apos;    &amp;#39;
     * </pre>
     * Note that &amp;apos; is an entity in XML but not an entity in HTML.
     * <p>
     * If <tt>src</tt> does not contain any of these special characters,
     * then <tt>src</tt> itself is returned unmodified (a new <tt>String</tt>
     * is <i>not</i> constructed).
     * If <tt>src</tt> is <tt>null</tt>, then <tt>null</tt> is returned.
     * Otherwise, a new <tt>String</tt> is returned with the substitutions
     * made.
     * <p>
     * Note that passing the returned <tt>String</tt> back into this
     * method will produce yet another new <tt>String</tt> with the
     * ampersands substituted. For example:
     * <table cellpadding="1" cellspacing="1" border="1">
     * <tr><td>Before</td><td>After</td></tr>
     * <tr><td><tt>Small &lt; Medium</tt></td>
     *     <td><tt>Small &amp;lt; Medium</tt></td></tr>
     * <tr><td><tt>Small &amp;lt; Medium</tt></td>
     *     <td><tt>Small &amp;amp;lt; Medium</tt></td></tr>
     * </table>
     */
    public static String processMarkupEntities(String src) {
        if ( StringTools.isEmptyWithoutTrim(src) ) {
            return src;
        }

        char[] ch = src.toCharArray();
        int firstChangePos = -1;
        for ( int i = 0; i < ch.length; i++ ) {
            char c = ch[i];

            if ( c == '<' || c == '>' || c == '&' || c == '"' || c == '\'' ) {
                firstChangePos = i;
                break;
            }
        }

        if ( firstChangePos == -1 ) {
            // no entities to process
            return src;
        }

        StringBuffer sb = new StringBuffer(ch.length + 100);
        sb.append(ch, 0, firstChangePos);
        for ( int i = firstChangePos; i < ch.length; i++ ) {
            switch ( ch[i] ) {
                case '<':
                    sb.append("&lt;");
                    break;

                case '>':
                    sb.append("&gt;");
                    break;

                case '&':
                    sb.append("&amp;");
                    break;

                case '"':
                    sb.append("&quot;");
                    break;

                case '\'':
                    //sb.append("&apos;"); // this is not allowed in HTML
                    sb.append("&#39;");
                    break;

                default:
                    sb.append(ch[i]);
                    break;
            }
        }

        return sb.toString();
    }

    /**
     * Returns a string representation of the passed value which has been
     * processed for entities. Null is never returned&mdash;a zero-len
     * string is returned instead.
     */
    public static String toStringParsed(Object value) {
        if ( value == null ) {
            return StringTools.ZERO_LEN_STRING;
        }

        String s = null;
        if ( value instanceof String ) {
            s = (String) value;
        } else if ( value instanceof Value ) {
            s = ((Value) value).getString();
        } else {
            s = String.valueOf(value);
        }

        return processMarkupEntities(s);
    }

    /**
     * Returns a string representation of the passed value which has NOT been
     * processed for entities. Null is never returned&mdash;a zero-len
     * string is returned instead.
     */
    public static String toStringUnparsed(Object value) {
        if ( value == null ) {
            return StringTools.ZERO_LEN_STRING;
        }

        String s = null;
        if ( value instanceof String ) {
            s = (String) value;
        } else if ( value instanceof Value ) {
            s = ((Value) value).getString();
        } else {
            s = String.valueOf(value);
        }

        return s;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.