package com.programix.xml.tree.node.type;

import com.programix.value.*;
import com.programix.xml.tree.*;

/**
 * This kind of XML element supports attributes.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface XmlAttributeElement extends XmlNode, XmlCoreElement {
    /**
     * Returns <tt>true</tt> if this element has any attributes set.
     */
    boolean hasAttributes();

    /**
     * Returns an array of all of the attributes.
     * If there are no attributes, a zero-length array is returned.
     */
    XmlAttribute[] getAttributes();

    /**
     * Sets the specified attribute potentially replacing anything that was
     * previously stored for the same name.
     */
    void setAttribute(XmlAttribute attribute);

    /**
     * Sets the specified attribute potentially replacing anything that was
     * previously stored for the same name.
     * The value is parsed for entities
     * (see {@link XmlAttribute#HTMLAttribute(String, String)}).
     */
    void setAttribute(String name, String value)
            throws IllegalArgumentException;

    /**
     * Sets the specified attribute potentially replacing anything that was
     * previously stored for the same name.
     * The value is parsed for entities
     * (see {@link XmlAttribute#HTMLAttribute(String, Value)}).
     */
    void setAttribute(String name, Value value)
            throws IllegalArgumentException;

    /**
     * Sets the specified attribute potentially replacing anything that was
     * previously stored for the same name.
     * The value is parsed for entities
     * (see {@link XmlAttribute#HTMLAttribute(String, Object)}).
     */
    void setAttribute(String name, Object value)
            throws IllegalArgumentException;

    /**
     * Sets the specified attribute potentially replacing anything that was
     * previously stored for the same name.
     * (see {@link XmlAttribute#HTMLAttribute(String, int)}).
     */
    void setAttribute(String name, int value) throws IllegalArgumentException;

    /**
     * Sets ALL the specified attributes potentially replacing anything that was
     * previously stored for the same name(s).
     */
    void setAttributeGroup(XmlAttribute[] attributeGroup);

    /**
     * Attempts to remove the attribute with the specified name.
     * @param name the name of the attribute to remove
     * @return <tt>true</tt> if the attribute was removed,
     * <tt>false</tt> otherwise.
     */
    boolean removeAttribute(String name);

    /**
     * Removes all of the attributes.
     */
    void removeAllAttributes();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.