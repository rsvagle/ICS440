package com.programix.xml.tree;

import java.io.*;

import com.programix.util.*;
import com.programix.xml.tree.node.impl.*;

/**
 * Generic interface for printing XML.
 * See {@link XmlDocument#encodeToStream(java.io.OutputStream, boolean)}
 * for something which works in many cases.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface XmlPrinter {

	/**
	 * Appends the specified string to the output.
	 *
	 * @throws XmlException if there is a problem printing
	 */
	void out(String s) throws XmlException;

	/**
	 * Appends the specified string to the output
	 * followed by {@link XmlString#NEWLINE}.
	 *
	 * @throws XmlException if there is a problem printing
	 */
	void outln(String line) throws XmlException;


	/**
	 * This implementation of {@link XmlPrinter} which relays the
	 * output to a {@link Writer}.
	 *
	 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
	 */
	public static class WriterXmlPrinter implements XmlPrinter {
	    private final Writer writer;

        public WriterXmlPrinter(Writer writer) {
            ObjectTools.paramNullCheck(writer, "writer");
            this.writer = writer;
        }

        @Override
        public void out(String s) throws XmlException {
            try {
                writer.write(s);
            } catch ( IOException x ) {
                throw new XmlException(x);
            }
        }

        @Override
        public void outln(String line) throws XmlException {
            out(line);
            out(XmlString.NEWLINE);
        }
    } // class WriterXmlPrinter
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.