package com.programix.xml.tree;

import java.nio.charset.*;

import com.programix.util.*;

/**
 * Holds the combination of the XML encoding textual name and the
 * Java {@link Charset} which can be used to convert to/from bytes.
 * <p>
 * Instances are immutable.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class XmlEncoding {
    public static final XmlEncoding UTF_8 =
        new XmlEncoding("UTF-8", Charset.forName("UTF-8"));

    private final String xmlEncodingName;
    private final Charset charset;

    public XmlEncoding(String xmlEncodingName, Charset charset) {
        ObjectTools.paramNullCheck(xmlEncodingName, "xmlEncodingName");
        ObjectTools.paramNullCheck(charset, "charset");

        this.xmlEncodingName = xmlEncodingName;
        this.charset = charset;
    }

    /**
     * Returns the XML encoding textual name.
     * @return
     */
    public String getXmlEncodingName() {
        return xmlEncodingName;
    }

    /**
     * Returns the Java {@link Charset} which can be used to convert
     * to/from bytes.
     */
    public Charset getCharset() {
        return charset;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.