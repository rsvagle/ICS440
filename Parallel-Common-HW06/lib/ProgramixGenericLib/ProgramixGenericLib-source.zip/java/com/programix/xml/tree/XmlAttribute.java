package com.programix.xml.tree;

import java.util.*;

import com.programix.util.*;
import com.programix.value.*;


/**
 * Immutable objects which hold a string-based name and a string-based
 * value. Since instances are immutable, they can be safely shared.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class XmlAttribute {
    public static final XmlAttribute[] ZERO_LEN_ARRAY = new XmlAttribute[0];

    private final String name;
    private final String value;

    private XmlAttribute(String name,
                          String value,
                          boolean scanForMarkup
                      ) throws IllegalArgumentException {

        ObjectTools.paramNullCheck(name, "name");
        ObjectTools.paramNullCheck(value, "value");

        this.name = StringTools.trim(name);

        if ( StringTools.isEmpty(this.name) ) {
            throw new IllegalArgumentException("name of attribute is empty");
        }

        this.value =
            scanForMarkup ? XmlUtil.processMarkupEntities(value) : value;
    }

    /**
     * Creates an attribute with the specified name and value.
     * The value is automatically parsed for entities (see
     * {@link XmlUtil#processMarkupEntities(String)}).
     *
     * @param name the name of the attribute and it must not be null and must
     * not be {@link StringTools#isEmpty(String) empty}.
     * @param value the value of the attribute and it must not be null.
     * @throws IllegalArgumentException if name or value is null, or if
     * name is nothing but whitespace.
     */
    public XmlAttribute(String name, String value)
            throws IllegalArgumentException {

        this(name, value, true);
    }

    /**
     * Creates an attribute with the specified name and value.
     * The value is automatically parsed for entities (see
     * {@link XmlUtil#processMarkupEntities(String)}).
     * The value also has any leading and trailing whitespace trimmed.
     *
     * @param name the name of the attribute and it must not be null and must
     * not be {@link StringTools#isEmpty(String) empty}.
     * @param value the value of the attribute and it must not be null.
     * @throws IllegalArgumentException if name or value is null, or if
     * name is nothing but whitespace.
     */
    public XmlAttribute(String name, Value value)
            throws IllegalArgumentException {

        this(name, (String)((value == null) ? null : value.getString()));
    }

    /**
     * Creates an attribute with the specified name and value.
     * The value is automatically parsed for entities (see
     * {@link XmlUtil#processMarkupEntities(String)}).
     *
     * @param name the name of the attribute and it must not be null and must
     * not be {@link StringTools#isEmpty(String) empty}.
     * @param value the value of the attribute and it must not be null.
     * @throws IllegalArgumentException if name or value is null, or if
     * name is nothing but whitespace.
     */
    public XmlAttribute(String name, Object value)
            throws IllegalArgumentException {

        this(name, (String)
            ((value == null) ? null : XmlUtil.toStringParsed(value)));
    }

    /**
     * Creates an attribute with the specified name and value.
     *
     * @param name the name of the attribute and it must not be null and must
     * not be {@link StringTools#isEmpty(String) empty}.
     * @param value the value of the attribute
     * @throws IllegalArgumentException if name is null, or if
     * name is nothing but whitespace.
     */
    public XmlAttribute(String name, int value)
            throws IllegalArgumentException {

        this(name, String.valueOf(value));
    }

    /**
     * Creates an attribute with the specified name and value.
     *
     * @param name the name of the attribute and it must not be null and must
     * not be {@link StringTools#isEmpty(String) empty}.
     * @param value the value of the attribute
     * @throws IllegalArgumentException if name is null, or if
     * name is nothing but whitespace.
     */
    public XmlAttribute(String name, double value)
            throws IllegalArgumentException {

        this(name, String.valueOf(value));
    }

    /**
     * Creates an attribute defaulting the value to be the same as the name.
     *
     * @param name the name of the attribute and it must not be null and must
     * not be {@link StringTools#isEmpty(String) empty}.
     * @throws IllegalArgumentException if name is null, or if
     * name is nothing but whitespace.
     */
    public XmlAttribute(String name) throws IllegalArgumentException {
        this(name, name);
    }

    /**
     * Creates an attribute with the specified name and value.
     * The value is NOT parsed for entities (you should have a good reason for
     * using this method&mdash;this is not typical).
     *
     * @param name the name of the attribute and it must not be null and must
     * not be {@link StringTools#isEmpty(String) empty}.
     * @param value the value of the attribute and it must not be null.
     * @throws IllegalArgumentException if name or value is null, or if
     * name is nothing but whitespace.
     */
    public static XmlAttribute createUnparsed(String name, String value)
            throws IllegalArgumentException {

        return new XmlAttribute(name, value, false);
    }

    /**
     * Creates an attribute with the specified name and value.
     * The value is NOT parsed for entities (you should have a good reason for
     * using this method&mdash;this is not typical).
     * The value also has any leading and trailing whitespace trimmed.
     *
     * @param name the name of the attribute and it must not be null and must
     * not be {@link StringTools#isEmpty(String) empty}.
     * @param value the value of the attribute and it must not be null.
     * @throws IllegalArgumentException if name or value is null, or if
     * name is nothing but whitespace.
     */
    public static XmlAttribute createUnparsed(String name, Value value)
            throws IllegalArgumentException {

        return new XmlAttribute(
            name, (String)((value == null) ? null : value.getString()), false);
    }

    /**
     * Creates an attribute with the specified name and value.
     * The value is NOT parsed for entities (you should have a good reason for
     * using this method&mdash;this is not typical).
     *
     * @param name the name of the attribute and it must not be null and must
     * not be {@link StringTools#isEmpty(String) empty}.
     * @param value the value of the attribute and it must not be null.
     * @throws IllegalArgumentException if name or value is null, or if
     * name is nothing but whitespace.
     */
    public static XmlAttribute createUnparsed(String name, Object value)
            throws IllegalArgumentException {

        return new XmlAttribute(name, (String)
            ((value == null) ? null : XmlUtil.toStringUnparsed(value)), false);
    }

    /**
     * Returns the name of the attribute (never null and never blank).
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the value of the attribute (never null, might be blank).
     */
    public String getValue() {
        return value;
    }

    /**
     * Used to provide general support for a list of attributes
     * on a XML element.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class ListHelper {
        private Map<String, XmlAttribute> attributeList;

        public ListHelper() {
        }

        public boolean hasAttributes() {
            return (attributeList != null) && (attributeList.size() > 0);
        }

        public XmlAttribute[] getAttributes() {
            if ( hasAttributes() ) {
                return (XmlAttribute[])
                    attributeList.values().toArray(XmlAttribute.ZERO_LEN_ARRAY);
            } else {
                return XmlAttribute.ZERO_LEN_ARRAY;
            }
        }

        /**
         * Adds or replaces the specified attribute to the list of attributes.
         */
        public void setAttribute(XmlAttribute attribute) {
            if ( attribute == null ) {
                return; // silently ignore
            }

            if ( attributeList == null ) {
                // construct only on-demand
                attributeList = new LinkedHashMap<String, XmlAttribute>(8);
            }

            // silently replaces any attribute with the same name
            attributeList.put(attribute.name, attribute);
        }

        public void setAttribute(String name, String value) {
            setAttribute(new XmlAttribute(name, value));
        }

        public void setAttribute(String name, Value value) {
            setAttribute(new XmlAttribute(name, value));
        }

        public void setAttribute(String name, Object value) {
            setAttribute(new XmlAttribute(name, value));
        }

        public void setAttribute(String name, int value) {
            setAttribute(new XmlAttribute(name, value));
        }

        public void setAttribute(String name, double value) {
            setAttribute(new XmlAttribute(name, value));
        }

        public void setAttribute(String name) {
            setAttribute(new XmlAttribute(name, name));
        }

        public void setAttributeGroup(XmlAttribute[] attributeGroup) {
            if ( attributeGroup != null ) {
                for ( int i = 0; i < attributeGroup.length; i++ ) {
                    setAttribute(attributeGroup[i]);
                }
            }
        }

        public boolean removeAttribute(String attName) {
            if ( attributeList == null || attName == null ) {
                return false;
            }

            XmlAttribute attribute = attributeList.remove(attName);
            return attribute != null;
        }

        public void removeAllAttributes() {
            if ( attributeList != null ) {
                attributeList.clear();
            }
        }
    } // class ListHelper
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.