package com.programix.xml.tree.node.impl;

import java.util.*;

import com.programix.collections.*;
import com.programix.util.*;
import com.programix.xml.tree.node.type.*;

public abstract class AbstractXmlContainerNode extends AbstractXmlNode
        implements XmlNode, XmlContainerNode {

    private List<XmlNode> childList;

    protected AbstractXmlContainerNode() {
    }

    @Override
    public boolean hasChildren() {
        return CollectionsTools.isNotEmpty(childList);
    }

    @Override
    public XmlNode[] getChildren() {
        if ( hasChildren() ) {
            return (XmlNode[])
                childList.toArray(XmlNode.ZERO_LEN_ARRAY);
        } else {
            return XmlNode.ZERO_LEN_ARRAY;
        }
    }

    @Override
    public <T extends XmlNode> T addChild(T node) {
        if ( node == null ) {
            return null; // silently ignore
        }

        if ( childList == null ) {
            // construct only on-demand
            childList = new ArrayList<XmlNode>(15);
        }

        childList.add(node);
        node.setParent(this);
        return node;
    }

    @Override
    public XmlString addChild(String text) {
        if ( StringTools.isEmptyWithoutTrim(text) ) {
            return null;
        } else {
            return (XmlString) addChild(new XmlString(text));
        }
    }

    @Override
    public boolean removeChild(int index) {
        if ( (childList == null) || (index >= childList.size()) ||
             (index < 0) ) {

            return false;
        }

        childList.remove(index);
        return true;
    }

    @Override
    public void removeAllChildren() {
        if ( childList != null ) {
            childList.clear();
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.