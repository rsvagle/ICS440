package com.programix.xml.tree.node.impl;

import java.io.*;

import com.programix.io.*;
import com.programix.xml.tree.*;
import com.programix.xml.tree.node.type.*;

public class XmlDocument implements XmlNode {
    public static final XmlEncoding DEFAULT_ENCODING = XmlEncoding.UTF_8;

    private String version = "1.0";
    private XmlEncoding encoding = XmlEncoding.UTF_8;

    private XmlCoreElement rootElement;

    // TODO - support comments and DTD's

    public XmlDocument(XmlCoreElement rootElement) {
        this.rootElement = rootElement;
    }

    public XmlDocument() {
    }

    public XmlCoreElement getRootElement() {
        return rootElement;
    }

    public void setRootElement(XmlCoreElement rootElement) {
        this.rootElement = rootElement;
    }

    public XmlEncoding getEncoding() {
        return encoding;
    }

    public void setEncoding(XmlEncoding proposedEncoding) {
        this.encoding =
            proposedEncoding == null ? DEFAULT_ENCODING : proposedEncoding;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String proposedVersion) {
        this.version =
            proposedVersion == null ? "1.0" : proposedVersion;
    }

    /**
     * Always returns null.
     */
    @Override
    public XmlNode getParent() {
        return null;
    }

    /**
     * Ignores all calls as an {@link XmlDocument} never has a parent.
     */
    @Override
    public void setParent(XmlNode parent) {
    }

    /**
     * Always throws an exception because {@link XmlDocument}'s can't
     * have any siblings (they don't have a parent!).
     */
    @Override
    public <T extends XmlNode> T addSibling(T node) throws XmlException {
        throw new XmlException(
                "XmlDocument can't have any siblings (no parent)");
    }

    /**
     * Always throws an exception because {@link XmlDocument}'s can't
     * have any siblings (they don't have a parent!).
     */
    @Override
    public XmlString addSibling(String text) throws XmlException {
        throw new XmlException(
            "XmlDocument can't have any siblings (no parent)");
    }

    /**
     * Encodes this XML document into bytes on the specified
     * {@link OutputStream}.
     * See {@link #encodeToFile(File)} and {@link #encodeToBytes()}
     * for other ways to encode.
     *
     * @param rawOut the the destination for the encoded bytes. There is
     * no reason to add buffering as that will be handled internally.
     * @param closeStream if true and if the entire document successfully
     * encodes, then rawOut will be closed.
     * @throws XmlException if there are any problems encoding to the stream.
     */
    public void encodeToStream(OutputStream rawOut, boolean closeStream)
            throws XmlException {

        OutputStreamWriter writer = null;
        boolean success = false;
        try {
            writer = new OutputStreamWriter(
                new BufferedOutputStream(rawOut), encoding.getCharset());

            XmlPrinter printer = new XmlPrinter.WriterXmlPrinter(writer);

            XmlTreeClimber treeClimber = new XmlTreeClimber(this);
            treeClimber.process(printer);
            writer.flush();
            success = true;
        } catch ( Exception x ) {
            throw XmlException.convert(x);
        } finally {
            if ( closeStream && success ) {
                IOTools.closeQuietly(writer);
            }
        }
    }

    /**
     * Encodes this XML document into bytes saved into the specified file.
     * See {@link #encodeToStream(OutputStream, boolean)}
     * and {@link #encodeToBytes()} for other ways to encode.
     *
     * @param outputFile the destination for the encoded bytes
     * @throws XmlException if there are any problems encoding to the stream.
     */
    public void encodeToFile(File outputFile) throws XmlException {
        try {
            encodeToStream(new FileOutputStream(outputFile), true);
        } catch ( Exception x ) {
            throw XmlException.convert(x);
        }
    }

    /**
     * Encodes this XML document into bytes.
     * See {@link #encodeToStream(OutputStream, boolean)}
     * and {@link #encodeToFile(File)} for other ways to encode.
     *
     * @throws XmlException if there are any problems encoding to the stream.
     */
    public byte[] encodeToBytes() throws XmlException {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            encodeToStream(baos, true);
            return baos.toByteArray();
        } catch ( Exception x ) {
            throw XmlException.convert(x);
        }
    }

    /**
     * Encodes this XML document into a single String.
     * See {@link #encodeToStream(OutputStream, boolean)}
     * and {@link #encodeToFile(File)} for other ways to encode.
     *
     * @throws XmlException if there are any problems encoding to the stream.
     */
    public String encodeToString() throws XmlException {
        StringWriter writer = null;
        try {
            writer = new StringWriter();

            XmlPrinter printer = new XmlPrinter.WriterXmlPrinter(writer);

            XmlTreeClimber treeClimber = new XmlTreeClimber(this);
            treeClimber.process(printer);
            writer.flush();
            return writer.toString();
        } catch ( Exception x ) {
            throw XmlException.convert(x);
        } finally {
            IOTools.closeQuietly(writer);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.