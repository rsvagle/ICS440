package com.programix.xml.tree;

import java.util.*;

import com.programix.util.*;
import com.programix.xml.tree.node.impl.*;
import com.programix.xml.tree.node.type.*;

/**
 * Climbs an {@link XmlNode} tree and sends output to the specified
 * {@link XmlPrinter}.
 * See {@link XmlDocument#encodeToStream(java.io.OutputStream, boolean)}
 * for something which works in many cases.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class XmlTreeClimber {
    public static final String ONE_SPACE_INDENT = " ";
    public static final String TWO_SPACE_INDENT = "  ";
    public static final String FOUR_SPACE_INDENT = "    ";

    private final XmlNode rootNode;
    private final String indent;

    public XmlTreeClimber(XmlNode rootNode, String indent) {
        this.rootNode = rootNode;
        this.indent = indent;
    }

    /**
     * Defaults the indent to {@link #TWO_SPACE_INDENT}
     */
    public XmlTreeClimber(XmlNode rootNode) {
        this(rootNode, TWO_SPACE_INDENT);
    }

    public void process(XmlPrinter printer) throws XmlException {
        output(rootNode, 0, printer);
    }

    private void output(XmlNode node, int indentLevel, XmlPrinter printer)
            throws XmlException {

        if ( node instanceof XmlString ) {
            printer.out(((XmlString) node).getText());
            return;
        } else if ( node instanceof XmlEntity ) {
            printer.out(((XmlEntity) node).getEntityText());
            return;
        } else if ( node instanceof XmlDocument ) {
            XmlDocument doc = (XmlDocument) node;
            String version = doc.getVersion();
            if ( StringTools.isEmpty(version) ) {
                version = "1.0";
            }

            printer.out("<?xml version=\"");
            printer.out(version);
            printer.out("\"");
            if ( StringTools.isNotEmpty(doc.getEncoding()) ) {
                printer.out(" encoding=\"");
                printer.out(doc.getEncoding().getXmlEncodingName());
                printer.out("\"");
            }
            printer.outln(" ?>");

            output(doc.getRootElement(), 0, printer);
            return;
        }

        XmlCoreElement element = null;
        if ( node instanceof XmlCoreElement ) {
            element = (XmlCoreElement) node;
        }

        if ( element == null &&
             node instanceof XmlContainerNode == false ) {

            // not an element and not a transparent container...
            throw new XmlException("Unsupported XmlNode type of " +
                node.getClass().getName());
        }

        // get children (if any)
        XmlNode[] children = getChildren(node);

        if ( children.length == 0 && element == null ) {
            // no children and not an element, there's nothing to do
            return;
        }

        if ( element != null ) {
            printer.out("<" + element.getName());

            if ( element instanceof XmlAttributeElement ) {
                XmlAttributeElement attributeElement =
                        (XmlAttributeElement) element;
                if ( attributeElement.hasAttributes() ) {
                    XmlAttribute[] attributes =
                            attributeElement.getAttributes();

                    for ( XmlAttribute attribute : attributes ) {
                        printer.out(" ");
                        printer.out(attribute.getName());
                        printer.out("=\"");
                        printer.out(attribute.getValue());
                        printer.out("\"");
                    }
                }
            }

            if ( children.length == 0 ) {
                if ( node instanceof DoNotMinimizeEmpty ) {
                    printer.out("></" + element.getName() + ">");
                    return;
                } else {
                    printer.out(" />");
                    return;
                }
            } else {
                printer.out(">");
            }
        }

        // If we get here, there *are* children
        // (node may or may not be an element)

        for ( int i = 0; i < children.length; i++ ) {
            XmlNode prevNode = i > 0 ? children[i - i] : node;
            addWhitespaceIfOk(prevNode, children[i], indentLevel + 1, printer);
            output(children[i], indentLevel + 1, printer); // recursive
        }

        addWhitespaceIfOk(
            children[children.length - 1], node, indentLevel, printer);

        if ( element != null ) {
            printer.out("</" + element.getName() + ">");
        }
    }

    private XmlNode[] getChildren(XmlNode parent) {
        if ( parent instanceof XmlContainerNode == false ) {
            return XmlNode.ZERO_LEN_ARRAY;
        }

        XmlContainerNode parentContainer = (XmlContainerNode) parent;
        if ( parentContainer.hasChildren() == false ) {
            return XmlNode.ZERO_LEN_ARRAY;
        }

        List<XmlNode> childList = new ArrayList<XmlNode>(50);
        fillChildren(parentContainer, childList);
        return (XmlNode[]) childList.toArray(XmlNode.ZERO_LEN_ARRAY);
    }

    private static void fillChildren(XmlContainerNode parent,
                                     List<XmlNode> childList) {

        XmlNode[] children = parent.getChildren();
        for ( XmlNode child : children ) {
            if ( child instanceof XmlContainerNode == true &&
                 child instanceof XmlCoreElement == false ) {

                // it's a container, but not an element, transparently
                // ignore the wrapping container and place it's children
                // in it's place
                fillChildren((XmlContainerNode) child, childList);
            } else {
                childList.add(child);
            }
        }
    }

    private void addWhitespaceIfOk(XmlNode nodeA,
                                   XmlNode nodeB,
                                   int indentLevel,
                                   XmlPrinter printer) {

        if ( nodeA instanceof XmlWhitespaceWrapDetectable == false ||
             nodeB instanceof XmlWhitespaceWrapDetectable == false ) {

            return;
        }

        XmlWhitespaceWrapDetectable a = (XmlWhitespaceWrapDetectable) nodeA;
        XmlWhitespaceWrapDetectable b = (XmlWhitespaceWrapDetectable) nodeB;

        if ( a.isSafeToWrapWithWhitespace() &&
             b.isSafeToWrapWithWhitespace() ) {

            printer.outln("");
            for ( int i = 0; i < indentLevel; i++ ) {
                printer.out(indent);
            }
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.