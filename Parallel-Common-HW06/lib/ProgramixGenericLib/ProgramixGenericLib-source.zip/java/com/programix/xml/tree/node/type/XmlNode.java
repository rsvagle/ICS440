package com.programix.xml.tree.node.type;

import com.programix.xml.tree.*;
import com.programix.xml.tree.node.impl.*;

/**
 * Marker interface for everything on the tree in the XML world.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface XmlNode {
    public static final XmlNode[] ZERO_LEN_ARRAY = new XmlNode[0];

    /**
     * Returns the current parent node of this node (may be null).
     * Null is returned for partial trees that have not yet been
     * added and always returns null for the {@link XmlDocument} node.
     */
    XmlNode getParent();

    /**
     * Changes or initially sets the parent node for this node.
     */
    void setParent(XmlNode parent);

    /**
     * Add the specified node to this node's <i>parent</i>.
     * The value returned is the same as the value passed in&mdash;allowing
     * for convenient method chaining. Equivalent to:
     * <pre>
     * {@link #getParent() getParent}().{@link #add(XmlNode) add}(node);
     * </pre>
     *
     * @param node the node to add.
     * <tt>null</tt> is ignored (and returned).
     * @return the node added (same as what is passed in).
     * @exception XmlException if there is no parent container at
     * the moment (if <tt>getParent()</tt> returns <tt>null</tt>).
     * This exception is also thrown if the parent is not an
     * {@link XmlContainerNode} (if the parent can't have any children).
     * This is a {@link RuntimeException}, so callers are not <i>required</i>
     * to use a <tt>try/catch</tt> block.
     */
    <T extends XmlNode> T addSibling(T node) throws XmlException;

    /**
     * Convenience method to wrap the specified text in an {@link XmlString}
     * and call {@link #addSibling(XmlNode) addSibling(node)}.
     * Only adds the specified <tt>text</tt> if it is not null and has a
     * length greater than 0. The value returned is the <tt>XmlString</tt>
     * created, or null if the passed text was null or zero-length.
     * @exception XmlException if there is no parent container at
     * the moment (if <tt>getParent()</tt> returns <tt>null</tt>). This is a
     * {@link RuntimeException}, so callers are not <i>required</i> to
     * use a <tt>try/catch</tt> block.
     */
    XmlString addSibling(String text) throws XmlException;
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.