package com.programix.xml.tree;

/**
 * Thrown in cases where there is trouble with the XML.
 * This is a {@link RuntimeException} so callers are not required to
 * explicitly write a <tt>try/catch</tt>.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class XmlException extends RuntimeException {
    public XmlException() {
        super();
    }

    public XmlException(String message) {
        super(message);
    }

    public XmlException(Throwable cause) {
        super(cause);
    }

    public XmlException(String message, Throwable cause) {
        super(message, cause);
    }

    public static XmlException convert(Throwable t) {
        if ( t instanceof XmlException ) {
            return (XmlException) t;
        } else {
            return new XmlException(t);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.