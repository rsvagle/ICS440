package com.programix.xml.tree.node.impl;

import com.programix.util.*;
import com.programix.value.*;
import com.programix.xml.tree.*;
import com.programix.xml.tree.node.type.*;

/**
 * A general purposed XML element which supports the setting of attributes
 * but NOT the adding of children.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class NoChildrenXmlElement extends AbstractXmlNode
        implements XmlNode, XmlCoreElement, XmlAttributeElement {

    private final String name;
    private final boolean safeToWrapWithWhitespace;
    private final XmlAttribute.ListHelper attrListHelper;

    public NoChildrenXmlElement(String name,
                           boolean safeToWrapWithWhitespace)
            throws IllegalArgumentException {

        ObjectTools.paramNullCheck(name, "name");
        this.name = name;
        this.safeToWrapWithWhitespace = safeToWrapWithWhitespace;
        attrListHelper = new XmlAttribute.ListHelper();
    }

    public NoChildrenXmlElement(String name)
            throws IllegalArgumentException {

        this(name, true);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public boolean isSafeToWrapWithWhitespace() {
        return safeToWrapWithWhitespace;
    }

    @Override
    public boolean hasAttributes() {
        return attrListHelper.hasAttributes();
    }

    @Override
    public XmlAttribute[] getAttributes() {
        return attrListHelper.getAttributes();
    }

    @Override
    public void setAttribute(XmlAttribute attribute) {
        attrListHelper.setAttribute(attribute);
    }

    @Override
    public void setAttribute(String name, String value)
            throws IllegalArgumentException {

        attrListHelper.setAttribute(name, value);
    }

    @Override
    public void setAttribute(String name, Value value)
            throws IllegalArgumentException {

        attrListHelper.setAttribute(name, value);
    }

    @Override
    public void setAttribute(String name, Object value)
            throws IllegalArgumentException {

        attrListHelper.setAttribute(name, value);
    }

    @Override
    public void setAttribute(String name, int value)
            throws IllegalArgumentException {

        attrListHelper.setAttribute(name, value);
    }

    @Override
    public void setAttributeGroup(XmlAttribute[] attributeGroup) {
        attrListHelper.setAttributeGroup(attributeGroup);
    }

    @Override
    public boolean removeAttribute(String attributeName) {
        return attrListHelper.removeAttribute(attributeName);
    }

    @Override
    public void removeAllAttributes() {
        attrListHelper.removeAllAttributes();
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.