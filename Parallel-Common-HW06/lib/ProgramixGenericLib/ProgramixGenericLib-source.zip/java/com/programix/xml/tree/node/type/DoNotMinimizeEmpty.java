package com.programix.xml.tree.node.type;


/**
 * Marker interface to indicate that when this {@link XmlNode} has
 * no child elements, this tag MUST <b>NOT</b> be minimized.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface DoNotMinimizeEmpty {
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.