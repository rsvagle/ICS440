package com.programix.xml.tree.node.type;

/**
 * Implemented by items which would like to report whether or not
 * they can be safely wrapped with whitespace padding.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface XmlWhitespaceWrapDetectable {
    /**
     * Returns true if is is safe to add whitespace before and after this
     * item. This is mostly used for formatting XML purposes. Any
     * items that are not sure should return false to be safer.
     * Most of the time, it is safe to wrap XML elements with whitespace
     * and that will help readability by humans.
     */
    boolean isSafeToWrapWithWhitespace();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.