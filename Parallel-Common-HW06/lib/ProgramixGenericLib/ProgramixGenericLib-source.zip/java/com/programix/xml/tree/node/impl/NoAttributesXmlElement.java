package com.programix.xml.tree.node.impl;

import com.programix.util.*;
import com.programix.xml.tree.node.type.*;

/**
 * A general purpose XML element which supports the adding of children,
 * but does NOT support the setting of attributes.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class NoAttributesXmlElement extends AbstractXmlContainerNode
        implements XmlNode, XmlContainerNode, XmlCoreElement {

    private final String name;
    private final boolean safeToWrapWithWhitespace;

    public NoAttributesXmlElement(String name,
                           boolean safeToWrapWithWhitespace)
            throws IllegalArgumentException {

        ObjectTools.paramNullCheck(name, "name");
        this.name = name;
        this.safeToWrapWithWhitespace = safeToWrapWithWhitespace;
    }

    public NoAttributesXmlElement(String name)
            throws IllegalArgumentException {

        this(name, true);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public boolean isSafeToWrapWithWhitespace() {
        return safeToWrapWithWhitespace;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.