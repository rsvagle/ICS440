package com.programix.xml.tree.node.impl;

import com.programix.util.*;
import com.programix.xml.tree.*;
import com.programix.xml.tree.node.type.*;

public abstract class AbstractXmlNode implements XmlNode {
    private XmlNode parent;

    protected AbstractXmlNode() {
    }

    @Override
    public XmlNode getParent() {
        return parent;
    }

    @Override
    public void setParent(XmlNode parent) {
        this.parent = parent;
    }

    @Override
    public <T extends XmlNode> T addSibling(T node) throws XmlException {
        XmlNode par = getParent();
        if ( par == null ) {
            throw new XmlException("Can't add a sibling now, no parent yet.");
        } else if ( par instanceof XmlContainerNode ) {
            XmlContainerNode container = (XmlContainerNode) par;
            return container.addChild(node);
        } else {
            throw new XmlException("Can't add a sibling, my parent does " +
        		"not support the adding of children");
        }
    }

    @Override
    public XmlString addSibling(String text) throws XmlException {
        if ( StringTools.isEmptyWithoutTrim(text) ) {
            return null;
        } else {
            return (XmlString) addSibling(new XmlString(text));
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.