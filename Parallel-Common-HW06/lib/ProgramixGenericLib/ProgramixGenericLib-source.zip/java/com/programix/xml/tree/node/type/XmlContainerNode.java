package com.programix.xml.tree.node.type;

import com.programix.xml.tree.node.impl.*;

/**
 * A node which can contain other nodes (children).
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface XmlContainerNode extends XmlNode {
    /**
     * Returns true if there are currently any children nested within this
     * node.
     */
    boolean hasChildren();

    /**
     * Returns an array of all of the children of this node.
     * If there are no children, then a zero-len array is returned (null
     * is never returned).
     */
    XmlNode[] getChildren();

    /**
     * Add the specified child node to this container.
     * The value returned is the same as the value passed in&mdash;allowing
     * for convenient method chaining.
     *
     * @param node the node to add.
     * <tt>null</tt> is ignored (and returned).
     * @return the node added (same as what is passed in).
     */
    <T extends XmlNode> T addChild(T node);

    /**
     * Convenience method to wrap the specified text in an {@link XmlString}
     * and call {@link #addChild(XmlNode)}.
     * Only adds the specified <tt>text</tt> if it is not null and has a
     * length greater than 0. The value returned is the <tt>XmlString</tt>
     * created, or null if the passed text was null or zero-length.
     */
    XmlString addChild(String text);

    /**
     * Attempts to remove the child <tt>XmlNode</tt> at the specified index.
     * Out of range index values are silently ignored. The index value is
     * based on the order the node are returned from {@link #getChildren()}.
     *
     * @param index value from 0 to <tt>(getChildren().length - 1)</tt>
     * @return <tt>true</tt> if the child was removed, <tt>false</tt> otherwise.
     */
    boolean removeChild(int index);

    /**
     * Removes all of the children.
     */
    void removeAllChildren();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.