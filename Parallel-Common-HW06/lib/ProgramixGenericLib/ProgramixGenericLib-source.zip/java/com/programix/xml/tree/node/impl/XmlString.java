package com.programix.xml.tree.node.impl;

import javax.xml.bind.annotation.*;

import com.programix.util.*;
import com.programix.xml.tree.*;
import com.programix.xml.tree.node.type.*;

/**
 * Represents a <tt>String</tt> as an <tt>XmlElement</tt>.
 * <p>
 * Strings passed to the constructors are parsed by
 * {@link XmlUtil#processMarkupEntities(String)} so that any special markup
 * characters (like &lt;, &gt;, etc.) are substituted with the entity
 * references. In some rarer cases, you can avoid this substitution by creating
 * an instance with the {@link #createUnparsed(String, XmlElement)} or
 * {@link #createUnparsed(String)} methods.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class XmlString extends AbstractXmlNode implements XmlNode {
    /**
     * This is the standard XML newline: <tt>\n"</tt>.
     */
    public static final String NEWLINE = "\n";

    private final String text;

    private XmlString(String text, boolean scanForMarkup) {
        String s = StringTools.nullToBlank(text);

        if ( scanForMarkup ) {
            s = XmlUtil.processMarkupEntities(s);
        }

        this.text = s;
    }

    public XmlString(String text) {
        this(text, true);
    }

    /**
     * Creates an XmlString for the specified text <i>without</i> substituting
     * special markup characters with their entities.
     */
    public static XmlString createUnparsed(String text) {
        return new XmlString(text, false);
    }

    /**
     * Returns the text&mdash;potentially parsed with entity substitution during
     * construction.
     */
    public String getText() {
        return text;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.