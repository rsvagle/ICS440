package com.programix.value;

/**
 * Thrown to indicate that there is a problem interpreting or parsing 
 * a {@link Value}. This is a {@link RuntimeException}, so use of
 * a <tt>try</tt>/<tt>catch</tt> block is not <i>required</i>.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ValueException extends RuntimeException {

    public ValueException() {
        super();
    }

    public ValueException(String message) {
        super(message);
    }

    public ValueException(String message, Throwable cause) {
        super(message, cause);
    }

    public ValueException(Throwable cause) {
        super(cause);
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.