package com.programix.value;

import java.io.*;
import java.math.*;
import java.net.*;
import java.util.*;

import com.programix.io.*;
import com.programix.thread.*;
import com.programix.time.*;
import com.programix.util.*;

/**
 * Maps <tt>String</tt> keys to {@link Value} values with an iteration order
 * matching the insertion order.
 * <p>
 * Many of the methods on this class declare that they might throw a
 * {@link ValueException} or a {@link ValueMapException} or a subclass of
 * <tt>ValueMapException</tt>, {@link ValueMapRequiredKeyException}. All
 * three of these exceptions are subclasses of {@link RuntimeException} so
 * they do <i>not</i> have to be explicitly caught (aka "can-catch" exceptions
 * or "unchecked" exceptions).
 * <p>
 * <tt>ValueMap</tt>'s can be populated
 * directly from files (and other stream sources) when those files are
 * in a format very similar to that which {@link Properties} reads,
 * specifically:
 * <ul>
 * <li>The 'key' and the 'value' are delimited by the first <tt>=</tt> found
 *     on the line and that delimiter is not included in the text of the key
 *     or in the text of the value. If any more <tt>=</tt>'s are present, they
 *     <i>are</i> retained as part of the value&mdash;only the first <tt>=</tt>
 *     gets special consideration.</li>
 * <li>The 'key' is from the beginning of the line up to the first occurrence
 *     of <tt>=</tt> character.</li>
 * <li>The 'value' is from the first <tt>=</tt> until the end of the line.</li>
 * <li>If <tt>=</tt> is the last non-whitespace character on the line, then
 *     the value is a zero-length <tt>String</tt>.</li>
 * <li>Both the 'key' and the 'value' have <i>all</i> their leading and trailing
 *     whitespace trimmed before being stored. It is not possible to have a key
 *     or a value that has leading whitespace or trailing whitespace.</li>
 * <li>Blank lines (and lines of only whitespace) are ignored.</li>
 * <li>Lines whose first non-whitespace character is <tt>#</tt> are treated
 *     as ignorable comments.</li>
 * <li>A line with the last non-whitespace character being a backslash
 *     (<tt>\</tt>) is concatenated with the following line. This allows
 *     for very long lines to be broken up into multiple lines. If an
 *     actual backslash is needed as the last character on a line,
 *     use two in a row: <tt>\\</tt> to escape the special meaning. Elsewhere
 *     in the line a single backslash means simply a single backslash.</li>
 * </ul>
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ValueMap extends Object implements Serializable, ThreadSafe {
    private static final char BACKSLASH = '\\';

    private final Object lock;
    private final Store store;

    /**
     * Creates a mapping which synchronizes on the specified lock object.
     *
     * @param lock the object to synchronize on, or <code>null</code> to
     * lock on this instance of <code>ValueMap</code>.
     */
    public ValueMap(Object lock) {
        this.lock = (lock == null) ? this : lock;
        store = new Store(true);
    }

    /**
     * Creates a mapping that locks on this instance of
     * <tt>ValueMap</tt>.
     */
	public ValueMap() {
        this(null);
	}

    /**
     * Returns the object used for synchronization. This <i>may</i> or
     * <i>may not</i> be the instance of <code>ValueMap</code>.
     */
    public Object getLockObject() {
        return lock;
    }

    /**
     * Returns true if the keys for this ValueMap are case-sensitive.
     * The default is true if {@link #setCaseSensitive(boolean)} has never
     * been called.
     */
    public boolean isCaseSensitive() {
        synchronized ( lock ) {
            return store.isCaseSensitive();
        }
    }

    /**
     * Specifies whether or not they keys should be treated as case-sensitive
     * or not.
     * If {@link #isCaseSensitive()} returns true and then this method is
     * called with false, then it is possible that some entries will
     * disappear if the only difference was the case of the keys.
     */
    public void setCaseSensitive(boolean caseSensitive) {
        synchronized ( lock ) {
            store.setCaseSensitive(caseSensitive);
        }
    }

    /**
     * Returns the number of entries in this <tt>ValueMap</tt>.
     */
    public int getSize() {
        synchronized ( lock ) {
            return store.getSize();
        }
    }

    /**
     * Stores (and possibly replaces) a key-value pair.
     *
     * @param key the name to use for subsequent retrieval of the value. If
     *            <tt>key</tt> is <tt>null</tt> or a zero-length
     *            <tt>String</tt>, a {@link ValueMapException} is
     *            thrown. Leading and trailing whitespace on the key is NOT
     *            trimmed before storage (using keys with leading and trailing
     *            whitespace is highly discouraged anyway).
     * @param value the value mapped to the specified key. If the specified
     *            <tt>value</tt> reference is <tt>null</tt>, a
     *            {@link Value} will be created to wrap the <tt>null</tt>
     *            [specifically, {@link ValueFactory#NULL_INSTANCE} is stored].
     * @return old value stored under the key, or plain <tt>null</tt> if
     *         nothing was previously stored.
     * @throws ValueMapException if key is <tt>null</tt>
     *          or a zero-length <tt>String</tt>.
     */
    public Value put(String key, Value value) throws ValueMapException {
        if ( StringTools.isEmpty(key) ) {
            throw new ValueMapException("Key can not be empty");
        }

        if ( value == null ) {
            value = ValueFactory.NULL_INSTANCE;
        }

        synchronized ( lock ) {
            return store.put(key, value);
        }
    }

    /**
     * Stores (and possibly replaces) a key-value pair.
     *
     * @param key the name to use for subsequent retrieval of the value. If
     *            <tt>key</tt> is <tt>null</tt> or a zero-length
     *            <tt>String</tt>, a {@link ValueMapException} is
     *            thrown. Leading and trailing whitespace on the key is NOT
     *            trimmed before storage (using keys with leading and trailing
     *            whitespace is highly discouraged anyway).
     * @param value the value mapped to the specified key. If the specified
     *            <tt>value</tt> reference is <tt>null</tt>, a
     *            {@link Value} will be created to wrap the <tt>null</tt>
     *            [specifically, {@link ValueFactory#NULL_INSTANCE} is stored].
     * @return old value stored under the key, or plain <tt>null</tt> if
     *         nothing was previously stored.
     * @throws ValueMapException if key is <tt>null</tt>
     *          or a zero-length <tt>String</tt>.
     */
    public Value put(String key, String value) throws ValueMapException {
        return put(key, ValueFactory.create(value));
    }

    /**
     * Stores (and possibly replaces) a key-value pair.
     *
     * @param key the name to use for subsequent retrieval of the value. If
     *            <tt>key</tt> is <tt>null</tt> or a zero-length
     *            <tt>String</tt>, a {@link ValueMapException} is
     *            thrown. Leading and trailing whitespace on the key is NOT
     *            trimmed before storage (using keys with leading and trailing
     *            whitespace is highly discouraged anyway).
     * @param value the value mapped to the specified key. If the specified
     *            <tt>value</tt> reference is <tt>null</tt>, a
     *            {@link Value} will be created to wrap the <tt>null</tt>
     *            [specifically, {@link ValueFactory#NULL_INSTANCE} is stored].
     * @return old value stored under the key, or plain <tt>null</tt> if
     *         nothing was previously stored.
     * @throws ValueMapException if key is <tt>null</tt>
     *          or a zero-length <tt>String</tt>.
     */
    public Value put(String key, Number value) throws ValueMapException {
        return put(key, ValueFactory.create(value));
    }

    /**
     * Stores (and possibly replaces) a key-value pair.
     *
     * @param key the name to use for subsequent retrieval of the value. If
     *            <tt>key</tt> is <tt>null</tt> or a zero-length
     *            <tt>String</tt>, a {@link ValueMapException} is
     *            thrown. Leading and trailing whitespace on the key is NOT
     *            trimmed before storage (using keys with leading and trailing
     *            whitespace is highly discouraged anyway).
     * @param value the value mapped to the specified key.
     * @return old value stored under the key, or plain <tt>null</tt> if
     *         nothing was previously stored.
     * @throws ValueMapException if key is <tt>null</tt>
     *          or a zero-length <tt>String</tt>.
     */
    public Value put(String key, int value) throws ValueMapException {
        return put(key, ValueFactory.create(value));
    }

    /**
     * Stores (and possibly replaces) a key-value pair.
     *
     * @param key the name to use for subsequent retrieval of the value. If
     *            <tt>key</tt> is <tt>null</tt> or a zero-length
     *            <tt>String</tt>, a {@link ValueMapException} is
     *            thrown. Leading and trailing whitespace on the key is NOT
     *            trimmed before storage (using keys with leading and trailing
     *            whitespace is highly discouraged anyway).
     * @param value the value mapped to the specified key.
     * @return old value stored under the key, or plain <tt>null</tt> if
     *         nothing was previously stored.
     * @throws ValueMapException if key is <tt>null</tt>
     *          or a zero-length <tt>String</tt>.
     */
    public Value put(String key, long value) throws ValueMapException {
        return put(key, ValueFactory.create(value));
    }

    /**
     * Stores (and possibly replaces) a key-value pair. If the <tt>Object</tt>
     * passed in is actually a reference to a <tt>Value</tt>, then the
     * passed parameter is NOT wrapped in a <tt>Value</tt> (no double-wrapping).
     * If it is any other type, the <tt>ValueFactory</tt> is used to create
     * a <tt>Value</tt> for storing.
     *
     * @param key the name to use for subsequent retrieval of the value. If
     *            <tt>key</tt> is <tt>null</tt> or a zero-length
     *            <tt>String</tt>, a {@link ValueMapException} is
     *            thrown. Leading and trailing whitespace on the key is NOT
     *            trimmed before storage (using keys with leading and trailing
     *            whitespace is highly discouraged anyway).
     * @param value the value mapped to the specified key.
     * @return old value stored under the key, or plain <tt>null</tt> if
     *         nothing was previously stored.
     * @throws ValueMapException if key is <tt>null</tt>
     *          or a zero-length <tt>String</tt>.
     */
    public Value put(String key, Object value) throws ValueMapException {
        if ( value instanceof Value ) {
            return put(key, (Value) value);
        } else {
            return put(key, ValueFactory.create(value));
        }
    }

    /**
     * Adds an entry to the map. Format of passed parameter is expected to be:
     * <pre>
     *    key=value
     * </pre>
     * String supplied is treated like a line in a source file as described
     * in the general class description for this class.
     */
    public Value putPair(String keyValuePair) throws ValueMapException {
        // all leading and trailing WS is ignored
        String line = keyValuePair.trim();

        int idx = line.indexOf('=');
        if ( idx == -1 ) {
            throw new ValueMapException(
                "'" + keyValuePair +
                "' does not have an '=' present.");
        }

        String key = line.substring(0, idx).trim();
        String stringValue = (idx == (line.length() - 1)) ? "" :
                             line.substring(idx + 1).trim();

        return put(key, ValueFactory.create(stringValue, stringValue));
    }

    /**
     * Copies all of the key-value pairs from the specified source
     * <tt>ValueMap</tt> into this <tt>ValueMap</tt>. Note that the
     * values themselves are not cloned, but that the references are
     * simply also stored into this <tt>ValueMap</tt>.
     * <p>
     * During the copy, the <tt>source</tt>'s lock is held to prohibit
     * modification to the <tt>source</tt>.
     */
    public void putAll(ValueMap source) {
        putAll(null, source);
    }

    /**
     * Copies all of the key-value pairs from the specified source
     * <tt>ValueMap</tt> into this <tt>ValueMap</tt> prefixing each
     * key with the specified <tt>nestedMapPrefix</tt>. Note that the
     * values themselves are not cloned, but that the references are
     * simply also stored into this <tt>ValueMap</tt>.
     * <p>
     * During the copy, the <tt>source</tt>'s lock is held to prohibit
     * modification to the <tt>source</tt>.
     *
     * @param nestedMapPrefix the prefix to add to each of the keys
     * in the source map before putting into this map. If null, or empty
     * then no prefix is added.
     */
    public void putAll(String nestedMapPrefix, ValueMap source) {
        ValueEntry[] sourceEntries = ValueEntry.ZERO_LEN_ARRAY;
        synchronized ( source.lock ) {
            sourceEntries = source.store.getAllValueEntries();
        }

        synchronized ( lock ) {
            boolean hasPrefix = StringTools.isNotEmpty(nestedMapPrefix);
            for ( ValueEntry sourceEntry : sourceEntries ) {
                if ( hasPrefix ) {
                    store.put(nestedMapPrefix + sourceEntry.realKey,
                        sourceEntry.value);
                } else {
                    store.put(sourceEntry);
                }
            }
        }
    }

    /**
     * Returns <tt>true</tt> if a {@link Value} is currently stored for the
     * specified key.
     * Any leading or trailing whitespace is first trimmed off of
     * the specified key.
     */
    public boolean containsKey(String key) {
        synchronized ( lock ) {
            return store.containsKey(StringTools.trim(key));
        }
    }

    /**
     * Returns <tt>true</tt> if the specified key is <i>not</i> present
     * in this map.
     * Any leading or trailing whitespace is first trimmed off of
     * the specified key.
     * Equivalent to:
     * <pre>
     * return <b>!</b>{@link #containsKey(String) containsKey}(key);
     * </pre>
     */
    public boolean doesNotContainKey(String key) {
        return !containsKey(key);
    }

    /**
     * Returns true if there are currently <i>any</i> keys that start with the
     * specified prefix.
     * Any leading or trailing whitespace is first trimmed off of
     * the specified prefix.
     */
    public boolean containsAnyKeyWithPrefix(String prefix) {
        prefix = StringTools.trim(prefix);

        String[] keys = null;
        synchronized ( lock ) {
            keys = store.getAllKeys();
        }

        for ( int i = 0; i < keys.length; i++ ) {
            if ( keys[i].startsWith(prefix) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Removes the key-value pair stored under the specified key.
     *
     * @param key the key to use for lookup.
     * @return the {@link Value} previously stored, or <tt>null</tt> if
     * no match was found for the specified key.
     */
    public Value remove(String key) {
        synchronized ( lock ) {
            return store.remove(key);
        }
    }

    /**
     * Retrieves the {@link Value} mapped to the specified <tt>key</tt> or
     * <tt>null</tt> if there is no such key.
     * This method does not alter the mapping.
     *
     * @param key the key to use for lookup.
     * @return the {@link Value} mapped to the specified key, or <tt>null</tt>
     * if nothing has been stored under the key.
     */
	public Value get(String key) {
        synchronized ( lock ) {
            return store.get(key);
        }
	}

    /**
     * Returns the {@link Value} mapped to the specified <tt>key</tt> or
     * if nothing is mapped to the key, <tt>defaultValue</tt> is returned.
     * This method <i>never</i> returns <tt>null</tt> and this method does not
     * complain if the specified key is not found.
     *
     * @param key the key to use for lookup.
     * @param defaultValue the {@link Value} to return is there is no
     * mapping for the specified <tt>key</tt>.
     * @return the {@link Value} mapped to the specified key, or
     * <tt>defaultValue</tt> if nothing has been stored under the key.
     * <i>Never</i> returns <tt>null</tt> (unless of course, the passed
     * <tt>defaultValue</tt> is <tt>null</tt>!).
     */
	public Value getOptional(String key, Value defaultValue) {
        synchronized ( lock ) {
    		Value value = store.get(key);
    		return (value == null) ? defaultValue : value;
        }
	}

	/**
     * Returns the {@link Value} mapped to the specified <tt>key</tt> or
     * if nothing is mapped to the key,
     * {@link ValueMapRequiredKeyException} is thrown.
     * This method <i>never</i> returns <tt>null</tt>: either a <tt>Value</tt>
     * is returned, or an exception is thrown if the specified key is not found.
     * The {@link #containsKey containsKey(String key)} method can be used to
     * test before calling this method.
     *
     * @param key the required key to use for lookup.
     * @return the {@link Value} mapped to the specified key.
     * <i>Never</i> returns <tt>null</tt>.
	 * @throws ValueMapRequiredKeyException if the mapping does not
     * have a value stored for the specified key.
	 */
    public Value getRequired(String key)
            throws ValueMapRequiredKeyException {

        synchronized ( lock ) {
            Value value = store.get(key);
            if ( value == null ) {
                throw new ValueMapRequiredKeyException(key);
            }

            return value;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * <tt>String</tt>. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getString() getString}();
     * </pre>
     */
    public String getString(String key)
            throws ValueMapRequiredKeyException {

        return getRequired(key).getString();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * <tt>String</tt>. If the specified key does not exist, the specified
     * <tt>defaultValue</tt> is returned. Equivalent to:
     * <pre class="preshade">
     * if ( {@link #containsKey containsKey}(key) ) {
     *     return {@link #get get}(key).{@link Value#getString getString}();
     * } else {
     *     return defaultValue;
     * }
     * </pre>
     */
    public String getString(String key, String defaultValue) {
        Value value = get(key);
        if ( value == null ) {
            return defaultValue;
        } else {
            return value.getString();
        }
    }

    /**
     * Returns the value stored under the specified required key as an
     * <tt>Object</tt>. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the key does exist, but the {@link Value} stored under
     * it encapsulates <tt>null</tt> or an object of a type that can not be
     * cast into the specified <tt>type</tt>, a {@link ValueException} is
     * thrown. Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getObject() getObject}();
     * </pre>
     */
    public <T> T getObject(String key, Class<T> type)
            throws ValueMapRequiredKeyException, ValueException {

        return getRequired(key).getObject(type);
    }

    /**
     * Returns the value stored under the specified optional key as an
     * <tt>Object</tt>. If the specified key does not exist, the specified
     * <tt>defaultValue</tt> is returned.
     * If the key does exist, but the {@link Value} stored under
     * it encapsulates <tt>null</tt> or an object of a type that can not be
     * cast into the specified <tt>type</tt>, the specified
     * <tt>defaultValue</tt> is returned.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #containsKey containsKey}(key) ) {
     *     Value value = get(key);
     *     if ( value.{@link Value#isType(Class) isType}(type) ) {
     *         return value.getObject();
     *     }
     * }
     * return defaultValue;
     * </pre>
     */
    @SuppressWarnings("unchecked")
    public <T> T getObject(String key, Class<T> type, T defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotType(type) ) {
            return defaultValue;
        } else {
            return (T) value.getObject();
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * {@link Number}. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>Number</tt>, then <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getNumber() getNumber}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link Value#getNumber
     * getNumber()} method on {@link Value} if the looked up value can't be
     * interpreted as a <tt>Number</tt>.
     */
    public Number getNumber(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getNumber();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * {@link Number}. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>Number</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getNumber(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public Number getNumber(String key, Number defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getNumber();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * {@link BigDecimal}. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>BigDecimal</tt>, then <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getBigDecimal() getBigDecimal}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the
     * {@link Value#getBigDecimal getBigDecimal()} method on {@link Value}
     * if the looked up value can't be interpreted as a <tt>BigDecimal</tt>.
     */
    public BigDecimal getBigDecimal(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getBigDecimal();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * {@link BigDecimal}. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>BigDecimal</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getBigDecimal(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public BigDecimal getBigDecimal(String key, BigDecimal defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getBigDecimal();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * <tt>long</tt>. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>long</tt>, the <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getLong() getLong}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link Value#getLong
     * getLong()} method on {@link Value} if the looked up value can't be
     * interpreted as a <tt>long</tt>.
     */
    public long getLong(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getLong();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * <tt>long</tt>. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>long</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getLong(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public long getLong(String key, long defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getLong();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * {@link Long}. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>Long</tt>, the <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getLongNumber() getLongNumber}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link
     * Value#getLongNumber getLongNumber()} method on {@link Value}
     * if the looked up value can't be
     * interpreted as a <tt>Long</tt>.
     */
    public Long getLongNumber(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getLongNumber();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * {@link Long}. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>Long</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getLongNumber(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public Long getLongNumber(String key, Long defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getLongNumber();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as an
     * <tt>int</tt>. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as an
     * <tt>int</tt>, the <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getInt() getInt}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link Value#getInt
     * getInt()} method on {@link Value} if the looked up value can't be
     * interpreted as an <tt>int</tt>.
     */
    public int getInt(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getInt();
    }

    /**
     * Returns the value stored under the specified optional key as an
     * <tt>int</tt>. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as an <tt>int</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getInt(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public int getInt(String key, int defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getInt();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as an
     * {@link Integer}. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as an
     * <tt>Integer</tt>, the <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getIntegerNumber() getIntegerNumber}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link
     * Value#getIntegerNumber getIntegerNumber()} method on {@link Value}
     * if the looked up value can't be interpreted as an <tt>Integer</tt>.
     */
    public Integer getIntegerNumber(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getIntegerNumber();
    }

    /**
     * Returns the value stored under the specified optional key as an
     * {@link Integer}. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as an <tt>Integer</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getIntegerNumber(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public Integer getIntegerNumber(String key, Integer defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getIntegerNumber();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * <tt>double</tt>. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>double</tt>, the <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getDouble() getDouble}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link Value#getDouble
     * getDouble()} method on {@link Value} if the looked up value can't be
     * interpreted as a <tt>double</tt>.
     */
    public double getDouble(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getDouble();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * <tt>double</tt>. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>double</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getDouble(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public double getDouble(String key, double defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getDouble();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as an
     * {@link Double}. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as an
     * <tt>Double</tt>, then <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getDoubleNumber() getDoubleNumber}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link
     * Value#getDoubleNumber getDoubleNumber()} method on {@link Value}
     * if the looked up value can't be interpreted as an <tt>Double</tt>.
     */
    public Double getDoubleNumber(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getDoubleNumber();
    }

    /**
     * Returns the value stored under the specified optional key as an
     * {@link Double}. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as an <tt>Double</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getDoubleNumber(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public Double getDoubleNumber(String key, Double defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getDoubleNumber();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * <tt>float</tt>. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>float</tt>, the <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getFloat() getFloat}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link Value#getFloat
     * getFloat()} method on {@link Value} if the looked up value can't be
     * interpreted as a <tt>float</tt>.
     */
    public float getFloat(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getFloat();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * <tt>float</tt>. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>float</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getFloat(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public float getFloat(String key, float defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getFloat();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as an
     * {@link Float}. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as an
     * <tt>Float</tt>, then <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getFloatNumber() getFloatNumber}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link
     * Value#getFloatNumber getFloatNumber()} method on {@link Value}
     * if the looked up value can't be interpreted as an <tt>Float</tt>.
     */
    public Float getFloatNumber(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getFloatNumber();
    }

    /**
     * Returns the value stored under the specified optional key as an
     * {@link Float}. If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as an <tt>Float</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getFloatNumber(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public Float getFloatNumber(String key, Float defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotNumeric() ) {
            return defaultValue;
        }

        try {
            return value.getFloatNumber();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * <tt>boolean</tt>. If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#isTrue() isTrue}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     */
    public boolean isTrue(String key)
            throws ValueMapRequiredKeyException {

        return getRequired(key).isTrue();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * <tt>boolean</tt>. If the specified key does not exist,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return isTrue(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public boolean isTrue(String key, boolean defaultValue) {
        Value value = get(key);
        if ( value == null ) {
            return defaultValue;
        }

        return value.isTrue();
    }

    /**
     * Returns the value stored under the specified required key as a
     * {@link TriState}.
     * If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getTriState() getTriState}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     */
    public TriState getTriState(String key)
            throws ValueMapRequiredKeyException {

        return getRequired(key).getTriState();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * {@link TriState}.
     * If the specified key does not exist,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getTriState(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public TriState getTriState(String key, TriState defaultValue) {
        Value value = get(key);
        if ( value == null ) {
            return defaultValue;
        }

        return value.getTriState();
    }

    /**
     * Returns the value stored under the specified required key as a
     * {@link DateTime} (defaulting to the UTC timezone if necessary).
     * If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>DateTime</tt>, then <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getDateTime() getDateTime}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link Value#getDateTime
     * getDateTime()} method on {@link Value} if the looked up value can't be
     * interpreted as a <tt>DateTime</tt>.
     */
    public DateTime getDateTime(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getDateTime();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * {@link DateTime} (defaulting to the UTC timezone if necessary).
     * If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>DateTime</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getDateTime(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public DateTime getDateTime(String key, DateTime defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotDateTime() ) {
            return defaultValue;
        }

        try {
            return value.getDateTime();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * {@link DateTime} (defaulting to the local VM's timezone if necessary).
     * If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>DateTime</tt>, then <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getDateTimeLocal() getDateTimeLocal}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link Value#getDateTime
     * getDateTime()} method on {@link Value} if the looked up value can't be
     * interpreted as a <tt>DateTime</tt>.
     */
    public DateTime getDateTimeLocal(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getDateTimeLocal();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * {@link DateTime} (defaulting to the local VM's timezone if necessary).
     * If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>DateTime</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getDateTime(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public DateTime getDateTimeLocal(String key, DateTime defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotDateTime() ) {
            return defaultValue;
        }

        try {
            return value.getDateTimeLocal();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * {@link DateTime} (defaulting to the specified timezone if necessary).
     * If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>DateTime</tt>, then <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getDateTime(TimeZone) getDateTime}(tz);
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link Value#getDateTime
     * getDateTime()} method on {@link Value} if the looked up value can't be
     * interpreted as a <tt>DateTime</tt>.
     */
    public DateTime getDateTime(String key, TimeZone tz)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getDateTime(tz);
    }

    /**
     * Returns the value stored under the specified optional key as a
     * {@link DateTime} (defaulting to the specified timezone if necessary).
     * If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>DateTime</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getDateTime(key, tz);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public DateTime getDateTime(String key,
                                TimeZone tz,
                                DateTime defaultValue) {

        Value value = get(key);
        if ( value == null || value.isNotDateTime() ) {
            return defaultValue;
        }

        try {
            return value.getDateTime(tz);
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * {@link PlainDate}.
     * If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * If the {@link Value} found can't be interpreted as a
     * <tt>PlainDate</tt>, then <tt>ValueException</tt> is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getPlainDate() getPlainDate}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     * @exception ValueException passed along from the {@link Value#getPlainDate
     * getPlainDate()} method on {@link Value} if the looked up value can't be
     * interpreted as a <tt>PlainDate</tt>.
     */
    public PlainDate getPlainDate(String key)
            throws ValueException, ValueMapRequiredKeyException {

        return getRequired(key).getPlainDate();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * {@link PlainDate}.
     * If the specified key does not exist or if the
     * {@link Value} found can't be interpreted as a <tt>PlainDate</tt>,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getPlainDate(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * } catch ( ValueException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public PlainDate getPlainDate(String key, PlainDate defaultValue) {
        Value value = get(key);
        if ( value == null || value.isNotPlainDate() ) {
            return defaultValue;
        }

        try {
            return value.getPlainDate();
        } catch ( ValueException x ) {
            return defaultValue;
        }
    }

    /**
     * Returns the value stored under the specified required key as a
     * <tt>byte[]</tt>.
     * If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getBytes() getBytes}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     */
    public byte[] getBytes(String key)
            throws ValueMapRequiredKeyException {

        return getRequired(key).getBytes();
    }

    /**
     * Returns the value stored under the specified optional key as a
     * <tt>byte[]</tt>.
     * If the specified key does not exist,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getBytes(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public byte[] getBytes(String key, byte[] defaultValue) {
        Value value = get(key);
        if ( value == null ) {
            return defaultValue;
        }

        return value.getBytes();
    }


    /**
     * Returns the value stored under the specified required key as an
     * {@link InputStream}.
     * If the specified key does not exist, a
     * {@link ValueMapRequiredKeyException} is thrown.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getRequired getRequired}(key).{@link
     *         Value#getBytesAsStream() getBytesAsStream}();
     * </pre>
     * @exception ValueMapRequiredKeyException if the key is
     * not present in this mapping.
     */
    public InputStream getBytesAsStream(String key)
            throws ValueMapRequiredKeyException {

        return getRequired(key).getBytesAsStream();
    }

    /**
     * Returns the value stored under the specified optional key as an
     * {@link InputStream}.
     * If the specified key does not exist,
     * then the specified <tt>defaultValue</tt> is returned.
     * Equivalent to (although it may be implemented more efficiently):
     * <pre class="preshade">
     * try {
     *     return getBytesAsStream(key);
     * } catch ( ValueMapRequiredKeyException x ) {
     *     return defaultValue;
     * }
     * </pre>
     */
    public InputStream getBytesAsStream(String key, InputStream defaultValue) {
        Value value = get(key);
        if ( value == null ) {
            return defaultValue;
        }

        return value.getBytesAsStream();
    }

    /**
     * Returns all the keys in the map in insertion order.
     */
    public String[] getOrderedKeys() {
        synchronized ( lock ) {
            return store.getAllKeys();
        }
    }

    /**
     * Returns a snapshot of all the mappings as a {@link Map}.
     * This is a copy and not connected to the underlying ValueMap.
     */
    public Map<String, Value> getMapView() {
        synchronized ( lock ) {
            return store.getMapSnapshot();
        }
    }

    /**
     * Returns a copy of all the mappings as a {@link Properties}.
     * The <tt>Properties</tt> object returned is a snapshot of the
     * mappings as of the time this method is called&mdash;there is
     * no linkage between this <tt>ValueMap</tt> and the newly created
     * <tt>Properties</tt> object. All keys in this map are already
     * restricted to being only <tt>String</tt>'s. All values in this
     * map are interpreted using {@link #getString(String) getString(key)}
     * to create the <tt>String</tt> to be placed into the <tt>Properties</tt>
     * instance returned.
     */
    public Properties getProperties() {
        ValueEntry[] valueEntries;
        synchronized ( lock ) {
            valueEntries = store.getAllValueEntries();
        }

        Properties prop = new Properties();
        for ( ValueEntry valueEntry : valueEntries ) {
            prop.put(valueEntry.realKey, valueEntry.value.getString());
        }
        return prop;
    }

    /**
     * Returns a new <tt>ValueMap</tt> for all the key/value pairs with
     * the specified key prefix (with the key prefix trimmed off).
     * The {@link Value}'s are <i>shared</i> (not copied) as most
     * implementations of <tt>Value</tt> are immutable (if you have
     * mutable <tt>Value</tt>'s in your map you may need to be careful).
     * If no keys match the prefix, then an empty <tt>ValueMap</tt>
     * (with zero entries) is returned.
     * <p>
     * For example, consider starting with the following file to populate a
     * <tt>ValueMap</tt>:
     * <pre>
     * solar.system.Mercury.diameter=0.38
     * solar.system.Venus.diameter=0.95
     * solar.system.Earth.diameter=1.00
     * solar.system.Mars.diameter=0.53
     * solar.system.Jupiter.diameter=11.2
     * solar.system.Mercury.mass=0.06
     * solar.system.Venus.mass=0.82
     * solar.system.Earth.mass=1.00
     * solar.system.Mars.mass=0.11
     * solar.system.Jupiter.mass=318
     * solar.system.Mercury.moon.count=0
     * solar.system.Venus.moon.count=0
     * solar.system.Earth.moon.count=1
     * solar.system.Mars.moon.count=2
     * solar.system.Jupiter.moon.count=63
     * country.usa.full.name=United States
     * country.usa.capital=Washington, DC
     * country.can.full.name=Canada
     * country.can.capital=Ottawa
     * country.gbr.full.name=United Kingdom
     * country.gbr.capital=London
     * country.swe.full.name=Sweden
     * country.swe.capital=Stockholm
     * country.nor.full.name=Norway
     * country.nor.capital=Oslo
     * country.che.full.name=Switzerland
     * country.che.capital=Bern
     * </pre>
     * The new <tt>ValueMap</tt> created by:
     * <pre>
     * ValueMap countryMap = map.getNestedValueMap("country.");
     * </pre>
     * would be:
     * <pre>
     * usa.full.name=United States
     * usa.capital=Washington, DC
     * can.full.name=Canada
     * can.capital=Ottawa
     * gbr.full.name=United Kingdom
     * gbr.capital=London
     * swe.full.name=Sweden
     * swe.capital=Stockholm
     * nor.full.name=Norway
     * nor.capital=Oslo
     * che.full.name=Switzerland
     * che.capital=Bern
     * </pre>
     * from that map, if someone did this:
     * <pre>
     * ValueMap usaMap = countryMap.getNestedValueMap("usa.");
     * </pre>
     * the result would be:
     * <pre>
     * full.name=United States
     * capital=Washington, DC
     * </pre>
     * <p>
     * Going back to the original, the new <tt>ValueMap</tt> created by:
     * <pre>
     * ValueMap solarMap = map.getNestedValueMap("solar.system.");
     * </pre>
     * would be:
     * <pre>
     * Mercury.diameter=0.38
     * Venus.diameter=0.95
     * Earth.diameter=1.00
     * Mars.diameter=0.53
     * Jupiter.diameter=11.2
     * Mercury.mass=0.06
     * Venus.mass=0.82
     * Earth.mass=1.00
     * Mars.mass=0.11
     * Jupiter.mass=318
     * Mercury.moon.count=0
     * Venus.moon.count=0
     * Earth.moon.count=1
     * Mars.moon.count=2
     * Jupiter.moon.count=63
     * </pre>
     * from that map, if someone did this:
     * <pre>
     * ValueMap marsMap = solarMap.getNestedValueMap("Mars.");
     * </pre>
     * the result would be:
     * <pre>
     * diameter=0.53
     * mass=0.11
     * moon.count=2
     * </pre>
     *
     * @param keyPrefix specifies the subset of keys to match. Matched keys
     * must start with this prefix and then must have at least one remaining
     * character.
     */
    public ValueMap getNestedValueMap(String keyPrefix) {
        ValueEntry[] valueEntries;
        ValueMap newMap = new ValueMap();
        synchronized ( lock ) {
            valueEntries = store.getAllValueEntries();
            newMap.setCaseSensitive(isCaseSensitive());
        }

        synchronized ( newMap.lock ) {
            String prefix = StringTools.trim(keyPrefix);
            String prefixLowerCase = prefix.toLowerCase();
            int prefixLen = prefix.length();
            boolean caseSensitive = newMap.isCaseSensitive();

            for ( ValueEntry valueEntry : valueEntries ) {
                String fullRealKey = valueEntry.realKey;
                Value value = valueEntry.value;

                if ( fullRealKey.length() > prefixLen ) {
                    boolean match = false;
                    if ( caseSensitive ) {
                        match = fullRealKey.startsWith(prefix);
                    } else {
                        match = valueEntry.lowerCaseKey.startsWith(
                            prefixLowerCase);
                    }

                    if ( match ) {
                        String subKey = fullRealKey.substring(prefixLen).trim();
                        if ( subKey.length() > 0 ) {
                            newMap.store.put(subKey, value);
                        }
                    }
                }
            }
        }
        return newMap;
    }

    /**
     * Returns a single-line textual approximation of values currently
     * stored. To get in a multi-line format, call {@link #toStringMultiLine()}.
     * The returned string looks something like:
     * <pre>
     *   "{key1=value1, key2=value2, key3=, key4=value4}"
     * </pre>
     */
    @Override
    public String toString() {
        synchronized ( lock ) {
            StringBuilder sb = new StringBuilder();
            sb.append("{");
            boolean firstEntry = true;

            for ( ValueEntry valueEntry : store.getAllValueEntries() ) {
                if ( firstEntry ) {
                    firstEntry = false;
                } else {
                    sb.append(", ");
                }

                formatEntry(sb, valueEntry);
            }

            sb.append("}");
            return sb.toString();
        }
    }

    /**
     * Returns a multi-line textual approximation of values currently
     * stored as they would be written by {@link #writeTo(BufferedWriter)}.
     * To get in a single-line format, call {@link #toString()}.
     */
    public String toStringMultiLine() {
        StringWriter sw = new StringWriter();
        writeTo(sw);
        return sw.toString();
    }

    private static void formatEntry(StringBuilder sb,
                                    ValueEntry valueEntry) {

        sb.append(valueEntry.realKey);
        sb.append('=');

        Value value = valueEntry.value;
        if ( value.isEmpty() ) {
            // nothing--zero length string for empty
        } else if ( value.isTypeDateTime() ) {
            sb.append(DateTools.formatUTC(
                DateTimeFormat.YMD_HMSF_DASH, value.getDateTime()));
        } else if ( value.isTypeByteArray() ) {
            sb.append("byte[] with length=" +
                value.getBytes().length);
        } else {
            sb.append(value.getString());
        }
    }

    private static String formatEntry(ValueEntry valueEntry) {
        StringBuilder sb = new StringBuilder();
        formatEntry(sb, valueEntry);
        return sb.toString();
    }

    /**
     * Writes the contents of the <tt>ValueMap</tt> out to the specified
     * stream as text in key=value format. Note that not all values can be
     * properly represented in <tt>String</tt> form. Note also that the stream
     * is flushed and closed by this method.
     *
     * @param out destination for the key=value pairs.
     * @throws ValueMapException if there are any troubles writing out to the
     *             stream.
     */
    public void writeTo(BufferedWriter out) throws ValueMapException {
        try {
            synchronized ( lock ) {
                for ( ValueEntry valueEntry : store.getAllValueEntries() ) {
                    out.write(formatEntry(valueEntry));
                    out.newLine();
                }

                out.flush();
            }
        } catch ( IOException x ) {
            throw new ValueMapException(x);
        } finally {
            IOTools.closeQuietly(out);
        }
    }

    public void writeTo(Writer out) throws ValueMapException {
        if ( out instanceof BufferedWriter ) {
            writeTo((BufferedWriter) out);
        } else {
            writeTo(new BufferedWriter(out));
        }
    }

    public void writeTo(OutputStream out) throws ValueMapException {
        writeTo(IOTools.createBufferedWriter(out));
    }

    public void writeTo(File file) throws ValueMapException {
        try {
            writeTo(IOTools.createBufferedWriter(file));
        } catch ( IOException x ) {
            throw new ValueMapException(x);
        }
    }

    public void writeToFile(String filename) throws ValueMapException {
        try {
            writeTo(IOTools.createBufferedWriterToFile(filename));
        } catch ( IOException x ) {
            throw new ValueMapException(x);
        }
    }

    /**
     * Copies the entries from the specified {@link Map} into a new
     * <tt>ValueMap</tt>. Each key in the map is passed to the
     * {@link String#valueOf(Object)} method
     * to generate the string-based key
     * needed by <tt>ValueMap</tt>. Each value is simply passed to
     * {@link ValueFactory#create(Object) create(Object obj)} method on
     * {@link ValueFactory}.
     * @param map source of key/value pairs
     * @return a new instance with copies of the data in the <tt>map</tt>.
     * @throws ValueMapException
     */
    public static ValueMap createFrom(Map<?, ?> map) {
        ValueMap svm = new ValueMap();

        for ( Map.Entry<?, ?> entry : map.entrySet() ) {
            svm.put(String.valueOf(entry.getKey()),
                ValueFactory.create(entry.getValue()));
        }

        return svm;
    }

    /**
     * Creates a mapping from the specified data source. Stream is
     * read until the end, at which point the stream is closed.
     * Even on an exception condition, the stream is closed.
     *
     * @param in source of data; always closed by this method.
     * @return a new mapping derived from the data in the stream.
     * @throws ValueMapException if there are problems reading
     * from the stream, or if an line it improperly formatted.
     */
    public static ValueMap createFrom(BufferedReader in)
            throws ValueMapException {

        ValueMap map = new ValueMap();

        try {
            String line = null;
            int lineCount = 0;
            StringBuilder partialLine = new StringBuilder();
            while ( (line = in.readLine() ) != null ) {
                lineCount++;
                line = line.trim();  // all leading and trailing WS is ignored

                if ( line.length() == 0 || line.charAt(0) == '#' ) {
                    // blank line or comment, go to the next line
                    continue;
                }

                if ( line.charAt(line.length() - 1) == BACKSLASH ) {
                    // first see how many backslashes are present...if two
                    // then just change to one and proceed. If just one,
                    // then the next line should be concated to this line.

                    if ( line.length() >= 2 &&
                         line.charAt(line.length() - 2) == BACKSLASH ) {

                        // clip off one of two backslashes
                        line = line.substring(0, line.length() - 1);
                    } else {
                        // just one, this indicates that it should be
                        // continued with the next line
                        partialLine.append(
                            line.substring(0, line.length() - 1));
                        continue;
                    }
                }

                if ( partialLine.length() > 0 ) {
                    line = partialLine.append(line).toString();
                    partialLine.setLength(0);
                }

                int idx = line.indexOf('=');
                if ( idx == -1 ) {
                    throw new ValueMapException(
                        "Line " + lineCount +
                        " does not have an '=' present, line: " + line);
                }

                String key = line.substring(0, idx).trim();
                String stringValue = (idx == (line.length() - 1)) ? "" :
                                     line.substring(idx + 1).trim();

                map.put(key, ValueFactory.create(stringValue, stringValue));
            }

            return map;
        } catch ( IOException x ) {
            throw new ValueMapException(x);
        } finally {
            IOTools.closeQuietly(in);
        }
    }

    /**
     * Creates a mapping from the specified data source. Stream is
     * read until the end, at which point the stream is closed.
     * Even on an exception condition, the stream is closed.
     *
     * @param rawIn source of data; always closed by this method.
     * @return a new mapping derived from the data in the stream.
     * @throws ValueMapException if there are problems reading
     * from the stream, or if an line it improperly formatted.
     */
    public static ValueMap createFrom(Reader rawIn)
            throws ValueMapException {

        return createFrom(new BufferedReader(rawIn));
    }

    public static ValueMap createFrom(InputStream rawIn)
            throws ValueMapException {

        return createFrom(IOTools.createBufferedReader(rawIn));
    }

    public static ValueMap createFrom(File source)
            throws ValueMapException {

        try {
            return createFrom(IOTools.createBufferedReader(source));
        } catch ( IOException x ) {
            throw new ValueMapException(x);
        }
    }

    public static ValueMap createFromFile(String sourceFilename)
            throws ValueMapException {

        try {
            return createFrom(
                IOTools.createBufferedReaderFromFile(sourceFilename));
        } catch ( IOException x ) {
            throw new ValueMapException(x);
        }
    }

    public static ValueMap createFrom(URL source)
            throws ValueMapException {

        try {
            return createFrom(IOTools.createBufferedReader(source));
        } catch ( IOException x ) {
            throw new ValueMapException(x);
        }
    }

    public static ValueMap createFromResource(String resourceLocation,
                                              Class<?> searchStartPoint)
            throws ValueMapException {

        try {
            return createFrom(
                IOTools.createBufferedReaderFromResource(
                    resourceLocation, searchStartPoint));
        } catch ( IOException x ) {
            throw new ValueMapException(x);
        }
    }

    public static ValueMap createFromResource(String resourceLocation)
            throws ValueMapException {

        try {
            return createFrom(
                IOTools.createBufferedReaderFromResource(resourceLocation));
        } catch ( IOException x ) {
            throw new ValueMapException(x);
        }
    }

    private static class Store implements Serializable {
        private final Map<String, ValueEntry> map;
        private boolean caseSensitive;

        public Store(boolean caseSensitive) {
            this.caseSensitive = caseSensitive;
            map = new LinkedHashMap<String, ValueEntry>();
        }

        private String calcKey(String key) {
            if ( key == null ) {
                return null;
            } else if ( caseSensitive ) {
                return key;
            } else {
                return key.toLowerCase();
            }
        }

        private String calcKey(ValueEntry valueEntry) {
            return caseSensitive ? valueEntry.realKey : valueEntry.lowerCaseKey;
        }

        private Value calcValue(ValueEntry valueEntry) {
            return valueEntry == null ? null : valueEntry.value;
        }

        public boolean isCaseSensitive() {
            return caseSensitive;
        }

        public void setCaseSensitive(boolean newCaseSensitive) {
            if ( newCaseSensitive != caseSensitive ) {
                ValueEntry[] oldEntries = getAllValueEntries();
                map.clear();
                this.caseSensitive = newCaseSensitive;
                for ( ValueEntry oldEntry : oldEntries ) {
                    put(oldEntry);
                }
            }
        }

        public boolean containsKey(String key) {
            return map.containsKey(calcKey(key));
        }

        public Value get(String key) {
            return calcValue(map.get(calcKey(key)));
        }

        public Value put(ValueEntry valueEntry) {
            return calcValue(map.put(calcKey(valueEntry), valueEntry));
        }

        public Value put(String rawKey, Value value) {
            return put(new ValueEntry(rawKey, value));
        }

        public Value remove(String key) {
            return calcValue(map.remove(calcKey(key)));
        }

        public int getSize() {
            return map.size();
        }

        public boolean isEmpty() {
            return map.isEmpty();
        }

        public String[] getAllKeys() {
            return StringTools.toArray(map.keySet());
        }

        public ValueEntry[] getAllValueEntries() {
            return map.values().toArray(ValueEntry.ZERO_LEN_ARRAY);
        }

        public Map<String, Value> getMapSnapshot() {
            Map<String, Value> copy = new LinkedHashMap<String, Value>();
            for ( ValueEntry valueEntry : map.values() ) {
                copy.put(valueEntry.realKey, valueEntry.value);
            }
            return copy;
        }
    } // class Store

    private static class ValueEntry implements Serializable {
        public static final ValueEntry[] ZERO_LEN_ARRAY = new ValueEntry[0];

        public final String realKey;
        public final String lowerCaseKey;
        public final Value value;

        public ValueEntry(String realKey, Value value) {
            this.realKey = realKey;
            this.lowerCaseKey = realKey.toLowerCase();
            this.value = value;
        }
    } // class ValueEntry
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.