package com.programix.value;

/**
 * A special kind of {@link ValueMapException} used to indicate that a 
 * <i>required key</i> was not found in a {@link ValueMap}.
 * This is a {@link RuntimeException}, so it can be generally ignored 
 * when it is unexpected 
 * (use of <tt>try</tt>/<tt>catch</tt> is not <i>required</i>).
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ValueMapRequiredKeyException extends ValueMapException {
    private final String keyName;

    /**
     * Pass in the name of the expected key. The resulting message is generated
     * from this:
     * <pre>
     *     "Required key '" + keyName + "' not found."
     * </pre>
     * The {@link #getKeyName()} method can be used to retrieve the exact key
     * name if desired.
     */
    public ValueMapRequiredKeyException(String keyName) {
        super("Required key '" + keyName + "' not found.");
        this.keyName = keyName;
    }
    
    public String getKeyName() {
        return keyName;
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.