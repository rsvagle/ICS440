package com.programix.value;

import java.io.*;
import java.math.*;
import java.util.*;

import com.programix.math.*;
import com.programix.time.*;
import com.programix.util.*;

/**
 * Used to create instances classes that implement the {@link Value}
 * interface. All implementations returned are {@link Serializable},
 * as long as the <tt>Object</tt> passed in is also <tt>Serializable</tt>.
 */
public class ValueFactory {
    /**
     * A fixed, shareable <tt>Value</tt> that represents an internal value
     * of <tt>null</tt>. Specifically, results of calling these methods on
     * {@link Value} are:
     * <ul>
     * <li>{@link Value#isNull isNull()} always returns <tt>true</tt>.</li>
     * <li>{@link Value#isEmpty isEmpty()} always returns <tt>true</tt>.</li>
     * <li>{@link Value#isNumeric isNumeric()} always returns
     * <tt>false</tt>.</li>
     * <li>{@link Value#isDateTime isDateTime()} always returns
     * <tt>false</tt>.</li>
     * <li>{@link Value#getString getString()} always returns <tt>""</tt>.</li>
     * <li>{@link Value#getRawString getRawString()} always
     * returns <tt>""</tt>.</li>
     * </ul>
     */
    public static final Value NULL_INSTANCE = new NullValue();

    /**
     * A fixed, shareable <tt>Value</tt> that represents an internal value
     * of a zero-length <tt>String</tt>.
     * Specifically, results of calling these methods on {@link Value} are:
     * <ul>
     * <li>{@link Value#isNull isNull()} always returns <tt>false</tt>.</li>
     * <li>{@link Value#isEmpty isEmpty()} always returns <tt>true</tt>.</li>
     * <li>{@link Value#isNumeric isNumeric()} always returns
     * <tt>false</tt>.</li>
     * <li>{@link Value#isDateTime isDateTime()} always returns
     * <tt>false</tt>.</li>
     * <li>{@link Value#getString getString()} always returns <tt>""</tt>.</li>
     * <li>{@link Value#getRawString getRawString()} always
     * returns <tt>""</tt>.</li>
     * </ul>
     */
    public static final Value ZERO_LEN_STRING_INSTANCE =
        new ZeroLenStringValue();

    private static final String ZERO_LEN_STRING = StringTools.ZERO_LEN_STRING;
    private static final byte[] ZERO_LEN_BYTE_ARRAY = new byte[0];

    // private --no instances
    private ValueFactory() {
    }

    /**
     * Creates a instance encapsulating the specified value.
     * Internally, this method will re-direct the create request to another
     * of the <tt>create</tt> methods on <tt>ValueFactory</tt> if the type
     * matches one of those method's parameter better. If you do know the type
     * more specifically than <tt>Object</tt>, it is a little more efficient
     * to call one of the other <tt>create</tt> methods directly.
     *
     * @param value the value to be encapsulated.
     * @return the <tt>Value</tt>. {@link #NULL_INSTANCE} is returned if the
     * passed parameter is <tt>null</tt>.
     */
    public static Value create(Object value) {
        if ( value == null ) {
            return NULL_INSTANCE;
        } else if ( value instanceof String ) {
            return create((String) value);
        } else if ( value instanceof BigDecimal ) {
            return create((BigDecimal) value);
        } else if ( value instanceof Number ) {
            return create((Number) value);
        } else if ( value instanceof DateTime ) {
            return create((DateTime) value);
        } else if ( value instanceof PlainDate ) {
            return create((PlainDate) value);
        } else if ( value instanceof byte[] ) {
            return create((byte[]) value);
        } else {
            return new GenericValue(value);
        }
    }

    /**
     * Creates a instance encapsulating the specified <tt>String</tt> value.
     * The "trimmed" version of the "raw" <tt>String</tt> is calculated.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #create(String, String) create}(rawString, null);
     * </pre>
     *
     * @param rawString the <tt>String</tt> to be encapsulated.
     * @return the <tt>Value</tt>. {@link #NULL_INSTANCE} is returned if the
     * passed parameter is <tt>null</tt>. {@link #ZERO_LEN_STRING_INSTANCE}
     * is returned if the passed parameter is a <tt>String</tt> with a length
     * of zero.
     */
    public static Value create(String rawString) {
        return create(rawString, (String) null);
    }

    /**
     * Creates a instance encapsulating the specified <tt>String</tt> value.
     * This method accepts the "trimmed" version of the "raw" <tt>String</tt>,
     * if known (if not known, use the
     * {@link #create(String) create(String rawString)} method instead).
     * For an explanation of "trimmed" and "raw", see the
     * {@link Value#getString getString()} and the
     * {@link Value#getRawString() getRawString()} methods on {@link Value}.
     *
     * @param rawString the value to be encapsulated.
     * @param trimmedString the <tt>rawString</tt> with leading and trailing
     * whitespace removed, or <tt>null</tt> if the trimmed version should be
     * calculated from <tt>rawString</tt>.
     * @return the <tt>Value</tt>. {@link #NULL_INSTANCE} is returned if the
     * passed parameter <tt>rawString</tt> is <tt>null</tt>.
     * {@link #ZERO_LEN_STRING_INSTANCE} is returned if the passed parameter
     * <tt>rawString</tt> is a <tt>String</tt> with a length of zero.
     */
    public static Value create(String rawString, String trimmedString) {
        if ( rawString == null ) {
            return NULL_INSTANCE;
        } else if ( rawString.length() == 0 ) {
            return ZERO_LEN_STRING_INSTANCE;
        }

        if ( trimmedString == null ) {
            trimmedString = rawString.trim();  // raw never null if we get here
        }

        if ( trimmedString.length() == 0 ) {
            return new BlankStringValue(rawString);
        }

        return new StringValue(rawString, trimmedString);
    }

    /**
     * Creates a instance encapsulating the specified value.
     *
     * @param value the value to be encapsulated.
     * @return the <tt>Value</tt>. {@link #NULL_INSTANCE} is returned if the
     * passed parameter is <tt>null</tt>.
     */
    public static Value create(Number value) {
        if ( value == null ) {
            return NULL_INSTANCE;
        } else if ( value instanceof BigDecimal ) {
            return new BigDecimalValue((BigDecimal) value);
        } else {
            return new NumberValue(value);
        }
    }

    /**
     * Creates a instance encapsulating the specified value.
     *
     * @param value the value to be encapsulated.
     * @return the <tt>Value</tt>. {@link #NULL_INSTANCE} is returned if the
     * passed parameter is <tt>null</tt>.
     */
    public static Value create(BigDecimal value) {
        if ( value == null ) {
            return NULL_INSTANCE;
        } else {
            return new BigDecimalValue(value);
        }
    }

    /**
     * Creates a new {@link Value} encapsulating the specified
     * <tt>int</tt> value.
     */
    public static Value create(int value) {
        return create(new Integer(value));
    }

    /**
     * Creates a new {@link Value} encapsulating the specified
     * <tt>long</tt> value.
     */
    public static Value create(long value) {
        return create(new Long(value));
    }

    /**
     * Creates a new {@link Value} encapsulating the specified
     * <tt>double</tt> value.
     */
    public static Value create(double value) {
        return create(new Double(value));
    }

    /**
     * Creates a instance encapsulating the specified {@link DateTime} value.
     *
     * @param dateTime the value to be encapsulated.
     * @return the <tt>Value</tt>. {@link #NULL_INSTANCE} is returned if the
     * passed parameter is <tt>null</tt>.
     */
    public static Value create(DateTime dateTime) {
        if ( dateTime == null ) {
            return NULL_INSTANCE;
        } else {
            return new DateTimeValue(dateTime);
        }
    }

    /**
     * Creates a instance encapsulating the specified {@link PlainDate} value.
     *
     * @param plainDate the value to be encapsulated.
     * @return the <tt>Value</tt>. {@link #NULL_INSTANCE} is returned if the
     * passed parameter is <tt>null</tt>.
     */
    public static Value create(PlainDate plainDate) {
        if ( plainDate == null ) {
            return NULL_INSTANCE;
        } else {
            return new PlainDateValue(plainDate);
        }
    }

    /**
     * Creates a instance encapsulating the specified <tt>byte[]</tt> value.
     *
     * @param data the value to be encapsulated.
     * @return the <tt>Value</tt>. {@link #NULL_INSTANCE} is returned if the
     * passed parameter is <tt>null</tt>.
     */
    public static Value create(byte[] data) {
        if ( data == null ) {
            return NULL_INSTANCE;
        } else {
            return new ByteArrayValue(data);
        }
    }

    // --- Begin nested classes --- //

    private static final class NullValue
            extends AbstractValue implements Serializable {

        @Override
        public Object getObject() {
            return null;
        }

        @Override
        public boolean isNull() {
            return true;
        }

        @Override
        public boolean isEmpty() {
            return true;
        }

        @Override
        public boolean isType(Class<?> targetType) {
            return false;
        }

        @Override
        public boolean isTypeNumber() {
            return false;
        }

        @Override
        public boolean isTypeDateTime() {
            return false;
        }

        @Override
        public boolean isTypePlainDate() {
            return false;
        }

        @Override
        public boolean isTypeByteArray() {
            return false;
        }

        @Override
        public String getString() {
            return ZERO_LEN_STRING;
        }

        @Override
        public String getRawString() {
            return ZERO_LEN_STRING;
        }

        @Override
        public boolean isNumeric() {
            return false;
        }

        @Override
        public Number getNumber() throws ValueException {
            throw new ValueException(
                "Can't interpret null or blank value as a number");
        }

        @Override
        public BigDecimal getBigDecimal() throws ValueException {
            throw new ValueException(
                "Can't interpret null or blank value as a number");
        }

        @Override
        public boolean isTrue() {
            return false;
        }

        @Override
        public TriState getTriState() {
            return TriState.UNKNOWN;
        }

        @Override
        public boolean isDateTime() {
            return false;
        }

        @Override
        public boolean isPlainDate() {
            return false;
        }

        @Override
        public byte[] getBytes() {
            return ZERO_LEN_BYTE_ARRAY;
        }

        @Override
        public InputStream getBytesAsStream() {
            return new ByteArrayInputStream(ZERO_LEN_BYTE_ARRAY);
        }

        @Override
        public boolean isMutable() {
            return false;
        }
    }  // class NullValue

    private static class ZeroLenStringValue
            extends AbstractValue implements Serializable {

        @Override
        public Object getObject() {
            return ZERO_LEN_STRING;
        }

        @Override
        public boolean isNull() {
            return false;
        }

        @Override
        public boolean isEmpty() {
            return true;
        }

        @Override
        public boolean isType(Class<?> targetType) {
            return false;
        }

        @Override
        public boolean isTypeNumber() {
            return false;
        }

        @Override
        public boolean isTypeDateTime() {
            return false;
        }

        @Override
        public boolean isTypePlainDate() {
            return false;
        }

        @Override
        public boolean isTypeByteArray() {
            return false;
        }

        @Override
        public String getString() {
            return ZERO_LEN_STRING;
        }

        @Override
        public String getRawString() {
            return ZERO_LEN_STRING;
        }

        @Override
        public boolean isNumeric() {
            return false;
        }

        @Override
        public Number getNumber() throws ValueException {
            throw new ValueException(
                "Can't interpret null or blank value as a number");
        }

        @Override
        public BigDecimal getBigDecimal() throws ValueException {
            throw new ValueException(
                "Can't interpret null or blank value as a number");
        }

        @Override
        public boolean isTrue() {
            return false;
        }

        @Override
        public TriState getTriState() {
            return TriState.UNKNOWN;
        }

        @Override
        public boolean isDateTime() {
            return false;
        }

        @Override
        public boolean isPlainDate() {
            return false;
        }

        @Override
        public byte[] getBytes() {
            return ZERO_LEN_BYTE_ARRAY;
        }

        @Override
        public InputStream getBytesAsStream() {
            return new ByteArrayInputStream(ZERO_LEN_BYTE_ARRAY);
        }

        @Override
        public boolean isMutable() {
            return false;
        }
   }  // class ZeroLenStringValue

    // Used when the raw string has a length > 0, but is all whitespace
    private static final class BlankStringValue
            extends ZeroLenStringValue implements Serializable {

        private final String rawString;

        public BlankStringValue(String rawString) {
            this.rawString = rawString;
        }

        @Override
        public Object getObject() {
            return rawString;
        }

        @Override
        public String getRawString() {
            return rawString;
        }
    }  // class BlankStringValue

    private static final class StringValue
            extends AbstractValue implements Serializable {

        private final String rawString;
        private final String trimmedString;
        private transient BigDecimal bigDecimal;
        private transient DateTime utcDateTime;
        private transient DateTime localDateTime;
        private transient PlainDate plainDate;

        public StringValue(String rawString, String trimmedString) {
            this.rawString = rawString;
            this.trimmedString = trimmedString;
            this.bigDecimal = null;     // constructed only on demand
            this.utcDateTime = null;    // constructed only on demand
            this.localDateTime = null;  // constructed only on demand
            this.plainDate = null;      // constructed only on demand
        }

        @Override
        public Object getObject() {
            return rawString;
        }

        @Override
        public String getString() {
            return trimmedString;
        }

        @Override
        public String getRawString() {
            return rawString;
        }

        @Override
        public boolean isTypeNumber() {
            return false;
        }

        @Override
        public boolean isTypeDateTime() {
            return false;
        }

        @Override
        public boolean isTypePlainDate() {
            return false;
        }

        @Override
        public boolean isTypeByteArray() {
            return false;
        }

        @Override
        public Number getNumber() throws ValueException {
            return getBigDecimal();
        }

        @Override
        public synchronized BigDecimal getBigDecimal() throws ValueException {
            if ( bigDecimal == null ) {
                bigDecimal = DecimalTools.parseBigDecimal(getString());
            }

            return bigDecimal;
        }

        @Override
        public synchronized DateTime getDateTime() throws ValueException {
            if ( utcDateTime == null ) {
                if ( isEmpty() ) {
                    throw new ValueException(
                        "Can't interpret null or blank value as a DateTime.");
                }

                try {
                    utcDateTime = DateTools.parseUTC(getString());
                } catch ( DateTimeException x ) {
                    throw new ValueException(x);
                }
            }

            return utcDateTime;
        }

        @Override
        public synchronized DateTime getDateTimeLocal() throws ValueException {
            if ( localDateTime == null ) {
                if ( isEmpty() ) {
                    throw new ValueException(
                        "Can't interpret null or blank value as a DateTime.");
                }

                try {
                    localDateTime = DateTools.parseLocal(getString());
                } catch ( DateTimeException x ) {
                    throw new ValueException(x);
                }
            }

            return localDateTime;
        }

        @Override
        public synchronized PlainDate getPlainDate() throws ValueException {
            if ( plainDate == null ) {
                if ( isEmpty() ) {
                    throw new ValueException(
                        "Can't interpret null or blank value as a PlainDate.");
                }

                try {
                    plainDate = PlainDate.create(getString());
                } catch ( PlainDateException x ) {
                    throw new ValueException(x);
                }
            }

            return plainDate;
        }

        @Override
        public boolean isMutable() {
            return false;
        }
    }  // class StringValue

    private static final class NumberValue
            extends AbstractValue implements Serializable {

        private final Number number;
        private transient BigDecimal bigDecimal;
        private transient Integer integerValue;
        private transient Long longValue;
        private transient String stringView;

        public NumberValue(Number number) throws IllegalArgumentException {
            if ( number == null ) {
                // Should 'never' happen as internal callers should
                // pre-check this.
                throw new IllegalArgumentException(
                    "Passed Number can't be null");
            }

            this.number = number;
        }

        @Override
        public Object getObject() {
            return number;
        }

        @Override
        public boolean isNull() {
            return false;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean isTypeNumber() {
            return true;
        }

        @Override
        public boolean isTypeDateTime() {
            return false;
        }

        @Override
        public boolean isTypePlainDate() {
            return false;
        }

        @Override
        public boolean isTypeByteArray() {
            return false;
        }

        @Override
        public boolean isNumeric() {
            return true;
        }

        @Override
        public synchronized String getString() {
            if ( stringView == null ) {
                stringView = number.toString();
            }

            return stringView;
        }

        @Override
        public String getRawString() {
            return getString();
        }

        @Override
        public Number getNumber() {
            return number;
        }

        @Override
        public synchronized BigDecimal getBigDecimal() throws ValueException {
            if ( bigDecimal == null ) {
                if ( number instanceof BigDecimal ) {
                    bigDecimal = (BigDecimal) number;
                } else {
                    bigDecimal = DecimalTools.parseBigDecimal(getString());
                }
            }

            return bigDecimal;
        }

        @Override
        public synchronized Integer getIntegerNumber() throws ValueException {
            if ( integerValue == null ) {
                integerValue = NumberTools.toIntegerNumber(number);
            }

            return integerValue;
        }

        @Override
        public synchronized Long getLongNumber() throws ValueException {
            if ( longValue == null ) {
                longValue = NumberTools.toLongNumber(number);
            }

            return longValue;
        }

        @Override
        public boolean isMutable() {
            return false;
        }
    }  // class NumberValue

    private static class BigDecimalValue
            extends AbstractValue implements Serializable {

        private final BigDecimal bigDecimal;
        private transient String stringView;

        public BigDecimalValue(BigDecimal bigDecimal)
                throws IllegalArgumentException {

            if ( bigDecimal == null ) {
                // Should 'never' happen as internal callers should
                // pre-check this.
                throw new IllegalArgumentException(
                    "Passed bigDecimal can't be null");
            }

            this.bigDecimal = bigDecimal;
            this.stringView = null;    // only create on demand
        }

        @Override
        public Object getObject() {
            return bigDecimal;
        }

        @Override
        public boolean isNull() {
            return false;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean isTypeNumber() {
            return true;
        }

        @Override
        public boolean isTypeDateTime() {
            return false;
        }

        @Override
        public boolean isTypePlainDate() {
            return false;
        }

        @Override
        public boolean isTypeByteArray() {
            return false;
        }

        @Override
        public boolean isNumeric() {
            return true;
        }

        @Override
        public synchronized String getString() {
            if ( stringView == null ) {
                stringView = bigDecimal.toString();  // bigDecimal can't be null
            }

            return stringView;
        }

        @Override
        public String getRawString() {
            return getString();
        }

        @Override
        public Number getNumber() {
            return bigDecimal;
        }

        @Override
        public BigDecimal getBigDecimal() {
            return bigDecimal;
        }

        @Override
        public boolean isMutable() {
            return false;
        }
    }  // class BigDecimalValue

    private static class DateTimeValue
            extends AbstractValue implements Serializable {

        private final DateTime dateTime;
        private transient String stringView;

        public DateTimeValue(DateTime dateTime)
                throws IllegalArgumentException {

            if ( dateTime == null ) {
                // Should 'never' happen as internal callers should
                // pre-check this.
                throw new IllegalArgumentException(
                    "Passed dateTime can't be null");
            }

            this.dateTime = dateTime;
            this.stringView = null;         // only create on demand
        }

        @Override
        public Object getObject() {
            return dateTime;
        }

        @Override
        public boolean isNull() {
            return false;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean isTypeNumber() {
            return false;
        }

        @Override
        public boolean isTypeDateTime() {
            return true;
        }

        @Override
        public boolean isTypePlainDate() {
            return false;
        }

        @Override
        public boolean isTypeByteArray() {
            return false;
        }

        @Override
        public boolean isNumeric() {
            return true;
        }

        @Override
        public boolean isTrue() {
            return false;
        }

        @Override
        public boolean isDateTime() {
            return true;
        }

        @Override
        public DateTime getDateTime() {
            return dateTime;
        }

        @Override
        public DateTime getDateTimeLocal() {
            return dateTime;
        }

        @Override
        public DateTime getDateTime(TimeZone defaultTimeZone) {
            return dateTime;
        }

        @Override
        public synchronized String getString() {
            if ( stringView == null ) {
                stringView = dateTime.toString();  // dateTime can't be null
            }

            return stringView;
        }

        @Override
        public String getRawString() {
            return getString();
        }

        @Override
        public boolean isMutable() {
            return false;
        }
    } // class DateTimeValue

    private static class PlainDateValue
            extends AbstractValue implements Serializable {

        private final PlainDate plainDate;
        private transient String stringView;

        public PlainDateValue(PlainDate plainDate)
                throws IllegalArgumentException {

            if ( plainDate == null ) {
                // Should 'never' happen as internal callers should
                // pre-check this.
                throw new IllegalArgumentException(
                    "Passed plainDate can't be null");
            }

            this.plainDate = plainDate;
            this.stringView = null;         // only create on demand
        }

        @Override
        public Object getObject() {
            return plainDate;
        }

        @Override
        public boolean isNull() {
            return false;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean isTypeNumber() {
            return false;
        }

        @Override
        public boolean isTypeDateTime() {
            return false;
        }

        @Override
        public boolean isTypePlainDate() {
            return true;
        }

        @Override
        public boolean isTypeByteArray() {
            return false;
        }

        @Override
        public boolean isNumeric() {
            return true;
        }

        @Override
        public boolean isTrue() {
            return false;
        }

        @Override
        public boolean isDateTime() {
            return true;
        }

        @Override
        public boolean isPlainDate() {
            return true;
        }

        @Override
        public DateTime getDateTime() {
            return plainDate.toDateTimeUTC();
        }

        @Override
        public DateTime getDateTimeLocal() {
            return plainDate.toDateTimeLocal();
        }

        @Override
        public DateTime getDateTime(TimeZone defaultTimeZone) {
            return plainDate.toDateTime(defaultTimeZone);
        }

        @Override
        public PlainDate getPlainDate() throws ValueException {
            return plainDate;
        }

        @Override
        public synchronized String getString() {
            if ( stringView == null ) {
                stringView = plainDate.toString();  // plainDate can't be null
            }

            return stringView;
        }

        @Override
        public String getRawString() {
            return getString();
        }

        @Override
        public boolean isMutable() {
            return false;
        }
    } // class PlainDateValue

    private static class ByteArrayValue
            extends AbstractValue implements Serializable {

        private final byte[] data;

        public ByteArrayValue(byte[] data) {
            this.data = data;
        }

        @Override
        public Object getObject() {
            return getBytes();  // be sure to give back a *copy*!
        }

        @Override
        public boolean isNull() {
            return false;
        }

        @Override
        public boolean isEmpty() {
            return data.length == 0;
        }

        @Override
        public String getString() {
            return StringTools.toHexString(data);
        }

        @Override
        public String getRawString() {
            return getString();
        }

        @Override
        public boolean isTypeByteArray() {
            return true;
        }

        @Override
        public boolean isTypeNumber() {
            return false;
        }

        @Override
        public boolean isTypeDateTime() {
            return false;
        }

        @Override
        public byte[] getBytes() {
            return (byte[]) data.clone();
        }

        @Override
        public InputStream getBytesAsStream() {
            return new ByteArrayInputStream(data);
        }

        @Override
        public boolean isMutable() {
            return false;
        }
    } // class ByteArrayValue

    private static class GenericValue
            extends AbstractValue implements Serializable {

        private final Object value;
        private transient String trimmedString;
        private transient String rawString;
        private transient BigDecimal bigDecimal;

        public GenericValue(Object value) {
            this.value = value;
        }

        @Override
        public Object getObject() {
            return value;
        }

        @Override
        public synchronized String getString() {
            if ( trimmedString == null ) {
                trimmedString = getRawString().trim();
            }

            return trimmedString;
        }

        @Override
        public synchronized String getRawString() {
            if ( rawString == null ) {
                rawString =
                    (value == null) ? ZERO_LEN_STRING : value.toString();
            }

            return rawString;
        }

        @Override
        public synchronized Number getNumber() throws ValueException {
            return getBigDecimal();
        }

        @Override
        public synchronized BigDecimal getBigDecimal() throws ValueException {
            if ( bigDecimal == null ) {
                bigDecimal = DecimalTools.parseBigDecimal(getString());
            }

            return bigDecimal;
        }
    }  // class GenericValue
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.