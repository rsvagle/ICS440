package com.programix.value;

import java.io.*;
import java.math.*;
import java.util.*;

import com.programix.math.*;
import com.programix.time.*;
import com.programix.util.*;

/**
 * A simple partial implementation of {@link Value}.
 * See {@link Value} for a full explanation of all of the methods.
 * Check out {@link ValueFactory} to see if there is a <tt>create</tt> method
 * available that might eliminate your need to extend <tt>AbstractValue</tt>.
 * Check out {@link ValueMap} for key-value mappings, reading and writing
 * to files and other streams, and more.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public abstract class AbstractValue implements Value {
    /**
     * This constructor is <tt>protected</tt> because it only makes sense
     * to be called from a subclass as <tt>AbstractValue</tt> is
     * not a concrete class (it's <tt>abstract</tt> after all).
     */
    protected AbstractValue() {
    }

    public abstract Object getObject();

    @SuppressWarnings("unchecked")
    public <T> T getObject(Class<T> targetType)
            throws ValueException, IllegalArgumentException {

        if ( isType(targetType) ) {
            return (T) getObject();
        }

        if ( isNull() ) {
            throw new ValueException(
                "Value is null, so type does not match specified " +
                "target type (" + targetType.getName() + ")");
        }

        throw new ValueException("Retrieved object's type (" +
            getObject().getClass().getName() + ") can't be cast into " +
            "the target type (" + targetType.getName() + ")");
    }

    public <T> T getObjectOrNull(Class<T> targetType)
            throws ValueException, IllegalArgumentException {

        return isEmpty() ? null : getObject(targetType);
    }

    public boolean isNull() {
        return getObject() == null;
    }

    public boolean isNotNull() {
        return !isNull();
    }

    public boolean isEmpty() {
        return isNull() || StringTools.isEmpty(getString());
    }

    public boolean isNotEmpty() {
        return !isEmpty();
    }

    public boolean isType(Class<?> targetType) throws IllegalArgumentException {
        if ( targetType == null ) {
            throw new IllegalArgumentException("targetType can not be null");
        }

        return targetType.isInstance(getObject());
    }

    public boolean isNotType(Class<?> targetType)
            throws IllegalArgumentException {

        return !isType(targetType);
    }

    public boolean isTypeNumber() {
        return getObject() instanceof Number;
    }

    public boolean isNotTypeNumber() {
        return !isTypeNumber();
    }

    public boolean isTypeDateTime() {
        return getObject() instanceof DateTime;
    }

    public boolean isNotTypeDateTime() {
        return !isTypeDateTime();
    }

    public boolean isTypePlainDate() {
        return getObject() instanceof PlainDate;
    }

    public boolean isNotTypePlainDate() {
        return !isTypePlainDate();
    }

    public boolean isTypeByteArray() {
        return getObject() instanceof byte[];
    }

    public boolean isNotTypeByteArray() {
        return !isTypeByteArray();
    }

    public String getString() {
        return StringTools.trim(getObject());
    }

    public String getStringOrNull() {
        return isEmpty() ? null : getString();
    }

    public String getRawString() {
        return StringTools.nullToBlank(getObject());
    }

    public boolean isNumeric() {
        if ( isEmpty() ) {
            return false;
        }

        try {
            getNumber();
            return true;
        } catch ( ValueException x ) {
            return false;
        }
    }

    public boolean isNotNumeric() {
        return !isNumeric();
    }

    public Number getNumber() throws ValueException {
        Object obj = getObject();
        if ( obj instanceof Number ) {
            return (Number) obj;
        } else if ( obj instanceof DateTime ) {
            DateTime dateTime = (DateTime) obj;
            return new Long(dateTime.getTime());
        } else {
            return DecimalTools.parseBigDecimal(getString());
        }
    }

    public Number getNumberOrNull() throws ValueException {
        return isEmpty() ? null : getNumber();
    }

    public BigDecimal getBigDecimal() throws ValueException {
        Number num = getNumber();
        if ( num instanceof BigDecimal ) {
            return (BigDecimal) num;
        } else if ( num instanceof Long ||
                    num instanceof Integer ||
                    num instanceof Short ||
                    num instanceof Byte ) {

            return BigDecimal.valueOf(num.longValue());
        } else if ( num instanceof BigInteger ) {
            return new BigDecimal((BigInteger) num);
        } else {
            return DecimalTools.parseBigDecimal(num.toString());
        }
    }

    public BigDecimal getBigDecimalOrNull() throws ValueException {
        return isEmpty() ? null : getBigDecimal();
    }

    public long getLong() throws RangeValueException, ValueException {
        return NumberTools.toLong(getNumber());
    }

    public Long getLongNumber() throws RangeValueException, ValueException {
        return NumberTools.toLongNumber(getNumber());
    }

    public Long getLongNumberOrNull()
            throws RangeValueException, ValueException {

        return isEmpty() ? null : getLongNumber();
    }

    public int getInt() throws RangeValueException, ValueException {
        return NumberTools.toInt(getNumber());
    }

    public Integer getIntegerNumber()
            throws RangeValueException, ValueException {

        return NumberTools.toIntegerNumber(getNumber());
    }

    public Integer getIntegerNumberOrNull()
            throws RangeValueException, ValueException {

        return isEmpty() ? null : getIntegerNumber();
    }

    public short getShort() throws RangeValueException, ValueException {
        return NumberTools.toShort(getNumber());
    }

    public Short getShortNumber() throws RangeValueException, ValueException {
        return NumberTools.toShortNumber(getNumber());
    }

    public Short getShortNumberOrNull()
            throws RangeValueException, ValueException {

        return isEmpty() ? null : getShortNumber();
    }


    public byte getByte() throws RangeValueException, ValueException {
        return NumberTools.toByte(getNumber());
    }

    public Byte getByteNumber() throws RangeValueException, ValueException {
        return NumberTools.toByteNumber(getNumber());
    }

    public Byte getByteNumberOrNull()
            throws RangeValueException, ValueException {

        return isEmpty() ? null : getByteNumber();
    }

    public double getDouble() throws ValueException {
        return getNumber().doubleValue();
    }

    public Double getDoubleNumber() throws ValueException {
        Number number = getNumber();
        if ( number instanceof Double ) {
            return (Double) number;
        } else {
            return new Double(number.doubleValue());
        }
    }

    public Double getDoubleNumberOrNull() throws ValueException {
        return isEmpty() ? null : getDoubleNumber();
    }

    public float getFloat() throws ValueException {
        return getNumber().floatValue();
    }

    public Float getFloatNumber() throws ValueException {
        Number number = getNumber();
        if ( number instanceof Float ) {
            return (Float) number;
        } else {
            return new Float(number.floatValue());
        }
    }

    public Float getFloatNumberOrNull() throws ValueException {
        return isEmpty() ? null : getFloatNumber();
    }

    public boolean isTrue() {
        Object obj = getObject();
        if ( obj instanceof Boolean ) {
            return ((Boolean) obj).booleanValue();
        }

        if ( obj == null ) {
            return false;
        }

        String s = getString();
        if ( StringTools.isEmpty(s) ) {
            return false;
        }

        if ( s.length() == 1 ) {
            char ch = s.charAt(0);
            switch ( ch ) {
                case 'T':
                case 't':
                case 'Y':
                case 'y':
                case '1':
                    return true;
                default:
                    return false;
            }
        } else {
            if ( "true".equalsIgnoreCase(s) || "yes".equalsIgnoreCase(s) ||
                    "on".equalsIgnoreCase(s) ) {

                return true;
            }
        }

        return false;
    }

    public boolean isFalse() {
        return !isTrue();
    }

    public TriState getTriState() {
        Object obj = getObject();
        if ( obj instanceof TriState ) {
            return (TriState) obj;
        } else if ( obj == null ) {
            return TriState.UNKNOWN;
        } else if ( obj instanceof Boolean ) {
            if ( ((Boolean) obj).booleanValue() == true ) {
                return TriState.YES;
            } else {
                return TriState.NO;
            }
        }

        String s = getString();

        if ( StringTools.isEmpty(s) ) {
            return TriState.UNKNOWN;
        }

        if ( s.length() == 1 ) {
            char ch = s.charAt(0);
            switch ( ch ) {
                case 'y':
                case 'Y':
                case 't':
                case 'T':
                case '1':
                    return TriState.YES;

                case 'n':
                case 'N':
                case 'f':
                case 'F':
                case '0':
                    return TriState.NO;

                default:
                    return TriState.UNKNOWN;
            }
        }

        if ( "yes".equalsIgnoreCase(s) ||
             "true".equalsIgnoreCase(s) ||
             "on".equalsIgnoreCase(s) ) {

            return TriState.YES;
        }

        if ( "no".equalsIgnoreCase(s) ||
             "false".equalsIgnoreCase(s) ||
             "off".equalsIgnoreCase(s) ) {

            return TriState.NO;
        }

        return TriState.UNKNOWN;
    }

    public boolean isDateTime() {
        if ( getObject() instanceof DateTime ) {
            return true;
        }

        if ( isEmpty() ) {
            return false;
        }

        try {
            getDateTime();
            return true;
        } catch ( ValueException x ) {
            return false;
        }
    }

    public boolean isNotDateTime() {
        return !isDateTime();
    }

    public DateTime getDateTime() throws ValueException {
        Object obj = getObject();
        if ( obj instanceof DateTime ) {
            return (DateTime) obj;
        }

        if ( obj == null ) {
            throw new ValueException("Can not interpret null as a DateTime.");
        }

        try {
            return DateTools.parseUTC(getString());
        } catch ( DateTimeException x ) {
            throw new ValueException(x);
        }
    }

    public DateTime getDateTimeOrNull() throws ValueException {
        return isEmpty() ? null : getDateTime();
    }

    public DateTime getDateTimeLocal() throws ValueException {
        Object obj = getObject();
        if ( obj instanceof DateTime ) {
            return (DateTime) obj;
        }

        if ( obj == null ) {
            throw new ValueException("Can not interpret null as a DateTime.");
        }

        try {
            return DateTools.parseLocal(getString());
        } catch ( DateTimeException x ) {
            throw new ValueException(x);
        }
    }

    public DateTime getDateTimeLocalOrNull() throws ValueException {
        return isEmpty() ? null : getDateTimeLocal();
    }

    public DateTime getDateTime(TimeZone defaultTimeZone)
            throws ValueException, IllegalArgumentException {

        Object obj = getObject();
        if ( obj instanceof DateTime ) {
            return (DateTime) obj;
        }

        if ( obj == null ) {
            throw new ValueException("Can not interpret null as a DateTime.");
        }

        try {
            return DateTools.parse(getString(), defaultTimeZone);
        } catch ( DateTimeException x ) {
            throw new ValueException(x);
        }
    }

    public DateTime getDateTimeOrNull(TimeZone defaultTimeZone)
            throws ValueException, IllegalArgumentException {

        return isEmpty() ? null : getDateTime(defaultTimeZone);
    }

    public boolean isPlainDate() {
        if ( getObject() instanceof PlainDate ) {
            return true;
        }

        if ( isEmpty() ) {
            return false;
        }

        try {
            getPlainDate();
            return true;
        } catch ( ValueException x ) {
            return false;
        }
    }

    public boolean isNotPlainDate() {
        return !isPlainDate();
    }

    public PlainDate getPlainDate() throws ValueException {
        Object obj = getObject();
        if ( obj instanceof PlainDate ) {
            return (PlainDate) obj;
        }

        if ( obj == null ) {
            throw new ValueException("Can not interpret null as a PlainDate.");
        }

        try {
            return DateTools.parsePlainDate(getString());
        } catch ( PlainDateException x ) {
            throw new ValueException(x);
        }
    }

    public PlainDate getPlainDateOrNull() throws ValueException {
        return isEmpty() ? null : getPlainDate();
    }

    public byte[] getBytes() {
        Object obj = getObject();
        if ( obj instanceof byte[] ) {
            return (byte[]) ((byte[]) obj).clone();
        }

        return StringTools.parseHexString(getString());
    }

    public InputStream getBytesAsStream() {
        Object obj = getObject();
        if ( obj instanceof byte[] ) {
            return new ByteArrayInputStream((byte[]) obj);
        }

        return new ByteArrayInputStream(
            StringTools.parseHexString(getString()));
    }

    public boolean isMutable() {
        return true;
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.