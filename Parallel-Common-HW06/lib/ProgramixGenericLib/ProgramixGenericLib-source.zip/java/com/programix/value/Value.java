package com.programix.value;

import java.io.*;
import java.math.*;
import java.util.*;

import com.programix.math.*;
import com.programix.time.*;
import com.programix.util.*;

/**
 * Encapsulates a generic value with accessors to read the data as
 * different data types. Note that depending on the encapsulated value,
 * it might not be possible to read the value as all of the different
 * data types (however, {@link #getString() getString()},
 * {@link #getRawString() getRawString()}, and {@link #getObject() getObject()}
 * will <i>always</i> return a value safely).
 * <p>
 * {@link ValueException} is potentially thrown from some of the methods
 * on <tt>Value</tt>. It is used to indicate trouble&mdash;usually trouble
 * interpreting the value as particular type.
 * For example, if <tt>"abc"</tt> is returned from {@link #getString()},
 * attempting to call {@link #getInt()} would result in {@link #getInt()}
 * throwing a <tt>ValueException</tt> as no integer value can be parsed.
 * <tt>ValueException</tt> is a subclass of {@link RuntimeException}
 * so it does not have to be explicitly caught.
 * <p>
 * {@link RangeValueException} is potentially thrown from some of the
 * methods on <tt>Value</tt>. This subclass of {@link ValueException}
 * is used to specifically indicate that the value does not fit into
 * the acceptable range.
 * For example, if <tt>"5000000000"</tt> is returned from {@link #getString()},
 * attempting to call {@link #getInt()} would result in {@link #getInt()}
 * throwing a <tt>RangeValueException</tt> as this value is too large to
 * fit into an <tt>int</tt>.
 * <tt>RangleValueException</tt> is a subclass of {@link RuntimeException}
 * so it does not have to be explicitly caught.
 * <p>
 * The documentation for many of the methods have code snippets labeled
 * as "equivalent to". An implementation of <tt>Value</tt> may actually
 * implement the method in a more efficient manner as appropriate.
 * <p>
 * Most implementations ensure that each instance is immutable (that is,
 * the internal value can NOT be changed after construction). If mutability
 * is needed (or can't be avoided), the {@link #isMutable()} method
 * returns <tt>true</tt>. See {@link #isMutable()} for details.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface Value {
	/**
	 * Returns the encapsulated value as a generic <tt>Object</tt> reference.
	 * If the caller knows the actual type that should be returned, the calling
	 * code can attempt to explicitly cast the value returned (the
	 * {@link #isType(Class) isType(Class target)} method can be used to
	 * test the type first, if desired).
	 * If the value stored internally is <tt>null</tt>, then <tt>null</tt>
	 * will be returned.
	 */
	Object getObject();

    /**
     * Returns the encapsulated value as a generic <tt>Object</tt> reference
     * that is guaranteed to be able to be explicitly cast
     * into the specified <code>targetType</code>.
     * If the internal value is not of the specified
     * type, a {@link ValueException} is thrown with details in its
     * message about the actual type of the internal object.
     * If the value stored internally is <tt>null</tt>, then a
     * <code>ValueException</code> <i>will</i> be thrown.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isNotType(Class) isNotType}(targetType) ) {
     *     throw new ValueException( //...
     * }
     *
     * return {@link #getObject() getObject}();
     * </pre>
     *
     * @param targetType type to check against, must not be <tt>null</tt>.
     * @return the encapsulated value
     * @throws ValueException if the encapsulated value is not of the
     * specified type, or if it is <code>null</code>.
     * @throws IllegalArgumentException if <tt>targetType</tt> is <tt>null</tt>.
     */
    <T> T getObject(Class<T> targetType)
        throws ValueException, IllegalArgumentException;

    /**
     * Returns the encapsulated value as a generic <tt>Object</tt> reference
     * or <tt>null</tt> if the value is empty.
     * The returned value is guaranteed to be able to be explicitly cast
     * into the specified <code>targetType</code> (note: <tt>null</tt>
     * can be cast into any type).
     * If the internal value is not empty and is not of the specified
     * type, a {@link ValueException} is thrown with details in its
     * message about the actual type of the internal object.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getObject(Class) getObject(targetType)};
     * }
     * </pre>
     *
     * @param targetType type to check against, must not be <tt>null</tt>.
     * @return the encapsulated value, or <tt>null</tt> if empty.
     * @throws ValueException if the encapsulated value is not empty and
     * is not of the specified type.
     * @throws IllegalArgumentException if <tt>targetType</tt> is <tt>null</tt>.
     * Note that <tt>ValueException</tt> and <tt>IllegalArgumentException</tt>
     * are both a {@link RuntimeException}
     * so neither has to be explicitly caught.
     */
    <T> T getObjectOrNull(Class<T> targetType)
        throws ValueException, IllegalArgumentException;

    /**
     * Returns <tt>true</tt> if the encapsulated value is <tt>null</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getObject() getObject()} == null;
     * </pre>
     */
    boolean isNull();

    /**
     * Returns <tt>true</tt> if the encapsulated value is NOT <tt>null</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isNull() isNull()};
     * </pre>
     */
    boolean isNotNull();

    /**
     * Returns <tt>true</tt> if the encapsulated value is either <tt>null</tt>,
     * a zero-length <tt>String</tt>, or a <tt>String</tt> of all whitespace.
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #isNull() isNull()} || ({@link #getString()
     * getString()}.length() == 0);
     * </pre>
     */
    boolean isEmpty();

    /**
     * Returns <tt>true</tt> if the encapsulated value is NOT empty.
     * See {@link #isEmpty() isEmpty()} for an explanation of <i>empty</i>.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isEmpty() isEmpty()};
     * </pre>
     */
    boolean isNotEmpty();

	/**
	 * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
	 * is <u>not <tt>null</tt></u> and can be cast into the specified type.
     *
     * @throws IllegalArgumentException if <tt>targetType</tt> is <tt>null</tt>.
	 */
	boolean isType(Class<?> targetType) throws IllegalArgumentException;

    /**
     * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
     * <u>is  <tt>null</tt></u> <i>or</i> can <i>not</i> be cast into the
     * specified type.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isType(Class) isType}(targetType);
     * </pre>
     * @throws IllegalArgumentException if <tt>targetType</tt> is <tt>null</tt>.
	 */
	boolean isNotType(Class<?> targetType) throws IllegalArgumentException;

	/**
	 * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
	 * is <u>not <tt>null</tt></u> and can be cast to the type {@link Number}.
     * {@link Number} is the <tt>abstract</tt> superclass of
     * {@link Byte}, {@link Short}, {@link Integer}, {@link Long},
     * {@link Float}, {@link Double}, {@link BigDecimal},
     * and {@link BigInteger}.
     * This method's test is stricter than {@link #isNumeric()} (which
     * checks to see if there is <i>any way</i> to interpret the value as a
     * number).
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #isNotNull() isNotNull()} && ({@link
     *        #getObject() getObject()} instanceof Number);
     * </pre>
	 */
	boolean isTypeNumber();

	/**
	 * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
	 * is not an object of the type {@link Number}.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isTypeNumber() isTypeNumber()};
     * </pre>
	 */
	boolean isNotTypeNumber();

    /**
     * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
     * is <u>not <tt>null</tt></u> and can be cast to the type {@link DateTime}.
     * This method's test is stricter than {@link #isDateTime()} (which
     * checks to see if there is <i>any way</i> to interpret the value as a
     * <tt>DateTime</tt>).
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #isNotNull() isNotNull()} && ({@link
     *        #getObject() getObject()} instanceof {@link DateTime});
     * </pre>
     */
	boolean isTypeDateTime();

    /**
     * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
     * is not an object of the type {@link DateTime}.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isTypeDateTime() isTypeDateTime()};
     * </pre>
     */
    boolean isNotTypeDateTime();

    /**
     * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
     * is <u>not <tt>null</tt></u> and can be cast to the type {@link PlainDate}.
     * This method's test is stricter than {@link #isPlainDate()} (which
     * checks to see if there is <i>any way</i> to interpret the value as a
     * <tt>PlainDate</tt>).
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #isNotNull() isNotNull()} && ({@link
     *        #getObject() getObject()} instanceof {@link PlainDate});
     * </pre>
     */
    boolean isTypePlainDate();

    /**
     * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
     * is not an object of the type {@link PlainDate}.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isTypePlainDate() isTypePlainDate()};
     * </pre>
     */
    boolean isNotTypePlainDate();

    /**
     * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
     * is <u>not <tt>null</tt></u> and can be cast to the type <tt>byte[]</tt>.
     * This method's test is stricter than {@link #getBytes()} and
     * {@link #getBytesAsStream()}
     * (they always find a way to interpret the value as a <tt>byte[]</tt>).
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #isNotNull() isNotNull()} && ({@link
     *        #getObject() getObject()} instanceof byte[]);
     * </pre>
     */
    boolean isTypeByteArray();

    /**
     * Returns <tt>true</tt> if the result of {@link #getObject() getObject()}
     * is not an object of the type <tt>byte[]</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isTypeByteArray() isTypeByteArray()};
     * </pre>
     */
    boolean isNotTypeByteArray();

	/**
	 * Returns the encapsulated value as a <tt>String</tt> value
	 * <u><i>after</i> trimming</u> leading and trailing whitespace.
	 * If the encapsulated value is <tt>null</tt>, a zero-length <tt>String</tt>
	 * will be returned (<tt>null</tt> is never returned).
	 * Equivalent to:
	 * <pre class="preshade">
	 * Object obj = {@link #getObject() getObject()};
	 * return (obj == null) ? "" : obj.toString().trim();
	 * </pre>
	 */
	String getString();

    /**
     * Returns the result as a {@link String}
     * or <tt>null</tt> if the value is empty.
     * Note that this method returns <tt>null</tt> if the value is
     * <tt>null</tt>, a zero-length string, or a string of all whitespace; a
     * string is only returned if there are non-whitespace characters
     * available. Look carefully at {@link #isEmpty()} and {@link #getString()}.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getString() getString()};
     * }
     * </pre>
     */
    String getStringOrNull();

	/**
	 * Returns the encapsulated value as a <tt>String</tt> value
	 * <u><i>without</i> trimming</u> leading and trailing whitespace.
	 * If the encapsulated value is <tt>null</tt>, a zero-length <tt>String</tt>
	 * will be returned (<tt>null</tt> is never returned).
	 * Equivalent to:
	 * <pre class="preshade">
	 * Object obj = {@link #getObject() getObject()};
	 * return (obj == null) ? "" : obj.toString();
	 * </pre>
	 */
	String getRawString();

	/**
	 * Returns <tt>true</tt> if the encapsulated value can be interpreted
	 * as a number. If {@link #getNumber() getNumber()} can be called without
	 * a throwing a {@link ValueException}, <tt>isNumeric</tt> returns
	 * <tt>true</tt>. See {@link #getNumber()} for details.
     * This method's test is more lenient than {@link #isTypeNumber()} (which
     * only checks to see if the encapsulated object is a subclass of
     * {@link Number}).
     * <p>
	 * Equivalent to (although typically implemented more efficiently):
	 * <pre class="preshade">
	 * try {
	 *     {@link #getNumber() getNumber}();
	 *     return true;
	 * } catch ( ValueException x ) {
	 *     return false;
	 * }
	 * </pre>
	 */
	boolean isNumeric();

    /**
     * Returns <tt>true</tt> if the encapsulated value can not be interpreted
     * as a numeric value.
     * See {@link #isNumeric() isNumeric()} for an explanation of how
     * <i>numeric</i> is determined.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isNumeric() isNumeric}();
     * </pre>
     */
    boolean isNotNumeric();

	/**
	 * Returns the encapsulated value interpreted a <tt>Number</tt> value.
     * More specifically:
     * <ul>
	 * <li>If the encapsulated value is a subclass of {@link Number},
	 * the value is simply returned.</li>
	 * <li>If the encapsulated value is a {@link DateTime},
	 * a new {@link Long} is wrapped around the <tt>long</tt> returned by
	 * {@link DateTime#getTime getTime()}.</li>
     * <li>If the <tt>String</tt> returned by {@link #getString() getString()}
     * is run through {@link StringTools#winnowDecimal(String)
     * StringTools.winnowDecimal()} and the result can be successfully parsed
     * by the constructor of {@link BigDecimal#BigDecimal(String) BigDecimal},
     * then that <tt>BigDecimal</tt> is returned.</li>
     * <li>If the encapsulated value is <tt>null</tt>, a <tt>ValueException</tt>
     * is thrown.</li>
     * </ul>
     * <p>
     * Equivalent to:
	 * <pre class="preshade">
	 * Object obj = {@link #getObject() getObject}();
	 * if ( obj instanceof Number ) {
	 *     return (Number) obj;
	 * } else if ( obj instanceof DateTime ) {
     *     DateTime dateTime = (DateTime) obj;
     *     return new Long(dateTime.getTime());
     * } else if ( obj == null ) {
     *     throw new ValueException(//...
     * }
	 *
     * try {
	 *     return new {@link BigDecimal#BigDecimal(String)
	 *         BigDecimal}(StringTools.{@link StringTools#winnowDecimal
     *         winnowDecimal}({@link #getString() getString}()));
     * } catch ( NumberFormatException x ) {
     *     throw new ValueException(x);
     * }
	 * </pre>
     * <b><i>NOTE:</i></b> if you really need a <tt>BigDecimal</tt>,
	 * then call {@link #getBigDecimal getBigDecimal()} instead.
	 *
	 * @exception ValueException if the encapsulated value can not
     * be interpreted as a numeric value.
	 * Note that <tt>ValueException</tt> is a {@link RuntimeException}
	 * so it does not have to be explicitly caught.
	 */
	Number getNumber() throws ValueException;

    /**
     * Returns the result as a {@link Number}
     * or <tt>null</tt> if the value is empty.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getNumber() getNumber()};
     * }
     * </pre>
     *
     * @exception ValueException if the value is not empty and can not
     * be interpreted as a numeric value.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    Number getNumberOrNull() throws ValueException;

	/**
	 * Returns the result as a {@link BigDecimal}. Equivalent to:
	 * <pre class="preshade">
     * Number num = {@link #getNumber() getNumber()};
     * if ( num instanceof BigDecimal ) {
     *     return (BigDecimal) num;
     * }
     *
     * try {
     *     return new BigDecimal(num.toString());
     * } catch ( NumberFormatException x ) {
     *     throw new ValueException( //...
     * }
	 * </pre>
	 *
	 * @exception ValueException if the value is <tt>null</tt> or can not be
	 * viewed as a {@link BigDecimal}.
	 * Note that <tt>ValueException</tt> is a {@link RuntimeException}
	 * so it does not have to be explicitly caught.
	 */
	BigDecimal getBigDecimal() throws ValueException;

	/**
	 * Returns the result as a {@link BigDecimal}
     * or <tt>null</tt> if the value is empty.
     * Equivalent to:
	 * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getBigDecimal() getBigDecimal()};
     * }
	 * </pre>
	 *
	 * @exception ValueException if the value is not empty and can not be
	 * viewed as a {@link BigDecimal}.
	 * Note that <tt>ValueException</tt> is a {@link RuntimeException}
	 * so it does not have to be explicitly caught.
	 */
	BigDecimal getBigDecimalOrNull() throws ValueException;

    /**
     * Returns the result as a <i>rounded</i> off <tt>long</tt> value.
     * Equivalent to:
     * <pre class="preshade">
     * return NumberTools.{@link NumberTools#toLong toLong}({@link
     * #getNumber getNumber()});
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>long</tt> values.
     * @exception ValueException if the value can not be
     * interpreted as a numeric value.
     *
     * @see #getLongNumber
     */
    long getLong() throws RangeValueException, ValueException;

    /**
     * Returns the result as a <i>rounded</i> off {@link Long} value.
     * Equivalent to:
     * <pre class="preshade">
     * return NumberTools.{@link NumberTools#toLongNumber toLongNumber}({@link
     * #getNumber getNumber()});
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>long</tt> values.
     * @exception ValueException if the value can not be
     * interpreted as a numeric value.
     *
     * @see #getLong
     */
    Long getLongNumber() throws RangeValueException, ValueException;

    /**
     * Returns the result as a {@link Long}
     * or <tt>null</tt> if the value is empty.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getLongNumber() getLongNumber()};
     * }
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>long</tt> values.
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link Long}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    Long getLongNumberOrNull() throws RangeValueException, ValueException;

    /**
     * Returns the result as a <i>rounded</i> off <tt>int</tt> value.
     * Equivalent to:
     * <pre class="preshade">
     * return NumberTools.{@link NumberTools#toInt toInt}({@link
     * #getNumber getNumber()});
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>int</tt> values.
     * @exception ValueException if the value can not be
     * interpreted as a numeric value.
     *
     * @see #getIntegerNumber
     */
    int getInt() throws RangeValueException, ValueException;

    /**
     * Returns the result as a <i>rounded</i> off {@link Integer} value.
     * Equivalent to:
     * <pre class="preshade">
     * return NumberTools.{@link NumberTools#toIntegerNumber
     * toIntegerNumber}({@link #getNumber getNumber()});
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>int</tt> values.
     * @exception ValueException if the value can not be
     * interpreted as a numeric value.
     *
     * @see #getInt
     */
    Integer getIntegerNumber() throws RangeValueException, ValueException;

    /**
     * Returns the result as an {@link Integer}
     * or <tt>null</tt> if the value is empty.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getIntegerNumber() getIntegerNumber()};
     * }
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>int</tt> values.
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link Integer}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    Integer getIntegerNumberOrNull() throws RangeValueException, ValueException;

    /**
     * Returns the result as a <i>rounded</i> off <tt>short</tt> value.
     * Equivalent to:
     * <pre class="preshade">
     * return NumberTools.{@link NumberTools#toShort toShort}({@link
     * #getNumber getNumber()});
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>short</tt> values.
     * @exception ValueException if the value can not be
     * interpreted as a numeric value.
     *
     * @see #getShortNumber
     */
    short getShort() throws RangeValueException, ValueException;

    /**
     * Returns the result as a <i>rounded</i> off {@link Short} value.
     * Equivalent to:
     * <pre class="preshade">
     * return NumberTools.{@link NumberTools#toShortNumber toShortNumber}({@link
     * #getNumber getNumber()});
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>short</tt> values.
     * @exception ValueException if the value can not be
     * interpreted as a numeric value.
     *
     * @see #getShort
     */
    Short getShortNumber() throws RangeValueException, ValueException;

    /**
     * Returns the result as a {@link Short}
     * or <tt>null</tt> if the value is empty.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getShortNumber() getShortNumber()};
     * }
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>short</tt> values.
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link Short}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    Short getShortNumberOrNull() throws RangeValueException, ValueException;

	/**
	 * Returns the result as a <i>rounded</i> off <tt>byte</tt> value.
     * Equivalent to:
	 * <pre class="preshade">
     * return NumberTools.{@link NumberTools#toByte toByte}({@link
     * #getNumber getNumber()});
	 * </pre>
	 *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>byte</tt> values.
	 * @exception ValueException if the value can not be
	 * interpreted as a numeric value.
     *
     * @see #getByteNumber
	 */
	byte getByte() throws RangeValueException, ValueException;

	/**
	 * Returns the result as a <i>rounded</i> off {@link Byte} value.
	 * Equivalent to:
	 * <pre class="preshade">
     * return NumberTools.{@link NumberTools#toByteNumber toByteNumber}({@link
     * #getNumber getNumber()});
	 * </pre>
	 *
	 * @exception RangeValueException if the value does not fit in
	 * the range of valid <tt>byte</tt> values.
	 * @exception ValueException if the value can not be
	 * interpreted as a numeric value.
	 *
     * @see #getByte
	 */
	Byte getByteNumber() throws RangeValueException, ValueException;

    /**
     * Returns the result as a {@link Byte}
     * or <tt>null</tt> if the value is empty.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getByteNumber() getByteNumber()};
     * }
     * </pre>
     *
     * @exception RangeValueException if the value does not fit in
     * the range of valid <tt>byte</tt> values.
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link Byte}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    Byte getByteNumberOrNull() throws RangeValueException, ValueException;

	/**
	 * Returns the result as a <tt>double</tt> value. Equivalent to:
	 * <pre class="preshade">
	 * return {@link #getNumber getNumber()}.{@link Number#doubleValue()
	 * doubleValue}();
	 * </pre>
	 *
	 * @exception ValueException if the string can not be
	 * parsed into a numeric value.
	 * Note that <tt>ValueException</tt> is a {@link RuntimeException}
	 * so it does not have to be explicitly caught.
	 */
	double getDouble() throws ValueException;

    /**
     * Returns the result as a {@link Double} value.
     * Equivalent to:
     * <pre class="preshade">
     * return new Double({@link #getDouble getDouble()});
     * </pre>
     *
     * @exception ValueException if the value can not be
     * interpreted as a numeric value.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     *
     * @see #getDouble
     */
    Double getDoubleNumber() throws ValueException;

    /**
     * Returns the result as an {@link Double}
     * or <tt>null</tt> if the value is empty.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getDoubleNumber() getDoubleNumber()};
     * }
     * </pre>
     *
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link Double}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    Double getDoubleNumberOrNull() throws ValueException;

	/**
	 * Returns the result as a <tt>float</tt> value. Equivalent to:
	 * <pre class="preshade">
	 * return {@link #getNumber getNumber()}.{@link Number#floatValue()
	 * floatValue}();
	 * </pre>
	 *
	 * @exception ValueException if the string can not be
	 * parsed into a numeric value.
	 * Note that <tt>ValueException</tt> is a {@link RuntimeException}
	 * so it does not have to be explicitly caught.
	 */
	float getFloat() throws ValueException;

    /**
     * Returns the result as a {@link Float} value.
     * Equivalent to:
     * <pre class="preshade">
     * return new Float({@link #getFloat getFloat()});
     * </pre>
     *
     * @exception ValueException if the value can not be
     * interpreted as a numeric value.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     *
     * @see #getFloat
     */
    Float getFloatNumber() throws ValueException;

    /**
     * Returns the result as an {@link Float}
     * or <tt>null</tt> if the value is empty.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getFloatNumber() getFloatNumber()};
     * }
     * </pre>
     *
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link Float}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    Float getFloatNumberOrNull() throws ValueException;

	/**
	 * Returns the result as a <tt>boolean</tt> value.
	 * Returns <tt>true</tt> if the result of {@link #getString() getString()}
	 * matches (case-<i>in</i>sensitively) any one of the following:
	 * <pre>
	 *     true, t,
	 *     yes, y,
	 *     on,
	 *     1
	 * </pre>
	 */
	boolean isTrue();

    /**
     * Returns <tt>true</tt> if the encapsulated value can <i>not</i> be
     * interpreted as something considered to be "true".
     * See {@link #isTrue() isTrue()} for an explanation of how
     * "true" is interpreted. This method can be thought of more as a
     * "is not true" as opposed to confirming that something is "false"
     * (for example, blank and <tt>null</tt> are consider to be "not true").
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isTrue() isTrue}();
     * </pre>
     */
    boolean isFalse();

    /**
     * Returns the encapsulated value interpreted as a {@link TriState}.
     * More specifically:
     * <ul>
     * <li>If the encapsulated value is a {@link TriState},
     * the value is simply returned.</li>
     * <li>If the encapsulated value is <tt>null</tt>, then
     * {@link TriState#UNKNOWN} is returned.</li>
     * <li>If the encapsulated value is a {@link Boolean}
     * and that <tt>Boolean</tt> is holding <tt>true</tt>, then
     * {@link TriState#YES} is returned.</li>
     * <li>If the encapsulated value is a {@link Boolean}
     * and that <tt>Boolean</tt> is holding <tt>false</tt>, then
     * {@link TriState#NO} is returned.</li>
     * <li>If the result of {@link #getString() getString()}
     * matches (case-<i>in</i>sensitively) any one of the following:
     * <tt>"yes"</tt>, <tt>"y"</tt>, <tt>"true"</tt>, <tt>"t"</tt>,
     * <tt>"on"</tt>, or <tt>"1"</tt>,
     * then {@link TriState#YES} is returned.</li>
     * <li>If the result of {@link #getString() getString()}
     * matches (case-<i>in</i>sensitively) any one of the following:
     * <tt>"no"</tt>, <tt>"n"</tt>, <tt>"false"</tt>, <tt>"f"</tt>,
     * <tt>"off"</tt>, or <tt>"0"</tt>,
     * then {@link TriState#NO} is returned.</li>
     * <li>Otherwise, {@link TriState#UNKNOWN} is returned.</li>
     * </ul>
     * This method always returns one of the instances of {@link TriState},
     * <tt>null</tt> is never returned.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * Object obj = {@link #getObject() getObject}();
     * if ( obj instanceof {@link TriState} ) {
     *     return (TriState) obj;
     * } else if ( obj == null ) {
     *     return TriState.{@link TriState#UNKNOWN UNKNOWN};
     * } else if ( obj instanceof Boolean ) {
     *     if ( ((Boolean) obj).booleanValue() == true ) {
     *         return TriState.{@link TriState#YES YES};
     *     } else {
     *         return TriState.{@link TriState#NO NO};
     *     }
     * }
     *
     * String s = {@link #getString() getString}();
     * if ( "yes".equalsIgnoreCase(s) || "y".equalsIgnoreCase(s) ||
     *      "true".equalsIgnoreCase(s) || "t".equalsIgnoreCase(s) ||
     *      "on".equalsIgnoreCase(s) || "1".equals(s) ) {
     *
     *     return TriState.{@link TriState#YES YES};
     * }
     *
     * if ( "no".equalsIgnoreCase(s) || "n".equalsIgnoreCase(s) ||
     *      "false".equalsIgnoreCase(s) || "f".equalsIgnoreCase(s) ||
     *      "off".equalsIgnoreCase(s) || "0".equals(s) ) {
     *
     *     return TriState.{@link TriState#NO NO};
     * }
     *
     * return TriState.{@link TriState#UNKNOWN UNKNOWN};
     * </pre>
     */
    TriState getTriState();

    /**
     * Returns <tt>true</tt> if this value is, or if it can be interpreted as,
     * a {@link DateTime}.
     * Specifically, <tt>true</tt> is returned if calling
     * {@link #getDateTime()} will not result in an exception being thrown.
     */
    boolean isDateTime();

    /**
     * Returns <tt>true</tt> if the encapsulated value can not be interpreted
     * as a {@link DateTime} value.
     * See {@link #getDateTime() getDateTime()} for an explanation of how
     * <i>DateTime</i> is determined.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isDateTime() isDateTime}();
     * </pre>
     */
    boolean isNotDateTime();

    /**
     * Returns the encapsulated value interpreted as a {@link DateTime}
     * assuming the UTC timezone <i>if necessary</i>.
     * More specifically:
     * <ul>
     * <li>If the encapsulated value is a {@link DateTime},
     * the value is simply returned.
     * The default timezone of UTC is neither needed nor used.</li>
     * <li>If the <tt>String</tt> returned by {@link #getString() getString()}
     * can be successfully parsed by the
     * {@link DateTools#parseUTC(String)} method, the resulting
     * <tt>DateTime</tt> is returned, if not, a <tt>ValueException</tt>
     * is thrown instead.</li>
     * <li>If the encapsulated value is <tt>null</tt>,
     * <tt>ValueException</tt> is thrown.</li>
     * </ul>
     * This method assumes the UTC timezone should be used to
     * interpret the time if (and only if) no understandable timezone
     * information is present at the end of the supplied <tt>String</tt>.
     *
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * Object obj = {@link #getObject() getObject}();
     * if ( obj instanceof {@link DateTime} ) {
     *     return (DateTime) obj;
     * }
     *
     * try {
     *     return DateTools.{@link DateTools#parseUTC(String)
     *         parseUTC}({@link #getString() getString}());
     * } catch ( DateTimeException x ) {
     *     throw new ValueException(x);
     * }
     * </pre>
     *
     * @exception ValueException if the encapsulated value is
     * <tt>null</tt> or if it is not a instance of <tt>DateTime</tt> and the
     * result of <tt>getString()</tt> can not be parsed into a DateTime.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    DateTime getDateTime() throws ValueException;

    /**
     * Returns the result as a {@link DateTime}
     * or <tt>null</tt> if the value is empty
     * (using the UTC timezone for interpretation if necessary).
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getDateTime() getDateTime()};
     * }
     * </pre>
     *
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link DateTime}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    DateTime getDateTimeOrNull() throws ValueException;

    /**
     * Returns the encapsulated value interpreted as a {@link DateTime}
     * assuming the local VM's timezone <i>if necessary</i>.
     * More specifically:
     * <ul>
     * <li>If the encapsulated value is a {@link DateTime},
     * the value is simply returned.
     * The default timezone of the local VM is neither needed nor used.</li>
     * <li>If the <tt>String</tt> returned by {@link #getString() getString()}
     * can be successfully parsed by the
     * {@link DateTools#parseLocal(String)} method, the resulting
     * <tt>DateTime</tt> is returned, if not, a <tt>ValueException</tt>
     * is thrown instead.</li>
     * <li>If the encapsulated value is <tt>null</tt>,
     * <tt>ValueException</tt> is thrown.</li>
     * </ul>
     * This method assumes the VM's local timezone should be used to
     * interpret the time if (and only if) no understandable timezone
     * information is present at the end of the supplied <tt>String</tt>.
     *
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * Object obj = {@link #getObject() getObject}();
     * if ( obj instanceof DateTime ) {
     *     return (DateTime) obj;
     * }
     *
     * try {
     *     return DateTools.{@link DateTools#parseLocal(String)
     *         parseLocal}({@link #getString() getString}());
     * } catch ( DateTimeException x ) {
     *     throw new ValueException(x);
     * }
     * </pre>
     *
     * @exception ValueException if the encapsulated value is
     * <tt>null</tt> or if it is not a instance of <tt>DateTime</tt> and the
     * result of <tt>getString()</tt> can not be parsed into a DateTime.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    DateTime getDateTimeLocal() throws ValueException;

    /**
     * Returns the result as a {@link DateTime}
     * or <tt>null</tt> if the value is empty
     * (using the local VM's timezone for interpretation if necessary).
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getDateTimeLocal() getDateTimeLocal()};
     * }
     * </pre>
     *
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link DateTime}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    DateTime getDateTimeLocalOrNull() throws ValueException;

    /**
     * Returns the encapsulated value interpreted as a {@link DateTime}
     * assuming the specified timezone <i>if necessary</i>.
     * More specifically:
     * <ul>
     * <li>If the encapsulated value is a {@link DateTime},
     * the value is simply returned.
     * The timezone passed in is neither needed nor used.</li>
     * <li>If the <tt>String</tt> returned by {@link #getString() getString()}
     * can be successfully parsed by the
     * {@link DateTools#parse(String, TimeZone)} method, the resulting
     * <tt>DateTime</tt> is returned, if not, a <tt>ValueException</tt>
     * is thrown instead.</li>
     * <li>If the encapsulated value is <tt>null</tt>,
     * <tt>ValueException</tt> is thrown.</li>
     * </ul>
     * This method uses the timezone passed in as a parameter to
     * interpret the time if (and only if) no understandable timezone
     * information is present at the end of the supplied <tt>String</tt>.
     *
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * Object obj = {@link #getObject() getObject}();
     * if ( obj instanceof DateTime ) {
     *     return (DateTime) obj;
     * }
     *
     * try {
     *     return DateTools.{@link DateTools#parse(String, TimeZone)
     *         parse}({@link #getString() getString}(), defaultTimeZone);
     * } catch ( DateTimeException x ) {
     *     throw new ValueException(x);
     * }
     * </pre>
     *
     * @param defaultTimeZone the timezone to use to interpret the value
     * as a <tt>DateTime</tt> if necessary.
     *
     * @exception ValueException if the encapsulated value is
     * <tt>null</tt> or if it is not a instance of <tt>DateTime</tt> and the
     * result of <tt>getString()</tt> can not be parsed into a DateTime.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     * @exception IllegalArgumentException if <tt>defaultTimeZone</tt>
     * is <tt>null</tt>.
     */
    DateTime getDateTime(TimeZone defaultTimeZone)
            throws ValueException, IllegalArgumentException;

    /**
     * Returns the result as a {@link DateTime}
     * or <tt>null</tt> if the value is empty
     * (using the specified timezone for interpretation if necessary).
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getDateTime(TimeZone) getDateTime(defaultTimeZone)};
     * }
     * </pre>
     *
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link DateTime}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     * @exception IllegalArgumentException if <tt>defaultTimeZone</tt>
     * is <tt>null</tt>.
     */
    DateTime getDateTimeOrNull(TimeZone defaultTimeZone)
            throws ValueException, IllegalArgumentException;

    /**
     * Returns <tt>true</tt> if this value is, or if it can be interpreted as,
     * a {@link PlainDate}.
     * Specifically, <tt>true</tt> is returned if calling
     * {@link #getPlainDate()} will not result in an exception being thrown.
     */
    boolean isPlainDate();

    /**
     * Returns <tt>true</tt> if the encapsulated value can not be interpreted
     * as a {@link PlainDate} value.
     * See {@link #getPlainDate() getPlainDate()} for an explanation of how
     * <i>PlainDate</i> is determined.
     * Equivalent to:
     * <pre class="preshade">
     * return <b>!</b>{@link #isPlainDate() isPlainDate}();
     * </pre>
     */
    boolean isNotPlainDate();

    /**
     * Returns the encapsulated value interpreted as a {@link PlainDate}.
     * More specifically:
     * <ul>
     * <li>If the encapsulated value is a {@link PlainDate},
     * the value is simply returned.</li>
     * <li>If the <tt>String</tt> returned by {@link #getString() getString()}
     * can be successfully parsed by the
     * {@link DateTools#parsePlainDate(String)} method, the resulting
     * <tt>PlainDate</tt> is returned, if not, a <tt>ValueException</tt>
     * is thrown instead.</li>
     * <li>If the encapsulated value is <tt>null</tt>,
     * <tt>ValueException</tt> is thrown.</li>
     * </ul>
     *
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * Object obj = {@link #getObject() getObject}();
     * if ( obj instanceof {@link PlainDate} ) {
     *     return (PlainDate) obj;
     * }
     *
     * try {
     *     return DateTools.{@link DateTools#parsePlainDate(String)
     *         parsePlainDate}({@link #getString() getString}());
     * } catch ( PlainDateException x ) {
     *     throw new ValueException(x);
     * }
     * </pre>
     *
     * @exception ValueException if the encapsulated value is
     * <tt>null</tt> or if it is not a instance of <tt>PlainDate</tt> and the
     * result of <tt>getString()</tt> can not be parsed into a PlainDate.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    PlainDate getPlainDate() throws ValueException;

    /**
     * Returns the result as a {@link PlainDate}
     * or <tt>null</tt> if the value is empty.
     * Equivalent to:
     * <pre class="preshade">
     * if ( {@link #isEmpty() isEmpty()} ) {
     *     return null;
     * } else {
     *     return {@link #getPlainDate() getPlainDate()};
     * }
     * </pre>
     *
     * @exception ValueException if the value is not empty and can not be
     * viewed as a {@link PlainDate}.
     * Note that <tt>ValueException</tt> is a {@link RuntimeException}
     * so it does not have to be explicitly caught.
     */
    PlainDate getPlainDateOrNull() throws ValueException;

    /**
     * Returns the encapsulated value interpreted as a <tt>byte[]</tt>.
     * If the underlying value is actually a <tt>byte[]</tt>,
     * it is simply returned.
     * Otherwise, the result of {@link #getString()} is passed through
     * {@link StringTools#parseHexString(String)}.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * Object obj = {@link #getObject() getObject()};
     * if ( obj instanceof byte[] ) {
     *     return (byte[]) ((byte[]) obj).clone();
     * }
     *
     * return StringTools.{@link StringTools#parseHexString(String)
     * parseHexString}({@link #getString getString}());
     * </pre>
     * <p>
     * The <tt>byte[]</tt> returned
     * is a <i>copy</i> of the internal data, so there is no chance that an
     * outsider could manipulate the bytes held internally. To avoid making
     * copies of large amounts of data, you may want to consider
     * using {@link #getBytesAsStream()} instead.
     *
     * @return the value as an array of bytes. This method never
     * returns <tt>null</tt>. If the stored value is not a <tt>byte[]</tt>
     * and the parsing does not find any valid hex digits, then a
     * zero-length <tt>byte[]</tt> is returned. The <tt>byte[]</tt> returned
     * is a <i>copy</i> of the internal data, so there is no chance that an
     * outsider could manipulate the bytes held internally.
     *
     * @see #getBytesAsStream()
     */
    byte[] getBytes();

    /**
     * Returns the encapsulated value interpreted as bytes that are
     * readable from {@link InputStream}.
     * Internally, the <tt>byte[]</tt> that serves as a data source for an
     * {@link InputStream} is <tt>byte[]</tt> derived by {@link #getBytes()}
     * (however, there is no need to make a copy of the internal
     * <tt>byte[]</tt> as the <tt>InputStream</tt> provides no mechanism
     * for altering the source of the data). Every call to this method
     * returns a new lightweight <tt>InputStream</tt> that can be independently
     * read, but the bulky <tt>byte[]</tt> is efficiently shared among all of
     * the <tt>InputStream</tt>'s that are constructed.
     * <p>
     * This method is a more memory efficient than calling {@link #getBytes()}
     * as no copy of the binary data needs to be made.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * Object obj = {@link #getObject() getObject()};
     * if ( obj instanceof byte[] ) {
     *     return new ByteArrayInputStream((byte[]) obj);
     * }
     *
     * return new ByteArrayInputStream(
     *     StringTools.{@link StringTools#parseHexString(String)
     * parseHexString}({@link #getString getString}()));
     * </pre>
     *
     * @return the value as an stream of bytes available on an
     * <tt>InputStream</tt>. This method never
     * returns <tt>null</tt>. If the stored value is not a <tt>byte[]</tt>
     * and the parsing does not find any valid hex digits, then a
     * zero-length <tt>byte[]</tt> is used as the source for the
     * <tt>InputStream</tt>.
     *
     * @see #getBytes()
     */
    InputStream getBytesAsStream();

    /**
     * Returns <tt>true</tt> if the <tt>public</tt> view of this <tt>Value</tt>
     * <i>might</i> change over time. Note that most of the common
     * implementations of <tt>Value</tt> return <tt>false</tt> for this method.
     * If this method returns <tt>false</tt> then callers can be <i>sure</i>
     * that two calls to the same method on this particular <tt>Value</tt>
     * instance will <i><b>always</b></i> return the same result (the value
     * returned never changes).
     * <p>
     * If implementors of <tt>Value</tt> want to use internal caching for
     * efficiency, they are free to return <tt>false</tt> from
     * <tt>isMutable()</tt> as long as the return values for all of the
     * non-<tt>private</tt> methods never change.
     * <p>
     * Ironically, the return value from <i>this method</i> must be fixed
     * at the time of construction and may never change. If this method ever
     * returns <tt>false</tt> is must continue to return <tt>false</tt> during
     * any subsequent calls.
     *
     * @return <tt>true</tt> if the return values from other methods might
     * change over time, <tt>false</tt> if return values from all methods
     * are always the same.
     */
    boolean isMutable();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.