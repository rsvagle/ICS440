package com.programix.value;

/**
 * Used to signal problems with {@link ValueMap}.
 * This is a {@link RuntimeException}, so it can be generally ignored 
 * (use of <tt>try</tt>/<tt>catch</tt> is not <i>required</i>).
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ValueMapException extends RuntimeException {
    public ValueMapException() {
        super();
    }

    public ValueMapException(String message) {
        super(message);
    }

    public ValueMapException(String message, Throwable cause) {
        super(message, cause);
    }

    public ValueMapException(Throwable cause) {
        super(cause);
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.