package com.programix.value;


/**
 * A kind of {@link ValueException} thrown to indicate that a {@link Value} 
 * can not fit in the range of values for a given type. 
 * This is a {@link RuntimeException}, so use of a
 * <tt>try</tt>/<tt>catch</tt> block is not <i>required</i>.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde </a>
 */
public class RangeValueException extends ValueException {
    public RangeValueException(String message, Throwable cause) {
        super(message, cause);
    }

    public RangeValueException(Throwable cause) {
        super(cause);
    }

    public RangeValueException(String message) {
        super(message);
    }

    public RangeValueException() {
        super();
    }
    
    public static void throwForByte() throws RangeValueException {
        throw new RangeValueException(
            "Value does not fit into the range for 'byte': -128 .. 127");
    }
    
    public static void throwForShort() throws RangeValueException {
        throw new RangeValueException(
            "Value does not fit into the range for 'short': -32768 .. 32767");
        
    }
    
    public static void throwForInt() throws RangeValueException {
        throw new RangeValueException(
            "Value does not fit into the range for " +
            "'int': -2147483648 .. 2147483647");
    }
    
    public static void throwForLong() throws RangeValueException {
        throw new RangeValueException(
            "Value does not fit into the range for " +
            "'long': -9223372036854775808 .. 9223372036854775807");
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.