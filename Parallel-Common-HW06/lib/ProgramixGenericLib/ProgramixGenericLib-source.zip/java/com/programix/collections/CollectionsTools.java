package com.programix.collections;

import java.util.*;

import com.programix.util.*;

/**
 * Utility methods for working with the Collections API.
 * Unless otherwise stated, these methods are <u>not</u> thread-safe.
 *
 * @see ReverseComparator
 * @see ComparableComparator
 * @see NullFirstComparator
 * @see NullLastComparator
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class CollectionsTools extends Object {

    /**
     * This {@link Comparator} sorts {@link Comparable} objects in their
     * normal ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the top.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<Comparable<?>> NULL_FIRST_COMPARABLE_ASC =
        new NullFirstComparator<Comparable<?>>(
            new ComparableComparator<Comparable<?>>());

    /**
     * This {@link Comparator} sorts {@link Comparable} objects in their
     * reverse ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the top.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<Comparable<?>> NULL_FIRST_COMPARABLE_DESC =
        new NullFirstComparator<Comparable<?>>(
            new ReverseComparator<Comparable<?>>(
                new ComparableComparator<Comparable<?>>()));

    /**
     * This {@link Comparator} sorts {@link Comparable} objects in their
     * normal ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the bottom.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<Comparable<?>> NULL_LAST_COMPARABLE_ASC =
        new NullLastComparator<Comparable<?>>(
            new ComparableComparator<Comparable<?>>());

    /**
     * This {@link Comparator} sorts {@link Comparable} objects in their
     * reverse ordering, but with any <tt>null</tt>'s
     * that may be present sorted to the bottom.
     *
     * @see NullFirstComparator
     * @see NullLastComparator
     * @see ReverseComparator
     * @see ComparableComparator
     */
    public static final Comparator<Comparable<?>> NULL_LAST_COMPARABLE_DESC =
        new NullLastComparator<Comparable<?>>(
            new ReverseComparator<Comparable<?>>(
                new ComparableComparator<Comparable<?>>()));

    // no instances
	private CollectionsTools() {
	}

    public static String[] toStringArray(Collection<String> strings) {
        return StringTools.toArray(strings);
    }

	/**
	 * Converts a collection of {@link Number} to an <tt>int[]</tt>.
	 */
	public static int[] toIntArray(Collection<? extends Number> integerList) {
		int[] data = new int[integerList.size()];
		int ptr = 0;
		for ( Number number : integerList ) {
            data[ptr] = number.intValue();
            ptr++;
        }

		return data;
	}

    /**
     * Converts a <tt>Collection</tt> holding instances of
     * {@link Character} into a <tt>char[]</tt>.
     */
	public static char[] toCharArray(Collection<Character> charList) {
		char[] ch = new char[charList.size()];
		int ptr = 0;
		for ( Character c : charList ) {
		    ch[ptr] = c.charValue();
		    ptr++;
		}

		return ch;
	}

    /**
     * Returns <tt>true</tt> if the passed reference is <tt>null</tt>
     * or if the size of the collection is <tt>0</tt>.
     */
    public static boolean isEmpty(Collection<?> collection) {
        return collection == null || collection.size() == 0;
    }

    /**
     * Returns <tt>true</tt> if the passed reference is not <tt>null</tt>
     * and the size of the collection greater than <tt>0</tt>.
     */
    public static boolean isNotEmpty(Collection<?> collection) {
        return !isEmpty(collection);
    }

// Add this when going to 1.5 using <?> and <T> and such...
//    /**
//     * Returns an array snapshot of the elements in the collection as
//     * an array of the specified elementType. This can be explicitly
//     * cast, for example:
//     * <pre class="preshade">
//     * List list = new ArrayList();
//     * list.add(new DateTime());
//     * list.add(new DateTime());
//     * list.add(new DateTime());
//     * DateTime[] dt = (DateTime[])
//     *     CollectionTools.toArray(list, DateTime.class);
//     * </pre>
//     * @param col
//     * @param elementType
//     * @return
//     */
//    public static Object[] toArray(Collection col, Class elementType) {
//
//    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.