package com.programix.collections;

import java.util.*;

import com.programix.util.*;

/**
 * {@link Comparator} that can be used to compare <tt>String</tt>'s in
 * many different ways. Instances are immutable (everything must be
 * specified during construction).
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class GeneralStringComparator implements Comparator<String> {
    private CharSort charSort;
    private NullTreatment nullTreatment;
    private LengthTreatment lengthTreatment;
    private boolean trimBeforeCompare;

    public GeneralStringComparator(CharSort charSort,
                                   NullTreatment nullTreatment,
                                   LengthTreatment lengthTreatment,
                                   boolean trimBeforeCompare) {

        this.charSort = charSort;
        this.nullTreatment = nullTreatment;
        this.lengthTreatment = lengthTreatment;
        this.trimBeforeCompare = trimBeforeCompare;
    }

    /**
     * Defaults to case insensitive ascending, null less than all,
     * no special length treatment, and all strings trimmed before
     * comparing.
     * <p>
     * Equivalent to:
     * <pre>
     * this(CharSort.CASE_INSENSITIVE_ASC,
     *      NullTreatment.LESS_THAN_ALL,
     *      LengthTreatment.NONE,
     *      true);
     * </pre>
     */
    public GeneralStringComparator() {
        this(CharSort.CASE_INSENSITIVE_ASC,
             NullTreatment.LESS_THAN_ALL,
             LengthTreatment.NONE,
             true);
    }

    public CharSort getCharSort() {
        return charSort;
    }

    public LengthTreatment getLengthTreatment() {
        return lengthTreatment;
    }

    public NullTreatment getNullTreatment() {
        return nullTreatment;
    }

    public boolean isTrimBeforeCompare() {
        return trimBeforeCompare;
    }

    public int compare(String obj1, String obj2) {
        if ( obj1 == obj2 ) {
            // if exact same object or both are null, consider equal
            return 0;
        }

        if ( obj1 == null ) {
            // We know that obj2 is not also null as that would have been
            // caught above and 0 would have already been returned.

            if ( NullTreatment.LESS_THAN_ALL.equals(nullTreatment) ) {
                return -1;
            } else if ( NullTreatment.GREATER_THAN_ALL.equals(nullTreatment) ) {
                return 1;
            }
        } else if ( obj2 == null ) {
            // We know that obj1 is not also null as that would have been
            // caught above and 0 would have already been returned.

            if ( NullTreatment.LESS_THAN_ALL.equals(nullTreatment) ) {
                return 1;
            } else if ( NullTreatment.GREATER_THAN_ALL.equals(nullTreatment) ) {
                return -1;
            }
        }

        String s1 = (trimBeforeCompare) ?
            StringTools.trim(obj1) : StringTools.nullToBlank(obj1);

        String s2 = (trimBeforeCompare) ?
            StringTools.trim(obj2) : StringTools.nullToBlank(obj2);

        if ( LengthTreatment.SHORTEST_FIRST.equals(lengthTreatment) ) {
            int diff = s1.length() - s2.length();
            if ( diff != 0 ) {
                return diff;
            }
        } else if ( LengthTreatment.LONGEST_FIRST.equals(lengthTreatment) ) {
            int diff = s2.length() - s1.length();
            if ( diff != 0 ) {
                return diff;
            }
        }

        if ( CharSort.CASE_SENSITIVE_ASC.equals(charSort) ) {
            return s1.compareTo(s2);
        } else if ( CharSort.CASE_INSENSITIVE_ASC.equals(charSort) ) {
            return s1.compareToIgnoreCase(s2);
        } else if ( CharSort.CASE_SENSITIVE_DESC.equals(charSort) ) {
            return s2.compareTo(s1);
        } else {
            // CharSort.CASE_INSENSITIVE_DESC
            return s2.compareToIgnoreCase(s1);
        }
    }

    /**
     * Defines how <tt>null</tt> references should be treated when being
     * compared to <tt>String</tt>'s.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static final class NullTreatment {
        /**
         * When a <tt>null</tt> reference is found, treat it as if it
         * was a zero-length string.
         */
        public static final NullTreatment ZERO_LENGTH_STRING =
            new NullTreatment(1, "ZERO_LENGTH_STRING");

        /**
         * When a <tt>null</tt> reference is found, treat it as if it is
         * less than all other strings. This does not apply to comparing
         * <tt>null</tt> to <tt>null</tt> as they are considered to be
         * equal to each other.
         */
        public static final NullTreatment LESS_THAN_ALL =
            new NullTreatment(2, "LESS_THAN_ALL");

        /**
         * When a <tt>null</tt> reference is found, treat it as if it is
         * greater than all other strings. This does not apply to comparing
         * <tt>null</tt> to <tt>null</tt> as they are considered to be
         * equal to each other.
         */
        public static final NullTreatment GREATER_THAN_ALL =
            new NullTreatment(3, "GREATER_THAN_ALL");

        private static final NullTreatment[] VALUE_LIST = {
                ZERO_LENGTH_STRING, LESS_THAN_ALL, GREATER_THAN_ALL
        };

        private final int value;
        private final String name;

        private NullTreatment(int value, String name) {
            this.value = value;
            this.name = name;
        }

        public String getName() {
            return name;
        }

        /**
         * Use this method instead of <tt>==</tt> to be sure that serialization
         * or multiple class loaders have not resulted in multiple instances.
         */
        @Override
        public boolean equals(Object obj) {
            if ( this == obj ) {
                return true;
            } else if ( (obj instanceof NullTreatment) == false ) {
                return false;
            }

            NullTreatment other = (NullTreatment) obj;
            return value == other.value;
        }

        @Override
        public int hashCode() {
            return value;
        }

        @Override
        public String toString() {
            StringBuffer sb = new StringBuffer(getClass().getName() + "[");
            sb.append("name=" + name);
            sb.append("]");
            return sb.toString();
        }

        /**
         * Returns an array of all the legal values. A cloned copy is returned,
         * so no caution is required.
         */
        public static NullTreatment[] getValues() {
            return (NullTreatment[]) VALUE_LIST.clone();
        }
    } // class NullTreatment

    /**
     * Defines how the length of the string should be considered when being
     * compared to other <tt>String</tt>'s.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static final class LengthTreatment {
        /**
         * Nothing about the length of the <tt>String</tt> should be
         * given special consideration.
         */
        public static final LengthTreatment NONE =
            new LengthTreatment(1, "NONE");

        /**
         * The shortest <tt>String</tt>'s should come first. Any additional
         * sorting would happen within that length group (all the strings with
         * a length of 4 would be sorted together, etc.).
         */
        public static final LengthTreatment SHORTEST_FIRST =
            new LengthTreatment(2, "SHORTEST_FIRST");

        /**
         * The longest <tt>String</tt>'s should come first. Any additional
         * sorting would happen within that length group (all the strings with
         * a length of 4 would be sorted together, etc.).
         */
        public static final LengthTreatment LONGEST_FIRST =
            new LengthTreatment(3, "LONGEST_FIRST ");

        private static final LengthTreatment[] VALUE_LIST = {
                NONE, SHORTEST_FIRST, LONGEST_FIRST
        };

        private final int value;
        private final String name;

        private LengthTreatment(int value, String name) {
            this.value = value;
            this.name = name;
        }

        public String getName() {
            return name;
        }

        /**
         * Use this method instead of <tt>==</tt> to be sure that serialization
         * or multiple class loaders have not resulted in multiple instances.
         */
        @Override
        public boolean equals(Object obj) {
            if ( this == obj ) {
                return true;
            } else if ( (obj instanceof LengthTreatment) == false ) {
                return false;
            }

            LengthTreatment other = (LengthTreatment) obj;
            return value == other.value;
        }

        @Override
        public int hashCode() {
            return value;
        }

        @Override
        public String toString() {
            StringBuffer sb = new StringBuffer(getClass().getName() + "[");
            sb.append("name=" + name);
            sb.append("]");
            return sb.toString();
        }

        /**
         * Returns an array of all the legal values. A cloned copy is returned,
         * so no caution is required.
         */
        public static LengthTreatment[] getValues() {
            return (LengthTreatment[]) VALUE_LIST.clone();
        }
    } // class LengthTreatment

    /**
     * Defines how the characters of the string should be considered when being
     * compared to other <tt>String</tt>'s.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static final class CharSort {
        /**
         * Character's case will be considered and will sort ascending.
         */
        public static final CharSort CASE_SENSITIVE_ASC =
            new CharSort(1, "CASE_SENSITIVE_ASC");

        /**
         * Character's case will be considered and will sort descending.
         */
        public static final CharSort CASE_SENSITIVE_DESC =
            new CharSort(2, "CASE_SENSITIVE_DESC");

        /**
         * Character's case will be not be considered and will sort ascending.
         */
        public static final CharSort CASE_INSENSITIVE_ASC =
            new CharSort(3, "CASE_INSENSITIVE_ASC");

        /**
         * Character's case will not be be considered and will sort descending.
         */
        public static final CharSort CASE_INSENSITIVE_DESC =
            new CharSort(4, "CASE_INSENSITIVE_DESC");

        private static final CharSort[] VALUE_LIST = {
                CASE_SENSITIVE_ASC, CASE_SENSITIVE_DESC,
                CASE_INSENSITIVE_ASC, CASE_INSENSITIVE_DESC
        };

        private final int value;
        private final String name;

        private CharSort(int value, String name) {
            this.value = value;
            this.name = name;
        }

        public String getName() {
            return name;
        }

        /**
         * Use this method instead of <tt>==</tt> to be sure that serialization
         * or multiple class loaders have not resulted in multiple instances.
         */
        @Override
        public boolean equals(Object obj) {
            if ( this == obj ) {
                return true;
            } else if ( (obj instanceof CharSort) == false ) {
                return false;
            }

            CharSort other = (CharSort) obj;
            return value == other.value;
        }

        @Override
        public int hashCode() {
            return value;
        }

        @Override
        public String toString() {
            StringBuffer sb = new StringBuffer(getClass().getName() + "[");
            sb.append("name=" + name);
            sb.append("]");
            return sb.toString();
        }

        /**
         * Returns an array of all the legal values. A cloned copy is returned,
         * so no caution is required.
         */
        public static CharSort[] getValues() {
            return (CharSort[]) VALUE_LIST.clone();
        }
    } // class CharSort
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.