package com.programix.collections;

import java.util.*;

/**
 * This {@link Comparator} wrapper considers "null" to be "less than"
 * any non-null reference and will sort any null's to the top.
 * This <tt>Comparator</tt> wraps around a "raw" <tt>Comparator</tt> and
 * first checks to see if either of the references is null. If they are
 * both null, then they are considered equal. If one is null and the other
 * is not null, then the null one is considered to be "less than" the other.
 * If both references are not null, then the supplied "raw" <tt>Comparator</tt>
 * is used to complete the comparison.
 *
 * @see NullLastComparator
 * @see ReverseComparator
 * @see ComparableComparator
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class NullFirstComparator<T> implements Comparator<T> {
    private final Comparator<T> rawComparator;

    /**
     * Create a wrapper that checks for null references before calling
     * the <tt>rawComparator</tt> and considers null's to be "less than"
     * non-null references.
     *
     * @param rawComparator the comparator to use if (and only if) both
     * references are NOT null.
     */
    public NullFirstComparator(Comparator<T> rawComparator) {
        this.rawComparator = rawComparator;
    }

    /**
     * This implementation of the
     * {@link Comparator#compare(Object, Object) compare} method on
     * {@link Comparator} will quickly check
     * if both references are the same using <tt>==</tt> (which
     * evaluates to <tt>true</tt> if both references are pointing
     * to the same object or both are <tt>null</tt>).
     * If the references are the same, then this will quickly return
     * <tt>0</tt>.
     */
    public int compare(T obj1, T obj2) {
        if ( obj1 == obj2 ) {
            // same object or both null
            return 0;
        }

        if ( obj1 == null ) {
            // obj1 is null, but obj2 is not
            return -1;
        } else if ( obj2 == null ) {
            // obj1 is not null, but obj2 is
            return 1;
        } else {
            // both are NOT null
            return rawComparator.compare(obj1, obj2);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.