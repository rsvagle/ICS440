package com.programix.collections;

import java.util.*;

/**
 * This {@link Comparator} wrapper reverses the sense of the
 * <tt>Comparator</tt> supplied at the time of construction.
 * If the original <tt>Comparator</tt> would have returned a <tt>1</tt>,
 * then this reverses it and returns a <tt>-1</tt> (and vice versa).
 *
 * @see NullFirstComparator
 * @see NullLastComparator
 * @see ComparableComparator
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public final class ReverseComparator<T> implements Comparator<T> {
    private final Comparator<T> forwardComparator;

    /**
     * Takes the supplied <i>forward</i> {@link Comparator} and
     * holds it for use when the reversing is needed.
     */
    public ReverseComparator(Comparator<T> forwardComparator) {
        this.forwardComparator = forwardComparator;
    }

    /**
     * This implementation of the
     * {@link Comparator#compare(Object, Object) compare} method on
     * {@link Comparator} will quickly check
     * if both references are the same using <tt>==</tt> (which
     * evaluates to <tt>true</tt> if both references are pointing
     * to the same object or both are <tt>null</tt>).
     * If the references are the same, then this will quickly return
     * <tt>0</tt>.
     * <p>
     * If the references are not the same, then the forward comparator supplied
     * at construction is used.
     */
    public int compare(T obj1, T obj2) {
        if ( obj1 == obj2 ) {
            // pointing to the same object, or both are null.
            return 0;
        } else {
            return forwardComparator.compare(obj2, obj1);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.