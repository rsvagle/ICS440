package com.programix.collections;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Commonly needed utilities for working with the Collections API Map.
 */
public class MapTools extends Object {
	private MapTools() {
	}

	public static <K, V> V get(Map<K, V> map, K key) throws MapException {
		if ( map == null ) {
			throw new MapException("Map passed in is a null reference");
		}

		if ( key == null ) {
			throw new MapException("key passed in is a null reference");
		}

		V value = map.get(key);

		if ( value == null ) {
			throw new MapException(
				"required key '" + key + "' not found in map");
		}

		return value;
	}

	public static <K, V> V get(Map<K, V> map, K key, Class<V> valueType)
			throws MapException {

		V value = get(map, key);

		if ( (valueType != null) && (valueType.isInstance(value) == false) ) {
			throw new MapException("retrieved object's type (" +
				value.getClass().getName() + ") can't be cast into the " +
				"target type (" + valueType.getName() + ")");

		}

		return value;
	}

	/**
	 * Used to lookup required String values in a Map.
	 *
	 * @exception MapException if the key is not in the map or if
	 * the value found can't be cast into a String or either either
	 * parameter is null.
	 */
	public static <K> String getString(Map<K, String> map, K key)
	        throws MapException {

		String value = get(map, key);

		if ( !(value instanceof String) ) {
			throw new MapException("value found is not a String, it is: " +
				value.getClass().getName());
		}

		return value;
	}

	public static Properties generateFrom(InputStream rawIn)
			throws MapException {

		try {
			Properties prop = new Properties();
			prop.load(new BufferedInputStream(rawIn));
			return prop;
		} catch ( IOException x ) {
			throw new MapException("failed to load map", x);
		}
	}

	public static Properties generateFrom(File propertiesFile)
			throws MapException {

		InputStream rawIn = null;

		try {
			rawIn = new FileInputStream(propertiesFile);
			return generateFrom(rawIn);
		} catch ( IOException x ) {
			throw new MapException("failed to load map", x);
		} finally {
			try { rawIn.close(); } catch ( Exception x ) {}
		}
	}

	public static Properties generateFrom(URL propertiesURL)
			throws MapException {

		InputStream rawIn = null;

		try {
			URLConnection con = propertiesURL.openConnection();
			rawIn = con.getInputStream();
			return generateFrom(rawIn);
		} catch ( IOException x ) {
			throw new MapException("failed to load map", x);
		} finally {
			try { rawIn.close(); } catch ( Exception x ) {}
		}
	}

	/**
	 * Used to indicate that something went wrong in one of the
	 * MapTools functions. This is a RuntimeException, so it can
	 * be ignored (try/catch no required).
	 */
	public static class MapException extends RuntimeException {
		public MapException(String msg, Throwable cause) {
			super(msg, cause);
		}

		public MapException(String msg) {
			super(msg);
		}
	} // inner MapException
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.