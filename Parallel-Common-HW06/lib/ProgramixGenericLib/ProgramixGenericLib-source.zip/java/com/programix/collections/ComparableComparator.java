package com.programix.collections;

import java.util.*;

/**
 * This {@link Comparator} can be used to compare types that are
 * {@link Comparable} when a <tt>Comparator</tt> is required.
 * This effectively <i>converts</i> the natural ordering
 * <tt>Compar<u>able</u></tt> implementation on a class to be
 * accessible via a <tt>Compar<u>ator</u></tt>.
 * <p>
 * Both references are cast into <tt>Comparable</tt> to complete
 * the comparison.
 * <p>
 * If there is a chance that any of the references involved in the
 * comparisons might be <tt>null</tt>, you can protect
 * yourself against <tt>NullPointerException</tt>'s by using either the
 * {@link NullFirstComparator} or {@link NullLastComparator} wrappers
 * to first check for <tt>null</tt>'s before proceeding to the
 * regular comparison.
 *
 * @see ReverseComparator
 * @see NullFirstComparator
 * @see NullLastComparator
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
@SuppressWarnings("unchecked")
public class ComparableComparator<T extends Comparable>
        implements Comparator<T> {


    public ComparableComparator() {
    }

    /**
     * This implementation of the
     * {@link Comparator#compare(Object, Object) compare} method on
     * {@link Comparator} will quickly check
     * if both references are the same using <tt>==</tt> (which
     * evaluates to <tt>true</tt> if both references are pointing
     * to the same object or both are <tt>null</tt>).
     * If the references are the same, then this will quickly return
     * <tt>0</tt>.
     * <p>
     * If the are not the same,
     * then the references are cast into {@link Comparable} to
     * complete the comparison.
     *
     * @throws NullPointerException if the first reference is null, and the
     * second reference is not null. To deal with this possibility,
     * check out {@link NullFirstComparator} and {@link NullLastComparator}.
     */
    public int compare(T obj1, T obj2) {
        if ( obj1 == obj2 ) {
            // pointing to the same object, or both are null.
            return 0;
        }

        return obj1.compareTo(obj2);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.