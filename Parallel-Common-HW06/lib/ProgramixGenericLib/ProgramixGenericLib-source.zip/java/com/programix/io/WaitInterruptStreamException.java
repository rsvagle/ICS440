package com.programix.io;

import java.io.*;

/**
 * Thrown to indicate that the thread waiting on an I/O condition was
 * interrupted while waiting. During construction, the calling thread
 * has its interrupted status set to true again (meaning that if, down the
 * road, the calling thread bumps into a <tt>wait</tt> or <tt>sleep</tt>,
 * it will immediately throw an <tt>InterruptedException</tt>.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class WaitInterruptStreamException extends InterruptedIOException {
    public WaitInterruptStreamException(InterruptedException cause) {
        super("Interrupted while waiting on a stream " +
            "condition [InterruptedException]");

        initCause(cause);

        // Since we can't throw an InterruptedException, re-assert
        // the interrupt in case this thread hits any wait() or sleep()
        // down the road.
        Thread.currentThread().interrupt();
    }

    public WaitInterruptStreamException() {
        super("Interrupted while waiting on a stream " +
            "condition [InterruptedException]");

        // Since we can't throw an InterruptedException, re-assert
        // the interrupt in case this thread hits any wait() or sleep()
        // down the road.
        Thread.currentThread().interrupt();
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.