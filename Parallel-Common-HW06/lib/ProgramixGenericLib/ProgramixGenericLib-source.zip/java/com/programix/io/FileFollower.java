package com.programix.io;

import java.io.*;

import com.programix.gui.*;

// FIXME - incomplete.

/**
 * Incomplete. This will be changed or removed in future releases.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class FileFollower {
    public static void main(String[] args) {
        try {
            GuiConsole.createFramedInstance();
            
            String filename = args[0];

            RandomAccessFile raf = new RandomAccessFile(filename, "r");
            byte[] buf = new byte[4096];
            while ( true ) {
                int len = raf.read(buf);
                if ( len < 1 ) {
                    //long pos = raf.getFilePointer();
//                    System.err.println(
//                        "--- time to sleep, pos=" + pos + ", len=" + len);
                    Thread.sleep(1000);
                } else {
                    System.out.write(buf, 0, len);
                    System.out.flush();
                }
            }
            
            /*
            BufferedReader in = new BufferedReader(
                new InputStreamReader(
                new BufferedInputStream(
                new FileInputStream(filename))));
            
            String line = null;
            while ( (line = in.readLine()) != null ) {
                System.out.println(line);
            }
             */
        } catch ( IOException x ) {
            x.printStackTrace();
        } catch ( InterruptedException x ) {
            x.printStackTrace();
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.