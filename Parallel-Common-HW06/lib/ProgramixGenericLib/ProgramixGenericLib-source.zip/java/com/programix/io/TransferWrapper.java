package com.programix.io;

import java.io.*;

/**
 * Used to transfer <tt>byte[]</tt> data with a marker indicating whether or
 * not the data has been compressed.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class TransferWrapper implements Serializable {
    private boolean compressed;
    private byte[] payload;

    public boolean isCompressed() {
        return compressed;
    }

    public void setCompressed(boolean compressed) {
        this.compressed = compressed;
    }

    public byte[] getPayload() {
        return payload;
    }

    public void setPayload(byte[] payload) {
        this.payload = payload;
    }
    
    public int calcWriteToByteCount() {
        // 1 - boolean, compressed or not
        // 4 - int, byte array length
        return 5 + ((payload == null) ? 0 : payload.length);
    }
    
    public void writeTo(DataOutput out) throws IOException {
        out.writeBoolean(compressed);
        if ( payload == null ) {
            out.writeInt(0);
        } else {
            out.writeInt(payload.length);
            out.write(payload);
        }
    }
    
    public void readFrom(DataInput in) throws IOException {
        compressed = in.readBoolean();
        int payloadLength = in.readInt();
        payload = new byte[payloadLength];
        if ( payloadLength > 0 ) {
            in.readFully(payload);
        }
    }
    
    public static TransferWrapper createFrom(DataInput in) throws IOException {
        TransferWrapper tw = new TransferWrapper();
        tw.readFrom(in);
        return tw;
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.