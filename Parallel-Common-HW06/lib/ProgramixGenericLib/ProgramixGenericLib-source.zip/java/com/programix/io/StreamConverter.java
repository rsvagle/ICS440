package com.programix.io;

import java.io.*;

import com.programix.math.*;

/**
 * Converts an {@link OutputStream} to an {@link InputStream}.
 * <p>
 * Bytes can be written to the <tt>OutputStream</tt> (accessed by calling
 * {@link #getOutputStream()}) up the the capacity of the internal
 * buffer. While the buffer is full, further attempts to write bytes block
 * until another thread removes bytes from the buffer via the
 * <tt>StreamConverter</tt>'s <tt>InputStream</tt>. Flushing the
 * <tt>OutputStream</tt> blocks the calling thread until the buffer has
 * been emptied by the thread reading from the <tt>InputStream</tt>.
 * Closing the <tt>OutputStream</tt> automatically flushes the stream
 * first, and then closes the stream.
 * <p>
 * Bytes can be read from the <tt>InputStream</tt> (accessed by calling
 * {@link #getInputStream()}).
 * While the buffer is empty, attempts to read bytes block
 * until another thread adds bytes to the buffer via the
 * <tt>StreamConverter</tt>'s <tt>OutputStream</tt>.
 * Closing the <tt>InputStream</tt> stops any more bytes from being written
 * to the <tt>OutputStream</tt> (an exception is thrown if this is attempted).
 * <p>
 * If the <tt>OutputStream</tt> is closed first, the close operation can not
 * complete until the buffer is flushed (empty). Any further attempts to
 * write bytes results in an exception being thrown. The <tt>InputStream</tt>
 * can otherwise take its time getting around to closing. The <tt>close</tt>
 * method on the <tt>OutputStream</tt> may be safely called more than once.
 * <p>
 * If the <tt>InputStream</tt> is closed first, the internals also force the
 * closing of the <tt>OutputStream</tt>. Any further attempts to read from
 * the <tt>InputStream</tt> result in an <tt>IOException</tt>. Similarly,
 * any further attempts to write to the <tt>OutputStream</tt> also result
 * in an exception being thrown (there is no way that they could ever be
 * read!).
 * The <tt>close</tt> method on the <tt>InputStream</tt> may be safely
 * called more than once.
 * <p>
 * Most often, two threads will be interacting with the
 * <tt>StreamConverter</tt>: one doing the writing to the <tt>OutputStream</tt>
 * and one doing the reading from the <tt>InputStream</tt>. It is possible that
 * only one thread is used to first write and then to read, but this should
 * be approached with caution as this single thread could get eternally blocked
 * trying to write when the buffer is full or trying to read when the buffer
 * is empty.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class StreamConverter {
// TODO - consider adding this feature:
//    /**
//     * Specifies that their should be unlimited buffering between the
//     * <tt>OutputStream</tt> and the <tt>InputStream</tt>. This would make it
//     * safe for the same thread to first write the data and then to read the
//     * data (with fixed size buffering, the thread writing the output might
//     * block while waiting for another thread to read from the input side).
//     * This option should only be used when you are sure that the buffer
//     * won't grow really, really big.
//     */
//    public static final int UNLIMITED = -1;

    /**
     * The default size used for the internal buffer between the input stream
     * and the output stream. This value is always <tt>2048</tt>.
     */
    public static final int DEFAULT_BUFFER_SIZE = 2048;

    private final WriteStream writeStream;
    private final ReadStream readStream;
    private final ByteFIFO fifo;

    // NOTE: Do all lock on the fifo instance--one lock for all operations
    //       to help avoid deadlocks.

    public StreamConverter(int bufferSize) {
        fifo = new ByteFIFO(bufferSize);
        writeStream = new WriteStream();
        readStream = new ReadStream();
    }

    public StreamConverter() {
        this(DEFAULT_BUFFER_SIZE);
    }

    public OutputStream getOutputStream() {
        return writeStream;
    }

    public InputStream getInputStream() {
        return readStream;
    }

    private class WriteStream extends OutputStream {
        private byte[] single = new byte[1];
        private boolean closeInProgress = false;

        public WriteStream() {
        }

        @Override
        public void write(int b) throws IOException {
            synchronized ( fifo ) {
                single[0] = (byte) b;
                write(single, 0, 1);
            }
        }

        @Override
        public void write(byte[] b) throws IOException {
            if ( b == null ) {
                throw new NullPointerException("byte[] reference is null");
            }

            write(b, 0, b.length);
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            if ( b == null ) {
                throw new NullPointerException("byte[] reference is null");
            }

            if ( len == 0 || b.length == 0 ) {
                return;
            }

            if ( off < 0 || len < 0 || (off + len) > b.length ) {
                throw new IndexOutOfBoundsException(
                    "offset and len must be at least zero, and sum must " +
                    "not be more than the length of the byte[]");
            }

            if ( closeInProgress ) {
                throw new ClosedStreamException();
            } else {
                fifo.add(b, off, len);
            }
        }

        @Override
        public void flush() throws IOException {
            synchronized ( fifo ) {
                try {
                    while ( fifo.isNotEmpty() ) {
                        fifo.checkAdderShutdown();
                        fifo.wait();
                    }
                } catch ( InterruptedException x ) {
                    throw new WaitInterruptStreamException(x);
                }
            }
        }

        @Override
        public void close() throws IOException {
            synchronized ( fifo ) {
                if ( fifo.isAdderShutdown() ) {
                    return;
                }

                try {
                    closeInProgress = true;
                    flush();
                } finally {
                    fifo.shutdownAdder();
                }
            }
        }
    } // class WriteStream

    private class ReadStream extends InputStream {
        private byte[] single = new byte[1];

        public ReadStream() {
        }

        @Override
        public int read() throws IOException {
            synchronized ( fifo ) {
                int result = read(single, 0, 1);

                if ( result > 0 ) {
                    return single[0] & 0x0FF;
                } else if ( result == 0 ) {
                    return 0;
                } else {
                    return IOTools.EOS;
                }
            }
        }

        @Override
        public int read(byte[] b) throws IOException {
            if ( b == null ) {
                throw new NullPointerException("byte[] reference is null");
            }

            return read(b, 0, b.length);
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if ( b == null ) {
                throw new NullPointerException("byte[] reference is null");
            }

            if ( len == 0 || b.length == 0 ) {
                return 0;
            }

            if ( off < 0 || len < 0 || (off + len) > b.length ) {
                throw new IndexOutOfBoundsException(
                    "offset and len must be at least zero, and sum must " +
                    "not be more than the length of the byte[]");
            }

            return fifo.remove(b, off, len);
        }

        @Override
        public void close() throws IOException {
            synchronized ( fifo ) {
                if ( fifo.isRemoverShutdown() ) {
                    return;
                } else {
                    fifo.shutdownRemover();
                }
            }
        }

        @Override
        public int available() throws IOException {
            return fifo.getSize();
        }

        @Override
        public boolean markSupported() {
            return false;
        }
    } // class ReadStream

    private static class ByteFIFO {
        private byte[] queue;
        private int capacity;
        private int size;
        private int head;
        private int tail;
        private boolean adderShutdown;
        private boolean removerShutdown;

        public ByteFIFO(int cap) {
            capacity = ( cap > 0 ) ? cap : 1; // at least 1
            queue = new byte[capacity];
            head = 0;
            tail = 0;
            size = 0;

            adderShutdown = false;
            removerShutdown = false;
        }

        public synchronized void shutdownAdder() {
            adderShutdown = true;
            notifyAll();
        }

        public synchronized boolean isAdderShutdown() {
            return adderShutdown;
        }

        public synchronized void checkAdderShutdown()
                throws ClosedStreamException {

            if ( adderShutdown ) {
                throw new ClosedStreamException();
            }
        }

        public synchronized void shutdownRemover() {
            shutdownAdder(); // do this too

            removerShutdown = true;
            notifyAll();
        }

        public synchronized boolean isRemoverShutdown() {
            return removerShutdown;
        }

        public synchronized void checkRemoverShutdown()
                throws ClosedStreamException {

            if ( removerShutdown ) {
                throw new ClosedStreamException();
            }
        }

        public synchronized int getSize() {
            return size;
        }

        public synchronized boolean isEmpty() {
            return ( size == 0 );
        }

        public synchronized boolean isNotEmpty() {
            return ( size > 0 );
        }

        public synchronized boolean isFull() {
            return ( size == capacity );
        }

        public synchronized void add(byte[] list, int offset, int count)
                    throws ClosedStreamException, WaitInterruptStreamException {

            checkAdderShutdown();

            try {
                // For efficiency, the bytes are copied in blocks
                // instead of one at a time. As space becomes available,
                // more bytes are copied until all of them have been
                // added.

                int ptr = offset;
                int endPtr = offset + count;

                while ( ptr < endPtr ) {
                    // If full, the lock will be released to allow
                    // another thread to come in and remove bytes.
                    while ( isFull() ) {
                        wait();
                        checkAdderShutdown();
                    }

                    int space = capacity - size;
                    int distToEnd = capacity - tail;
                    int bytesRemaining = endPtr - ptr;
                    int copyLen =
                        NumberTools.min(space, distToEnd, bytesRemaining);

                    System.arraycopy(list, ptr, queue, tail, copyLen);
                    tail = ( tail + copyLen ) % capacity;
                    size += copyLen;
                    ptr += copyLen;

                    // Keep the lock for now, but let any waiting threads
                    // know that something has changed.
                    notifyAll();
                }
            } catch ( InterruptedException x ) {
                throw new WaitInterruptStreamException(x);
            }
        }

        /**
         * Removes at least one byte from the FIFO and stores into the specified
         * destination array.
         * @param dest destination for the byte(s) that are removed
         * @param destOffset offset into the dest array to start copying
         * in bytes, must be a least 1 less than the length of dest.
         * @param maxCount the maximum number of bytes to copy, must be at
         * least 1.
         * @return the actual number of bytes copied, always at least 1.
         * @throws InterruptedException if interrupted while waiting on an
         * empty fifo.
         * @throws WaitInterruptStreamException
         * @throws ClosedStreamException
         */
        public synchronized int remove(byte[] dest,
                                       int destOffset,
                                       int maxCount)
                    throws ClosedStreamException, WaitInterruptStreamException {

            checkRemoverShutdown();

            try {
                // If full, the lock will be released to allow
                // another thread to come in and remove bytes.
                while ( isEmpty() ) {
                    if ( isAdderShutdown() ) {
                        // Empty, and there's no way that any more bytes will
                        // ever be written to the buffer, so we've reached
                        // the end-of-stream.
                        return IOTools.EOS;
                    }

                    wait();
                    checkRemoverShutdown();
                }
            } catch ( InterruptedException x ) {
                throw new WaitInterruptStreamException(x);
            }

            // For efficiency, the bytes are copied in blocks
            // instead of one at a time.
            int removeCount =
                NumberTools.min(size, maxCount, dest.length - destOffset);

            int distToEnd = capacity - head;
            if ( removeCount <= distToEnd ) {
                // all in one chunk
                System.arraycopy(queue, head, dest, destOffset, removeCount);
            } else {
                // bytes are in two chunks
                System.arraycopy(queue, head, dest, destOffset, distToEnd);
                System.arraycopy(queue, 0,
                    dest, destOffset + distToEnd, removeCount - distToEnd);
            }

            head = ( head + removeCount ) % capacity;
            size -= removeCount;

            notifyAll(); // let any waiting threads know about change
            return removeCount;
        }
    } // class ByteFIFO
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.