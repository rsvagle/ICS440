package com.programix.io;

import java.io.*;
import java.net.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.programix.util.*;

/**
 * Handy tools for working with I/O.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class IOTools {
    /**
     * Constant for "end of stream" or more loosely "end of file".
     * The value of this constant is <tt>-1</tt> (the value that is so
     * commonly used throughout Java I/O to indicate end of stream/file).
     */
    public static final int EOS = -1;

    /**
     * The default buffer size that is used with streams in the tools class.
     * This value is always 2048.
     */
    public static final int DEFAULT_BUFFER_SIZE = 2048;

    private static final ResourceAssistant resourceAssistant =
        new ResourceAssistant();

    // no instances
    private IOTools() {
    }

    /**
     * Copies all the bytes from the <tt>InputStream</tt> to the
     * <tt>OutputStream</tt>. The <tt>InputStream</tt> is read until the
     * end of stream is detected. The <tt>OutputStream</tt> is flushed
     * after the final transfer.
     *
     * @param in the stream to read bytes from
     * @param closeInputStream if true, close the InputStream after reaching
     * the end-of-stream.
     * @param out the stream to write bytes out to
     * @param closeOutputStream if true, close the OutputStream after writing
     * and flushing the final bytes that were read from the InputStream.
     * @param transferBufferSize the byte-size of the internally allocated
     * buffer.
     * @return the number of bytes copied.
     * @throws IOException if there is a transfer problem
     */
    public static int copy(InputStream in,
                           boolean closeInputStream,
                           OutputStream out,
                           boolean closeOutputStream,
                           int transferBufferSize) throws IOException {

        try {
            byte[] buffer = new byte[transferBufferSize];
            int len = 0;
            int count = 0;

            while ( (len = in.read(buffer)) != EOS ) {
                out.write(buffer, 0, len);
                count += len;
            }

            out.flush();
            return count;
        } finally {
            if ( closeOutputStream ) {
                closeQuietly(out);
            }

            if ( closeInputStream ) {
                closeQuietly(in);
            }
        }
    }

    /**
     * Copies bytes between the streams with the {@link #DEFAULT_BUFFER_SIZE}.
     * Equivalent to:
     * <pre class="preshade">
     * return copy(in, closeInputStream,
     *             out, closeOutputStream, DEFAULT_BUFFER_SIZE);
     * </pre>
     * @see #copy(InputStream, boolean, OutputStream, boolean, int)
     */
    public static int copy(InputStream in,
                           boolean closeInputStream,
                           OutputStream out,
                           boolean closeOutputStream) throws IOException {

        return copy(in, closeInputStream,
                    out, closeOutputStream, DEFAULT_BUFFER_SIZE);
    }

    /**
     * Copies bytes between the streams with the {@link #DEFAULT_BUFFER_SIZE}
     * and closes both streams after the copy is complete.
     * Equivalent to:
     * <pre class="preshade">
     * return copy(in, true, out, true, DEFAULT_BUFFER_SIZE);
     * </pre>
     * @see #copy(InputStream, boolean, OutputStream, boolean, int)
     */
    public static int copy(InputStream in,
                           OutputStream out) throws IOException {

        return copy(in, true, out, true, DEFAULT_BUFFER_SIZE);
    }

    /**
     * Copies bytes between the files with the {@link #DEFAULT_BUFFER_SIZE} and
     * closes both streams after the copy is complete.
     * If an exception is thrown, any streams that were successfully opened are
     * automatically closed.
     * Equivalent to:
     * <pre class="preshade">
     * return copy(new FileInputStream(source), true,
     *             new FileOutputStream(destination), true,
     *             DEFAULT_BUFFER_SIZE);
     * </pre>
     * @see #copy(InputStream, boolean, OutputStream, boolean, int)
     */
    public static int copy(File source, File destination)
            throws FileNotFoundException, IOException {

        return copy(new FileInputStream(source), true,
                    new FileOutputStream(destination), true,
                    DEFAULT_BUFFER_SIZE);
    }

    private static InputStream getStreamFromUrl(URL url) {
        if ( url == null ) {
            return null;
        } else {
            try {
                return url.openStream();
            } catch ( IOException x ) {
                return null;
            }
        }
    }

    /**
     * Adds the specified locator to the <i>beginning</i> of the list of
     * {@link ResourceLocator}'s to use when searching for resources.
     * This is a VM-wide setting. The last locator prepended will be the
     * <i>first</i> one to be used when looking for resources.
     *
     * @param locator the resource locator to place at the front of the
     * search locations.
     *
     * @exception IllegalArgumentException if <tt>null</tt> is passed in
     *
     * @see IOTools.ClassLoaderResourceLocator
     * @see IOTools.ServletResourceLocator
     * @see IOTools.BaseDirectoryResourceLocator
     */
    public static void prependResourceLocator(ResourceLocator locator)
            throws IllegalArgumentException {

        ObjectTools.paramNullCheck(locator, "locator");
        resourceAssistant.addLocator(locator);
    }

    /**
     * Removes the specified ResourceLocator from the list if it
     * exists. See {@link #prependResourceLocator(IOTools.ResourceLocator)
     * prependResourceLocator} for more information.
     *
     * @param rl locator to remove
     * @return <tt>true</tt> if the locator was found and removed,
     * <tt>false</tt> if the specified locator was not found
     * (or if <tt>null</tt> is passed in).
     */
    public static boolean removeResourceLocator(ResourceLocator rl) {
        return resourceAssistant.removeLocator(rl);
    }

    /**
     * Returns a URL to access the specified <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * The {@link Class#getResource(String) getResource(String path)}
     * method on the {@link Class} object passed in is used
     * as a starting point to locate the requested resource.
     * After that, <tt>IOTools.class</tt> is used, and if that still doesn't
     * work, then <tt>String.class</tt> is used. If they all fail to be
     * able to locate the resource, then a <tt>FileNotFoundException</tt>
     * is thrown.
     *
     * @param resourceLocation the path to the resource, with or without
     * a leading <tt>/</tt>. If the resource is not found using name passed
     * in, then a <tt>/</tt> is prefixed and the search is re-attempted.
     * @param searchStartPoint the <tt>Class</tt> to invoke
     * <tt>getResource</tt> on first. If <tt>null</tt>, then this
     * <tt>IOTools</tt> class will be used first.
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are any other problems
     */
    public static URL getUrlForResource(
                String resourceLocation,
                Class<?> searchStartPoint
            ) throws FileNotFoundException, IOException {

        return resourceAssistant.getUrlFor(
            resourceLocation, searchStartPoint);

        /*
        if ( StringTools.isEmpty(resourceLocation) ) {
            throw new FileNotFoundException(
                "Unable to load resource because resourceLocation is empty");
        }

        try {
            String simpleLoc = StringTools.trim(resourceLocation);
            String slashLoc = "/" + simpleLoc;
            URL url = null;

            if ( searchStartPoint != null ) {
                url = resourceLookup(searchStartPoint, simpleLoc, slashLoc);
            }

            if ( url == null ) {
                // Try using this class
                url = resourceLookup(IO_TOOLS_CLASS, simpleLoc, slashLoc);
            }

            if ( url == null ) {
                // Try using an ultra-core class
                url = resourceLookup(String.class, simpleLoc, slashLoc);
            }

            if ( url == null ) {
                throw new FileNotFoundException("Unable to load resource '" +
                    resourceLocation + "'");
            } else {
                return url;
            }
        } catch ( IOException x ) {
            throw x; // just re-throw
        } catch ( Exception x ) {
            throw (IOException) new IOException("Unable to load resource '" +
                    resourceLocation + "'").initCause(x);
        }
        */
    }

    /**
     * Returns a URL to access the specified <tt>resourceLocation</tt>
     * using <tt>IOTools.class</tt> as a starting point.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getUrlForResource(String, Class)
     *      getUrlForResource}(resourceLocation, <b>null</b>);
     * </pre>
     *
     * @param resourceLocation the path to the resource, with or without
     * a leading <tt>/</tt>. If the resource is not found using name passed
     * in, then a <tt>/</tt> is prefixed and the search is re-attempted.
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are any other problems
     */
    public static URL getUrlForResource(String resourceLocation)
            throws FileNotFoundException, IOException {

        return getUrlForResource(resourceLocation, null);
    }

    /**
     * Returns an <tt>InputStream</tt> to read data from the specified
     * <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getUrlForResource(String, Class) getUrlForResource}(
     *         resourceLocation, searchStartPoint).openStream();
     * </pre>
     */
    public static InputStream getInputStreamForResource(
                String resourceLocation,
                Class<?> searchStartPoint
            ) throws FileNotFoundException, IOException {

        return resourceAssistant.getInputStreamFor(
            resourceLocation, searchStartPoint);

        /*
        if ( StringTools.isEmpty(resourceLocation) ) {
            throw new FileNotFoundException(
                "Unable to load resource because resourceLocation is empty");
        }

        try {
            String simpleLoc = StringTools.trim(resourceLocation);
            String slashLoc = "/" + simpleLoc;
            InputStream in = null;

            if ( searchStartPoint != null ) {
                in = resourceStreamLookup(
                    searchStartPoint, simpleLoc, slashLoc);
            }

            if ( in == null ) {
                // Try using this class
                in = resourceStreamLookup(IO_TOOLS_CLASS, simpleLoc, slashLoc);
            }

            if ( in == null ) {
                // Try using an ultra-core class
                in = resourceStreamLookup(String.class, simpleLoc, slashLoc);
            }

            if ( in == null ) {
                throw new FileNotFoundException("Unable to load resource '" +
                    resourceLocation + "'");
            } else {
                return in;
            }
        } catch ( IOException x ) {
            throw x; // just re-throw
        } catch ( Exception x ) {
            throw (IOException) new IOException("Unable to load resource '" +
                    resourceLocation + "'").initCause(x);
        }
        */
    }

    /**
     * Returns an <tt>InputStream</tt> to read data from the specified
     * <tt>resourceLocation</tt>.
     * Uses <tt>IOTools.class</tt> as a starting point for the search.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #getInputStreamForResource(String, Class)
     * getInputStreamForResource}(resourceLocation, null);
     * </pre>
     */
    public static InputStream getInputStreamForResource(String resourceLocation)
            throws FileNotFoundException, IOException {

        return getInputStreamForResource(resourceLocation, null);
    }

    /**
     * Reads the entire stream and returns all the data read in a
     * <tt>byte[]</tt>. The stream supplied does not need to be buffered.
     * The stream supplied is closed by this method (even if an IOException
     * is thrown).
     * @param rawIn source of bytes
     * @return all of the data read
     * @throws IOException if anything goes wrong
     */
    public static byte[] readAll(InputStream rawIn) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        copy(rawIn, baos);
        return baos.toByteArray();
    }

    /**
     * Reads the entire file and returns all the data read in a
     * <tt>byte[]</tt>. Equivalent to:
     * <pre class="preshade">
     * return readAll(new FileInputStream(source));
     * </pre>
     */
    public static byte[] readAll(File source)
            throws FileNotFoundException, IOException {

        return readAll(new FileInputStream(source));
    }

    /**
     * Reads the entire file and returns all the data read in a
     * <tt>byte[]</tt>. Equivalent to:
     * <pre class="preshade">
     * return readAll(new FileInputStream(source));
     * </pre>
     */
    public static byte[] readAllFromFile(String filename)
            throws FileNotFoundException, IOException {

        return readAll(new FileInputStream(filename));
    }

    /**
     * Reads the entire stream of data from the URL and returns all the data
     * read in a <tt>byte[]</tt>. Equivalent to:
     * <pre class="preshade">
     * return readAll(source.openStream());
     * </pre>
     */
    public static byte[] readAll(URL source) throws IOException {
        return readAll(source.openStream());
    }

    /**
     * Reads the entire stream from the specified <tt>resourceLocation</tt>
     * and returns all the data read in a <tt>byte[]</tt>. This method
     * is suitable for retrieving resources from JAR files, WAR files,
     * and CLASSPATH's. The
     * {@link Class#getResource(String) getResource(String path)}
     * method on the {@link Class} object passed in is used
     * to locate the requested resource.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #readAll(InputStream) readAll}(
     *     {@link #getInputStreamForResource(String, Class)
     * getInputStreamForResource}(resourceLocation, searchStartPoint));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @param searchStartPoint the <tt>Class</tt> to invoke
     * <tt>getResource</tt>. If <tt>null</tt>, <tt>IOTools.class</tt> is used.
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static byte[] readAllFromResource(
                String resourceLocation,
                Class<?> searchStartPoint
            ) throws FileNotFoundException, IOException {

        return readAll(
            getInputStreamForResource(resourceLocation, searchStartPoint));
    }

    /**
     * Reads the entire stream from the specified <tt>resourceLocation</tt>
     * and returns all the data read in a <tt>byte[]</tt>. This method
     * is suitable for retrieving resources from JAR files, WAR files,
     * and CLASSPATH's.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #readAll(InputStream)
     *     readAll}({@link #getInputStreamForResource(String)
     * getInputStreamForResource}(resourceLocation));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static byte[] readAllFromResource(String resourceLocation)
            throws FileNotFoundException, IOException {

        return readAll(getInputStreamForResource(resourceLocation));
    }

    /**
     * Reads the entire stream of data from the Socket and returns all the data
     * read in a <tt>byte[]</tt>. After reading, the <tt>InputStream</tt> for
     * the <tt>Socket</tt> is closed, but the <tt>Socket</tt> itself remains
     * open. Equivalent to:
     * <pre class="preshade">
     * return readAll(socket.getInputStream());
     * </pre>
     */
    public static byte[] readAll(Socket socket) throws IOException {
        return readAll(socket.getInputStream());
    }


    /**
     * Reads the entire stream of characters and returns all the lines
     * read in a <tt>String[]</tt>.
     * The <tt>BufferedReader</tt> supplied is closed by this method
     * (even if an IOException is thrown).
     * @param in source of characters
     * @return all of the lines read
     * @throws IOException if anything goes wrong
     */
    public static String[] readAllLines(BufferedReader in) throws IOException {
        try {
            List<String> list = new ArrayList<String>();
            String line = null;
            while ( (line = in.readLine()) != null ) {
                list.add(line);
            }

            return StringTools.toArray(list);
        } finally {
            closeQuietly(in);
        }
    }

    /**
     * Reads the entire stream of characters and returns all the lines
     * read in a <tt>String[]</tt>.
     * The <tt>Reader</tt> supplied is closed by this method
     * (even if an IOException is thrown).
     * @param in source of characters
     * @return all of the lines read
     * @throws IOException if anything goes wrong
     */
    public static String[] readAllLines(Reader in) throws IOException {
        if ( in instanceof BufferedReader ) {
            return readAllLines((BufferedReader) in);
        } else {
            return readAllLines(new BufferedReader(in));
        }
    }

    /**
     * Reads the entire stream of bytes converting them to characters using
     * the default <tt>InputStreamReader</tt> and returns all the lines
     * read in a <tt>String[]</tt>.
     * The stream supplied does not need to be buffered.
     * The stream supplied is closed by this method (even if an IOException
     * is thrown).
     * @param rawIn source of bytes
     * @return all of the lines read
     * @throws IOException if anything goes wrong
     */
    public static String[] readAllLines(InputStream rawIn) throws IOException {
        return readAllLines(createBufferedReader(rawIn));
    }

    /**
     * Reads the entire file converting bytes to characters using
     * the default <tt>InputStreamReader</tt> and returns all the lines
     * read in a <tt>String[]</tt>.
     * @param source file to read from
     * @return all of the lines read
     * @throws IOException if anything goes wrong
     */
    public static String[] readAllLines(File source)
            throws FileNotFoundException, IOException {

        return readAllLines(createBufferedReader(source));
    }

    /**
     * Reads the entire file converting bytes to characters using
     * the default <tt>InputStreamReader</tt> and returns all the lines
     * read in a <tt>String[]</tt>.
     * @param filename file to read from
     * @return all of the lines read
     * @throws IOException if anything goes wrong
     */
    public static String[] readAllLinesFromFile(String filename)
            throws FileNotFoundException, IOException {

        return readAllLines(createBufferedReaderFromFile(filename));
    }

    /**
     * Reads the entire stream of data from the URL converting bytes to
     * characters using the default <tt>InputStreamReader</tt>
     * and returns all the lines read in a <tt>String[]</tt>.
     * @param source url to read from
     * @return all of the lines read
     * @throws IOException if anything goes wrong
     */
    public static String[] readAllLines(URL source) throws IOException {
        return readAllLines(createBufferedReader(source));
    }

    /**
     * Reads the entire stream from the specified <tt>resourceLocation</tt>
     * and returns all the data read in a <tt>String[]</tt>. This method
     * is suitable for retrieving resources from JAR files, WAR files,
     * and CLASSPATH's. The
     * {@link Class#getResource(String) getResource(String path)}
     * method on the {@link Class} object passed in is used
     * to locate the requested resource.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #readAllLines(InputStream) readAllLines}(
     *     {@link #getInputStreamForResource(String, Class)
     * getInputStreamForResource}(resourceLocation, searchStartPoint));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @param searchStartPoint the <tt>Class</tt> to invoke
     * <tt>getResource</tt>. If <tt>null</tt>, <tt>IOTools.class</tt> is used.
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static String[] readAllLinesFromResource(
                 String resourceLocation,
                 Class<?> searchStartPoint
            ) throws FileNotFoundException, IOException {

        return readAllLines(
            getInputStreamForResource(resourceLocation, searchStartPoint));
    }

    /**
     * Reads the entire stream from the specified <tt>resourceLocation</tt>
     * and returns all the data read in a <tt>String[]</tt>. This method
     * is suitable for retrieving resources from JAR files, WAR files,
     * and CLASSPATH's.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #readAllLines(InputStream)
     *     readAllLines}({@link #getInputStreamForResource(String)
     * getInputStreamForResource}(resourceLocation));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static String[] readAllLinesFromResource(String resourceLocation)
            throws FileNotFoundException, IOException {

        return readAllLines(getInputStreamForResource(resourceLocation));
    }

    /**
     * Creates a BufferedWriter using the default <tt>OutputStreamWriter</tt>
     * constructor. Also adds a <tt>BufferedOutputStream</tt> to the supplied
     * <tt>OutputStream</tt>, <tt>rawOut</tt>.
     * @param rawOut unbuffered destination for the bytes
     */
    public static BufferedWriter createBufferedWriter(OutputStream rawOut) {
        return new BufferedWriter(
            new OutputStreamWriter(
                new BufferedOutputStream(rawOut)));
    }

    /**
     * Creates a BufferedWriter using the default <tt>OutputStreamWriter</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return createBufferedWriter(new FileOutputStream(destination));
     * </pre>
     */
    public static BufferedWriter createBufferedWriter(File destination)
            throws FileNotFoundException, IOException {

        return createBufferedWriter(new FileOutputStream(destination));
    }

    /**
     * Creates a BufferedWriter using the default <tt>OutputStreamWriter</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return createBufferedWriter(new FileOutputStream(filename));
     * </pre>
     */
    public static BufferedWriter createBufferedWriterToFile(String filename)
            throws FileNotFoundException, IOException {

        return createBufferedWriter(new FileOutputStream(filename));
    }

    /**
     * Creates a BufferedWriter using the default <tt>OutputStreamWriter</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return createBufferedWriter(socket.getOutputStream());
     * </pre>
     */
    public static BufferedWriter createBufferedWriter(Socket socket)
            throws IOException {

        return createBufferedWriter(socket.getOutputStream());
    }

    /**
     * Creates a BufferedReader using the default <tt>InputStreamReader</tt>
     * constructor.
     * If the passed <tt>InputStream</tt> is not a
     * <tt>BufferedInputStream</tt>, then it is automatically wrapped
     * with a <tt>BufferedInputStream</tt> to promote I/O efficiency.
     * Therefore, there is no need to pass in a <tt>BufferedInputStream</tt>
     * into this method, but there is also no need to avoid passing in a
     * <tt>BufferedInputStream</tt>.
     * @param rawIn source of the bytes
     */
    public static BufferedReader createBufferedReader(InputStream rawIn) {
        if ( rawIn instanceof BufferedInputStream ) {
            return new BufferedReader(
                new InputStreamReader((rawIn)));
        } else {
            return new BufferedReader(
                new InputStreamReader(
                    new BufferedInputStream(rawIn)));
        }
    }

    /**
     * Creates a BufferedReader using the default <tt>InputStreamReader</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return createBufferedReader(new FileInputStream(source));
     * </pre>
     */
    public static BufferedReader createBufferedReader(File source)
            throws FileNotFoundException, IOException {

        return createBufferedReader(new FileInputStream(source));
    }

    /**
     * Creates a BufferedReader using the default <tt>InputStreamReader</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return createBufferedReader(new FileInputStream(filename));
     * </pre>
     */
    public static BufferedReader createBufferedReaderFromFile(String filename)
            throws FileNotFoundException, IOException {

        return createBufferedReader(new FileInputStream(filename));
    }

    /**
     * Creates a BufferedReader using the default <tt>InputStreamReader</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return createBufferedReader(source.openStream());
     * </pre>
     */
    public static BufferedReader createBufferedReader(URL source)
            throws IOException {

        return createBufferedReader(source.openStream());
    }

    /**
     * Creates a BufferedReader using the default <tt>InputStreamReader</tt>.
     * The underlying <tt>InputStream</tt> comes from the specified
     * <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * The {@link Class#getResource(String) getResource(String path)}
     * method on the {@link Class} object passed in is used
     * to locate the requested resource.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #createBufferedReader(InputStream) createBufferedReader}(
     *     {@link #getInputStreamForResource(String, Class)
     * getInputStreamForResource}(resourceLocation, searchStartPoint));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @param searchStartPoint the <tt>Class</tt> to invoke
     * <tt>getResource</tt>. If <tt>null</tt>, <tt>IOTools.class</tt> is used.
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static BufferedReader createBufferedReaderFromResource(
                String resourceLocation,
                Class<?> searchStartPoint
            ) throws FileNotFoundException, IOException {

        return createBufferedReader(
            getInputStreamForResource(resourceLocation, searchStartPoint));
    }

    /**
     * Creates a BufferedReader using the default <tt>InputStreamReader</tt>.
     * The underlying <tt>InputStream</tt> comes from the specified
     * <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #createBufferedReader(InputStream) createBufferedReader}(
     *     {@link #getInputStreamForResource(String)
     * getInputStreamForResource}(resourceLocation));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static BufferedReader createBufferedReaderFromResource(
                String resourceLocation
            ) throws FileNotFoundException, IOException {

        return createBufferedReader(
            getInputStreamForResource(resourceLocation));
    }

    /**
     * Creates a BufferedReader using the default <tt>InputStreamReader</tt>.
     * Equivalent to:
     * <pre class="preshade">
     * return createBufferedReader(socket.getInputStream());
     * </pre>
     */
    public static BufferedReader createBufferedReader(Socket socket)
            throws IOException {

        return createBufferedReader(socket.getInputStream());
    }

    /**
     * Creates a DataOutputStream and adds buffering by wrapping a
     * <tt>BufferedOutputStream</tt> around the supplied
     * <tt>OutputStream</tt>, <tt>rawOut</tt>.
     * @param rawOut unbuffered destination for the bytes
     */
    public static DataOutputStream createDataOutputStream(OutputStream rawOut) {
        return new DataOutputStream(new BufferedOutputStream(rawOut));
    }

    /**
     * Creates a DataOutputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createDataOutputStream(new FileOutputStream(destination));
     * </pre>
     */
    public static DataOutputStream createDataOutputStream(File destination)
            throws FileNotFoundException, IOException {

        return createDataOutputStream(new FileOutputStream(destination));
    }

    /**
     * Creates a DataOutputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createDataOutputStream(new FileOutputStream(filename));
     * </pre>
     */
    public static DataOutputStream createDataOutputStreamToFile(String filename)
            throws FileNotFoundException, IOException {

        return createDataOutputStream(new FileOutputStream(filename));
    }

    /**
     * Creates a DataOutputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createDataOutputStream(socket.getOutputStream());
     * </pre>
     */
    public static DataOutputStream createDataOutputStream(Socket socket)
            throws IOException {

        return createDataOutputStream(socket.getOutputStream());
    }

    /**
     * Creates a DataInputStream and adds buffering by wrapping a
     * <tt>BufferedInputStream</tt> around the supplied
     * <tt>InputStream</tt>, <tt>rawIn</tt>.
     * @param rawIn unbuffered source of the bytes
     */
    public static DataInputStream createDataInputStream(InputStream rawIn) {
        return new DataInputStream(new BufferedInputStream(rawIn));
    }

    /**
     * Creates a DataInputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createDataInputStream(new FileInputStream(source));
     * </pre>
     */
    public static DataInputStream createDataInputStream(File source)
            throws FileNotFoundException, IOException {

        return createDataInputStream(new FileInputStream(source));
    }

    /**
     * Creates a DataInputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createDataInputStream(new FileInputStream(filename));
     * </pre>
     */
    public static DataInputStream createDataInputStreamFromFile(String filename)
            throws FileNotFoundException, IOException {

        return createDataInputStream(new FileInputStream(filename));
    }

    /**
     * Creates a DataInputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createDataInputStream(source.openStream());
     * </pre>
     */
    public static DataInputStream createDataInputStream(URL source)
            throws IOException {

        return createDataInputStream(source.openStream());
    }

    /**
     * Creates a buffered DataInputStream.
     * The underlying <tt>InputStream</tt> comes from the specified
     * <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * The {@link Class#getResource(String) getResource(String path)}
     * method on the {@link Class} object passed in is used
     * to locate the requested resource.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #createDataInputStream(InputStream) createDataInputStream}(
     *     {@link #getInputStreamForResource(String, Class)
     * getInputStreamForResource}(resourceLocation, searchStartPoint));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @param searchStartPoint the <tt>Class</tt> to invoke
     * <tt>getResource</tt>. If <tt>null</tt>, <tt>IOTools.class</tt> is used.
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static DataInputStream createDataInputStreamFromResource(
                String resourceLocation,
                Class<?> searchStartPoint
            ) throws FileNotFoundException, IOException {

        return createDataInputStream(
            getInputStreamForResource(resourceLocation, searchStartPoint));
    }

    /**
     * Creates a buffered <tt>DataInputStream</tt>.
     * The underlying <tt>InputStream</tt> comes from the specified
     * <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #createDataInputStream(InputStream) createDataInputStream}(
     *     {@link #getInputStreamForResource(String)
     * getInputStreamForResource}(resourceLocation));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static DataInputStream createDataInputStreamFromResource(
                String resourceLocation
            ) throws FileNotFoundException, IOException {

        return createDataInputStream(
            getInputStreamForResource(resourceLocation));
    }

    /**
     * Creates a DataInputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createDataInputStream(socket.getInputStream());
     * </pre>
     */
    public static DataInputStream createDataInputStream(Socket socket)
            throws IOException {

        return createDataInputStream(socket.getInputStream());
    }

    /**
     * Creates an ObjectOutputStream and adds buffering by wrapping a
     * <tt>BufferedOutputStream</tt> around the supplied
     * <tt>OutputStream</tt>, <tt>rawOut</tt>.
     * Just after construction and before being returned from this method,
     * the new <tt>ObjectOutputStream</tt> instance is flushed. The flushing
     * ensures that the "object stream header" is pushed out right away in case
     * an associated <tt>ObjectInputStream</tt> is waiting in its constructor.
     * @param rawOut unbuffered destination for the bytes
     * @throws IOException
     */
    public static ObjectOutputStream createObjectOutputStream(
                OutputStream rawOut
            ) throws IOException {

         ObjectOutputStream oos =
             new ObjectOutputStream(new BufferedOutputStream(rawOut));
         oos.flush();
         return oos;
    }

    /**
     * Creates an ObjectOutputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectOutputStream(new FileOutputStream(destination));
     * </pre>
     */
    public static ObjectOutputStream createObjectOutputStream(File destination)
            throws FileNotFoundException, IOException {

        return createObjectOutputStream(new FileOutputStream(destination));
    }

    /**
     * Creates an ObjectOutputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectOutputStream(new FileOutputStream(filename));
     * </pre>
     */
    public static ObjectOutputStream createObjectOutputStreamToFile(
                String filename
            ) throws FileNotFoundException, IOException {

        return createObjectOutputStream(new FileOutputStream(filename));
    }

    /**
     * Creates an ObjectOutputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectOutputStream(socket.getOutputStream());
     * </pre>
     */
    public static ObjectOutputStream createObjectOutputStream(Socket socket)
            throws IOException {

        return createObjectOutputStream(socket.getOutputStream());
    }

    /**
     * Creates an ObjectInputStream and adds buffering by wrapping a
     * <tt>BufferedInputStream</tt> around the supplied
     * <tt>InputStream</tt>, <tt>rawIn</tt>.
     * The standard <tt>ObjectInputStream</tt> constructor always blocks until
     * the "object stream header" is read from the underlying byte source; as
     * a result, this method must also block until that header is read.
     * @param rawIn unbuffered source of the bytes
     * @throws IOException
     */
    public static ObjectInputStream createObjectInputStream(InputStream rawIn)
            throws IOException {

        return new ObjectInputStream(new BufferedInputStream(rawIn));
    }

    /**
     * Creates an ObjectInputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectInputStream(new FileInputStream(source));
     * </pre>
     */
    public static ObjectInputStream createObjectInputStream(File source)
            throws FileNotFoundException, IOException {

        return createObjectInputStream(new FileInputStream(source));
    }

    /**
     * Creates an ObjectInputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectInputStream(new FileInputStream(filename));
     * </pre>
     */
    public static ObjectInputStream createObjectInputStreamFromFile(
                String filename
            ) throws FileNotFoundException, IOException {

        return createObjectInputStream(new FileInputStream(filename));
    }

    /**
     * Creates an ObjectInputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectInputStream(source.openStream());
     * </pre>
     */
    public static ObjectInputStream createObjectInputStream(URL source)
            throws IOException {

        return createObjectInputStream(source.openStream());
    }

    /**
     * Creates a buffered ObjectInputStream.
     * The underlying <tt>InputStream</tt> comes from the specified
     * <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * The {@link Class#getResource(String) getResource(String path)}
     * method on the {@link Class} object passed in is used
     * to locate the requested resource.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #createObjectInputStream(InputStream)
     * createObjectInputStream}(
     *     {@link #getInputStreamForResource(String, Class)
     * getInputStreamForResource}(resourceLocation, searchStartPoint));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @param searchStartPoint the <tt>Class</tt> to invoke
     * <tt>getResource</tt>. If <tt>null</tt>, <tt>IOTools.class</tt> is used.
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static ObjectInputStream createObjectInputStreamFromResource(
                String resourceLocation,
                Class<?> searchStartPoint
            ) throws FileNotFoundException, IOException {

        return createObjectInputStream(
            getInputStreamForResource(resourceLocation, searchStartPoint));
    }

    /**
     * Creates a buffered <tt>ObjectInputStream</tt>.
     * The underlying <tt>InputStream</tt> comes from the specified
     * <tt>resourceLocation</tt>.
     * This method is suitable for retrieving resources from JAR files,
     * WAR files, and CLASSPATH's.
     * See {@link #getUrlForResource(String, Class)
     * getUrlForResource(String, Class)} for the full explanation of how
     * the search for the <tt>URL</tt> is performed.
     * <p>
     * Equivalent to:
     * <pre class="preshade">
     * return {@link #createObjectInputStream(InputStream)
     * createObjectInputStream}(
     *     {@link #getInputStreamForResource(String)
     * getInputStreamForResource}(resourceLocation));
     * </pre>
     *
     * @param resourceLocation the path to the resource
     * @exception FileNotFoundException if the specified resource
     * can not be found by the class loader.
     * @exception IOException if there are problems reading the data
     */
    public static ObjectInputStream createObjectInputStreamFromResource(
                String resourceLocation
            ) throws FileNotFoundException, IOException {

        return createObjectInputStream(
            getInputStreamForResource(resourceLocation));
    }

    /**
     * Creates an ObjectInputStream with buffering.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectInputStream(socket.getInputStream());
     * </pre>
     */
    public static ObjectInputStream createObjectInputStream(Socket socket)
            throws IOException {

        return createObjectInputStream(socket.getInputStream());
    }

    /**
     * Creates an <tt>ObjectInputStream</tt> and an <tt>ObjectOutputStream</tt>
     * with buffering on the specified <tt>InputStream</tt> and
     * <tt>OutputStream</tt>. The <tt>Object<u>Output</u>Stream</tt> is created
     * (and flushed) <i>first</i>, which is customary for the server-side to do.
     */
    public static ObjectStreamPair createObjectStreamsForServer(
                InputStream rawIn,
                OutputStream rawOut
            ) throws IOException {

        // create the OOS first - "say 'hello'"
        ObjectOutputStream oos = createObjectOutputStream(rawOut);
        ObjectInputStream ois = createObjectInputStream(rawIn);
        return new ObjectStreamPair(ois, oos);
    }

    /**
     * Creates an <tt>ObjectInputStream</tt> and an <tt>ObjectOutputStream</tt>
     * with buffering on the specified <tt>InputStream</tt> and
     * <tt>OutputStream</tt>. The <tt>Object<u>Input</u>Stream</tt> is created
     * <i>first</i>, which is customary for the client-side to do.
     */
    public static ObjectStreamPair createObjectStreamsForClient(
                InputStream rawIn,
                OutputStream rawOut
            ) throws IOException {

        // create the OIS first - "listen for 'hello'"
        ObjectInputStream ois = createObjectInputStream(rawIn);
        ObjectOutputStream oos = createObjectOutputStream(rawOut);
        return new ObjectStreamPair(ois, oos);
    }

    /**
     * Creates an <tt>ObjectInputStream</tt> and an <tt>ObjectOutputStream</tt>
     * with buffering on the specified <tt>InputStream</tt> and
     * <tt>OutputStream</tt>.
     * Two threads are spawned behind the scenes to attempt to create the
     * <tt>ObjectInputStream</tt> and <tt>ObjectOutputStream</tt> as the same
     * time. This prevents an inter-VM deadlock that can occur when the stream
     * creation order for the client-side and the server-side are not
     * coordinated. This method is <i>less</i> efficient that using either
     * {@link #createObjectStreamsForServer(InputStream, OutputStream)} or
     * {@link #createObjectStreamsForClient(InputStream, OutputStream)}, so
     * this method should only be used when it is unknown if the far end will
     * be creating the streams in a cooperative order.
     */
    public static ObjectStreamPair createObjectStreamsAsync(
                InputStream rawIn,
                OutputStream rawOut
            ) throws IOException {

        OOSBuilder oosBuilder = new OOSBuilder(rawOut);
        OISBuilder oisBuilder = new OISBuilder(rawIn);

        ObjectOutputStream oos = oosBuilder.get(60000L);
        ObjectInputStream ois = oisBuilder.get(60000L);

        return new ObjectStreamPair(ois, oos);
    }

    /**
     * Creates an <tt>ObjectInputStream</tt> and an <tt>ObjectOutputStream</tt>
     * with buffering on the specified <tt>Socket</tt>'s streams.
     * The <tt>Object<u>Output</u>Stream</tt> is created
     * (and flushed) <i>first</i>, which is customary for the server-side to do.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectStreamsForServer(
     *     socket.getInputStream(), socket.getOutputStream());
     * </pre>
     */
    public static ObjectStreamPair createObjectStreamsForServer(Socket socket)
            throws IOException {

        return createObjectStreamsForServer(
            socket.getInputStream(), socket.getOutputStream());
    }

    /**
     * Creates an <tt>ObjectInputStream</tt> and an <tt>ObjectOutputStream</tt>
     * with buffering on the specified <tt>InputStream</tt> and
     * <tt>OutputStream</tt>. The <tt>Object<u>Input</u>Stream</tt> is created
     * <i>first</i>, which is customary for the client-side to do.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectStreamsForClient(
     *     socket.getInputStream(), socket.getOutputStream());
     * </pre>
     */
    public static ObjectStreamPair createObjectStreamsForClient(Socket socket)
            throws IOException {

        return createObjectStreamsForClient(
            socket.getInputStream(), socket.getOutputStream());
    }

    /**
     * Creates an <tt>ObjectInputStream</tt> and an <tt>ObjectOutputStream</tt>
     * with buffering on the specified <tt>InputStream</tt> and
     * <tt>OutputStream</tt>.
     * Two threads are spawned behind the scenes to attempt to create the
     * <tt>ObjectInputStream</tt> and <tt>ObjectOutputStream</tt> as the same
     * time. This prevents an inter-VM deadlock that can occur when the stream
     * creation order for the client-side and the server-side are not
     * coordinated. This method is <i>less</i> efficient that using either
     * {@link #createObjectStreamsForServer(Socket)} or
     * {@link #createObjectStreamsForClient(Socket)}, so
     * this method should only be used when it is unknown if the far end will
     * be creating the streams in a cooperative order.
     * Equivalent to:
     * <pre class="preshade">
     * return createObjectStreamsAsync(
     *     socket.getInputStream(), socket.getOutputStream());
     * </pre>
     */
    public static ObjectStreamPair createObjectStreamsAsync(Socket socket)
            throws IOException {

        return createObjectStreamsAsync(
            socket.getInputStream(), socket.getOutputStream());
    }

    /**
     * Closes the specified stream and suppresses any <tt>IOException</tt>'s
     * that may be thrown. There is no need to avoid passing a <tt>null</tt>
     * reference because if a <tt>null</tt> reference is passed to this
     * method, the request to close is silently ignored.
     */
    public static void closeQuietly(InputStream in) {
        try {
            if ( in != null ) {
                in.close();
            }
        } catch ( IOException x ) {
            // ignore
        }
    }

    /**
     * Closes the specified stream and suppresses any <tt>IOException</tt>'s
     * that may be thrown. There is no need to avoid passing a <tt>null</tt>
     * reference because if a <tt>null</tt> reference is passed to this
     * method, the request to close is silently ignored.
     */
    public static void closeQuietly(OutputStream out) {
        try {
            if ( out != null ) {
                out.close();
            }
        } catch ( IOException x ) {
            // ignore
        }
    }

    /**
     * Closes the <tt>OutputStream</tt> and the <tt>InputStream</tt>
     * [in that order].
     * Any <tt>IOException</tt>'s that may be thrown are silently suppressed.
     * There is no need to avoid passing <tt>null</tt> references
     * because if any <tt>null</tt> reference is passed to this
     * method, the request to close that particular item is silently ignored.
     * Equivalent to:
     * <pre class="preshade">
     * closeQuietly(out);
     * closeQuietly(in);
     * </pre>
     */
    public static void closeQuietly(InputStream in,
                                    OutputStream out) {

        closeQuietly(out);
        closeQuietly(in);
    }

    /**
     * Closes the specified stream and suppresses any <tt>IOException</tt>'s
     * that may be thrown. There is no need to avoid passing a <tt>null</tt>
     * reference because if a <tt>null</tt> reference is passed to this
     * method, the request to close is silently ignored.
     */
    public static void closeQuietly(Reader in) {
        try {
            if ( in != null ) {
                in.close();
            }
        } catch ( IOException x ) {
            // ignore
        }
    }

    /**
     * Closes the specified stream and suppresses any <tt>IOException</tt>'s
     * that may be thrown. There is no need to avoid passing a <tt>null</tt>
     * reference because if a <tt>null</tt> reference is passed to this
     * method, the request to close is silently ignored.
     */
    public static void closeQuietly(Writer out) {
        try {
            if ( out != null ) {
                out.close();
            }
        } catch ( IOException x ) {
            // ignore
        }
    }

    /**
     * Closes the specified <tt>Socket</tt> and suppresses any
     * <tt>IOException</tt>'s
     * that may be thrown. There is no need to avoid passing a <tt>null</tt>
     * reference because if a <tt>null</tt> reference is passed to this
     * method, the request to close is silently ignored.
     */
    public static void closeQuietly(Socket socket) {
        try {
            if ( socket != null ) {
                socket.close();
            }
        } catch ( IOException x ) {
            // ignore
        }
    }

    /**
     * Closes the <tt>OutputStream</tt>, <tt>InputStream</tt>, and
     * <tt>Socket</tt> [in that order].
     * Any <tt>IOException</tt>'s that may be thrown are silently suppressed.
     * There is no need to avoid passing <tt>null</tt> references
     * because if any <tt>null</tt> reference is passed to this
     * method, the request to close that particular item is silently ignored.
     * Equivalent to:
     * <pre class="preshade">
     * closeQuietly(out);
     * closeQuietly(in);
     * closeQuietly(socket);
     * </pre>
     */
    public static void closeQuietly(Socket socket,
                                    InputStream in,
                                    OutputStream out) {

        closeQuietly(out);
        closeQuietly(in);
        closeQuietly(socket);
    }

    /**
     * Closes the <tt>Writer</tt>, <tt>Reader</tt>, and
     * <tt>Socket</tt> [in that order].
     * Any <tt>IOException</tt>'s that may be thrown are silently suppressed.
     * There is no need to avoid passing <tt>null</tt> references
     * because if any <tt>null</tt> reference is passed to this
     * method, the request to close that particular item is silently ignored.
     * Equivalent to:
     * <pre class="preshade">
     * closeQuietly(out);
     * closeQuietly(in);
     * closeQuietly(socket);
     * </pre>
     */
    public static void closeQuietly(Socket socket,
                                    Reader in,
                                    Writer out) {

        closeQuietly(out);
        closeQuietly(in);
        closeQuietly(socket);
    }

    /**
     * Closes the specified <tt>ServerSocket</tt>
     * and suppresses any <tt>IOException</tt>'s
     * that may be thrown. There is no need to avoid passing a <tt>null</tt>
     * reference because if a <tt>null</tt> reference is passed to this
     * method, the request to close is silently ignored.
     */
    public static void closeQuietly(ServerSocket ss) {
        try {
            if ( ss != null ) {
                ss.close();
            }
        } catch ( IOException x ) {
            // ignore
        }
    }

    /**
     * An immutable holder of an <tt>ObjectInputStream</tt> and
     * <tt>ObjectOutputStream</tt> pair. Use the <tt>public final</tt>
     * member variables to retrieve the streams.
     */
    public static final class ObjectStreamPair {
        public final ObjectInputStream ois;
        public final ObjectOutputStream oos;

        private ObjectStreamPair(ObjectInputStream ois,
                                 ObjectOutputStream oos) {

            this.ois = ois;
            this.oos = oos;
        }
    } // class ObjectStreamPair

    private static class OOSBuilder implements Runnable {
        private OutputStream rawOut;
        private ObjectOutputStream oos;
        private IOException exception;
        private Thread internalThread;

        public OOSBuilder(OutputStream rawOut) {
            this.rawOut = rawOut;

            internalThread = new Thread(this, "OOSBuilder");
            internalThread.start();
        }

        public void run() {
            try {
                oos = createObjectOutputStream(rawOut);
            } catch ( IOException x ) {
                exception = x;
            } catch ( Exception x ) {
                exception = (IOException) new IOException().initCause(x);
            }
        }

        public ObjectOutputStream get(long msTimeout) throws IOException {
            try {
                internalThread.join(msTimeout);

                if ( internalThread.isAlive() ) {
                    throw new IOException(
                        "Timed out waiting for ObjectOutputStream");
                }

                if ( exception != null ) {
                    throw exception;
                }

                return oos;
            } catch ( InterruptedException x ) {
                throw new InterruptedIOException();
            }
        }
    } // class OOSBuilder

    private static class OISBuilder implements Runnable {
        private InputStream rawIn;
        private ObjectInputStream ois;
        private IOException exception;
        private Thread internalThread;

        public OISBuilder(InputStream rawIn) {
            this.rawIn = rawIn;

            internalThread = new Thread(this, "OISBuilder");
            internalThread.start();
        }

        public void run() {
            try {
                ois = createObjectInputStream(rawIn);
            } catch ( IOException x ) {
                exception = x;
            } catch ( Exception x ) {
                exception = (IOException) new IOException().initCause(x);
            }
        }

        public ObjectInputStream get(long msTimeout) throws IOException {
            try {
                internalThread.join(msTimeout);

                if ( internalThread.isAlive() ) {
                    throw new IOException(
                        "Timed out waiting for ObjectInputStream");
                }

                if ( exception != null ) {
                    throw exception;
                }

                return ois;
            } catch ( InterruptedException x ) {
                throw new InterruptedIOException();
            }
        }
    } // class OISBuilder


    private static class ResourceAssistant {
        private ResourceLocator[] locator;

        public ResourceAssistant() {
            locator = new ResourceLocator[2];
            locator[0] = new ClassLoaderResourceLocator(String.class);
            locator[1] = new ClassLoaderResourceLocator(IOTools.class);
        }

        public synchronized void addLocator(ResourceLocator rl) {
            locator = (ResourceLocator[])
                ObjectTools.changeArraySize(locator, locator.length + 1, rl);
        }

        /**
         * Removes the specified ResourceLocator from the list if it
         * exists.
         * @param rl locator to remove
         * @return <tt>true</tt> if the locator was found and removed,
         * <tt>false</tt> if the specified locator was not found (or
         * if null is passed in).
         */
        public synchronized boolean removeLocator(ResourceLocator rl) {
            if ( rl == null ) {
                return false;
            }

            ResourceLocator[] oldLocator = locator;

            locator = (ResourceLocator[])
                ObjectTools.removeFromArray(locator, rl);

            return locator.length != oldLocator.length;
        }

        private synchronized ResourceLocator[] getLocators() {
            return locator;
        }

        public InputStream getInputStreamFor(
                    String resourceLocation,
                    Class<?> searchStartPoint
                ) throws FileNotFoundException, IOException {

            if ( StringTools.isEmpty(resourceLocation) ) {
                throw new FileNotFoundException("Unable to load resource " +
                    "because resourceLocation is empty");
            }

            try {
                String simpleLoc = StringTools.trim(resourceLocation);
                InputStream in = getInputStream(simpleLoc, searchStartPoint);

                if ( in == null ) {
                    in = getInputStream("/" + simpleLoc, searchStartPoint);
                }

                if ( in == null ) {
                    throw new FileNotFoundException(
                        "Unable to load resource '" + resourceLocation + "'");
                } else {
                    return in;
                }
            } catch ( IOException x ) {
                throw x; // just re-throw
            } catch ( Exception x ) {
                throw (IOException) new IOException(
                    "Unable to load resource '" +
                    resourceLocation + "'").initCause(x);
            }
        }

        private InputStream getInputStream(String resourceLoc,
                                           Class<?> searchStartPoint) {

            InputStream in = null;

            if ( searchStartPoint != null ) {
                in = searchStartPoint.getResourceAsStream(resourceLoc);
            }

            ResourceLocator[] loc = resourceAssistant.getLocators();
            for ( int i = loc.length - 1; (in == null) && (i >= 0); i-- ) {
                in = loc[i].getInputStreamForResource(resourceLoc);
            }

            return in;
        }

        public URL getUrlFor(String resourceLocation,
                             Class<?> searchStartPoint
                ) throws FileNotFoundException, IOException {

            if ( StringTools.isEmpty(resourceLocation) ) {
                throw new FileNotFoundException("Unable to load resource " +
                        "because resourceLocation is empty");
            }

            try {
                String simpleLoc = StringTools.trim(resourceLocation);
                URL url = getUrl(simpleLoc, searchStartPoint);

                if ( url == null ) {
                    url = getUrl("/" + simpleLoc, searchStartPoint);
                }

                if ( url == null ) {
                    throw new FileNotFoundException(
                        "Unable to load resource '" + resourceLocation + "'");
                } else {
                    return url;
                }
            } catch ( IOException x ) {
                throw x; // just re-throw
            } catch ( Exception x ) {
                throw (IOException) new IOException(
                    "Unable to load resource '" +
                    resourceLocation + "'").initCause(x);
            }
        }

        private URL getUrl(String resourceLoc, Class<?> searchStartPoint) {
            URL url = null;

            if ( searchStartPoint != null ) {
                url = searchStartPoint.getResource(resourceLoc);
            }

            ResourceLocator[] loc = resourceAssistant.getLocators();
            for ( int i = loc.length - 1; (url == null) && (i >= 0); i-- ) {
                url = loc[i].getUrlForResource(resourceLoc);
            }

            return url;
        }
    } // class ResourceAssistant

    /**
     * A <tt>ResourceLocator</tt> is used to assist in finding and opening
     * <tt>InputStream</tt>'s and <tt>URL</tt>'s for an application based
     * on the resources name. One or more <tt>ResourceLocator</tt>'s can
     * be added to the VM-wide way that {@link IOTools} locates resources.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static interface ResourceLocator {
        /**
         * Returns an <tt>InputStream</tt> that gets its bytes from the
         * specified resource. A return value of <tt>null</tt> indicates
         * that the resource could not be found (do not throw an exception
         * as the search may continue on to other locators). A return
         * value of <tt>null</tt> can also be used to indicate that this
         * particular locator can not supply the resource in the desired
         * format (for example, it can not be returned as a {@link URL},
         * but it might be able to be returned as an {@link InputStream}).
         *
         * @param resourceLocation the name of the resource to find.
         * @return the <tt>InputStream</tt> or <tt>null</tt> if the specified
         * resource could not be found by this locator.
         */
        InputStream getInputStreamForResource(String resourceLocation);

        /**
         * Returns a <tt>URL</tt> that gets its bytes from the
         * specified resource. A return value of <tt>null</tt> indicates
         * that the resource could not be found (do not throw an exception
         * as the search may continue on to other locators). A return
         * value of <tt>null</tt> can also be used to indicate that this
         * particular locator can not supply the resource in the desired
         * format (for example, it can not be returned as an {@link URL},
         * but it might be able to be returned as an {@link InputStream}).
         *
         * @param resourceLocation the name of the resource to find.
         * @return the <tt>URL</tt> or <tt>null</tt> if the specified
         * resource could not be found by this locator.
         */
        URL getUrlForResource(String resourceLocation);
    } // class ResourceLocator

    /**
     * An implementation of {@link ResourceLocator} that uses the specified
     * <tt>Class</tt> to try to locate resources.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class ClassLoaderResourceLocator implements ResourceLocator {
        private final Class<?> searchStartPoint;

        public ClassLoaderResourceLocator(Class<?> searchStartPoint) {
            this.searchStartPoint = searchStartPoint;
        }

        public InputStream getInputStreamForResource(String resourceLocation) {
            InputStream in =
                searchStartPoint.getResourceAsStream(resourceLocation);

            if ( in == null ) {
                in = getStreamFromUrl(getUrlForResource(resourceLocation));
            }

            return in;
        }

        public URL getUrlForResource(String resourceLocation) {
            return searchStartPoint.getResource(resourceLocation);
        }
    } // class ClassLoaderResourceLocator

    /**
     * An implementation of {@link ResourceLocator} that uses the specified
     * <tt>HttpServlet</tt> to try to locate resources. Servlets make
     * available an additional mechanism beyond what a normal classloader
     * can do.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class ServletResourceLocator implements ResourceLocator {
        private final HttpServlet servlet;
        private final ServletContext servletContext;

        public ServletResourceLocator(HttpServlet servlet) {
            this.servlet = servlet;
            this.servletContext = servlet.getServletContext();
        }

        public InputStream getInputStreamForResource(String resourceLocation) {
            InputStream in =
                servletContext.getResourceAsStream(resourceLocation);

            if ( in == null ) {
                try {
                    in = getStreamFromUrl(
                        servletContext.getResource(resourceLocation));
                } catch ( MalformedURLException x ) {
                    // ignore
                }
            }

            if ( in == null ) {
                in = servlet.getClass().getResourceAsStream(resourceLocation);
            }

            if ( in == null ) {
                in = getStreamFromUrl(
                    servlet.getClass().getResource(resourceLocation));
            }

            return in;
        }

        public URL getUrlForResource(String resourceLocation) {
            URL url = null;

            try {
                url = servletContext.getResource(resourceLocation);
            } catch ( MalformedURLException x ) {
                url = null;
            }

            if ( url == null ) {
                url = servlet.getClass().getResource(resourceLocation);
            }

            return url;
        }
    } // class ServletResourceLocator

    /**
     * An implementation of {@link ResourceLocator} that uses the specified
     * base directory to try to locate resources. Requested resources are
     * assumed to be under the specified base directory or sub-directories
     * of the base directory.
     * <p>
     * A moderate attempt is made to avoid a resource requesting a file that
     * is not under the base directory. For example, any leading "/" or
     * ".." from a resource name is stripped. However, there is no guarantee
     * that this is secure. If you can't trust the code requesting
     * resource locations, then you should NOT use this locator.
     *
     * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
     */
    public static class BaseDirectoryResourceLocator
            implements ResourceLocator {

        private File baseDirectory;

        public BaseDirectoryResourceLocator(File baseDirectory)
                throws IOException {

            if ( baseDirectory == null ) {
                throw new IOException("baseDirectory is null");
            }

            if ( baseDirectory.exists() == false ) {
                throw new IOException(
                    StringTools.quoteWrap(baseDirectory.getPath()) +
                    " does not exist");
            }

            if ( baseDirectory.isDirectory() == false ) {
                throw new IOException(
                    StringTools.quoteWrap(baseDirectory.getPath()) +
                    " is not a directory");
            }

            this.baseDirectory = baseDirectory;
        }

        public BaseDirectoryResourceLocator(String baseDirectoryName)
                throws IOException {

            this(new File(emptyCheck(baseDirectoryName)));
        }

        private static String emptyCheck(String baseDirectoryName)
                throws IOException {

            if ( StringTools.isEmpty(baseDirectoryName) ) {
                throw new IOException("baseDirectoryName is empty");
            } else {
                return baseDirectoryName;
            }
        }

        private File getFile(String resourceLocation) {
            resourceLocation = StringTools.trim(resourceLocation);

            int pos = 0;
            char[] ch = resourceLocation.toCharArray();
            while ( pos < ch.length ) {
                if ( ch[pos] == '/' || ch[pos] == '\\' || ch[pos] == '.' ) {
                    pos++;
                } else {
                    break;
                }
            }

            if ( pos > 0 ) {
                if ( pos >= ch.length ) {
                    return null; // no valid characters left
                } else {
                    resourceLocation = resourceLocation.substring(pos);
                }
            }

            if ( StringTools.isEmpty(resourceLocation) ) {
                return null; // no valid characters left
            }

            File file = new File(baseDirectory, resourceLocation);
            if ( file.exists() && file.isFile() && file.canRead() ) {
                return file;
            } else {
                return null;
            }
        }

        public InputStream getInputStreamForResource(String resourceLocation) {
            File file = getFile(resourceLocation);
            if ( file == null ) {
                return null;
            }

            try {
                return new BufferedInputStream(new FileInputStream(file));
            } catch ( FileNotFoundException x ) {
                return null;
            }
        }

        public URL getUrlForResource(String resourceLocation) {
            File file = getFile(resourceLocation);
            if ( file == null ) {
                return null;
            }

            try {
                return file.toURI().toURL();
            } catch ( MalformedURLException x ) {
                return null;
            }
        }
    } // class BaseDirectoryResourceLocator
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.