package com.programix.io;

import java.io.*;

/**
 * Thrown to indicate that either the stream was closed before the request,
 * or that the stream was closed while waiting for the request to complete.
 *   
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class ClosedStreamException extends IOException {
    /**
     * The message of this exception indicates that the stream has
     * been closed at some time in the past.
     */
    public ClosedStreamException() {
        super("Unable to complete request, stream is closed");
    }
    
    /** 
     * Uses the message of the zero-arg constructor, but also chains
     * the specified exception as the cause of this exception.
     */
    public ClosedStreamException(Throwable cause) {
        this();
        initCause(cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.