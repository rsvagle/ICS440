package com.programix.io;

import java.io.*;
import java.util.zip.*;

import com.programix.util.*;

/**
 * Handy tools for doing common object serialization tasks.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class SerializationTools extends Object {
	// no instances
	private SerializationTools() {
	}

	public static ByteArrayOutputStream toBAOS(Object obj, boolean compress)
			throws SerializationException {

		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream(100);

			ObjectOutputStream oos = null;
			if ( compress ) {
				Deflater def = new Deflater(Deflater.BEST_COMPRESSION, true);
				oos = new ObjectOutputStream(
					new DeflaterOutputStream(baos, def));
			} else {
				oos = new ObjectOutputStream(baos);
			}
			oos.writeObject(obj);
			oos.flush();
			oos.close();

			return baos;
		} catch ( Exception x ) {
			throw new SerializationException(x);
		}
	}

    /**
     * Serializes to a <tt>ByteArrayOutputStream</tt> without doing any
     * compression.
     */
	public static ByteArrayOutputStream toBAOS(Object obj)
			throws SerializationException {

		return toBAOS(obj, false);
	}

    /**
     * Serializes without doing any compression.
     */
	public static byte[] toByteArray(Object obj) throws SerializationException {
		return toBAOS(obj, false).toByteArray();
	}

	public static Object fromByteArray(byte[] data)
			throws SerializationException {

		return fromInputStream(
			new ByteArrayInputStream(data), Object.class, false);
	}

	public static <T> T fromInputStream(
				InputStream rawIn,
				Class<T> targetType,
				boolean compressed
			) throws SerializationException {

		ObjectInputStream ois = null;

        try {
			if ( compressed ) {
				Inflater inf = new Inflater(true);
				ois = new ObjectInputStream(new InflaterInputStream(
					new BufferedInputStream(rawIn), inf));
			} else {
				ois = new ObjectInputStream(new BufferedInputStream(rawIn));
			}

			return ObjectTools.typeCheck(ois.readObject(), targetType);
		} catch ( Exception x ) {
			throw new SerializationException(x);
		} finally {
            IOTools.closeQuietly(ois);
		}
	}

    /**
     * Deserializes, source bytes do not need to be decompressed.
     */
	public static <T> T fromInputStream(
				InputStream rawIn,
				Class<T> targetType
			) throws SerializationException {

		return fromInputStream(rawIn, targetType, false);
	}

	/**
	 * Make a deep "clone" by serializing and then deserializing a new instance.
	 */
	@SuppressWarnings("unchecked")
    public static <T> T makeClone(T obj) throws SerializationException {
		return (T) fromByteArray(toByteArray(obj));
	}

    /**
     * Serializes the payload and potentially compresses the resulting bytes.
     *
     * @param payload the object to be serialized.
     * @param compressionThreshold if the serialized object's byte count is
     * below the threshold, no compression will be done. If at or above,
     * then compression is performed.
     *
     * @return the wrapper with the bytes for the serialized object and
     * an indicator as to whether compressed was used or not.
     * @throws SerializationTools.SerializationException if there are problems
     * serializing the payload
     */
    public static TransferWrapper wrap(Object payload, int compressionThreshold)
            throws SerializationTools.SerializationException {

        ObjectOutputStream oos = null;
        OutputStream out = null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            oos = new ObjectOutputStream(baos);
            oos.writeObject(payload);
            oos.flush();
            oos.close();
            oos = null;

            TransferWrapper tw = new TransferWrapper();

            if ( baos.size() < compressionThreshold ) {
                tw.setCompressed(false);
                tw.setPayload(baos.toByteArray());
                return tw;
            }

            byte[] uncompressedData = baos.toByteArray();
            baos.reset(); // so that we can recycle it now

            Deflater def = new Deflater(Deflater.BEST_COMPRESSION, true);
            out = new DeflaterOutputStream(baos, def);
            out.write(uncompressedData);
            out.flush();
            out.close();
            out = null;

            if ( baos.size() >= uncompressedData.length ) {
                tw.setCompressed(false);
                tw.setPayload(uncompressedData);
            } else {
                tw.setCompressed(true);
                tw.setPayload(baos.toByteArray());
            }

            return tw;
        } catch ( Exception x ) {
            throw new SerializationException(x);
        } finally {
            // be sure:
            IOTools.closeQuietly(oos);
            IOTools.closeQuietly(out);
        }
    }

    /**
     * Serializes the payload and potentially compresses the resulting bytes.
     * Compression is done if the resulting number of serialized bytes is
     * at least <tt>512</tt>.
     *
     * @param payload the object to be serialized.
     *
     * @return the wrapper with the bytes for the serialized object and
     * an indicator as to whether compressed was used or not.
     * @throws SerializationTools.SerializationException if there are problems
     * serializing the payload
     */
    public static TransferWrapper wrap(Object payload)
            throws SerializationTools.SerializationException {

        return wrap(payload, 512);
    }

    /**
     * Deserializes the byte representation of an object inside the wrapper.
     *
     * @param tw the source of the bytes and the compression setting
     * @param targetType if <tt>null</tt>, then no checking is done and
     * any type of object is returned (including <tt>null</tt>). If not
     * <tt>null</tt>, then the deserialized object must not be null and must
     * be of the specified type (or a subtype of the specified type).
     *
     * @return the deserialized object.
     *
     * @throws SerializationTools.SerializationException if there are problems
     * during deserialization, if the specified targetType is not matched, or
     * is a targetType is specified, but the deserialized object is null.
     */
    public static <T> T unwrap(TransferWrapper tw, Class<T> targetType)
            throws SerializationTools.SerializationException {

        ObjectInputStream ois = null;
        try {
            if ( tw.isCompressed() ) {
                Inflater inf = new Inflater(true);
                ois = new ObjectInputStream(new InflaterInputStream(
                    new ByteArrayInputStream(tw.getPayload()), inf));
            } else {
                ois = new ObjectInputStream(
                    new ByteArrayInputStream(tw.getPayload()));
            }

            return ObjectTools.typeCheck(ois.readObject(), targetType);
        } catch ( Exception x ) {
            throw new SerializationException(x);
        } finally {
            IOTools.closeQuietly(ois);
        }
    }

    public static Object unwrap(TransferWrapper tw)
            throws SerializationTools.SerializationException {

        return unwrap(tw, null);
    }

	/**
	 * Used to indicate that something went wrong in one of the
	 * SerializationTools functions. This is a RuntimeException, so it can
	 * be ignored (try/catch no required) in code that "knows what is
	 * coming".
	 */
	public static class SerializationException extends RuntimeException {
		public SerializationException(String msg, Throwable cause) {
			super(msg, cause);
		}

		public SerializationException(Throwable cause) {
            super(cause);
        }

        public SerializationException(String msg) {
			super(msg);
		}
	} // inner SerializationException
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.