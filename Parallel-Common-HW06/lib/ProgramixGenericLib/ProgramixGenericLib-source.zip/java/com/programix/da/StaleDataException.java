package com.programix.da;

/**
 * Used with Optimistic Concurrency Control to indicate that there has been an
 * attempt to update a record with a <i>stale </i> version.
 * <p>
 * For example, assume that a shipping address record with an "update count" of
 * 5 has been read by User A. While User A is editing this data, User B also
 * reads version 5, edits the data, and then updates the record in the 
 * data store (and consequently the "update count" gets changed to 6). Now,
 * when User A attempts to save his/her version of the record, the save fails
 * by throwing a <tt>StaleDataException</tt> where {@link #getTarget()}
 * returns something like <tt>"shipping_address"</tt>, 
 * {@link #getExpectedCount()} returns <tt>5</tt>, and   
 * {@link #getActualCount()} returns <tt>6</tt>.
 * The textual message for <tt>StaleDataException</tt> also includes those
 * three pieces of data.    
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde </a>
 */
public class StaleDataException extends Exception {
    private String target;
    private int expectedCount;
    private int actualCount;

    public StaleDataException(String target, 
                              int expectedCount, 
                              int actualCount) {
        
        super("Data is stale for " + target + 
            ", expectedCount=" + expectedCount + 
            ", actualCount=" + actualCount);
        
        this.target= target;
        this.expectedCount = expectedCount;
        this.actualCount = actualCount;
    }
    
    public StaleDataException() {
        super();
    }

    public StaleDataException(String message) {
        super(message);
    }

    public StaleDataException(String message, Throwable cause) {
        super(message, cause);
    }

    public StaleDataException(Throwable cause) {
        super(cause);
    }

    public String getTarget() {
        return target;
    }

    public int getExpectedCount() {
        return expectedCount;
    }

    public int getActualCount() {
        return actualCount;
    }
}// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.