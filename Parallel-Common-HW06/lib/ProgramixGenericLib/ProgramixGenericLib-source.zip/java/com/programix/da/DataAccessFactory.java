package com.programix.da;

import java.io.*;
import java.net.*;

import com.programix.value.*;

/**
 * Used to construct and initialize instances of {@link DataAccess}
 * using reflection.
 * <p>Common usage is (where <code>CustomerDataAccess</code> is an interface
 * that extends the {@link DataAccess} interface):
 * <pre class="preshade">
 * {@link ValueMap} config = //...
 * CustomerDataAccess cda = (CustomerDataAccess)
 *     DataAccessFactory.{@link
 *     #create(ValueMap, Class) create}(config, CustomerDataAccess.class);</pre>
 * or
 * <pre class="preshade">
 * String filename = //...
 * CustomerDataAccess cda = (CustomerDataAccess)
 *     DataAccessFactory.{@link
 *     #createFromFile(String, Class) create}(filename, CustomerDataAccess.class);</pre>
 *
 * The configuration {@link ValueMap} passed in must contain the
 * class name of the class to be instantiated stored under the key
 * {@link #DATA_ACCESS_CLASSNAME_KEY}. Other key/value pairs in the map
 * are populated with whatever the specific <tt>DataAccess</tt>
 * implementation needs for initialization.
 *
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DataAccessFactory extends Object {
	/**
	 * The reserved key that retrieves the fully-qualified name
	 * (as a <tt>String</tt>)
	 * of the <tt>DataAccess</tt> implementation class that will
	 * be instantiated via reflection.
	 * <p>The value of this key is always:
	 * <pre class="preshade">
	 * data.access.classname
	 * </pre>
	 */
	public static final String DATA_ACCESS_CLASSNAME_KEY =
			"data.access.classname"; // keep value in sync with api docs!!!

	// no instances
	private DataAccessFactory() {
	}

	/**
	 * Constructs an instance of the {@link DataAccess} implementation
	 * specified in the configuration. One required key
	 * that must always be present is: {@link #DATA_ACCESS_CLASSNAME_KEY}
	 * with a <tt>String</tt> value which is the full class name.
	 * <p>
     * Immediately after the zero-argument constructor is invoked,
	 * the {@link DataAccess#init init(ValueMap conf)} of
     * <tt>DataAccess</tt> is invoked to initialize the configuration.
	 * <p>
     * If the <tt>targetType</tt> is not <tt>null</tt>, then an
	 * additional check is done to ensure that the constructed object
	 * can be type cast into that type (failures throw a
	 * <tt>DataAccessException</tt> instead of a <tt>ClassCastException</tt>).
	 *
	 * @param config key/value mapping with everything that is needed to
	 * initialize the instance of <tt>DataAccess</tt>.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>DataAccessException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception DataAccessException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
	 */
	@SuppressWarnings("unchecked")
    public static <T extends DataAccess> T create(ValueMap config,
	                                              Class<T> targetType)
            throws DataAccessException {

		DataAccess da = null;

		try {
			String className = config.getString(DATA_ACCESS_CLASSNAME_KEY);

			Class<?> c = Class.forName(className);
			da = (DataAccess) c.newInstance(); // zero-arg constructor
		} catch ( Exception x ) {
			throw new DataAccessException(
				"Failed to create DataAccess implementation", x);
		}

		if ( (targetType != null ) && (targetType.isInstance(da) == false) ) {
			throw new DataAccessException("Constructed object's type (" +
				da.getClass().getName() + ") can't be cast into the " +
				"target type (" + targetType.getName() + ")");
		}

		da.init(config); // might throw DataAccessException too...

		return (T) da;
	}

	/**
	 * Create a <tt>DataAccess</tt> instance using a <tt>Reader</tt>
	 * whose data is in the format described by {@link ValueMap}
     * (nearly identical to the format for a <code>Properties</code> file).
	 * Internally, the stream <i>will</i> be buffered and the stream
	 * <i>will</i> be closed.
	 *
	 * @param rawIn a stream whose contents can be loaded into
	 * a <tt>ValueMap</tt> with everything that is needed to
	 * initialize the instance of <tt>DataAccess</tt>.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>DataAccessException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception DataAccessException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
	 */
	public static <T extends DataAccess> T create(Reader rawIn,
	                                              Class<T> targetType)
			throws DataAccessException {

		try {
            return create(ValueMap.createFrom(rawIn), targetType);
        } catch ( ValueMapException x ) {
            throw new DataAccessException(
                "Failed to create DataAccess implementation", x);
        }
	}

    /**
	 * Create a <tt>DataAccess</tt> instance using an <tt>InputStream</tt>
	 * whose data is in the format described by {@link ValueMap}
     * (nearly identical to the format for a <code>Properties</code> file).
	 * Internally, the stream <i>will</i> be buffered and the stream
	 * <i>will</i> be closed.
	 *
	 * @param rawIn a stream whose contents can be loaded into
	 * a <tt>ValueMap</tt> with everything that is needed to
	 * initialize the instance of <tt>DataAccess</tt>.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>DataAccessException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception DataAccessException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)

	 */
	public static <T extends DataAccess> T create(InputStream rawIn,
	                                              Class<T> targetType)
			throws DataAccessException {

		try {
            return create(ValueMap.createFrom(rawIn), targetType);
        } catch ( ValueMapException x ) {
            throw new DataAccessException(
                "Failed to create DataAccess implementation", x);
        }
	}

    /**
     * Create a <tt>DataAccess</tt> instance using an <tt>File</tt>
     * whose data is in the format described by {@link ValueMap}
     * (nearly identical to the format for a <code>Properties</code> file).
     *
     * @param file file with key/value mapping with everything that
     *            is needed to initialize the instance of <tt>DataAccess</tt>.
     * @param targetType the class type that this instance is expected to be
     *            cast into. Use <tt>null</tt> to skip this check. If not
     *            <tt>null</tt> and the type does not match what is
     *            constructed, then a <tt>DataAccessException</tt> is thrown.
     *
     * @return the constructed and initialized instance.
     *
     * @exception DataAccessException if instance can not be constructed and
     *                initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(URL, Class)

     */
    public static <T extends DataAccess> T create(File file,
                                                  Class<T> targetType)
            throws DataAccessException {

        try {
            return create(ValueMap.createFrom(file), targetType);
        } catch ( ValueMapException x ) {
            throw new DataAccessException(
                "Failed to create DataAccess implementation", x);
        }
    }

    /**
     * Create a <tt>DataAccess</tt> instance using the specified
     * <tt>filename</tt> whose data is in the format described by
     * {@link ValueMap}(nearly identical to the format for a
     * <code>Properties</code> file).
     *
     * @param filename file with key/value mapping with everything that is
     *            needed to initialize the instance of <tt>DataAccess</tt>.
     * @param targetType the class type that this instance is expected to be
     *            cast into. Use <tt>null</tt> to skip this check. If not
     *            <tt>null</tt> and the type does not match what is
     *            constructed, then a <tt>DataAccessException</tt> is thrown.
     *
     * @return the constructed and initialized instance.
     *
     * @exception DataAccessException if instance can not be constructed and
     *                initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
     */
    public static <T extends DataAccess> T createFromFile(String filename,
                                                          Class<T> targetType)
            throws DataAccessException {

        try {
            return create(ValueMap.createFromFile(filename), targetType);
        } catch ( ValueMapException x ) {
            throw new DataAccessException(
                "Failed to create DataAccess implementation", x);
        }
    }

	/**
     * Create a <tt>DataAccess</tt> instance using the specified
     * <tt>URL</tt> whose data is in the format described by
     * {@link ValueMap}(nearly identical to the format for a
     * <code>Properties</code> file).

	 * @param propertiesURL a URL whose contents can be loaded into
	 * a <tt>ValueMap</tt> with everything that is needed to
	 * initialize the instance of <tt>DataAccess</tt>.
	 * @param targetType the class type that this instance is expected
	 * to be cast into. Use <tt>null</tt> to skip this check. If not
	 * <tt>null</tt> and the type does not match what is constructed,
	 * then a <tt>DataAccessException</tt> is thrown.
	 *
	 * @return the constructed and initialized instance.
	 *
	 * @exception DataAccessException if instance can not be constructed
	 * and initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #createFromFile(String, Class)
     * @see #create(File, Class)
	 */
	public static <T extends DataAccess> T create(URL propertiesURL,
	                                              Class<T> targetType)
			throws DataAccessException {

        try {
            return create(ValueMap.createFrom(propertiesURL), targetType);
        } catch ( ValueMapException x ) {
            throw new DataAccessException(
                "Failed to create DataAccess implementation", x);
        }
	}

    /**
     * Create a <tt>DataAccess</tt> instance using the specified
     * <tt>resourceLocation</tt> whose data is in the format described by
     * {@link ValueMap}(nearly identical to the format for a
     * <code>Properties</code> file).
     *
     * @param resourceLocation resource with key/value mapping with
     *            everything that is
     *            needed to initialize the instance of <tt>DataAccess</tt>.
     * @param targetType the class type that this instance is expected to be
     *            cast into. Use <tt>null</tt> to skip this check. If not
     *            <tt>null</tt> and the type does not match what is
     *            constructed, then a <tt>DataAccessException</tt> is thrown.
     *
     * @return the constructed and initialized instance.
     *
     * @exception DataAccessException if instance can not be constructed and
     *                initialized.
     *
     * @see #create(ValueMap, Class)
     * @see #create(Reader, Class)
     * @see #create(InputStream, Class)
     * @see #create(File, Class)
     * @see #create(URL, Class)
     */
    public static <T extends DataAccess> T createFromResource(
                String resourceLocation,
                Class<T> targetType) throws DataAccessException {

        try {
            return create(
                ValueMap.createFromResource(resourceLocation), targetType);
        } catch ( ValueMapException x ) {
            throw new DataAccessException(
                "Failed to create DataAccess implementation", x);
        }
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.