package com.programix.da;

import com.programix.value.*;

/**
 * Used to implementation the very useful "Data Access Layer" abstraction.
 * <p>
 * This interface is extended to provide a useful collection of methods. Each
 * method should perform a 'unit of work'. Each method should declare that it
 * throws {@link DataAccessException} to indicate an underlying problem (such
 * as an {@link java.io.IOException}, {@link java.sql.SQLException}, etc. 
 * Application-specific
 * exceptions can be thrown in addition to <tt>DataAccessException</tt>.
 * <p>
 * {@link DataAccessFactory} has many <code>create</code> methods to automate
 * the task of instantiating and initializing an instance.
 * <p>
 * NOTE: all implementations must have a public zero-argument constructor.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public interface DataAccess {
    
    /**
     * Called once just after construction to allow the implementation to
     * setup everything required to run. This method is called before any
     * other methods on this interface. If this method returns without
     * throwing an exception, access to the other methods is opened up.
     * 
     * @param config all the settings needed to complete initialization
     * @throws DataAccessException if initialization could not complete,
     * possibly chained to an underlying cause.
     */
    void init(ValueMap config) throws DataAccessException;
    
    
    /**
     * Called to 'shutdown' the instance. No other methods should be called
     * after this method. Calling other methods after calling this method
     * results in undefined behavior. Calling <tt>close()</tt> more than
     * once must be allowed and <tt>close()</tt> does not complain. Also note
     * that <tt>close()</tt> never throws <i>any</i> exceptions&mdash;it just
     * makes its best effort of close down everything.
     */
    void close();
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.