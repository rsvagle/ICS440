package com.programix.da;

public class NotFoundException extends Exception {
    public NotFoundException(String message) {
        super(message);
    }

    public NotFoundException() {
        super();
    }
    
    public NotFoundException(String target, Object id) {
        this("No '" + target + "' found for id=" + id);
    }

    public NotFoundException(String target, int id) {
        this(target, String.valueOf(id));
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.