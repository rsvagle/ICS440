package com.programix.da;

/**
 * Thrown to indicate a technical problem with the 'Data Access Layer' inner
 * workings. For example, instead of throwing an {@link java.sql.SQLException}
 * if there were problems talking to the database, chain it to a 
 * <code>DataAccessException</code> and throw that instead. However, if there 
 * was another kind of problem (like a required value missing) and if the
 * application <i>was</i> able to communicate with the network, file, database,
 * remote object, or whatever, <code>DataAccessExcepion</code> should NOT be
 * used&mdash;use an application-specific exception instead.
 * <code>DataAccessException</code> means a part of the subsystem failed.
 * 
 * @author <a href="http://www.programix.com/staff/paul.html">Paul Hyde</a>
 */
public class DataAccessException extends Exception {
    public DataAccessException() {
        super();
    }

    public DataAccessException(String message) {
        super(message);
    }

    public DataAccessException(Throwable cause) {
        super(cause);
    }

    public DataAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}
// Copyright (c) 2002-2012, Programix Incorporated. See license for the
// details on use and modification.